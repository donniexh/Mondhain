-- Mondhain – Gewand Paladin (Zusatz-Addon)
-- Meldet bei Mondhain eine eigene Farbstimmung mit eigenen Bildern an.
-- Paladine bekommen sie automatisch, solange sie keine Farbstimmung selbst
-- gewählt haben; alle anderen können sie im Menü unter „Farbstimmung“ wählen.

local P = "Interface\\AddOns\\Mondhain_Paladin\\media\\"

if not (MondhainAPI and MondhainAPI.RegisterPalette) then
    print("|cffd4a017Mondhain – Gewand Paladin:|r braucht Mondhain 0.40.0 oder neuer.")
    return
end
if (MondhainAPI.version or 0) < 40 then
    print("|cffd4a017Mondhain – Gewand Paladin:|r Mondhain ist zu alt für die Bauweise Stein (ab 0.40.0) – nur Farben aktiv.")
end

MondhainAPI.RegisterPalette("paladin", {
    label = "Paladin (Gewand)",
    class = "PALADIN",
    strand = P .. "balken",                 -- Marmorbalken mit Goldleisten statt Ast
    bark = P .. "stein",                    -- Kathedralenstein statt Rinde
    fill = P .. "balken_fuell",             -- Marmor für Zwickel und Symbolrahmen
    knot = P .. "meilenstein_zu",           -- EP-Meilenstein: Goldbuckel mit Saphir …
    knotRound = true,
    bloom = P .. "meilenstein_auf",         -- … der beim Erreichen aufstrahlt
    liane = P .. "lichtband",               -- goldenes Lichtband statt grüner Liane
    lianeStrip = P .. "lichtband",
    lianeRep = P .. "lichtband_blau",       -- Ruf: silberblaues Band
    leaves = { P .. "laub", P .. "laub", P .. "laub" },
    cast = { 0.520, 0.400, 0.140, bot = { 0.200, 0.140, 0.050 } },
    accent = { 1.00, 0.82, 0.38 },
    -- Kampfanzeige (Ben 26.11. 08:15): Goldleisten wachsen statt Ranken, an den
    -- Enden das gewählte Mittelstück; Gold rein, Silberblau raus
    -- Stufenaufstieg: Zeichen je Talentbaum (Heilig / Schutz / Vergeltung)
    levelUp = { emblems = { P .. "wappen_libram", P .. "wappen_hand", P .. "wappen_hammer" } },
    -- Stufenaufstieg: Wappen je Talentbaum (1 Heilig, 2 Schutz, 3 Vergeltung)
    levelUp = { P .. "wappen_libram", P .. "wappen_hand", P .. "wappen_hammer", default = P .. "wappen_hand" },
    combat = {
        rail = P .. "goldleiste", railV = { 0, 1 }, railH = 10,
        ends = "crest", endSize = 34, noFlip = true,
        colorIn = { 1.00, 0.84, 0.42 }, colorOut = { 0.78, 0.86, 1.00 },
    },   -- Überschriften (z. B. Questzone) in Gold statt Druiden-Orange
    -- Bauweise Stein (Ben 25.11.: „Ecken und Kanten“, A + B + C): gerade Stufen mit
    -- Schrägen statt gewachsenem Ast, Säulen in den Lücken, Goldleiste obenauf,
    -- Zinnen über den Leisten, Banner an den Säulen neben den Leisten, Lichtscheibe
    arch = {
        pillar = P .. "saeule", cap = P .. "kapitell", merlon = P .. "zinne",
        banner = P .. "banner", rail = P .. "goldleiste",
        -- Maße aus Bens Gemini-Bildern: Kapitell unten 35 % so breit wie oben,
        -- Seitenverhältnisse von Kapitell, Zinne, Banner
        capNeck = 0.353, capAspect = 1.98, merlonAspect = 1.08, bannerAspect = 0.254,
        merlonW = 1.5, merlonH = 0.85, merlonGap = 0.7,   -- breitere Zinnen (Ben 26.11.)
        -- EP: heiliges Großschwert, die Klinge füllt sich mit Licht (Ben 19:09);
        -- Ruf: Rosette aus Buntglas (Ben 19:02). Ohne sword = zehn Lanzettfenster
        glass = {
            sword = P .. "schwert", swordHilt = 0.40, swordAspect = 4, swordH = 4.5, swordStretch = 1.7, swordSink = 0.22,
            -- Panzerhand am Heft (Ben 26.11. 05:38)
            swordHand = P .. "hand", swordHandH = 1.15, swordHandU = 0.167, swordGripV = 0.51,
            swordHandGripV = 0.17, swordHandGripX = 0.562, swordHandAspect = 0.5,
            window = P .. "glas_fenster", frame = P .. "glas_rahmen",
            rose = P .. "glas_rose", roseSector = P .. "glas_rose_sektor", roseFrame = P .. "glas_rose_rahmen",
            count = 10, w = 1.2, aspect = 2, roseSize = 2.6,
        },
        -- Mittelstück (Ben 18:54, alle drei; im Menü „Ast“ umschaltbar)
        crests = {
            { key = "hand",   label = "Silberne Hand", tex = P .. "wappen_hand",   size = 2.6 },
            { key = "hammer", label = "Kriegshammer",  tex = P .. "wappen_hammer", size = 2.8 },
            { key = "libram", label = "Libram",        tex = P .. "wappen_libram", size = 2.5 },
        },
    },
    branch = { 0.92, 0.90, 0.86 }, trunk = { 0.50, 0.49, 0.47 }, orn = { 1, 1, 1 }, vine = { 1, 1, 1 },
})
