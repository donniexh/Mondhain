-- Greifzeit: summiert Zeit und Gold auf Flugrouten (Greif, Hippogryph, Fledermaus ...)
local f = CreateFrame("Frame")
local db, char
local flying, lastTick, ticker = false, 0, nil
local currentFlight, sessionTime, sessionGold = 0, 0, 0
local mapMoney            -- Gold beim Öffnen der Flugkarte
local flightBase, flightPaid = nil, 0
local pendingRoute, currentRoute -- Strecke aus der Flugkarte (von » nach)
local originName                  -- Flugmeister beim Öffnen der Karte
local ARROW = " » "               -- „→“ fehlt in der Spielschrift
local PREFIX = "|cff7fd4ffGreifzeit|r: "

local function Fmt(s)
  s = math.floor((s or 0) + 0.5)
  local d = math.floor(s / 86400); s = s % 86400
  local h = math.floor(s / 3600);  s = s % 3600
  local m = math.floor(s / 60);    s = s % 60
  if d > 0 then return string.format("%dT %dh %dm", d, h, m) end
  if h > 0 then return string.format("%dh %dm %ds", h, m, s) end
  if m > 0 then return string.format("%dm %ds", m, s) end
  return string.format("%ds", s)
end

local function Gold(copper)
  copper = copper or 0
  if GetCoinTextureString then return GetCoinTextureString(copper) end
  return string.format("%dg %ds %dk", math.floor(copper / 10000), math.floor(copper / 100) % 100, copper % 100)
end

local function Say(msg) print(PREFIX .. msg) end

local function AccountTotals()
  local t, g = 0, 0
  for _, c in pairs(db.chars) do t = t + (c.total or 0); g = g + (c.gold or 0) end
  return t, g
end

-- Flugkosten: Gold beim Öffnen der Karte minus Gold nach dem Abflug
local function UpdatePaid()
  if not flightBase then return end
  local p = flightBase - GetMoney()
  if p > flightPaid then
    local add = p - flightPaid
    char.gold = char.gold + add
    sessionGold = sessionGold + add
    flightPaid = p
  end
end

local function Accumulate()
  local now = GetTime()
  local dt = now - lastTick
  lastTick = now
  if dt > 0 and dt < 60 then
    char.total = char.total + dt
    currentFlight = currentFlight + dt
    sessionTime = sessionTime + dt
  end
end

-- ===== Flugrouten merken =====
local HISTORY_MAX = 200

local function NodeShort(name)
  if not name or name == "" then return "?" end
  return name:match("^([^,]+)") or name
end

-- Flugpunkte der offenen Karte (neue Schnittstelle, falls vorhanden)
local function MapNodes()
  if not (C_TaxiMap and C_TaxiMap.GetAllTaxiNodes) then return nil end
  local mapID = GetTaxiMapID and GetTaxiMapID()
  if not mapID then return nil end
  local ok, nodes = pcall(C_TaxiMap.GetAllTaxiNodes, mapID)
  return ok and nodes or nil
end

local function CurrentNodeName()
  local nodes = MapNodes()
  local current = Enum and Enum.FlightPathState and Enum.FlightPathState.Current
  if nodes and current then
    for _, n in ipairs(nodes) do
      if n.state == current and n.name then return n.name end
    end
  end
  if NumTaxiNodes then
    for i = 1, NumTaxiNodes() do
      if TaxiNodeGetType(i) == "CURRENT" then return TaxiNodeName(i) end
    end
  end
end

local function NodeNameBySlot(index)
  local name = TaxiNodeName and TaxiNodeName(index)
  if name and name ~= "" then return name end
  local nodes = MapNodes()
  if nodes then
    for _, n in ipairs(nodes) do
      if n.slotIndex == index then return n.name end
    end
  end
end

-- Notweg: wo bin ich gerade? (Unterzone, sonst Zone)
local function PlaceName()
  local sub = GetSubZoneText and GetSubZoneText()
  if sub and sub ~= "" then return sub end
  return (GetZoneText and GetZoneText()) or "?"
end

-- Beim Klick auf ein Ziel in der Flugkarte: Start und Ziel festhalten
if TakeTaxiNode then
  hooksecurefunc("TakeTaxiNode", function(index)
    local to = NodeNameBySlot(index)
    pendingRoute = {
      from = NodeShort(CurrentNodeName() or originName or PlaceName()),
      to = to and NodeShort(to) or nil,
      d = date("%Y-%m-%d %H:%M"),
    }
  end)
end

local function DateDE(s)
  local y, m, d = (s or ""):match("(%d+)-(%d+)-(%d+)")
  if not y then return s or "?" end
  return d .. "." .. m .. "." .. y
end

local function RecordFlight()
  local r = currentRoute or { from = originName and NodeShort(originName) or nil, d = date("%Y-%m-%d %H:%M") }
  -- Ziel unbekannt? Dann gilt der Ort der Landung
  local to = r.to or NodeShort(PlaceName())
  local from = r.from or "?"
  if from == "?" and to == "?" then currentRoute = nil return end -- nichts Brauchbares
  local e = { d = r.d, from = from, to = to, t = math.floor(currentFlight + 0.5), g = flightPaid or 0 }
  table.insert(char.history, 1, e)
  while #char.history > HISTORY_MAX do table.remove(char.history) end
  local key = e.from .. ARROW .. e.to
  local st = char.routes[key] or { n = 0, t = 0, g = 0 }
  st.n = st.n + 1
  st.t = st.t + e.t
  st.g = st.g + e.g
  if not st.best or e.t < st.best then st.best = e.t end
  st.last = e.d
  char.routes[key] = st
  if not char.first then char.first = e.d end
  currentRoute = nil
end

local ShowTimer, HideTimer -- unten definiert (Flugtimer, braucht die Fraktions-Stile)
local function Land()
  if not flying then return end
  Accumulate()
  flying = false
  HideTimer()
  flightBase = nil
  if ticker then ticker:Cancel(); ticker = nil end
  if currentFlight > 3 then
    char.flights = char.flights + 1
    if currentFlight > char.longest then char.longest = currentFlight end
    RecordFlight()
  end
  currentRoute = nil
  if db.announce then
    Say("Gelandet. Gesamt: |cffffffff" .. Fmt(char.total) .. "|r · " .. Gold(char.gold))
  end
  currentFlight = 0
end

local function Tick()
  if UnitOnTaxi("player") then Accumulate() else Land() end
end

local function TakeOff()
  if flying or not UnitOnTaxi("player") then return end
  flying = true
  currentFlight = 0
  currentRoute, pendingRoute = pendingRoute, nil
  if not currentRoute and originName then
    currentRoute = { from = NodeShort(originName), d = date("%Y-%m-%d %H:%M") }
  end
  originName = nil
  lastTick = GetTime()
  ticker = C_Timer.NewTicker(1, Tick)
  ShowTimer()
  if mapMoney then
    flightBase, flightPaid = mapMoney, 0
    mapMoney = nil
    UpdatePaid()
    -- falls die Abbuchung erst kurz nach dem Start ankommt
    C_Timer.After(10, function() flightBase = nil end)
  end
end

local function CheckSoon() C_Timer.After(0.3, TakeOff) end



-- ===== Infofenster an der Flugkarte =====
local panel

-- Fraktions-Stile: Farben, Rahmen, Wappen, Schlachtruf
local STYLES = {
  Alliance = {
    bg = { 0.04, 0.08, 0.20, 0.95 },
    border = { 1, 0.82, 0.25 },
    edge = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
    bannerA = { 0.10, 0.22, 0.55, 1 }, bannerB = { 0.04, 0.08, 0.25, 0.2 },
    accent = "ffd100",
    atlas = "AllianceEmblem", file = "Interface\\Timer\\Alliance-Logo",
    cry = "Für die Allianz!",
  },
  Horde = {
    bg = { 0.16, 0.03, 0.02, 0.95 },
    border = { 0.75, 0.25, 0.15 },
    edge = "Interface\\DialogFrame\\UI-DialogBox-Border",
    bannerA = { 0.55, 0.06, 0.04, 1 }, bannerB = { 0.20, 0.02, 0.01, 0.2 },
    accent = "ff9a3c",
    atlas = "HordeEmblem", file = "Interface\\Timer\\Horde-Logo",
    cry = "Für die Horde!",
  },
  Neutral = {
    bg = { 0.05, 0.06, 0.10, 0.92 },
    border = { 0.5, 0.8, 1 },
    edge = "Interface\\Tooltips\\UI-Tooltip-Border",
    bannerA = { 0.15, 0.35, 0.5, 1 }, bannerB = { 0.05, 0.1, 0.15, 0.2 },
    accent = "7fd4ff",
    cry = "Guten Flug!",
  },
}

-- ===== Flugtimer: wie lange noch? =====
-- Die Dauer je Strecke kennt Greifzeit aus früheren Flügen (alle Charaktere).
-- Unbekannte Strecke: es wird hochgezählt, nach der Landung ist sie bekannt.
local timer, timerStart, timerDur

local function ExpectedDuration(from, to)
  if not from or not to then return end
  local key = from .. ARROW .. to
  local n, t, best = 0, 0
  for _, c in pairs(db.chars) do
    local st = c.routes and c.routes[key]
    if st and st.n and st.n > 0 then
      n, t = n + st.n, t + st.t
      if st.best and (not best or st.best < best) then best = st.best end
    end
  end
  if n == 0 then return end
  -- Flugzeiten sind fest; Ausreißer (Ladebildschirm, Abbruch) nicht überbewerten
  local avg = t / n
  if best and avg - best > 20 then return best end
  return avg
end

local function Clock(s)
  s = math.max(0, math.floor(s + 0.5))
  return string.format("%d:%02d", math.floor(s / 60), s % 60)
end

-- ===== Flugzeit schon auf der Flugkarte (Ben 25.11.) =====
-- Maus über ein Ziel: ist die Strecke von hier dorthin schon geflogen worden
-- (irgendein Charakter), steht die Flugzeit im Tooltip – vor dem Abflug.
local function RouteInfo(from, to)
  local key = from .. ARROW .. to
  local n, t, best = 0, 0
  for _, c in pairs(db and db.chars or {}) do
    local st = c.routes and c.routes[key]
    if st and st.n and st.n > 0 then
      n, t = n + st.n, t + st.t
      if st.best and (not best or st.best < best) then best = st.best end
    end
  end
  return n, ExpectedDuration(from, to), best
end

-- Welches Ziel zeigt der Tooltip gerade? (neue Flugkarte: Pin mit taxiNodeData,
-- alte: TaxiButtonN mit Platznummer)
local function TipTarget(owner)
  if type(owner) ~= "table" then return end
  local d = owner.taxiNodeData
  if type(d) == "table" and d.name then
    local cur = Enum and Enum.FlightPathState and Enum.FlightPathState.Current
    if cur and d.state == cur then return end
    return d.name
  end
  local name = owner.GetName and owner:GetName()
  if name and name:match("^TaxiButton%d+$") and owner.GetID then
    local idx = owner:GetID()
    if TaxiNodeGetType and TaxiNodeGetType(idx) == "CURRENT" then return end
    return TaxiNodeName and TaxiNodeName(idx)
  end
end

local function AddFlightTime(tt)
  local owner = tt:GetOwner()
  if tt.gzOwner == owner then return end           -- schon ergänzt
  local to = TipTarget(owner)
  if not to or to == "" then return end
  local from = NodeShort(CurrentNodeName() or originName)
  to = NodeShort(to)
  if from == "?" or to == "?" then return end
  tt.gzOwner = owner
  local n, dur, best = RouteInfo(from, to)
  if n > 0 and dur then
    tt:AddLine("Flugzeit: " .. Clock(dur), 0.5, 0.85, 1)
    local more = (n == 1) and "1 Flug" or (n .. " Flügen")
    if best and math.abs(best - dur) >= 5 then more = more .. ", schnellster " .. Clock(best) end
    tt:AddLine("aus " .. more, 0.65, 0.65, 0.65)
  else
    tt:AddLine("Flugzeit: noch nicht geflogen", 0.6, 0.6, 0.6)
  end
  tt:Show()
end

do
  local busy
  hooksecurefunc(GameTooltip, "Show", function(tt)
    if busy then return end
    busy = true
    pcall(AddFlightTime, tt)
    busy = false
  end)
  GameTooltip:HookScript("OnTooltipCleared", function(tt) tt.gzOwner = nil end)
  GameTooltip:HookScript("OnHide", function(tt) tt.gzOwner = nil end)
end

local function BuildTimer()
  timer = CreateFrame("Frame", "GreifzeitFlugtimer", UIParent, "BackdropTemplate")
  timer:SetSize(220, 52)
  timer:SetFrameStrata("MEDIUM")
  local p = db.timerPos
  if p then timer:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else timer:SetPoint("TOP", UIParent, "TOP", 0, -110) end
  timer:SetMovable(true)
  timer:SetClampedToScreen(true)
  timer:EnableMouse(true)
  timer:RegisterForDrag("LeftButton")
  timer:SetScript("OnDragStart", timer.StartMoving)
  timer:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local a, _, b, x, y = self:GetPoint()
    db.timerPos = { a, b, x, y }
  end)
  timer:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
  timer.dest = timer:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  timer.dest:SetPoint("TOPLEFT", 10, -8)
  timer.dest:SetPoint("TOPRIGHT", -60, -8)
  timer.dest:SetJustifyH("LEFT")
  timer.dest:SetWordWrap(false)
  timer.left = timer:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
  timer.left:SetPoint("TOPRIGHT", -10, -6)
  timer.bar = CreateFrame("StatusBar", nil, timer)
  timer.bar:SetPoint("BOTTOMLEFT", 10, 9)
  timer.bar:SetPoint("BOTTOMRIGHT", -10, 9)
  timer.bar:SetHeight(8)
  timer.bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")
  timer.bar:SetMinMaxValues(0, 1)
  local bg = timer.bar:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetColorTexture(0, 0, 0, 0.5)
  timer.note = timer:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  timer.note:SetPoint("BOTTOM", 0, 8)
  local acc = 0
  timer:SetScript("OnUpdate", function(self, el)
    acc = acc + el
    if acc < 0.1 then return end
    acc = 0
    local gone = GetTime() - (timerStart or GetTime())
    if timerDur then
      local rest = timerDur - gone
      self.left:SetText(rest > 0 and Clock(rest) or "gleich da")
      self.bar:SetValue(math.min(1, gone / timerDur))
    else
      self.left:SetText(Clock(gone))
    end
  end)
  timer:Hide()
end

function ShowTimer()
  if db.timer == false or not flying then return end
  if not timer then BuildTimer() end
  local st = STYLES[UnitFactionGroup("player") or ""] or STYLES.Neutral
  timer:SetBackdropColor(st.bg[1], st.bg[2], st.bg[3], 0.85)
  timer:SetBackdropBorderColor(st.border[1], st.border[2], st.border[3], 0.9)
  timer.bar:SetStatusBarColor(st.border[1], st.border[2], st.border[3], 0.9)
  local r = currentRoute
  timerStart = GetTime()
  timerDur = r and ExpectedDuration(r.from, r.to)
  timer.dest:SetText(r and r.to and ("|cff" .. st.accent .. "»|r " .. r.to) or "Unterwegs")
  timer.bar:SetShown(timerDur ~= nil)
  timer.note:SetShown(timerDur == nil)
  timer.note:SetText("Strecke neu – Dauer wird gemerkt")
  timer.bar:SetValue(0)
  timer:Show()
end

function HideTimer()
  if timer then timer:Hide() end
end

local function SetEmblem(tex, st)
  if st.atlas and C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(st.atlas) then
    tex:SetAtlas(st.atlas)
  elseif st.file then
    tex:SetTexture(st.file)
  else
    tex:SetTexture(nil)
  end
end


-- ===== Stadtwappen des Flugmeisters =====
-- Wappen-Icons aus dem Argentumturnier (je eins pro Hauptstadt)
local CITIES = {
  stormwind = { name = "Sturmwind",   icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_Human" },
  ironforge = { name = "Eisenschmiede", icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_Dwarf" },
  darnassus = { name = "Darnassus",   icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_NightElf" },
  orgrimmar = { name = "Orgrimmar",   icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_Orc" },
  thunder   = { name = "Donnerfels",  icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_Tauren" },
  undercity = { name = "Unterstadt",  icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_Scourge" },
  darkspear = { name = "Dunkelspeere", icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_Troll" },
  gnomeregan = { name = "Gnomeregan", icon = "Interface\\Icons\\INV_Misc_Tournaments_Symbol_Gnome" },
}

-- ===== Fraktionen aus dem Ruf-Fenster =====
-- Hauptstadt-Fraktionen tragen ihr Stadtwappen
local CITY_BY_FACTION = {
  [72] = "stormwind", [47] = "ironforge", [69] = "darnassus", [54] = "gnomeregan",
  [76] = "orgrimmar", [81] = "thunder", [68] = "undercity", [530] = "darkspear",
}
-- Wappen-Kandidaten (das erste Symbol, das es im Spiel gibt, wird genommen)
local ICONS_BY_ID = {
  [529] = { "INV_Jewelry_Talisman_07", "Achievement_Reputation_ArgentCrusader" }, -- Argentumdämmerung
  [87]  = { "INV_Helmet_66" },                                    -- Blutsegelbukaniere
  [909] = { "INV_Misc_Ticket_Darkmoon_01" },                      -- Dunkelmond-Jahrmarkt
  [609] = { "Spell_Nature_Regeneration" },                        -- Zirkel des Cenarius
  [1090] = { "Achievement_Reputation_KirinTor", "Spell_Holy_MagicalSentry" }, -- Kirin Tor
  [92]  = { "Achievement_Character_Tauren_Male", "Ability_Hunter_Pet_Tallstrider" }, -- Gelkisklan
  [93]  = { "Achievement_Character_Tauren_Male", "Ability_Hunter_Pet_Tallstrider" }, -- Magramklan
  [21]  = { "Achievement_Goblinhead", "INV_Misc_Coin_02" },       -- Beutebucht
  [577] = { "Achievement_Goblinhead", "INV_Misc_Coin_02" },       -- Ewige Warte
  [369] = { "Achievement_Goblinhead", "INV_Misc_Coin_02" },       -- Gadgetzan
  [470] = { "Achievement_Goblinhead", "INV_Misc_Coin_02" },       -- Ratschet
  [576] = { "Achievement_Reputation_TimbermawHold", "INV_Misc_Horn_01" }, -- Holzschlundfeste
  [589] = { "Ability_Mount_PinkTiger" },                          -- Wintersäblerausbilder
  [890] = { "INV_BannerPVP_02" },                                 -- Silberschwingen
  [730] = { "INV_BannerPVP_02" },                                 -- Sturmlanzengarde
  [509] = { "INV_BannerPVP_02" },                                 -- Bund von Arathor
}
-- Forever-Fraktionen (Namen deutsch/englisch, klein geschrieben)
local ICONS_BY_NAME = {
  ["bruderschaft des pferdes"] = { "Ability_Mount_RidingHorse" },
  ["brotherhood of the horse"] = { "Ability_Mount_RidingHorse" },
  ["powderfuse"] = { "INV_Misc_Bomb_05", "INV_Misc_Bomb_01" },
  ["druiden der nachtklaue"] = { "Ability_Druid_CatForm" },
  ["nightclaw druids"] = { "Ability_Druid_CatForm" },
  ["expeditionskorps von theramore"] = { "INV_BannerPVP_02" },
  ["theramore expeditionary force"] = { "INV_BannerPVP_02" },
  ["der hohe orden"] = { "Ability_Druid_FlightForm", "INV_Feather_12" },
  ["high order"] = { "Ability_Druid_FlightForm", "INV_Feather_12" },
  ["hüter des hyjal"] = { "Achievement_Reputation_GuardiansOfHyjal" },
  ["guardians of hyjal"] = { "Achievement_Reputation_GuardiansOfHyjal" },
  ["irdener ring"] = { "Spell_Nature_EarthShock" },
  ["earthen ring"] = { "Spell_Nature_EarthShock" },
}
local ICONS_FALLBACK = { "Achievement_Reputation_01", "INV_Misc_Note_06", "INV_Misc_QuestionMark" }

local iconCache = {}
local function FirstIcon(list)
  for _, n in ipairs(list or {}) do
    local path = "Interface\\Icons\\" .. n
    if not GetFileIDFromPath or GetFileIDFromPath(path) then return path end
  end
end
local function FactionIcon(id, name)
  local key = tostring(id) .. ":" .. tostring(name)
  if iconCache[key] == nil then
    iconCache[key] = FirstIcon(id and ICONS_BY_ID[id])
      or FirstIcon(name and ICONS_BY_NAME[name:lower()])
      or FirstIcon(ICONS_FALLBACK) or false
  end
  return iconCache[key] or nil
end

-- Zone -> zuständige Hauptstadt (deutsche + englische Namen, klein geschrieben)
local function Z(t, city, ...) for _, n in ipairs({ ... }) do t[n] = city end end
local ZONES = { Alliance = {}, Horde = {} }
do
  local A, H = ZONES.Alliance, ZONES.Horde
  -- Allianz
  Z(A, "stormwind", "sturmwind", "stormwind city", "stormwind", "elwynnwald", "elwynn forest", "westfall",
    "rotkammgebirge", "redridge mountains", "dämmerwald", "duskwood", "schlingendorntal", "stranglethorn vale",
    "sümpfe des elends", "swamp of sorrows", "verwüstete lande", "blasted lands", "brennende steppe",
    "burning steppes", "gebirgspass der totenwinde", "deadwind pass", "düstermarschen", "dustwallow marsh")
  Z(A, "ironforge", "eisenschmiede", "ironforge", "dun morogh", "loch modan", "sumpfland", "wetlands",
    "arathihochland", "arathi highlands", "hinterland", "the hinterlands", "ödland", "badlands",
    "sengende schlucht", "searing gorge", "vorgebirge des hügellands", "hillsbrad foothills",
    "alteracgebirge", "alterac mountains", "westliche pestländer", "western plaguelands",
    "östliche pestländer", "eastern plaguelands")
  Z(A, "darnassus", "darnassus", "teldrassil", "dunkelküste", "darkshore", "eschental", "ashenvale",
    "steinkrallengebirge", "stonetalon mountains", "desolace", "feralas", "mondlichtung", "moonglade",
    "teufelswald", "felwood", "winterquell", "winterspring", "azshara", "silithus",
    "krater von un'goro", "un'goro crater", "tanaris", "tausend nadeln", "thousand needles")
  -- Horde
  Z(H, "orgrimmar", "orgrimmar", "durotar", "brachland", "the barrens", "nördliches brachland",
    "northern barrens", "südliches brachland", "southern barrens", "eschental", "ashenvale", "azshara",
    "düstermarschen", "dustwallow marsh", "tanaris", "tausend nadeln", "thousand needles", "silithus",
    "krater von un'goro", "un'goro crater", "teufelswald", "felwood", "winterquell", "winterspring",
    "ödland", "badlands", "brennende steppe", "burning steppes", "sümpfe des elends", "swamp of sorrows",
    "verwüstete lande", "blasted lands")
  Z(H, "thunder", "donnerfels", "thunder bluff", "mulgore", "steinkrallengebirge", "stonetalon mountains",
    "desolace", "feralas", "mondlichtung", "moonglade")
  Z(H, "undercity", "unterstadt", "undercity", "tirisfal", "tirisfal glades", "silberwald",
    "silverpine forest", "vorgebirge des hügellands", "hillsbrad foothills", "arathihochland",
    "arathi highlands", "alteracgebirge", "alterac mountains", "westliche pestländer",
    "western plaguelands", "östliche pestländer", "eastern plaguelands", "sengende schlucht", "searing gorge")
  Z(H, "darkspear", "hinterland", "the hinterlands", "schlingendorntal", "stranglethorn vale",
    "nördliches schlingendorntal", "northern stranglethorn", "das schlingendornkap", "the cape of stranglethorn")
end

local function CurrentZoneNames()
  local names = {}
  local id = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local guard = 0
  while id and guard < 6 do
    local info = C_Map.GetMapInfo(id)
    if not info then break end
    names[#names + 1] = info.name
    id = info.parentMapID
    guard = guard + 1
  end
  names[#names + 1] = GetRealZoneText and GetRealZoneText()
  names[#names + 1] = GetZoneText and GetZoneText()
  return names
end

-- Schlüssel für das aktuelle Gebiet (Zonen-Ebene der Karte)
local function CurrentZoneKey()
  local id = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local zoneType = (Enum and Enum.UIMapType and Enum.UIMapType.Zone) or 3
  local guard = 0
  while id and guard < 6 do
    local info = C_Map.GetMapInfo(id)
    if not info then break end
    if info.mapType and info.mapType <= zoneType then
      return "map:" .. id, info.name
    end
    id = info.parentMapID
    guard = guard + 1
  end
  local z = (GetRealZoneText and GetRealZoneText()) or "?"
  return "zone:" .. z:lower(), z
end

-- Fraktionsliste: was das Ruf-Fenster gerade zeigt, gesammelt über die Zeit
local function ReadFactions()
  db.factions = db.factions or {}
  local header = "Sonstige"
  local function add(id, name, hdr)
    if id and name and name ~= "" then db.factions[id] = { name = name, header = hdr } end
  end
  if C_Reputation and C_Reputation.GetNumFactions and C_Reputation.GetFactionDataByIndex then
    for i = 1, C_Reputation.GetNumFactions() do
      local d = C_Reputation.GetFactionDataByIndex(i)
      if d then
        if d.isHeader then
          if d.isHeaderWithRep then add(d.factionID, d.name, header) end
          if not d.isChild then header = d.name end
        else
          add(d.factionID, d.name, header)
        end
      end
    end
  elseif GetNumFactions and GetFactionInfo then
    for i = 1, GetNumFactions() do
      local name, _, _, _, _, _, _, _, isHeader, _, hasRep, _, isChild, factionID = GetFactionInfo(i)
      if isHeader then
        if hasRep then add(factionID, name, header) end
        if not isChild then header = name end
      else
        add(factionID, name, header)
      end
    end
  end
  return db.factions
end

-- Wappen zu einem gespeicherten Schlüssel: Stadtschlüssel oder „f:<FraktionsID>“
local function Crest(key, name)
  if not key or key == "none" then return nil end
  if CITIES[key] then return CITIES[key] end
  local id = tonumber(key:match("^f:(%d+)$") or "")
  if id then
    if CITY_BY_FACTION[id] then return CITIES[CITY_BY_FACTION[id]] end
    local f = db.factions and db.factions[id]
    local n = name or (f and f.name) or ("Fraktion " .. id)
    return { name = n, icon = FactionIcon(id, n) }
  end
end

-- Gebiete, deren Flugmeister einer bestimmten Fraktion gehören (Name aus dem Ruf-Fenster)
local FACTION_BY_ZONE = {
  ["flusslande"] = { Alliance = "bruderschaft des pferdes" },
  ["riverglades"] = { Alliance = "brotherhood of the horse" },
}
local function FactionGuess(faction)
  local facs = ReadFactions()
  for _, zn in ipairs(CurrentZoneNames()) do
    local m = zn and FACTION_BY_ZONE[zn:lower()]
    local want = m and m[faction]
    if want then
      for id, f in pairs(facs) do
        if f.name:lower() == want then return "f:" .. id end
      end
    end
  end
end

-- Liefert: Stadt (oder nil), geratener Stadtschlüssel, Eintrag aus der Sammlung
local function CurrentCity(faction)
  local zkey = CurrentZoneKey()
  local entry = db.zones[zkey]
  local guess
  local list = ZONES[faction]
  if list then
    for _, n in ipairs(CurrentZoneNames()) do
      guess = n and list[n:lower()]
      if guess then break end
    end
  end
  guess = FactionGuess(faction) or guess
  if entry and entry.answer then
    if entry.city == "none" then return nil, guess, entry end
    return Crest(entry.city, entry.cityName), guess, entry
  end
  return Crest(guess), guess, entry
end

local function MapFrame()
  for _, name in ipairs({ "FlightMapFrame", "TaxiFrame" }) do
    local fr = _G[name]
    if fr and fr:IsShown() then return fr end
  end
end


-- ===== Druiden-Rahmen um die Flugkarte =====
local MEDIA = "Interface\\AddOns\\Greifzeit\\media\\"
local skin
local STRATA = { "BACKGROUND", "LOW", "MEDIUM", "HIGH", "DIALOG", "FULLSCREEN", "FULLSCREEN_DIALOG", "TOOLTIP" }
local BAND = 39 / 1024        -- Mitte des Wurzelstrangs in der Textur (vom Rand)

-- Die eigentliche Kartenfläche (ohne Blizzards Rand und Titelleiste) suchen
local function MapBox(map)
  local name = map:GetName() or ""
  local cands = { _G.TaxiRouteMap, map.TaxiRouteMap, map.RouteMap, _G[name .. "RouteMap"],
    _G.TaxiMap, map.TaxiMap, map.ScrollContainer, map.MapCanvas, map.Inset }
  for _, c in ipairs(cands) do
    if c and c.GetWidth and c:GetWidth() > 100 and c:GetHeight() > 100 then
      return c
    end
  end
  return map
end

-- Abstand nach außen, damit die Strangmitte genau auf dem Kartenrand liegt (+ eigene Feinkorrektur)
local function RingOutset(box)
  local extra = db.skinOff or 0
  local adj = db.skinAdj
  local function o(len) return BAND * len / (1 - 2 * BAND) end
  return o(box:GetWidth()) + extra + adj.ex, o(box:GetHeight()) + extra + adj.ey
end

local function StrataAbove(strata)
  for i, n in ipairs(STRATA) do
    if n == strata then return STRATA[math.min(i + 1, #STRATA - 1)] end
  end
  return "DIALOG"
end

local function BuildSkin()
  skin = CreateFrame("Frame", "GreifzeitKartenRahmen", UIParent)
  skin:EnableMouse(false)
  skin.veil = skin:CreateTexture(nil, "BACKGROUND")
  skin.veil:SetAllPoints()
  skin.veil:SetTexture(MEDIA .. "flugkarte_schleier")
  skin.ring = skin:CreateTexture(nil, "ARTWORK")
  skin.ring:SetAllPoints()
  skin.ring:SetTexture(MEDIA .. "flugkarte_rahmen")

  skin.plaque = CreateFrame("Frame", nil, skin)
  skin.plaque.tex = skin.plaque:CreateTexture(nil, "ARTWORK")
  skin.plaque.tex:SetAllPoints()
  skin.plaque.tex:SetTexture(MEDIA .. "holzschild")
  skin.plaque.text = skin.plaque:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  skin.plaque.text:SetPoint("CENTER", 0, 1)
  skin.plaque.text:SetTextColor(0.72, 1, 0.92)
  skin.plaque.text:SetShadowColor(0.05, 0.35, 0.3, 1)
  skin.plaque.text:SetShadowOffset(1, -1)

  -- eigener Schließen-Knopf aus Holz (schließt über die Spiel-Funktion, keine Blizzard-Fenster anfassen)
  skin.close = CreateFrame("Button", nil, skin)
  skin.close:SetSize(28, 28)
  skin.close.tex = skin.close:CreateTexture(nil, "ARTWORK")
  skin.close.tex:SetAllPoints()
  skin.close.tex:SetTexture(MEDIA .. "knopf_schliessen")
  skin.close:SetHighlightTexture(MEDIA .. "knopf_schliessen", "ADD")
  skin.close:GetHighlightTexture():SetAlpha(0.35)
  skin.close:SetScript("OnClick", function() if CloseTaxiMap then CloseTaxiMap() end end)
  skin:Hide()
end


-- Blizzards eigenen Kartenrahmen unsichtbar machen (nur Transparenz, nichts verschieben oder umhängen)
local CHROME_KEYS = { "NineSlice", "Bg", "Background", "TitleContainer", "TitleBg", "TopTileStreaks",
  "PortraitContainer", "Portrait", "CloseButton", "Border", "BorderFrame", "TitleText", "Inset" }
local CHROME_SUFFIX = { "CloseButton", "TitleText", "Portrait", "Inset", "Bg", "TitleBg", "TopTileStreaks" }
local hidden = {}

local function HideChrome(map)
  if not db.hideBlizz then return end
  local function hide(obj)
    if obj and obj.SetAlpha and not hidden[obj] then
      hidden[obj] = obj:GetAlpha()
      obj:SetAlpha(0)
    end
  end
  for _, k in ipairs(CHROME_KEYS) do hide(map[k]) end
  local name = map:GetName()
  if name then
    for _, sfx in ipairs(CHROME_SUFFIX) do hide(_G[name .. sfx]) end
  end
  -- Rahmen-Texturen direkt am Kartenfenster (Ecken, Kanten, Titelleiste)
  for _, r in ipairs({ map:GetRegions() }) do
    local key = r.GetParentKey and r:GetParentKey()
    local tex = r.GetTexture and r:GetTexture()
    local atlas = r.GetAtlas and r:GetAtlas()
    local id = tostring(atlas or tex or key or ""):lower()
    if id:find("border") or id:find("corner") or id:find("edge") or id:find("title")
      or id:find("metal") or id:find("streak") or r:GetObjectType() == "FontString" then
      hide(r)
    end
  end
end

local function ShowChrome()
  for obj, a in pairs(hidden) do obj:SetAlpha(a or 1) end
  wipe(hidden)
end

local function DumpMap()
  local map = MapFrame()
  if not map then Say("Flugkarte ist nicht offen.") return end
  Say("Karte: " .. (map:GetName() or "?") .. " · " .. math.floor(map:GetWidth()) .. "x" .. math.floor(map:GetHeight()))
  local box = MapBox(map)
  print("   Kartenfläche: " .. (box == map and "nicht gefunden, ganzes Fenster" or (box.GetName and box:GetName() or "Teil")) ..
    " · " .. math.floor(box:GetWidth()) .. "x" .. math.floor(box:GetHeight()))
  for k, v in pairs(map) do
    if type(v) == "table" and v.GetObjectType then
      print("   ." .. tostring(k) .. " (" .. v:GetObjectType() .. ")" .. (hidden[v] and " |cff00ff00ausgeblendet|r" or ""))
    end
  end
  for i, r in ipairs({ map:GetRegions() }) do
    local id = (r.GetAtlas and r:GetAtlas()) or (r.GetTexture and r:GetTexture()) or (r.GetText and r:GetText()) or ""
    print(string.format("   Region %d: %s %s%s", i, r:GetObjectType(), tostring(id), hidden[r] and " |cff00ff00ausgeblendet|r" or ""))
  end
end

local function ShowSkin()
  if not db.skin then return end
  local map = MapFrame()
  if not map or map:GetWidth() < 50 then return end
  if not skin then BuildSkin() end
  local box = MapBox(map)
  local ox, oy = RingOutset(box)
  skin:ClearAllPoints()
  local adj = db.skinAdj
  skin:SetPoint("TOPLEFT", box, "TOPLEFT", -ox + adj.dx, oy + adj.dy)
  skin:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", ox + adj.dx, -oy + adj.dy)
  skin:SetFrameStrata(StrataAbove(map:GetFrameStrata()))
  skin:SetFrameLevel(10)

  local w, h = box:GetWidth() + 2 * ox, box:GetHeight() + 2 * oy
  local pw = math.min(330, w * 0.36)
  skin.plaque:SetSize(pw, pw / 4.5)
  skin.plaque:ClearAllPoints()
  skin.plaque:SetPoint("CENTER", skin, "TOP", 0, -h * BAND)
  skin.plaque:SetFrameLevel(skin:GetFrameLevel() + 2)
  skin.close:ClearAllPoints()
  skin.close:SetPoint("CENTER", skin, "TOPRIGHT", -w * BAND - 26, -h * BAND - 26)
  skin.close:SetFrameLevel(skin:GetFrameLevel() + 3)
  local npc = UnitName("npc")
  skin.plaque.text:SetText(npc and ("Flugmeister · " .. npc) or (GetMinimapZoneText and GetMinimapZoneText() or "Flugmeister"))
  skin.veil:SetShown(db.veil)
  HideChrome(map)
  skin:Show()
end


-- ===== Rahmen im Spiel anpassen und Maße ausgeben =====
local editing = false

local function Round(v) return math.floor(v * 10 + 0.5) / 10 end

local function ReportSkin()
  local map = MapFrame()
  if not map or not skin then Say("Flugkarte ist nicht offen.") return end
  local box = MapBox(map)
  local a = db.skinAdj
  Say("Rahmen-Maße (bitte an Claude schicken):")
  print(string.format("   Fenster: %s %dx%d · Kartenfläche: %s %dx%d", map:GetName() or "?", map:GetWidth(), map:GetHeight(),
    box == map and "ganzes Fenster" or (box:GetName() or "Teil"), box:GetWidth(), box:GetHeight()))
  print(string.format("   Rahmen außen: %dx%d · verschoben x %s / y %s · Zusatzbreite %s · Zusatzhöhe %s",
    skin:GetWidth(), skin:GetHeight(), Round(a.dx), Round(a.dy), Round(a.ex), Round(a.ey)))
  print(string.format("   UI-Skalierung: %s · Kartenskalierung: %s", Round(UIParent:GetEffectiveScale() * 100) / 100, Round(map:GetEffectiveScale() * 100) / 100))
end

local function SetEditing(on)
  if not skin then Say("Erst die Flugkarte öffnen.") return end
  editing = on
  skin:EnableMouse(on)
  skin:EnableMouseWheel(on)
  if not skin.hint then
    skin.hint = skin:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    skin.hint:SetPoint("CENTER")
    skin.hint:SetJustifyH("CENTER")
    skin.hint:SetText("|cff7fffd4Rahmen anpassen|r\nZiehen = verschieben\nMausrad = größer/kleiner\nShift + Mausrad = nur Breite\nStrg + Mausrad = nur Höhe\n\n/greif anpassen = fertig")
    skin.tint = skin:CreateTexture(nil, "BACKGROUND", nil, -8)
    skin.tint:SetAllPoints()
    skin.tint:SetColorTexture(0.2, 1, 0.8, 0.08)
    skin:SetScript("OnMouseDown", function(self, btn)
      if not editing or btn ~= "LeftButton" then return end
      local sc = UIParent:GetEffectiveScale()
      local x, y = GetCursorPosition()
      self.drag = { x = x / sc, y = y / sc, dx = db.skinAdj.dx, dy = db.skinAdj.dy }
      self:SetScript("OnUpdate", function(f)
        local cx, cy = GetCursorPosition()
        db.skinAdj.dx = f.drag.dx + cx / sc - f.drag.x
        db.skinAdj.dy = f.drag.dy + cy / sc - f.drag.y
        ShowSkin()
      end)
    end)
    skin:SetScript("OnMouseUp", function(self)
      self:SetScript("OnUpdate", nil)
      self.drag = nil
    end)
    skin:SetScript("OnMouseWheel", function(self, delta)
      if not editing then return end
      local a = db.skinAdj
      if IsShiftKeyDown() then a.ex = a.ex + delta
      elseif IsControlKeyDown() then a.ey = a.ey + delta
      else a.ex = a.ex + delta; a.ey = a.ey + delta end
      ShowSkin()
    end)
  end
  skin.hint:SetShown(on)
  skin.tint:SetShown(on)
  if on then
    Say("Anpassen an. Wenn es passt: |cff7fffd4/greif anpassen|r")
  else
    Say("Gespeichert.")
    ReportSkin()
  end
end

local function HideSkin()
  if editing then SetEditing(false) end
  if skin then skin:Hide() end
  ShowChrome()
end

local function PlacePanel()
  panel:ClearAllPoints()
  if db.panelPos then
    local p = db.panelPos
    panel:SetPoint(p[1], UIParent, p[2], p[3], p[4])
  else
    local map = MapFrame()
    if map then
      local box = MapBox(map)
      local ox = (db.skin and RingOutset(box)) or 0
      panel:SetPoint("TOPLEFT", box, "TOPRIGHT", ox + 24, 0)
    else
      panel:SetPoint("LEFT", UIParent, "LEFT", 420, 100)
    end
  end
end

local function BuildPanel()
  panel = CreateFrame("Frame", "GreifzeitPanel", UIParent, "BackdropTemplate")
  panel:SetSize(300, 190)
  panel.mode = "stats"
  panel:SetFrameStrata("HIGH")

  -- Ziehen = verschieben, Rechtsklick = wieder an die Karte heften
  panel:EnableMouse(true)
  panel:SetMovable(true)
  panel:SetClampedToScreen(true)
  panel:RegisterForDrag("LeftButton")
  panel:SetScript("OnDragStart", panel.StartMoving)
  panel:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p1, _, p2, x, y = self:GetPoint()
    db.panelPos = { p1, p2, x, y }
  end)
  panel:SetScript("OnMouseUp", function(self, btn)
    if btn == "RightButton" then db.panelPos = nil; PlacePanel() end
  end)

  -- Wurzelrahmen mit Moosgrund
  panel.bg = panel:CreateTexture(nil, "BACKGROUND")
  panel.bg:SetPoint("TOPLEFT", -12, 12)
  panel.bg:SetPoint("BOTTOMRIGHT", 12, -12)
  panel.bg:SetTexture(MEDIA .. "fenster_rahmen")
  panel.bg:SetTexCoord(0, 1, 0, 0.75)

  -- blasses Stadtwappen als Wasserzeichen
  panel.watermark = panel:CreateTexture(nil, "BORDER")
  panel.watermark:SetSize(72, 72)
  panel.watermark:SetPoint("RIGHT", panel, "RIGHT", -26, -6)
  panel.watermark:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  panel.watermark:SetAlpha(0.2)
  panel.watermark:SetDesaturation(0.3)
  local mask = panel:CreateMaskTexture()
  mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
  mask:SetAllPoints(panel.watermark)
  panel.watermark:AddMaskTexture(mask)

  -- feine Moos-Linie unter dem Titel
  panel.line = panel:CreateTexture(nil, "ARTWORK", nil, 2)
  panel.line:SetPoint("TOPLEFT", 18, -58)
  panel.line:SetPoint("TOPRIGHT", -18, -58)
  panel.line:SetHeight(1)

  -- Wappen ragt links oben über den Rand hinaus
  panel.emblem = panel:CreateTexture(nil, "OVERLAY")
  panel.emblem:SetSize(60, 60)
  panel.emblem:SetPoint("CENTER", panel, "TOPLEFT", 34, -30)

  panel.title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  panel.title:SetPoint("TOPLEFT", 70, -14)
  panel.title:SetText("Greifzeit")

  panel.cry = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  panel.cry:SetPoint("TOPLEFT", panel.title, "BOTTOMLEFT", 0, -2)

  -- kleiner Knopf: Wappen für dieses Gebiet neu wählen
  panel.change = CreateFrame("Button", nil, panel)
  panel.change:SetSize(46, 14)
  panel.change:SetPoint("LEFT", panel.cry, "RIGHT", 6, 0)
  panel.change.text = panel.change:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  panel.change.text:SetAllPoints()
  panel.change.text:SetText("ändern")
  panel.change:SetScript("OnEnter", function(self) self.text:SetFontObject("GameFontHighlightSmall") end)
  panel.change:SetScript("OnLeave", function(self) self.text:SetFontObject("GameFontDisableSmall") end)
  -- Klick-Aktion wird in ApplyStyle gesetzt (ShowPanel ist hier noch nicht bekannt)

  panel.text = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  panel.text:SetPoint("TOPLEFT", 20, -68)
  panel.text:SetPoint("RIGHT", -20, 0)
  panel.text:SetJustifyH("LEFT")
  panel.text:SetSpacing(3)
  panel:Hide()
end

-- ===== Wappen-Abfrage (sammelt über die Zeit Daten pro Gebiet) =====
local FACTION_CITIES = {
  Alliance = { "darnassus", "ironforge", "stormwind" },
  Horde = { "orgrimmar", "thunder", "undercity", "darkspear" },
}

local function MakeButton(parent, label, width)
  local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
  b:SetSize(width or 60, 20)
  b:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 8, edgeSize = 8,
    insets = { left = 2, right = 2, top = 2, bottom = 2 },
  })
  b:SetBackdropColor(0.22, 0.14, 0.08, 0.9)
  b:SetBackdropBorderColor(0.55, 0.4, 0.24, 1)
  b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.label:SetPoint("CENTER")
  b.label:SetText(label)
  b:SetScript("OnEnter", function(self) self:SetBackdropColor(1, 1, 1, 0.25) end)
  b:SetScript("OnLeave", function(self) self:SetBackdropColor(0.22, 0.14, 0.08, 0.9) end)
  return b
end

local ShowPanel = nil -- wird unten definiert

local function SaveAnswer(answer, cityKey, cityName)
  local zkey, zname = CurrentZoneKey()
  local e = db.zones[zkey] or {}
  db.zones[zkey] = e
  e.name = zname
  e.chain = table.concat(CurrentZoneNames(), " / ")
  e.faction = UnitFactionGroup("player")
  e.answer = answer          -- "ok" = Vermutung passt, "fix" = korrigiert
  e.city = cityKey           -- Stadtschlüssel, "f:<FraktionsID>" oder "none"
  e.cityName = cityName
  e.date = date("%Y-%m-%d")
  ShowPanel()
end

local function BuildAsk()
  local q = CreateFrame("Frame", nil, panel)
  q:SetPoint("TOPLEFT", panel.text, "BOTTOMLEFT", 0, -10)
  q:SetPoint("RIGHT", panel, "RIGHT", -20, 0)
  q:SetHeight(62)

  local line = q:CreateTexture(nil, "ARTWORK")
  line:SetPoint("TOPLEFT"); line:SetPoint("TOPRIGHT")
  line:SetHeight(1)
  q.line = line

  q.text = q:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  q.text:SetPoint("TOPLEFT", 0, -6)
  q.text:SetPoint("RIGHT")
  q.text:SetJustifyH("LEFT")

  q.yes = MakeButton(q, "Ja", 60)
  q.yes:SetPoint("TOPLEFT", q.text, "BOTTOMLEFT", 0, -5)
  q.no = MakeButton(q, "Nein", 60)
  q.no:SetPoint("LEFT", q.yes, "RIGHT", 6, 0)

  q.picks = {}
  panel.ask = q
end

-- Menü mit allen Fraktionen aus dem Ruf-Fenster, nach Rubriken
local function ShowFactionMenu(owner)
  local groups, order = {}, {}
  for id, f in pairs(ReadFactions()) do
    local h = f.header or "Sonstige"
    if not groups[h] then groups[h] = {}; order[#order + 1] = h end
    table.insert(groups[h], { id = id, name = f.name })
  end
  table.sort(order)
  for _, h in ipairs(order) do table.sort(groups[h], function(a, b) return a.name < b.name end) end
  if MenuUtil and MenuUtil.CreateContextMenu then
    MenuUtil.CreateContextMenu(owner, function(_, root)
      root:CreateTitle("Wem gehört dieser Flugmeister?")
      for _, h in ipairs(order) do
        local sub = root:CreateButton(h)
        for _, f in ipairs(groups[h]) do
          sub:CreateButton(f.name, function() SaveAnswer("fix", "f:" .. f.id, f.name) end)
        end
      end
      root:CreateDivider()
      root:CreateButton("Keins", function() SaveAnswer("fix", "none") end)
    end)
  else
    Say("Fraktionsmenü nicht verfügbar – bitte eine Hauptstadt oder „Keins“ wählen.")
  end
end

local function ShowPicker(faction)
  local q = panel.ask
  q.yes:Hide(); q.no:Hide()
  for _, b in ipairs(q.picks) do b:Hide() end
  q.text:SetText("Wem gehört dieser Flugmeister?")
  local keys = {}
  for _, k in ipairs(FACTION_CITIES[faction] or {}) do keys[#keys + 1] = k end
  keys[#keys + 1] = "other"
  keys[#keys + 1] = "none"
  local prev
  for i, k in ipairs(keys) do
    local b = q.picks[i] or MakeButton(q, "", 76)
    q.picks[i] = b
    if k == "other" then
      b.label:SetText("Andere …")
      b:SetScript("OnClick", function(self) ShowFactionMenu(self) end)
    else
      b.label:SetText(k == "none" and "Keins" or CITIES[k].name)
      b:SetScript("OnClick", function() SaveAnswer("fix", k) end)
    end
    b:ClearAllPoints()
    if i == 1 then
      b:SetPoint("TOPLEFT", q.text, "BOTTOMLEFT", 0, -5)
    elseif (i - 1) % 3 == 0 then
      b:SetPoint("TOPLEFT", q.picks[i - 3], "BOTTOMLEFT", 0, -4)
    else
      b:SetPoint("LEFT", prev, "RIGHT", 5, 0)
    end
    b:Show()
    prev = b
  end
  local rows = math.ceil(#keys / 3)
  q:SetHeight(24 + rows * 24)
  panel:SetHeight(panel.text:GetStringHeight() + 86 + q:GetHeight() + 10)
end

-- gibt die zusätzliche Höhe zurück, die die Frage braucht
local function UpdateAsk(city, guess, entry)
  if not panel.ask then BuildAsk() end
  local q = panel.ask
  local faction = UnitFactionGroup("player")
  if not db.ask or (entry and entry.answer and not panel.reasking) or not FACTION_CITIES[faction] then
    q:Hide()
    return 0
  end
  local st = panel.style
  q.line:SetColorTexture(st.border[1], st.border[2], st.border[3], 0.5)
  for _, b in ipairs(q.picks) do b:Hide() end
  q:Show()
  local gc = guess and Crest(guess)
  if gc then
    q.text:SetText("Passt das Wappen (" .. gc.name .. ") zu diesem Flugmeister?")
    q.yes:Show(); q.no:Show()
    q.yes:SetScript("OnClick", function() SaveAnswer("ok", guess) end)
    q.no:SetScript("OnClick", function() ShowPicker(faction) end)
    q:SetHeight(50)
  else
    ShowPicker(faction)
  end
  return q:GetHeight() + 10
end

-- ===== Reiter: Übersicht / Historie =====
local UpdatePanel -- unten definiert

local function BuildTabs()
  panel.tabs = {}
  local defs = { { "stats", "Übersicht" }, { "history", "Historie" } }
  local prev
  for i = #defs, 1, -1 do
    local key, label = defs[i][1], defs[i][2]
    local b = MakeButton(panel, label, 62)
    b:SetHeight(18)
    if prev then
      b:SetPoint("RIGHT", prev, "LEFT", -3, 0)
    else
      b:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -16, -14)
    end
    b:SetScript("OnClick", function()
      panel.mode = key
      UpdatePanel()
    end)
    b.key = key
    panel.tabs[key] = b
    prev = b
  end
end

local function PaintTabs()
  for key, b in pairs(panel.tabs) do
    if key == panel.mode then
      b.label:SetTextColor(1, 0.82, 0.25)
      b:SetBackdropBorderColor(0.85, 0.65, 0.3, 1)
    else
      b.label:SetTextColor(0.7, 0.7, 0.7)
      b:SetBackdropBorderColor(0.55, 0.4, 0.24, 1)
    end
  end
end

local function FirstFlightLine()
  if char.preRecord then
    return "|cff999999Erster Flug: vor dem " .. DateDE(char.since) .. "|r"
  elseif char.first then
    return "|cff999999Erster Flug: " .. DateDE(char.first) .. "|r"
  end
  return "|cff999999Erster Flug: steht noch aus|r"
end

local function SortedRoutes()
  local list = {}
  for key, st in pairs(char.routes) do list[#list + 1] = { key = key, st = st } end
  table.sort(list, function(a, b)
    if a.st.n ~= b.st.n then return a.st.n > b.st.n end
    return (a.st.last or "") > (b.st.last or "")
  end)
  return list
end

local function HistoryLines(c)
  local lines = {}
  if #char.history == 0 then
    lines[1] = "|cff999999Noch keine Route aufgezeichnet.|r"
    lines[2] = "|cff999999Ab jetzt wird jeder Flug gemerkt:|r"
    lines[3] = "|cff999999von wo, wohin, wann, wie lange.|r"
    return lines
  end
  lines[#lines + 1] = c .. "Häufigste Strecken|r"
  for i, r in ipairs(SortedRoutes()) do
    if i > 5 then break end
    lines[#lines + 1] = r.key .. "  |cff999999" .. r.st.n .. "× · Ø " .. Fmt(r.st.t / r.st.n) .. "|r"
  end
  lines[#lines + 1] = " "
  lines[#lines + 1] = c .. "Letzte Flüge|r"
  for i, e in ipairs(char.history) do
    if i > 6 then break end
    lines[#lines + 1] = "|cff999999" .. DateDE(e.d) .. "|r  " .. e.from .. ARROW .. e.to .. "  |cff999999" .. Fmt(e.t) .. "|r"
  end
  return lines
end

local function ApplyStyle()
  local st = STYLES[UnitFactionGroup("player") or ""] or STYLES.Neutral
  panel.style = st
  panel.line:SetColorTexture(0.45, 0.62, 0.25, 0.6)
  SetEmblem(panel.emblem, st)
  panel.title:SetTextColor(st.border[1], st.border[2], st.border[3])
  local city, guess, entry = CurrentCity(UnitFactionGroup("player"))
  panel.cityInfo = { city, guess, entry }
  if city then
    if city.icon then
      panel.watermark:SetTexture(city.icon)
      panel.watermark:SetTexCoord(0.08, 0.92, 0.08, 0.92)
      panel.watermark:Show()
    else
      panel.watermark:Hide()
    end
    panel.cry:SetText("|cffcccccc" .. city.name .. " · " .. st.cry .. "|r")
  else
    panel.watermark:Hide()
    panel.cry:SetText("|cffcccccc" .. st.cry .. "|r")
  end
  if panel.change then
    if not panel.change.wired then
      panel.change.wired = true
      panel.change:SetScript("OnClick", function()
        local e = db.zones[CurrentZoneKey()]
        if e then e.answer, e.city, e.cityName = nil, nil, nil end
        ShowPanel()
      end)
    end
    panel.change:SetShown(entry and entry.answer and true or false)
  end
end

function UpdatePanel()
  local t, g = AccountTotals()
  local c = "|cff" .. panel.style.accent
  if not panel.tabs then BuildTabs() end
  PaintTabs()
  if panel.mode == "history" then
    panel.text:SetText(table.concat(HistoryLines(c), "\n"))
    if panel.ask then panel.ask:Hide() end
    panel:SetHeight(panel.text:GetStringHeight() + 86)
    return
  end
  local lines = {
    c .. "Dieser Charakter|r",
    Fmt(char.total) .. "  ·  " .. char.flights .. " Flüge",
    Gold(char.gold),
    FirstFlightLine(),
  }
  if char.flights > 0 then
    lines[#lines + 1] = "|cff999999Schnitt: " .. Fmt(char.total / char.flights) .. " / " .. Gold(math.floor(char.gold / char.flights)) .. "|r"
  end
  lines[#lines + 1] = " "
  lines[#lines + 1] = c .. "Alle Charaktere|r"
  lines[#lines + 1] = Fmt(t) .. "  ·  " .. Gold(g)
  panel.text:SetText(table.concat(lines, "\n"))
  local extra = UpdateAsk(panel.cityInfo[1], panel.cityInfo[2], panel.cityInfo[3])
  if not (panel.ask:IsShown() and panel.ask.picks[1] and panel.ask.picks[1]:IsShown()) then
    panel:SetHeight(panel.text:GetStringHeight() + 86 + extra)
  end
end

function ShowPanel()
  if not db.panel then return end
  if not panel then BuildPanel() end
  panel.mode = "stats"
  ApplyStyle()
  UpdatePanel()
  PlacePanel()
  panel:Show()
end

local function HidePanel()
  if panel then panel:Hide() end
end

local function ShowStats()
  local t, g = AccountTotals()
  Say("Dieser Charakter: |cffffffff" .. Fmt(char.total) .. "|r in " .. char.flights .. " Flügen · bezahlt: " .. Gold(char.gold))
  if char.flights > 0 then
    print("   Schnitt pro Flug: " .. Fmt(char.total / char.flights) .. " / " .. Gold(math.floor(char.gold / char.flights))
      .. " · längster Flug: " .. Fmt(char.longest))
  end
  print("   Diese Sitzung: " .. Fmt(sessionTime) .. " · " .. Gold(sessionGold))
  print("   Alle Charaktere: |cffffffff" .. Fmt(t) .. "|r · " .. Gold(g))
end

local function ShowAll()
  local list = {}
  for name, c in pairs(db.chars) do list[#list + 1] = { name = name, c = c } end
  table.sort(list, function(a, b) return (a.c.total or 0) > (b.c.total or 0) end)
  Say("Flüge nach Charakter:")
  for _, e in ipairs(list) do
    print(string.format("   %s: %s (%d Flüge) · %s", e.name, Fmt(e.c.total), e.c.flights or 0, Gold(e.c.gold)))
  end
  local t, g = AccountTotals()
  print("   Summe: |cffffffff" .. Fmt(t) .. "|r · " .. Gold(g))
end

SLASH_GREIFZEIT1 = "/greif"
SLASH_GREIFZEIT2 = "/greifzeit"
SlashCmdList.GREIFZEIT = function(msg)
  msg = (msg or ""):lower():match("^%s*(.-)%s*$")
  local rahmenArg = msg:match("^rahmen%s*(.*)$")
  if rahmenArg then
    if rahmenArg == "größer" or rahmenArg == "groesser" or rahmenArg == "+" then
      db.skinOff = math.min(80, db.skinOff + 4)
    elseif rahmenArg == "kleiner" or rahmenArg == "-" then
      db.skinOff = math.max(-40, db.skinOff - 4)
    elseif rahmenArg == "normal" then
      db.skinOff = 0
    else
      db.skin = not db.skin
      if not db.skin then HideSkin() end
    end
    Say("Wurzelrahmen " .. (db.skin and "|cff00ff00an|r" or "|cffff5555aus|r") .. string.format(" · Abstand %d px", db.skinOff))
    if db.skin and MapFrame() then ShowSkin(); if panel and panel:IsShown() then PlacePanel() end end
    return
  end
  if msg == "schleier" then
    db.veil = not db.veil
    if skin then skin.veil:SetShown(db.veil) end
    Say("Schleier über der Karte " .. (db.veil and "|cff00ff00an|r" or "|cffff5555aus|r"))
    return
  elseif msg == "blizzard" then
    db.hideBlizz = not db.hideBlizz
    if db.hideBlizz then local m = MapFrame(); if m then HideChrome(m) end else ShowChrome() end
    Say("Blizzard-Kartenrahmen " .. (db.hideBlizz and "|cffff5555ausgeblendet|r" or "|cff00ff00sichtbar|r"))
    return
  elseif msg == "karte" then
    DumpMap()
    return
  elseif msg == "anpassen" then
    SetEditing(not editing)
    return
  elseif msg == "anpassen reset" then
    db.skinAdj = { dx = 0, dy = 0, ex = 0, ey = 0 }
    if skin and skin:IsShown() then ShowSkin() end
    Say("Anpassung zurückgesetzt.")
    return
  elseif msg == "maße" or msg == "masse" then
    ReportSkin()
    return
  end
  if flying then Accumulate() end
  if msg == "historie" or msg == "routen" then
    local routes = SortedRoutes()
    Say("Strecken (" .. #routes .. "), " .. FirstFlightLine():gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
    for i, r in ipairs(routes) do
      if i > 15 then break end
      print(string.format("   %s: %dx · Ø %s · schnellster %s · zuletzt %s", r.key, r.st.n,
        Fmt(r.st.t / r.st.n), Fmt(r.st.best or 0), DateDE(r.st.last)))
    end
    print("   Letzte Flüge:")
    for i, e in ipairs(char.history) do
      if i > 10 then break end
      print(string.format("   %s  %s » %s  %s · %s", DateDE(e.d), e.from, e.to, Fmt(e.t), Gold(e.g)))
    end
  elseif msg == "alle" then
    ShowAll()
  elseif msg == "melden" then
    db.announce = not db.announce
    Say("Meldung nach der Landung " .. (db.announce and "|cff00ff00an|r" or "|cffff5555aus|r"))
  elseif msg == "fenster" then
    db.panel = not db.panel
    Say("Fenster an der Flugkarte " .. (db.panel and "|cff00ff00an|r" or "|cffff5555aus|r"))
    if not db.panel then HidePanel() end
  elseif msg == "timer" then
    db.timer = not (db.timer ~= false)
    Say("Flugtimer " .. ((db.timer ~= false) and "|cff00ff00an|r" or "|cffff5555aus|r"))
    if db.timer == false then HideTimer() elseif flying then ShowTimer() end
  elseif msg == "timer reset" then
    db.timerPos = nil
    if timer then timer:ClearAllPoints(); timer:SetPoint("TOP", UIParent, "TOP", 0, -110) end
    Say("Flugtimer wieder oben in der Mitte.")
  elseif msg == "zone" then
    Say("Zonennamen: " .. table.concat(CurrentZoneNames(), " / "))
  elseif msg == "fragen" then
    db.ask = not db.ask
    Say("Wappen-Abfrage am Flugmeister " .. (db.ask and "|cff00ff00an|r" or "|cffff5555aus|r"))
  elseif msg == "daten" then
    local n, fixes = 0, {}
    for k, e in pairs(db.zones) do
      if e.answer then
        n = n + 1
        if e.answer == "fix" then
          local c = Crest(e.city, e.cityName)
          fixes[#fixes + 1] = (e.name or k) .. " » " .. (e.city == "none" and "keins" or (c and c.name or e.city))
        end
      end
    end
    Say(n .. " Gebiete erfasst, davon " .. #fixes .. " korrigiert.")
    for _, l in ipairs(fixes) do print("   " .. l) end
  elseif msg == "hier" then
    local zkey, zname = CurrentZoneKey()
    if db.zones[zkey] then db.zones[zkey].answer, db.zones[zkey].city, db.zones[zkey].cityName = nil, nil, nil end
    Say("Wappen für " .. (zname or "dieses Gebiet") .. " zurückgesetzt – am Flugmeister wird neu gefragt.")
  elseif msg == "neu" then
    wipe(db.zones)
    Say("Alle Wappen-Antworten gelöscht – es wird wieder überall gefragt.")
  elseif msg == "reset" then
    char.total, char.flights, char.longest, char.gold = 0, 0, 0, 0
    char.history, char.routes, char.first = {}, {}, nil
    char.since, char.preRecord = date("%Y-%m-%d"), false
    sessionTime, currentFlight, sessionGold = 0, 0, 0
    Say("Werte dieses Charakters zurückgesetzt.")
  elseif msg == "hilfe" or msg == "help" then
    Say("/greif – Übersicht · /greif alle – alle Charaktere · /greif historie – Strecken und letzte Flüge · /greif melden – Landemeldung an/aus · /greif fenster – Fenster an der Flugkarte an/aus · /greif timer – Flugtimer an/aus (ziehen zum Verschieben, /greif timer reset) · /greif fragen – Wappen-Abfrage an/aus · /greif rahmen – Wurzelrahmen an/aus (größer/kleiner/normal) · /greif schleier – Schleier an/aus · /greif blizzard – Blizzard-Rahmen zeigen/verstecken · /greif karte – Bauteile der Karte auflisten · /greif anpassen – Rahmen im Spiel ausrichten · /greif maße – Maße ausgeben · /greif daten – erfasste Gebiete · /greif hier – Wappen dieses Gebiets neu wählen · /greif neu – alle Antworten löschen · /greif reset – diesen Charakter nullen")
  else
    ShowStats()
  end
end

f:SetScript("OnEvent", function(self, event, arg1)
  if event == "ADDON_LOADED" and arg1 == "Greifzeit" then
    GreifzeitDB = GreifzeitDB or {}
    db = GreifzeitDB
    db.chars = db.chars or {}
    if db.announce == nil then db.announce = true end
    if db.panel == nil then db.panel = true end
    if db.ask == nil then db.ask = true end
    if db.skin == nil then db.skin = true end
    db.skinOff = db.skinOff or 0
    db.skinAdj = db.skinAdj or { dx = 0, dy = 0, ex = 0, ey = 0 }
    if db.veil == nil then db.veil = true end
    if db.hideBlizz == nil then db.hideBlizz = true end
    db.zones = db.zones or {}
    if not db.migrRiverglades then
      for _, e in pairs(db.zones) do
        local n = (e.name or ""):lower()
        if (n:find("flusslande") or n:find("riverglades")) and not (e.city and e.city:find("^f:")) then
          e.answer, e.city, e.cityName = nil, nil, nil
        end
      end
      db.migrRiverglades = true
    end
    local key = UnitName("player") .. "-" .. GetRealmName()
    db.chars[key] = db.chars[key] or {}
    char = db.chars[key]
    char.total = char.total or 0
    char.flights = char.flights or 0
    char.longest = char.longest or 0
    char.gold = char.gold or 0
    char.history = char.history or {}
    char.routes = char.routes or {}
    -- Aufräumen: Einträge ohne Start und Ziel weg, „→“ wird zu „»“
    for i = #char.history, 1, -1 do
      local e = char.history[i]
      if (e.from == "?" or not e.from) and (e.to == "?" or not e.to) then table.remove(char.history, i) end
    end
    local fixed = {}
    for key, st in pairs(char.routes) do
      local k2 = key:gsub(" → ", ARROW)
      if not k2:find("^%?" .. ARROW .. "%?$") then fixed[k2] = st end
    end
    char.routes = fixed
    -- Ab wann wird aufgezeichnet? Gab es schon Flüge, liegt der erste davor.
    if not char.since then
      char.since = date("%Y-%m-%d")
      char.preRecord = char.flights > 0
    end
    self:UnregisterEvent("ADDON_LOADED")
  elseif event == "TAXIMAP_OPENED" then
    mapMoney = GetMoney()
    originName = CurrentNodeName() or PlaceName()
    C_Timer.After(0, function() ShowSkin(); ShowPanel() end) -- warten, bis die Karte selbst offen ist
  elseif event == "TAXIMAP_CLOSED" then
    HidePanel()
    HideSkin()
  elseif event == "PLAYER_MONEY" then
    if flightBase then UpdatePaid() end
  elseif event == "PLAYER_ENTERING_WORLD" then
    CheckSoon()
  elseif event == "PLAYER_CONTROL_LOST" or event == "UNIT_FLAGS" then
    if not flying then CheckSoon() end
  elseif event == "PLAYER_CONTROL_GAINED" then
    if flying and not UnitOnTaxi("player") then Land() end
  elseif event == "PLAYER_LOGOUT" then
    if flying then Accumulate() end
  end
end)

f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("TAXIMAP_OPENED")
f:RegisterEvent("TAXIMAP_CLOSED")
f:RegisterEvent("PLAYER_MONEY")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("PLAYER_CONTROL_LOST")
f:RegisterEvent("PLAYER_CONTROL_GAINED")
f:RegisterEvent("PLAYER_LOGOUT")
f:RegisterUnitEvent("UNIT_FLAGS", "player")
