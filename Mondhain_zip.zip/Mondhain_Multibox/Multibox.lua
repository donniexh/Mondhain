-- Mondhain – Multibox (privat, nur für Ben und Steve, Ben 26.11.)
--
-- Multibox-Modus an → die Tasten 1, 2, 3 bekommen neue Aufgaben; aus → alles wie vorher:
--   1  Assist auf den Anführer + Zauberfolge (/castsequence, bis zu 5 Zauber hineinziehen)
--   2  dem Anführer folgen
--   3  Heilzauber auf den Anführer
--   4  Segen/Buff nachlegen – wer seinen festgelegten Buff nicht (mehr) hat
-- Anführer = eingetragener Name, leer = „party1“ (in einer Zweiergruppe immer der andere).
-- Jeder Tastendruck löst genau eine Aktion aus – reine Blizzard-Makros, nichts läuft
-- von selbst. Tasten und Makros lassen sich nur außerhalb des Kampfes ändern.
--
-- Leiste: links der Haken „aktiv“ (Tasten 1–3 → Multibox), rechts die drei Knöpfe,
-- Rechtsklick → Einstellungen
-- /mbx         Fenster auf/zu
-- /mbx an|aus  Modus schalten

local API = MondhainAPI
local db
local SIZE = 46            -- Ben 26.11. 05:13: größer
local PAD = 8
local CHECK_W = 58          -- Spalte links für den Haken „aktiv“

local DEFAULTS = {
    on = false,
    leader = "",
    seq = {},
    seqLen = 5,                -- wie viele Zauber die Folge hat (1–10)
    reset = "target",
    heal = nil,
    mount = nil,
    keys = { "1", "2", "3", "4" },
    buffs = {},                -- [Charname] = Zaubername
    showButtons = true,
    bar = { point = { "CENTER", "UIParent", "CENTER", 0, -190 } },
}
local RESETS = {
    { key = "target",        label = "Neustart bei neuem Ziel" },
    { key = "target/combat", label = "Neustart bei neuem Ziel oder Kampfende" },
    { key = "",              label = "kein Neustart" },
}
local ICON_ASSIST = "Interface\\Icons\\Ability_DualWield"
local ICON_FOLLOW = "Interface\\Icons\\Ability_Rogue_Sprint"
local ICON_HEAL   = "Interface\\Icons\\Spell_Holy_Heal"
local ICON_MOUNT  = "Interface\\Icons\\Ability_Mount_RidingHorse"
local ICON_BUFF   = "Interface\\Icons\\Spell_Holy_FistOfJustice"
local N = 4
local REBUFF = 60           -- Sekunden Rest, ab dann gilt der Buff als „fällig“
-- Auswahl im Fenster: nur, was der Char kennt
local BUFF_CANDIDATES = {
    "Segen der Macht", "Segen der Weisheit", "Segen der Könige", "Segen des Refugiums",
    "Segen des Lichts", "Segen der Rettung",
    "Mal der Wildnis", "Dornen",
    "Machtwort: Seelenstärke", "Göttlicher Willen", "Schattenschutz",
    "Arkane Intelligenz", "Magie dämpfen", "Magie verstärken",
}
local following = false     -- AUTOFOLLOW_BEGIN/END

local function say(msg)
    if API and API.Print then API.Print(msg) else print("|cffff7d0aMultibox:|r " .. msg) end
end

local function leader()
    local n = db.leader and db.leader:gsub("^%s+", ""):gsub("%s+$", "") or ""
    return n ~= "" and n or "party1"
end

local function spellIcon(name)
    if not name then return nil end
    if C_Spell and C_Spell.GetSpellTexture then
        local ok, t = pcall(C_Spell.GetSpellTexture, name)
        if ok and t then return t end
    end
    if GetSpellTexture then
        local ok, t = pcall(GetSpellTexture, name)
        if ok and t then return t end
    end
    return nil
end

---------------------------------------------------------------------------
-- Makros
---------------------------------------------------------------------------
local SEQ_MAX = 10
local function seqList()
    local list = {}
    for i = 1, math.max(1, math.min(SEQ_MAX, db.seqLen or 5)) do
        if db.seq[i] and db.seq[i] ~= "" then list[#list + 1] = db.seq[i] end
    end
    return list
end

local function macro1()
    local t = "/assist " .. leader()
    local list = seqList()
    if #list > 0 then
        local r = (db.reset and db.reset ~= "") and ("reset=" .. db.reset .. " ") or ""
        t = t .. "\n/castsequence " .. r .. table.concat(list, ", ")
    end
    return t
end
-- Ben 26.11.: Taste 2 wechselt nach Lage – läuft schon Folgen und sitzt der
-- Char nicht auf, wird daraus „Reittier rufen“; danach wieder Folgen.
local function mountMode()
    return db.mount and following and not IsMounted()
end
local function macro2()
    if mountMode() then return "/cast " .. db.mount end
    return "/follow " .. leader()
end
local function macro3()
    if db.heal then return ("/cast [@%s,help,nodead] %s"):format(leader(), db.heal) end
    return "/target " .. leader()
end

-- Taste 4: wer braucht seinen Buff? Fehlend zuerst, sonst der kürzeste Rest.
local UNITS = { "player", "party1", "party2", "party3", "party4" }
local function auraLeft(unit, spell)
    for _, n in ipairs({ spell, "Großer " .. spell }) do
        local exp
        if C_UnitAuras and C_UnitAuras.GetAuraDataBySpellName then
            local ok, a = pcall(C_UnitAuras.GetAuraDataBySpellName, unit, n, "HELPFUL")
            if ok and type(a) == "table" then
                exp = a.expirationTime
                if type(exp) ~= "number" then return 9999 end   -- geschützt/unbekannt: als da werten
            end
        elseif AuraUtil and AuraUtil.FindAuraByName then
            local ok, name, _, _, _, _, e = pcall(AuraUtil.FindAuraByName, n, unit, "HELPFUL")
            if ok and name then exp = type(e) == "number" and e or 0 end
        end
        if exp then
            if exp == 0 then return 9999 end
            return exp - GetTime()
        end
    end
    return nil
end
local function inRange(spell, unit)
    if unit == "player" then return true end
    local f = (C_Spell and C_Spell.IsSpellInRange) or IsSpellInRange
    if not f then return true end
    local ok, r = pcall(f, spell, unit)
    if not ok then return true end
    return r ~= false and r ~= 0
end
local function buffTarget()
    local best, bestLeft
    for _, u in ipairs(UNITS) do
        if UnitExists(u) and UnitIsConnected(u) and not UnitIsDeadOrGhost(u) then
            local spell = db.buffs[UnitName(u) or ""]
            if spell and inRange(spell, u) then
                local left = auraLeft(u, spell)
                if not left then left = -1 end
                if left < REBUFF and (not bestLeft or left < bestLeft) then
                    best, bestLeft = { unit = u, spell = spell, name = UnitName(u) }, left
                end
            end
        end
    end
    return best
end
local function macro4()
    local t = buffTarget()
    if t then return ("/cast [@%s] %s"):format(t.unit, t.spell), t end
    return "", nil
end

---------------------------------------------------------------------------
-- Knöpfe (auch auf dem Bildschirm) und Tasten
---------------------------------------------------------------------------
local bar, check, checkText, owner
local btn = {}
local pending = false
local refreshPanel

local LABELS = { "Assist + Zauberfolge", "Folgen", "Heilen", "Buffs nachlegen" }
local function makeButton(i)
    local b = CreateFrame("CheckButton", "MondhainMultiboxButton" .. i, bar, "SecureActionButtonTemplate")
    b:SetSize(SIZE, SIZE)
    if API and API.SkinButton then
        API.SkinButton(b, SIZE)
    else
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetAllPoints()
        b.HotKey = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmallGray")
        b.HotKey:SetPoint("TOPRIGHT", -2, -2)
    end
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("useOnKeyDown", GetCVarBool and GetCVarBool("ActionButtonUseKeyDown") or false)
    b:SetAttribute("type", "macro")
    b:SetPoint("LEFT", bar, "LEFT", PAD + CHECK_W + (i - 1) * (SIZE + 6), 0)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(LABELS[i], 1, 0.49, 0.04)
        local mt = self:GetAttribute("macrotext") or ""
        if i == 4 and mt == "" then mt = "alle haben ihren Buff" end
        GameTooltip:AddLine(mt:gsub("\n", "|n"), 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    btn[i] = b
end

local last4
local function apply()
    if not bar then return end
    if InCombatLockdown() then
        pending = true
        return
    end
    pending = false
    local m4, t4 = macro4()
    last4 = m4
    local texts = { macro1(), macro2(), macro3(), m4 }
    local list = seqList()
    local icons = { spellIcon(list[1]) or ICON_ASSIST,
        mountMode() and (spellIcon(db.mount) or ICON_MOUNT) or ICON_FOLLOW,
        spellIcon(db.heal) or ICON_HEAL,
        t4 and spellIcon(t4.spell) or ICON_BUFF }
    for i = 1, N do
        local b = btn[i]
        b:SetAttribute("macrotext", texts[i])
        b.icon:SetTexture(icons[i])
        -- aus: Knöpfe bleiben zum Zeigen, nur blass; die Tasten gehören dann den Leisten
        b.icon:SetDesaturated(not db.on or (i == 4 and not t4))
        b:SetAlpha(db.on and 1 or 0.55)
        if b.HotKey then
            b.HotKey:SetText(db.on and (db.keys[i] or "") or "")
            b.HotKey:Show()
        end
        b:Show()
    end
    ClearOverrideBindings(owner)
    if db.on then
        for i = 1, N do
            local k = db.keys[i]
            if k and k ~= "" then
                SetOverrideBindingClick(owner, true, k, btn[i]:GetName(), "LeftButton")
            end
        end
    end
    bar:SetShown(db.showButtons ~= false)
    check:SetChecked(db.on)
    checkText:SetText(db.on and "|cff7fff7faktiv|r" or "|cff999999aus|r")
    bar:SetBackdropBorderColor(db.on and 0.95 or 0.55, db.on and 0.70 or 0.40, db.on and 0.25 or 0.15, 1)
    if refreshPanel then refreshPanel() end
end

-- nur Taste 4 frisch halten (Ticker/Auren), ohne Tasten neu zu binden
local function updateBuff()
    if not bar or not btn[4] or InCombatLockdown() then return end
    local m4, t4 = macro4()
    if m4 == last4 then return end
    last4 = m4
    local b = btn[4]
    b:SetAttribute("macrotext", m4)
    b.icon:SetTexture(t4 and spellIcon(t4.spell) or ICON_BUFF)
    b.icon:SetDesaturated(not db.on or not t4)
end

local function setMode(v)
    if InCombatLockdown() then
        say("Im Kampf lässt sich der Modus nicht umschalten.")
        return
    end
    db.on = v and true or false
    apply()
    say(db.on and ("Multibox-Modus |cff7fff7fan|r – 1 Assist + Zauberfolge, 2 Folgen, 3 Heilen, 4 Buffs (Anführer: " .. leader() .. ")")
        or "Multibox-Modus |cffff5555aus|r – Tasten wie vorher")
end

local function openPanel()
    if MondhainMultiboxPanel then MondhainMultiboxPanel:SetShown(not MondhainMultiboxPanel:IsShown()) end
end

local function buildBar()
    owner = CreateFrame("Frame")
    -- Leiste mit Rahmen: links der Haken „aktiv“, rechts die drei Knöpfe
    bar = CreateFrame("Frame", "MondhainMultiboxBar", UIParent, "BackdropTemplate")
    bar:SetSize(PAD * 2 + CHECK_W + N * SIZE + (N - 1) * 6, SIZE + PAD * 2)
    bar:SetFrameStrata("MEDIUM")
    bar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 })
    bar:SetBackdropColor(0.05, 0.045, 0.04, 0.85)
    bar:SetBackdropBorderColor(0.55, 0.40, 0.15, 1)
    local p = db.bar.point
    bar:SetPoint(p[1], UIParent, p[3], p[4], p[5])
    bar:EnableMouse(true)
    bar:SetScript("OnMouseUp", function(_, mouse) if mouse == "RightButton" then openPanel() end end)

    -- Haken an: Tasten 1–3 gehören dem Multibox; Haken aus: wieder den Leisten
    check = CreateFrame("CheckButton", nil, bar, "UICheckButtonTemplate")
    check:SetSize(32, 32)
    check:SetPoint("TOP", bar, "TOPLEFT", PAD + CHECK_W / 2 - 2, -PAD + 2)
    check:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    check:SetScript("OnClick", function(self, mouse)
        if mouse == "RightButton" then
            self:SetChecked(db.on)
            openPanel()
            return
        end
        if InCombatLockdown() then
            self:SetChecked(db.on)
            say("Im Kampf lässt sich der Modus nicht umschalten.")
            return
        end
        setMode(self:GetChecked())
    end)
    check:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Multibox", 1, 0.49, 0.04)
        GameTooltip:AddLine("Haken drin: Taste 1 Assist + Zauberfolge, 2 Folgen, 3 Heilen, 4 Buffs", 1, 1, 1, true)
        GameTooltip:AddLine("Haken raus: Tasten wie auf deinen Leisten", 1, 1, 1, true)
        GameTooltip:AddLine("Rechtsklick: Einstellungen · am Rahmen ziehen: verschieben", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    check:SetScript("OnLeave", GameTooltip_Hide)
    checkText = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    checkText:SetPoint("TOP", check, "BOTTOM", 0, 2)

    for i = 1, N do makeButton(i) end
    -- Ben 26.11. 06:34: jederzeit verschiebbar – am Rahmen ziehen (nicht im Kampf)
    bar:SetMovable(true)
    bar:SetClampedToScreen(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart", function(self)
        if InCombatLockdown() then return end
        self:StartMoving()
    end)
    bar:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local a, _, rp, x, y = self:GetPoint()
        db.bar.point = { a, "UIParent", rp, x, y }
    end)
    if API and API.MakeMovable then API.MakeMovable(bar, db.bar, "Multibox-Leiste") end
end

---------------------------------------------------------------------------
-- Einstellungsfenster: Anführer, 5 Plätze für die Zauberfolge, Heilzauber
---------------------------------------------------------------------------
local function cursorSpell()
    local kind, a, b, c = GetCursorInfo()
    if kind == "mount" then
        local J = C_MountJournal
        if J then
            for _, id in ipairs({ a, b }) do
                if type(id) == "number" then
                    local ok, n = pcall(J.GetMountInfoByID, id)
                    if ok and n then return n end
                    ok, n = pcall(J.GetDisplayedMountInfo, id)
                    if ok and n then return n end
                end
            end
        end
        return nil
    end
    if kind ~= "spell" then return nil end
    local name
    if type(c) == "number" and C_Spell and C_Spell.GetSpellName then
        local ok, n = pcall(C_Spell.GetSpellName, c)
        if ok then name = n end
    end
    if not name and type(c) == "number" and GetSpellInfo then
        local ok, n = pcall(GetSpellInfo, c)
        if ok then name = n end
    end
    if not name and GetSpellBookItemName and a and b then
        local ok, n = pcall(GetSpellBookItemName, a, b)
        if ok then name = n end
    end
    return name
end

local function slotButton(parent, get, set)
    local s = CreateFrame("Button", nil, parent, "BackdropTemplate")
    s:SetSize(34, 34)
    s:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    s:SetBackdropColor(0.10, 0.08, 0.06, 0.9)
    s:SetBackdropBorderColor(0.55, 0.40, 0.15, 1)
    s.icon = s:CreateTexture(nil, "ARTWORK")
    s.icon:SetPoint("TOPLEFT", 2, -2)
    s.icon:SetPoint("BOTTOMRIGHT", -2, 2)
    s.plus = s:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    s.plus:SetPoint("CENTER")
    s.plus:SetText("+")
    local function take()
        local name = cursorSpell()
        if name then
            ClearCursor()
            set(name)
            apply()
        end
    end
    s:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    s:SetScript("OnReceiveDrag", take)
    s:SetScript("OnClick", function(_, mouse)
        if mouse == "RightButton" then
            set(nil)
            apply()
        else
            take()
        end
    end)
    s:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        local n = get()
        if n then GameTooltip:AddLine(n, 1, 1, 1) else GameTooltip:AddLine("Zauber aus dem Zauberbuch hierher ziehen", 1, 1, 1) end
        GameTooltip:AddLine("Rechtsklick: leeren", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    s:SetScript("OnLeave", GameTooltip_Hide)
    s.refresh = function()
        local n = get()
        local ic = spellIcon(n)
        s.icon:SetTexture(ic)
        s.icon:SetShown(ic ~= nil)
        s.plus:SetShown(not n)
    end
    return s
end

local function buildPanel()
    local f = CreateFrame("Frame", "MondhainMultiboxPanel", UIParent, "BackdropTemplate")
    f:SetSize(460, 620)
    f:SetPoint("CENTER", 0, 60)
    f:SetFrameStrata("DIALOG")
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    f:SetBackdropColor(0.05, 0.045, 0.04, 0.96)
    f:SetBackdropBorderColor(0.55, 0.40, 0.15, 1)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:Hide()
    tinsert(UISpecialFrames, "MondhainMultiboxPanel")

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 2, 2)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -14)
    title:SetText("|cffff7d0aMultibox|r  |cff888888(privat)|r")

    local y = -46
    local function label(text, yy, font)
        local t = f:CreateFontString(nil, "OVERLAY", font or "GameFontNormal")
        t:SetPoint("TOPLEFT", 16, yy)
        t:SetJustifyH("LEFT")
        t:SetText(text)
        return t
    end

    local mode = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    mode:SetSize(220, 26)
    mode:SetPoint("TOPLEFT", 16, y)
    mode:SetScript("OnClick", function() setMode(not db.on) end)
    y = y - 38

    label("Anführer (Name; leer = Gruppenmitglied 1)", y)
    local eb = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    eb:SetSize(180, 22)
    eb:SetPoint("TOPLEFT", 260, y + 4)
    eb:SetAutoFocus(false)
    local function saveLeader(self)
        db.leader = self:GetText() or ""
        self:ClearFocus()
        apply()
    end
    eb:SetScript("OnEnterPressed", saveLeader)
    eb:SetScript("OnEditFocusLost", saveLeader)
    eb:SetScript("OnEscapePressed", function(self) self:SetText(db.leader or ""); self:ClearFocus() end)
    y = y - 34

    label("Taste 1 – Assist + Zauberfolge (Zauber hineinziehen, Rechtsklick leert)", y)
    y = y - 22
    -- Länge der Folge: [-] n [+]
    local lenText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    lenText:SetPoint("TOPLEFT", 16, y - 5)
    lenText:SetWidth(92)
    lenText:SetJustifyH("LEFT")
    lenText:SetText("Zauber in Folge:")
    local function lenBtn(txt, dx, d)
        local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        b:SetSize(24, 22)
        b:SetPoint("TOPLEFT", dx, y)
        b:SetText(txt)
        b:SetScript("OnClick", function()
            db.seqLen = math.max(1, math.min(SEQ_MAX, (db.seqLen or 5) + d))
            apply()
        end)
        return b
    end
    lenBtn("–", 110, -1)
    lenBtn("+", 168, 1)
    local lenNum = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    lenNum:SetPoint("TOPLEFT", 136, y - 5)
    lenNum:SetWidth(30)
    local resetBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    resetBtn:SetSize(220, 24)
    resetBtn:SetPoint("TOPLEFT", 226, y)
    y = y - 30
    local slots = {}
    for i = 1, SEQ_MAX do
        local s = slotButton(f, function() return db.seq[i] end, function(n) db.seq[i] = n end)
        s:SetPoint("TOPLEFT", 16 + (i - 1) * 40, y)
        slots[i] = s
    end
    resetBtn:SetScript("OnClick", function()
        local idx = 1
        for i, r in ipairs(RESETS) do if r.key == db.reset then idx = i end end
        db.reset = RESETS[idx % #RESETS + 1].key
        apply()
    end)
    y = y - 46

    label("Taste 2 – dem Anführer folgen; folgst du schon, ruft sie dein Reittier", y)
    y = y - 22
    local mountSlot = slotButton(f, function() return db.mount end, function(n) db.mount = n end)
    mountSlot:SetPoint("TOPLEFT", 16, y)
    local mt = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    mt:SetPoint("LEFT", mountSlot, "RIGHT", 8, 0)
    mt:SetWidth(380)
    mt:SetJustifyH("LEFT")
    mt:SetText("Reittier aus der Sammlung oder Zauber (z. B. Schlachtross beschwören) hierher ziehen. Leer = immer nur Folgen.")
    y = y - 46

    label("Taste 3 – Heilzauber auf den Anführer", y)
    y = y - 22
    local healSlot = slotButton(f, function() return db.heal end, function(n) db.heal = n end)
    healSlot:SetPoint("TOPLEFT", 16, y)
    y = y - 46

    label("Taste 4 – Buffs nachlegen: wer seinen Buff nicht hat oder unter 1 Min.", y)
    y = y - 22
    -- Auswahlliste (eigenes kleines Menü, kein UIDropDownMenu)
    local menu = CreateFrame("Frame", nil, f, "BackdropTemplate")
    menu:SetFrameStrata("FULLSCREEN_DIALOG")
    menu:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    menu:SetBackdropColor(0.06, 0.05, 0.04, 0.98)
    menu:SetBackdropBorderColor(0.55, 0.40, 0.15, 1)
    menu:EnableMouse(true)
    menu:Hide()
    menu.items = {}
    local function openMenu(anchor, who, onPick)
        local list = { false }
        for _, n in ipairs(BUFF_CANDIDATES) do if spellIcon(n) then list[#list + 1] = n end end
        if #list == 1 then for _, n in ipairs(BUFF_CANDIDATES) do list[#list + 1] = n end end
        for k, it in ipairs(menu.items) do it:Hide() end
        for k, n in ipairs(list) do
            local it = menu.items[k]
            if not it then
                it = CreateFrame("Button", nil, menu)
                it:SetSize(200, 18)
                it.t = it:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                it.t:SetPoint("LEFT", 6, 0)
                it:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight", "ADD")
                menu.items[k] = it
            end
            it:SetPoint("TOPLEFT", 4, -4 - (k - 1) * 18)
            it.t:SetText(n or "|cff999999– kein Buff –|r")
            it:SetScript("OnClick", function() menu:Hide(); onPick(n or nil) end)
            it:Show()
        end
        menu:SetSize(208, 8 + #list * 18)
        menu:ClearAllPoints()
        menu:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
        menu:Show()
    end
    local rows = {}
    for r = 1, 5 do
        local row = {}
        row.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.name:SetPoint("TOPLEFT", 20, y - 5)
        row.name:SetWidth(130)
        row.name:SetJustifyH("LEFT")
        row.pick = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        row.pick:SetSize(220, 22)
        row.pick:SetPoint("TOPLEFT", 156, y)
        row.pick:SetScript("OnClick", function(self)
            local who = row.who
            if not who then return end
            if menu:IsShown() then menu:Hide() return end
            openMenu(self, who, function(n) db.buffs[who] = n; apply() end)
        end)
        rows[r] = row
        y = y - 24
    end
    y = y - 10

    local show = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
    show:SetSize(24, 24)
    show:SetPoint("TOPLEFT", 12, y)
    show:SetScript("OnClick", function(self)
        if InCombatLockdown() then self:SetChecked(db.showButtons ~= false) return end
        db.showButtons = self:GetChecked() and true or false
        apply()
    end)
    local st = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    st:SetPoint("LEFT", show, "RIGHT", 4, 0)
    st:SetText("Leiste auf dem Bildschirm zeigen (verschieben im Mondhain-Bearbeiten-Modus)")
    y = y - 34

    label("So sehen die Makros aus:", y, "GameFontNormalSmall")
    y = y - 16
    local preview = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    preview:SetPoint("TOPLEFT", 16, y)
    preview:SetWidth(428)
    preview:SetJustifyH("LEFT")
    preview:SetJustifyV("TOP")

    refreshPanel = function()
        mode:SetText(db.on and "Multibox-Modus: |cff7fff7fAN|r" or "Multibox-Modus: |cffff5555AUS|r")
        if not eb:HasFocus() then eb:SetText(db.leader or "") end
        local n = math.max(1, math.min(SEQ_MAX, db.seqLen or 5))
        lenNum:SetText(n)
        for i = 1, SEQ_MAX do
            slots[i]:SetShown(i <= n)
            if i <= n then slots[i].refresh() end
        end
        healSlot.refresh()
        mountSlot.refresh()
        for r = 1, 5 do
            local u = UNITS[r]
            local row = rows[r]
            local nm = UnitExists(u) and UnitName(u) or nil
            row.who = nm
            if nm then
                row.name:SetText((r == 1 and "|cffd8b26eDu|r  " or "") .. nm)
                row.pick:SetText(db.buffs[nm] or "|cff999999– kein Buff –|r")
                row.pick:Show()
            else
                row.name:SetText(r == 2 and "|cff777777(niemand in der Gruppe)|r" or "")
                row.pick:Hide()
            end
        end
        local lbl = RESETS[1].label
        for _, r in ipairs(RESETS) do if r.key == db.reset then lbl = r.label end end
        resetBtn:SetText(lbl)
        show:SetChecked(db.showButtons ~= false)
        local m4 = macro4()
        preview:SetText(("|cffd8b26e1:|r %s\n|cffd8b26e2:|r %s\n|cffd8b26e3:|r %s\n|cffd8b26e4:|r %s"):format(
            macro1():gsub("\n", "  ·  "), macro2(), macro3(), m4 ~= "" and m4 or "(alle gebufft)"))
    end
    f:SetScript("OnShow", refreshPanel)
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
ev:RegisterEvent("AUTOFOLLOW_BEGIN")
ev:RegisterEvent("AUTOFOLLOW_END")
ev:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("UNIT_AURA")
ev:SetScript("OnEvent", function(_, event, unit)
    if event == "PLAYER_LOGIN" then
        MondhainMultiboxDB = MondhainMultiboxDB or {}
        db = MondhainMultiboxDB
        for k, v in pairs(DEFAULTS) do
            if db[k] == nil then
                if type(v) == "table" then
                    db[k] = {}
                    for k2, v2 in pairs(v) do db[k][k2] = v2 end
                else
                    db[k] = v
                end
            end
        end
        if db.keys[4] == nil then db.keys[4] = "4" end
        db.buffs = db.buffs or {}
        API = MondhainAPI
        buildBar()
        buildPanel()
        apply()
        if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(1, updateBuff) end
    elseif event == "UNIT_AURA" then
        if unit == "player" or (unit and unit:find("^party%d")) then updateBuff() end
    elseif event == "GROUP_ROSTER_UPDATE" then
        if db and bar then apply() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if pending then apply() end
    elseif event == "AUTOFOLLOW_BEGIN" or event == "AUTOFOLLOW_END" or event == "PLAYER_MOUNT_DISPLAY_CHANGED" then
        if event == "AUTOFOLLOW_BEGIN" then following = true elseif event == "AUTOFOLLOW_END" then following = false end
        if db and bar then apply() end
    end
end)

SLASH_MONDHAINMULTIBOX1 = "/mbx"
SLASH_MONDHAINMULTIBOX2 = "/multibox"
SlashCmdList.MONDHAINMULTIBOX = function(msg)
    if not db then return end
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "an" or msg == "on" then
        setMode(true)
    elseif msg == "aus" or msg == "off" then
        setMode(false)
    else
        MondhainMultiboxPanel:SetShown(not MondhainMultiboxPanel:IsShown())
    end
end
