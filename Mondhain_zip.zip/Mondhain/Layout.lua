-- Mondhain – Grundaufstellung
-- Setzt alle Elemente auf die verabredeten Plätze (Zahlen in UI-Einheiten):
--
--   Parkleiste                      Gestaltleiste / Zauberleiste       Mikromenü, Taschen
--   Chat | Minikarte | Vorrat       Leiste 1 · 2 · 3                   Questtracker (2 Spalten)
--
-- Höhe unten: etwa ein Fünftel des Bildschirms. Wird einmalig beim Umstieg
-- gesetzt und lässt sich mit /mh grundaufstellung jederzeit wiederherstellen.

local _, ns = ...

local CHAT_W = 390   -- Platz, den der Chat links bekommt
local EDGE = 8       -- Abstand zum Bildschirmrand
local BARS_Y = 30    -- Leisten so hoch, dass darunter die EP-Ranke in der Mulde Platz hat

local function P(point, rel, x, y) return { point, "UIParent", rel, x, y } end

-- Über den Leisten: ganz unten der Schwungtimer (Waffenhand), darüber der
-- Zauberbalken, darüber Schildhand und Distanz (für Druiden meist leer).
function ns.DefaultSwingPoints(db)
    db.blizz.swingMain   = { point = P("BOTTOM", "BOTTOM", 0, 184) }
    db.blizz.cast        = { point = P("BOTTOM", "BOTTOM", 0, 208) }
    db.blizz.swingOff    = { point = P("BOTTOM", "BOTTOM", 0, 232) }
    db.blizz.swingRanged = { point = P("BOTTOM", "BOTTOM", 0, 256) }
end

-- Wurzel: Leisten anheben, Schwung/Zauber/Absteigen mit nach oben (Rest bleibt)
function ns.RootShift(db)
    db.actionBars.center.point = P("BOTTOM", "BOTTOM", 0, BARS_Y / 1.25)
    ns.DefaultSwingPoints(db)
    ns.DefaultLeavePoint(db)
end

-- Mitte: Schwung/Zauber über den Leisten, Gestaltleiste unter dem Spielerfenster
-- Absteigen-Knopf links neben Leiste 1 (Mitte der obersten Reihe)
function ns.DefaultLeavePoint(db)
    db.blizz.leave = { point = P("RIGHT", "BOTTOM", -206, 152) }
end

function ns.CenterStackPoints(db)
    ns.DefaultSwingPoints(db)
    ns.DefaultLeavePoint(db)
    db.stanceBar.point = P("BOTTOMRIGHT", "BOTTOM", -240, EDGE)
    db.stanceBar.scale = nil
end

function ns.ApplyDefaultLayout()
    local db = ns.db
    local map = db.minimapFrame.size or 150
    -- Ben 26.11. 06:20: gebaut für Bens Breitbild; Steve hat 16:9. Bei schmalem
    -- Bild (UI-Breite unter 2200) wird alles kompakter: schmalerer Chat und
    -- Questtracker, Leisten 100 % statt 125 %, Spieler/Ziel über die Leisten
    local W = UIParent:GetWidth() or 1920
    local narrow = W < 2200
    local chatW = narrow and math.max(260, math.min(CHAT_W, math.floor(W * 0.19))) or CHAT_W

    -- Links: Chat, Minikarte, Vorratsleiste; darüber die Parkleiste
    db.chat.point = P("BOTTOMLEFT", "BOTTOMLEFT", EDGE, EDGE)
    db.chat.width = chatW
    db.chat.height = 150
    db.minimapFrame.point = P("BOTTOMLEFT", "BOTTOMLEFT", EDGE + chatW + EDGE, EDGE)
    db.minimapFrame.scale = nil
    db.minimapFrame.boardLeft = {}  -- Tafeln wieder an Karte und Leisten
    db.minimapFrame.boardRight = {}
    db.minimapFrame.boardLeftSide = narrow and "right" or nil  -- schmal: Tafel rechts an die Karte
    db.stanceBar.inBoard = true
    -- Vorratsleiste hängt rechts an der Karte und wandert mit
    db.itemBar.followMap = true
    db.itemBar.point = P("BOTTOMLEFT", "BOTTOMLEFT", EDGE + chatW + EDGE + map + 6, EDGE)
    db.itemBar.vertical = true
    db.itemBar.scale = nil
    -- Parkleiste über dem Chat, mit Luft zu den Chat-Reitern
    db.actionBars.park.point = P("BOTTOMLEFT", "BOTTOMLEFT", EDGE, 190)
    db.actionBars.park.scale = 0.8

    -- Mitte: drei Leisten (Größe 125 %), darüber Gestalt- und Zauberleiste
    db.actionBars.center.point = P("BOTTOM", "BOTTOM", 0, narrow and EDGE or BARS_Y / 1.25)
    db.actionBars.center.scale = narrow and 1.0 or 1.25
    ns.CenterStackPoints(db)

    -- Einheitenfenster: Spieler links, Ziel rechts neben den Leisten (16:9-Ausschnitt passt)
    local u = db.unitFrames
    if narrow then
        -- kein Platz neben den Leisten: über Ast/Zauberbalken, links und rechts der Mitte
        u.player.point = P("BOTTOMRIGHT", "BOTTOM", -20, 290); u.player.scale = nil
        u.target.point = P("BOTTOMLEFT", "BOTTOM", 20, 290); u.target.scale = nil
        u.targettarget.point = P("BOTTOMLEFT", "BOTTOM", 290, 290); u.targettarget.scale = nil
    else
        u.player.point = P("BOTTOMRIGHT", "BOTTOM", -240, 46); u.player.scale = nil
        u.target.point = P("BOTTOMLEFT", "BOTTOM", 240, 46); u.target.scale = nil
        u.targettarget.point = P("BOTTOMLEFT", "BOTTOM", 508, 46); u.targettarget.scale = nil
    end
    u.pet.point = narrow and P("BOTTOMLEFT", "BOTTOM", 20, 250) or P("BOTTOMLEFT", "BOTTOM", 240, EDGE); u.pet.scale = nil

    -- Eigene Stärkungen/Schwächungen oben rechts untereinander
    db.auras.buffs.point = P("TOPRIGHT", "TOPRIGHT", -14, -14); db.auras.buffs.scale = nil
    db.auras.debuffs.point = P("TOPRIGHT", "TOPRIGHT", -14, -170); db.auras.debuffs.scale = nil

    -- Gruppenfenster links über dem Spieler, Schlachtzug darüber
    local g = db.groupFrames
    if narrow then
        g.party.point = P("BOTTOMRIGHT", "BOTTOM", -280, 290); g.party.scale = nil
        g.raid.point = P("BOTTOMRIGHT", "BOTTOM", -280, 400); g.raid.scale = nil
    else
        g.party.point = P("BOTTOMRIGHT", "BOTTOM", -240, 124); g.party.scale = nil
        g.raid.point = P("BOTTOMRIGHT", "BOTTOM", -240, 216); g.raid.scale = nil
    end

    -- Rechts: Questtracker flach und zweispaltig, darüber Mikromenü und Taschen
    local q = db.questTracker
    q.point = P("BOTTOMRIGHT", "BOTTOMRIGHT", -12, EDGE)
    q.width = narrow and math.max(360, math.min(680, math.floor(W * 0.27))) or 680
    q.height = 150
    q.scale = nil
    db.blizz.micro = { point = P("BOTTOMRIGHT", "BOTTOMRIGHT", -12, EDGE + 158) }
    db.blizz.bags  = { point = P("BOTTOMRIGHT", "BOTTOMRIGHT", -12, EDGE + 198) }
    db.menuButton.point = P("BOTTOMRIGHT", "BOTTOMRIGHT", -12, EDGE + 238)
    db.menuButton.scale = nil
end
