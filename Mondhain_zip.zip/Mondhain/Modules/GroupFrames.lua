-- Mondhain – Gruppenfenster
-- Zwei Varianten:
--   Gruppe (bis 5):   größere Rahmen untereinander, links über dem Spieler
--   Schlachtzug:      kompaktes Raster, eine Spalte je Untergruppe
--
-- Klickzauber direkt auf den Rahmen: Linksklick = anvisieren, Rechtsklick =
-- Verjüngung (vorbelegt), weitere Maustasten mit Shift/Strg/Alt frei belegbar.
-- Mouseover-Heilen über die Leisten kommt zusätzlich aus den Aktionstasten.
--
-- Anzeige: Name · Leben · Mana (bei Mana-Nutzern) · eigene HoTs oben rechts ·
-- Rahmen leuchtet bei entfernbaren Schwächungen · außer Reichweite blasser.

local _, ns = ...
local mod = ns.NewModule("GroupFrames")
ns.GroupFrames = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local FONT = STANDARD_TEXT_FONT
local db
local headers = {}
local buttons = {}

-- Zeilen im Klickzauber-Editor: Schlüssel = Blizzard-Attributpräfix + Maustaste
mod.CLICK_ROWS = {
    { key = "2",       label = "Rechtsklick" },
    { key = "3",       label = "Mittelklick" },
    { key = "shift-1", label = "Shift + Linksklick" },
    { key = "shift-2", label = "Shift + Rechtsklick" },
    { key = "ctrl-1",  label = "Strg + Linksklick" },
    { key = "ctrl-2",  label = "Strg + Rechtsklick" },
    { key = "alt-1",   label = "Alt + Linksklick" },
    { key = "alt-2",   label = "Alt + Rechtsklick" },
    { key = "4",       label = "Maustaste 4" },
    { key = "5",       label = "Maustaste 5" },
}

local function isSecret(v) return ns.isSecret(v) end
local function dim(r, g, b)
    local k = ((ns.db.unitFrames.look and ns.db.unitFrames.look.colorPct) or 55) / 100
    return r * k, g * k, b * k
end

---------------------------------------------------------------------------
-- Anzeige eines Rahmens
---------------------------------------------------------------------------
local function classColor(u)
    local _, class = UnitClass(u)
    local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    if c then return dim(c.r, c.g, c.b) end
    return dim(0.25, 0.72, 0.30)
end

local function setBar(bar, cur, max)
    pcall(bar.SetMinMaxValues, bar, 0, max or 1)
    pcall(bar.SetValue, bar, cur or 0)
end

local function updateHealth(b)
    local u = b.unit
    setBar(b.health, UnitHealth(u), UnitHealthMax(u))
    ns.UpdateHealPrediction(b.health, u)
    if not UnitIsConnected(u) then
        b.status:SetText("off")
    elseif UnitIsDeadOrGhost(u) then
        b.status:SetText("tot")
    elseif b.big then
        local s = ns.FormatNumber and ns.FormatNumber(UnitHealth(u))
        if not pcall(b.status.SetText, b.status, s or UnitHealth(u)) then b.status:SetText("") end
    else
        b.status:SetText("")
    end
end

local function updatePower(b)
    local u = b.unit
    local ptype = UnitPowerType(u)
    if ptype == 0 then
        b.power:Show()
        setBar(b.power, UnitPower(u, 0), UnitPowerMax(u, 0))
    else
        b.power:Hide()
    end
end

-- Farben wie Blizzards Schwächungsfarben (Retail/Forever)
local DISPEL_COLORS = {
    Magic = { 0.20, 0.60, 1.00 }, Curse = { 0.60, 0.00, 1.00 },
    Disease = { 0.60, 0.40, 0.00 }, Poison = { 0.00, 0.60, 0.00 },
}
local DISPEL_ENUM = { Magic = 1, Curse = 2, Disease = 3, Poison = 4 }
local DISPEL_ATLAS = {
    Magic = "RaidFrame-Icon-DebuffMagic", Curse = "RaidFrame-Icon-DebuffCurse",
    Disease = "RaidFrame-Icon-DebuffDisease", Poison = "RaidFrame-Icon-DebuffPoison",
}

-- Was kann ich bannen? (bekannte Zauber; Ben 25.11. 16:16: nur bannbare)
local CAN = {}
local DISPEL_SPELLS = {
    { 2782, { "Curse" } },            -- Fluch aufheben (Druide)
    { 2893, { "Poison" } },           -- Vergiftung aufheben (Druide)
    { 8946, { "Poison" } },           -- Vergiftung heilen (Druide)
    { 475, { "Curse" } },             -- Geringen Fluch aufheben (Magier)
    { 527, { "Magic" } },             -- Magiebannung (Priester)
    { 528, { "Disease" } }, { 552, { "Disease" } },
    { 1152, { "Poison", "Disease" } },               -- Läutern (Paladin)
    { 4987, { "Magic", "Poison", "Disease" } },      -- Reinigung des Glaubens (Paladin)
    { 526, { "Poison" } }, { 2870, { "Disease" } },  -- Schamane
    { 51886, { "Curse" } },                          -- Geist reinigen (Schamane, falls vorhanden)
    { 88423, { "Magic", "Curse", "Poison" } },       -- Natürliche Heilung (falls vorhanden)
}
local function learnDispels()
    wipe(CAN)
    for _, e in ipairs(DISPEL_SPELLS) do
        local known = (IsPlayerSpell and IsPlayerSpell(e[1])) or (IsSpellKnown and IsSpellKnown(e[1]))
        if known then for _, t in ipairs(e[2]) do CAN[t] = true end end
    end
end

-- Farbe im Kampf, wenn der Typ geheim ist: Blizzards Farbkurve (falls vorhanden)
local dispelCurve
local function curveColor(u, inst)
    if not (C_UnitAuras and C_UnitAuras.GetAuraDispelTypeColor and C_CurveUtil and C_CurveUtil.CreateColorCurve) then return end
    if not dispelCurve then
        local ok, c = pcall(C_CurveUtil.CreateColorCurve)
        if not ok or not c then return end
        pcall(c.SetType, c, Enum and Enum.LuaCurveType and Enum.LuaCurveType.Step)
        for name, idx in pairs(DISPEL_ENUM) do
            local col = DISPEL_COLORS[name]
            pcall(c.AddPoint, c, idx, CreateColor(col[1], col[2], col[3], 1))
        end
        dispelCurve = c
    end
    local ok, color = pcall(C_UnitAuras.GetAuraDispelTypeColor, u, inst, dispelCurve)
    if ok and color then return color end
end

local function updateAuras(b)
    local u = b.unit
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return end
    -- Eigene HoTs (oben rechts, max. 3)
    local n = 0
    for i = 1, 40 do
        local ok, data = pcall(C_UnitAuras.GetAuraDataByIndex, u, i, "HELPFUL|PLAYER")
        if not ok or not data then break end
        n = n + 1
        if n > 3 then break end
        local ic = b.hots[n]
        pcall(ic.tex.SetTexture, ic.tex, data.icon)
        if not pcall(function()
            if data.duration and data.duration > 0 then
                ic.cd:SetCooldown(data.expirationTime - data.duration, data.duration)
            else
                ic.cd:Clear()
            end
        end) then ic.cd:Clear() end
        ic:Show()
    end
    for i = n + 1, 3 do b.hots[i]:Hide() end

    -- Bannbare Schwächung (nur, was DU entfernen kannst) wie bei Blizzard:
    -- farbiger Rand, Farbschleier von unten über das Leben, Typ-Zeichen + Symbol
    local found, kind, color
    for i = 1, 40 do
        local ok, data = pcall(C_UnitAuras.GetAuraDataByIndex, u, i, "HARMFUL|RAID")
        if not ok or not data then break end
        local dn = data.dispelName
        if isSecret(dn) then
            -- im Kampf geheim: dem Filter trauen, Farbe über Blizzards Kurve
            found, color = data, curveColor(u, data.auraInstanceID)
            break
        elseif dn and DISPEL_COLORS[dn] and (next(CAN) == nil or CAN[dn]) then
            found, kind = data, dn
            break
        end
    end
    if found then
        local r, g, bl = 1, 0.5, 0
        if kind then
            r, g, bl = unpack(DISPEL_COLORS[kind])
        elseif color then
            r, g, bl = color:GetRGB()
        end
        pcall(b.glow.SetBackdropBorderColor, b.glow, r, g, bl, 1)
        pcall(b.dispelTint.SetVertexColor, b.dispelTint, r, g, bl, 1)
        pcall(b.dispelIconBorder.SetColorTexture, b.dispelIconBorder, r, g, bl, 1)
        pcall(b.dispelIcon.SetTexture, b.dispelIcon, found.icon)
        local atlas = kind and DISPEL_ATLAS[kind]
        if atlas and C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(atlas) then
            b.dispelType:SetAtlas(atlas)
            b.dispelType:Show()
        else
            b.dispelType:Hide()
        end
        b.glow:Show(); b.dispelTint:Show(); b.dispelBox:Show()
    else
        b.glow:Hide(); b.dispelTint:Hide(); b.dispelBox:Hide()
    end
end

local function updateAll(b)
    local u = b:GetAttribute("unit")
    b.unit = u
    if not u or not UnitExists(u) then return end
    local name = UnitName(u)
    if not pcall(b.name.SetText, b.name, name) then b.name:SetText("") end
    b.health:SetStatusBarColor(classColor(u))
    updateHealth(b)
    updatePower(b)
    updateAuras(b)
end

---------------------------------------------------------------------------
-- Aussehen eines Rahmens (wird beim Anlegen durch den Kopf aufgerufen)
---------------------------------------------------------------------------
local function style(b, big, fake)
    if b.mondhainStyled then return end
    b.mondhainStyled = true
    -- Alle Maustasten annehmen (geht nur außerhalb des Kampfes, sonst nach dem Kampf)
    if not fake then
        if not InCombatLockdown() then b:RegisterForClicks("AnyUp") else b.needsClicks = true end
    end
    b.big = big
    -- Inhalt in eigenem Rahmen: Transparenz (Reichweite) ist dort auch im Kampf erlaubt
    local c = CreateFrame("Frame", nil, b, "BackdropTemplate")
    c:SetAllPoints()
    c:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    c:SetBackdropColor(0.04, 0.05, 0.05, 0.85)
    c:SetBackdropBorderColor(unpack(ns.colors.border))
    b.content = c

    b.health = CreateFrame("StatusBar", nil, c)
    b.health:SetStatusBarTexture(WHITE)
    b.health:SetPoint("TOPLEFT", 1, -1)
    b.health:SetPoint("BOTTOMRIGHT", -1, big and 6 or 4)
    local bg = b.health:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.7)

    b.power = CreateFrame("StatusBar", nil, c)
    b.power:SetStatusBarTexture(WHITE)
    b.power:SetPoint("TOPLEFT", b.health, "BOTTOMLEFT", 0, -1)
    b.power:SetPoint("BOTTOMRIGHT", -1, 1)
    b.power:SetStatusBarColor(dim(0.2, 0.45, 1))

    b.name = b.health:CreateFontString(nil, "OVERLAY")
    b.name:SetFont(FONT, big and 12 or 10, "OUTLINE")
    b.name:SetPoint("LEFT", 4, big and 0 or 2)
    b.name:SetPoint("RIGHT", -4, 0)
    b.name:SetJustifyH(big and "LEFT" or "CENTER")
    b.name:SetWordWrap(false)

    b.status = b.health:CreateFontString(nil, "OVERLAY")
    b.status:SetFont(FONT, big and 11 or 9, "OUTLINE")
    if big then
        b.status:SetPoint("RIGHT", -4, 0)
        b.name:SetPoint("RIGHT", b.status, "LEFT", -4, 0)
    else
        b.status:SetPoint("BOTTOM", 0, 1)
    end
    ns.AttachHealPrediction(b.health)

    -- Eigene HoTs
    b.hots = {}
    local hs = big and 14 or 11
    for i = 1, 3 do
        local h = CreateFrame("Frame", nil, c)
        h:SetSize(hs, hs)
        h:SetPoint("TOPRIGHT", -1 - (i - 1) * (hs + 1), -1)
        h:SetFrameLevel(c:GetFrameLevel() + 3)
        h.tex = h:CreateTexture(nil, "ARTWORK")
        h.tex:SetAllPoints()
        h.tex:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        h.cd = CreateFrame("Cooldown", nil, h, "CooldownFrameTemplate")
        h.cd:SetAllPoints()
        h.cd:SetDrawEdge(false)
        h.cd:SetHideCountdownNumbers(true)
        h.cd:SetReverse(true)
        h:Hide()
        b.hots[i] = h
    end

    -- Bannbare Schwächung: farbiger Rand, Farbschleier, Symbol (wie Retail/Forever)
    b.glow = CreateFrame("Frame", nil, c, "BackdropTemplate")
    b.glow:SetPoint("TOPLEFT", -2, 2)
    b.glow:SetPoint("BOTTOMRIGHT", 2, -2)
    b.glow:SetBackdrop({ edgeFile = WHITE, edgeSize = 2 })
    b.glow:SetFrameLevel(c:GetFrameLevel() + 4)
    b.glow:Hide()
    b.dispelTint = b.health:CreateTexture(nil, "ARTWORK", nil, 7)
    b.dispelTint:SetAllPoints(b.health)
    b.dispelTint:SetTexture(WHITE)
    b.dispelTint:SetBlendMode("ADD")
    if b.dispelTint.SetGradient and CreateColor then        -- unten kräftig, oben aus
        pcall(b.dispelTint.SetGradient, b.dispelTint, "VERTICAL", CreateColor(1, 1, 1, 0.55), CreateColor(1, 1, 1, 0))
    else
        b.dispelTint:SetAlpha(0.35)
    end
    b.dispelTint:Hide()
    local ds = big and 18 or 14
    b.dispelBox = CreateFrame("Frame", nil, c)
    b.dispelBox:SetSize(ds, ds)
    b.dispelBox:SetPoint("BOTTOMLEFT", c, "BOTTOMLEFT", 2, big and 7 or 5)
    b.dispelBox:SetFrameLevel(c:GetFrameLevel() + 5)
    b.dispelIconBorder = b.dispelBox:CreateTexture(nil, "BACKGROUND")
    b.dispelIconBorder:SetAllPoints()
    b.dispelIcon = b.dispelBox:CreateTexture(nil, "ARTWORK")
    b.dispelIcon:SetPoint("TOPLEFT", 1, -1)
    b.dispelIcon:SetPoint("BOTTOMRIGHT", -1, 1)
    b.dispelIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.dispelType = b.dispelBox:CreateTexture(nil, "OVERLAY")
    b.dispelType:SetSize(ds * 0.7, ds * 0.7)
    b.dispelType:SetPoint("CENTER", b.dispelBox, "TOPRIGHT", 0, 0)
    b.dispelType:Hide()
    b.dispelBox:Hide()

    -- Maus drüber: Tooltip wie bei Blizzard
    b:HookScript("OnEnter", function(self)
        if self.unit then
            GameTooltip_SetDefaultAnchor(GameTooltip, self)
            pcall(GameTooltip.SetUnit, GameTooltip, self.unit)
        end
    end)
    b:HookScript("OnLeave", GameTooltip_Hide)
    if fake then return end
    b:HookScript("OnAttributeChanged", function(self, attr)
        if attr == "unit" then updateAll(self) end
    end)
    b:HookScript("OnShow", updateAll)
    buttons[#buttons + 1] = b
end

---------------------------------------------------------------------------
-- Klickzauber: Attribute als sichere Anweisung (gilt auch für Rahmen,
-- die mitten im Kampf neu entstehen)
---------------------------------------------------------------------------
local function clickSnippet()
    local lines = { [[self:SetAttribute("*type1", "target")]] }
    for key, spell in pairs(db.clicks) do
        if type(spell) == "string" and spell ~= "" then
            local prefix, btn = key:match("^(.-)(%d)$")
            prefix = prefix or ""
            lines[#lines + 1] = ("self:SetAttribute(%q, \"spell\")"):format(prefix .. "type" .. btn)
            lines[#lines + 1] = ("self:SetAttribute(%q, %q)"):format(prefix .. "spell" .. btn, spell)
        end
    end
    return table.concat(lines, "\n")
end

local function makeHeader(name, cfg, big, setup)
    local h = CreateFrame("Frame", name, UIParent, "SecureGroupHeaderTemplate")
    h:SetAttribute("template", "SecureUnitButtonTemplate")
    h:SetAttribute("initialConfigFunction", ([[
        self:SetWidth(%d)
        self:SetHeight(%d)
        %s
        self:GetParent():CallMethod("StyleButton", self:GetName())
    ]]):format(cfg.w, cfg.h, clickSnippet()))
    h.StyleButton = function(_, btnName)
        local b = _G[btnName]
        if b then style(b, big) end
    end
    setup(h)
    h:ClearAllPoints()
    h:SetPoint(cfg.point[1], UIParent, cfg.point[3], cfg.point[4], cfg.point[5])
    -- Griff zum Verschieben (der Kopf selbst ist geschützt und ändert seine Größe)
    local grip = CreateFrame("Frame", nil, UIParent)
    grip:SetPoint(cfg.point[1], UIParent, cfg.point[3], cfg.point[4], cfg.point[5])
    grip:SetSize(big and cfg.w or (cfg.w + 3) * 8, big and (cfg.h + 4) * 5 or (cfg.h + 3) * 5)
    h:ClearAllPoints()
    h:SetPoint(cfg.point[1], grip, cfg.point[1])
    headers[#headers + 1] = h
    h.grip, h.cfg, h.big = grip, cfg, big
    return h, grip
end

---------------------------------------------------------------------------
-- Testmodus: ausgedachte Mitglieder anzeigen, um Größe und Platz einzurichten
---------------------------------------------------------------------------
local TEST_NAMES = { "Holle", "Mondfeder", "Eichenruf", "Sternklinge", "Wurzelherz", "Nachtschwinge",
    "Silberblatt", "Dornenwacht", "Elunes Licht", "Moosbart", "Rindenfaust", "Lichtung" }
local TEST_CLASSES = { "DRUID", "WARRIOR", "PRIEST", "MAGE", "ROGUE", "HUNTER", "PALADIN", "WARLOCK", "SHAMAN" }
local HOT_ICON = "Interface\\Icons\\Spell_Nature_Rejuvenation"
local testFrames = { party = {}, raid = {} }
local testOn = { party = false, raid = false }

local function testButton(kind, i, parent, cfg, big)
    local list = testFrames[kind]
    if list[i] then return list[i] end
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(cfg.w, cfg.h)
    style(b, big, true)
    -- ausgedachte Werte, immer gleich (damit man vergleichen kann)
    local class = TEST_CLASSES[(i - 1) % #TEST_CLASSES + 1]
    local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    if c then b.health:SetStatusBarColor(dim(c.r, c.g, c.b)) end
    local pct = ({ 100, 82, 45, 63, 18, 100, 91, 37 })[(i - 1) % 8 + 1]
    b.health:SetMinMaxValues(0, 100)
    b.health:SetValue(pct)
    b.name:SetText(TEST_NAMES[(i - 1) % #TEST_NAMES + 1])
    if big then b.status:SetText(ns.FormatNumber and ns.FormatNumber(pct * 31) or (pct * 31)) end
    b.power:SetMinMaxValues(0, 100)
    b.power:SetValue(60)
    b.power:SetShown(class == "DRUID" or class == "PRIEST" or class == "MAGE" or class == "PALADIN")
    if i % 3 == 1 then -- eigener HoT
        b.hots[1].tex:SetTexture(HOT_ICON)
        b.hots[1]:Show()
    end
    if i == 3 then -- bannbarer Fluch (Vorschau)
        b.glow:SetBackdropBorderColor(0.6, 0, 1, 1)
        b.dispelTint:SetVertexColor(0.6, 0, 1, 1)
        b.dispelIconBorder:SetColorTexture(0.6, 0, 1, 1)
        b.dispelIcon:SetTexture(136139)
        b.glow:Show(); b.dispelTint:Show(); b.dispelBox:Show()
    end
    if i == 5 then b.status:SetText("tot"); b.health:SetValue(0) end
    if i == 4 then b.content:SetAlpha(0.45) end -- außer Reichweite
    list[i] = b
    return b
end

function mod:SetTest(kind, on)
    local h = (kind == "party") and headers[1] or headers[2]
    if not h then return end
    testOn[kind] = on
    local cfg, big, grip = h.cfg, h.big, h.grip
    local n = (kind == "party") and 5 or 40
    for i = 1, n do
        local b = testButton(kind, i, grip, cfg, big)
        b:ClearAllPoints()
        if kind == "party" then
            b:SetPoint("BOTTOMRIGHT", grip, "BOTTOMRIGHT", 0, (i - 1) * (cfg.h + 4))
        else
            local col = math.floor((i - 1) / 5)
            local row = (i - 1) % 5
            b:SetPoint("BOTTOMRIGHT", grip, "BOTTOMRIGHT", -col * (cfg.w + 3), row * (cfg.h + 3))
        end
        b:SetShown(on)
    end
    if on then
        ns.Print(kind == "party" and "Test: Gruppe an (5 ausgedachte Mitglieder)." or "Test: Schlachtzug an (40 ausgedachte Mitglieder).")
    end
end

function mod:IsTest(kind) return testOn[kind] end

---------------------------------------------------------------------------
-- Blizzards Gruppen-/Schlachtzugsrahmen wegstecken
---------------------------------------------------------------------------
local hider
local function hideBlizzard()
    if InCombatLockdown() then return end
    hider = hider or CreateFrame("Frame")
    hider:Hide()
    for _, n in ipairs({ "CompactPartyFrame", "PartyFrame", "CompactRaidFrameContainer", "CompactRaidFrameManager" }) do
        local f = _G[n]
        if f and f.SetParent and f:GetParent() ~= hider then
            f:SetParent(hider)
            if not f.mondhainHooked then
                f.mondhainHooked = true
                hooksecurefunc(f, "SetParent", function(self, parent)
                    if parent ~= hider and not self.mondhainBusy and not InCombatLockdown() then
                        self.mondhainBusy = true
                        self:SetParent(hider)
                        self.mondhainBusy = false
                    end
                end)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Sichtbarkeit (Gruppe / Schlachtzug / allein)
---------------------------------------------------------------------------
function mod:UpdateVisibility()
    if InCombatLockdown() or not headers[1] then return end
    local party, raid = headers[1], headers[2]
    RegisterStateDriver(party, "visibility",
        "[group:raid] hide; [group:party] show; " .. (db.showSolo and "show" or "hide"))
    RegisterStateDriver(raid, "visibility", "[group:raid] show; hide")
end

function mod:SetShowSolo(on)
    if InCombatLockdown() then return false end
    db.showSolo = on
    if headers[1] then headers[1]:SetAttribute("showSolo", on) end
    self:UpdateVisibility()
    return true
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.groupFrames
    if not db.enabled then return end
    learnDispels()
    ns.RegisterEvent("SPELLS_CHANGED", function()
        learnDispels()
        for _, b in ipairs(buttons) do if b:IsVisible() then pcall(updateAuras, b) end end
    end)

    -- Rechtsklick = Verjüngung vorbelegen (einmalig)
    if not db.clicksInit then
        local name = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(774)
            or (GetSpellInfo and GetSpellInfo(774)) or "Verjüngung"
        db.clicks["2"] = name
        db.clicksInit = true
    end

    local party, pgrip = makeHeader("MondhainParty", db.party, true, function(h)
        h:SetAttribute("showParty", true)
        h:SetAttribute("showPlayer", true)
        h:SetAttribute("showSolo", db.showSolo)
        h:SetAttribute("point", "BOTTOM") -- wächst nach oben
        h:SetAttribute("yOffset", 4)
    end)
    local raid, rgrip = makeHeader("MondhainRaid", db.raid, false, function(h)
        h:SetAttribute("showRaid", true)
        h:SetAttribute("groupBy", "GROUP")
        h:SetAttribute("groupingOrder", "1,2,3,4,5,6,7,8")
        h:SetAttribute("maxColumns", 8)
        h:SetAttribute("unitsPerColumn", 5)
        h:SetAttribute("point", "BOTTOM")
        h:SetAttribute("yOffset", 3)
        h:SetAttribute("columnSpacing", 3)
        h:SetAttribute("columnAnchorPoint", "RIGHT") -- Spalten wachsen nach links
    end)
    self:UpdateVisibility()
    party:Show(); raid:Show()

    ns.MakeMovable(pgrip, db.party, "Gruppe")
    ns.MakeMovable(rgrip, db.raid, "Schlachtzug")

    if db.hideBlizzard then
        hideBlizzard()
        C_Timer.After(1, hideBlizzard)
    end

    -- Ereignisse: passende Rahmen zur Einheit suchen
    local ev = CreateFrame("Frame")
    local handlers = {
        UNIT_HEALTH = updateHealth, UNIT_MAXHEALTH = updateHealth, UNIT_CONNECTION = updateHealth,
        UNIT_HEAL_PREDICTION = updateHealth, UNIT_ABSORB_AMOUNT_CHANGED = updateHealth,
        UNIT_HEAL_ABSORB_AMOUNT_CHANGED = updateHealth,
        UNIT_POWER_UPDATE = updatePower, UNIT_MAXPOWER = updatePower, UNIT_DISPLAYPOWER = updatePower,
        UNIT_AURA = updateAuras, UNIT_NAME_UPDATE = updateAll,
    }
    for e in pairs(handlers) do ev:RegisterEvent(e) end
    ev:SetScript("OnEvent", function(_, e, u)
        for _, b in ipairs(buttons) do
            if b.unit == u and b:IsVisible() then handlers[e](b) end
        end
    end)
    ns.RegisterEvent("GROUP_ROSTER_UPDATE", function()
        for _, b in ipairs(buttons) do if b:IsVisible() then updateAll(b) end end
    end)
    -- Testmodus beim Kampfbeginn ausschalten
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function()
        if testOn.party then mod:SetTest("party", false) end
        if testOn.raid then mod:SetTest("raid", false) end
    end)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
        mod:UpdateVisibility()
        for _, b in ipairs(buttons) do
            if b.needsClicks then b:RegisterForClicks("AnyUp"); b.needsClicks = nil end
        end
    end)

    -- Reichweite: alle 0,3 s blasser, wer zu weit weg ist
    C_Timer.NewTicker(0.3, function()
        for _, b in ipairs(buttons) do
            if b:IsVisible() and b.unit then
                local ok, inRange, checked = pcall(UnitInRange, b.unit)
                if ok and not isSecret(inRange) and not isSecret(checked) then
                    b.content:SetAlpha((checked and not inRange) and 0.45 or 1)
                end
            end
        end
    end)
end
