-- Mondhain – Wächter
-- · Nachbuffen: Fehlt eine eigene Stärkung (Dornen, Mal der Wildnis), springt
--   ihr Symbol als Medaillon über der Bildmitte auf und blinkt, bis sie wieder
--   drauf ist. Kurz vor dem Auslaufen (außerhalb des Kampfs) ruhige Vorwarnung.
-- · Zeiten am Gegner: Krallenhieb und Feenfeuer als Balken zwischen Spieler-
--   und Zielrahmen – dort pendelt der Blick ohnehin hin und her.
--
-- Forever gibt Auren im Kampf nicht an Addons heraus. Darum zwei Quellen:
-- außerhalb des Kampfs wird genau gelesen (Restzeit, echte Dauer – die merkt
-- sich Mondhain), im Kampf läuft eine Eieruhr: gestartet, wenn du den Zauber
-- erfolgreich wirkst, mit der gelernten Dauer.

local _, ns = ...
local mod = ns.NewModule("Watch")
ns.Watch = mod

local MEDIA = "Interface\\AddOns\\Mondhain\\media\\"
local FONT = STANDARD_TEXT_FONT
local WHITE = "Interface\\Buttons\\WHITE8x8"

---------------------------------------------------------------------------
-- Was beobachtet wird (je Klasse; andere Klassen folgen mit den Gewändern)
---------------------------------------------------------------------------
local SETS = {
    DRUID = {
        remind = {
            { key = "thorns", ids = { 467, 782, 1075, 8914, 9756, 9910, 26992 }, default = 600 },
            { key = "motw", ids = { 1126, 5232, 6756, 5234, 8907, 9884, 9885, 26990 }, default = 1800,
              -- Gabe der Wildnis (Gruppe) zählt als vorhanden und gilt immer auch für dich
              also = { 21849, 21850, 26991 }, alsoDefault = 3600 },
        },
        dots = {
            { key = "rake", ids = { 1822, 1823, 1824, 9904, 27003 }, default = 9,
              color = { 0.78, 0.16, 0.12 } },
            { key = "ff", ids = { 770, 778, 9749, 9907, 26993, 16857, 17390, 17391, 17392, 27011 }, default = 40,
              color = { 0.72, 0.42, 0.95 } },
        },
    },
    -- Ben 25.11. 16:22 (Steve): irgendein Segen, irgendeine Aura, Zorn der
    -- Gerechtigkeit nur für Schutz (Standard aus)
    PALADIN = {
        remind = {
            { key = "blessing", label = "Segen (beliebig)", default = 600, alsoDefault = 1800,
              ids = { 19740, 19834, 19835, 19836, 19837, 19838, 25291, 27140,     -- Macht
                      19742, 19850, 19852, 19853, 19854, 25290, 27142,            -- Weisheit
                      20217, 20911, 20912, 20913, 20914, 27168,                   -- Könige, Refugium
                      19977, 19978, 19979, 27144, 1038 },                         -- Licht, Rettung
              also = { 25782, 25916, 27141, 25894, 25918, 27143, 25898, 25899, 27169, 25890, 27145, 25895 } },
            { key = "aura", label = "Aura (beliebig)", default = 0,
              ids = { 465, 10290, 643, 10291, 1032, 10292, 10293, 27149,         -- Andacht
                      7294, 10298, 10299, 10300, 10301, 27150, 19746, 20218, 32223,
                      19876, 19895, 19896, 27151, 19888, 19897, 19898, 27152, 19891, 19899, 19900, 27153 } },
            { key = "rf", ids = { 25780 }, default = 1800, defaultOff = true },
        },
        dots = {},
    },
}

-- für alle Klassen (Ben 25.11. 10:10): Essens-Buff „Satt“ – alle Speisen
-- heißen gleich, darum genügt der Name; zählt nicht als Zauber, ist immer da
local COMMON = {
    remind = {
        { key = "food", ids = { 19705, 33254, 35272, 43722, 46899, 19706, 19708, 19709, 19710, 19711,
            24799, 25694, 25941, 33256, 33257, 33259, 33261, 33263, 33265, 33268 },
          default = 1800, always = true, defaultOff = true },
    },
}

local db
local set                         -- SETS[Klasse]
local byName = {}                 -- [Zaubername] = Eintrag (+ .isAlso)
local remindFrame, dotFrame
local medals, rows = {}, {}
local testUntil = 0

local function isSecret(v) return ns.isSecret(v) end
local function clean(v) if v == nil or isSecret(v) then return nil end return v end

local function spellName(id)
    local n
    if C_Spell and C_Spell.GetSpellName then n = clean(C_Spell.GetSpellName(id)) end
    if not n and GetSpellInfo then n = clean((GetSpellInfo(id))) end
    return n
end

local function spellIcon(id)
    local t
    if C_Spell and C_Spell.GetSpellTexture then t = clean(C_Spell.GetSpellTexture(id)) end
    if not t and GetSpellTexture then t = clean(GetSpellTexture(id)) end
    return t or 134400
end

-- Dauer aus der Zauberbeschreibung („… über 9 Sek.“, „… hält 10 Min.“)
local descCache = {}
local function durationFromText(id)
    if descCache[id] ~= nil then return descCache[id] or nil end
    local txt
    if C_Spell and C_Spell.GetSpellDescription then txt = clean(C_Spell.GetSpellDescription(id)) end
    if not txt and GetSpellDescription then txt = clean(GetSpellDescription(id)) end
    if type(txt) ~= "string" or txt == "" then return nil end   -- später noch einmal
    local s = txt:match("(%d+[,.]?%d*)%s*Sek") or txt:match("(%d+[,.]?%d*)%s*sec")
    local m = txt:match("(%d+)%s*Min") or txt:match("(%d+)%s*min")
    local d
    if m then d = tonumber(m) * 60 elseif s then d = tonumber((s:gsub(",", "."))) end
    descCache[id] = d or false
    return d
end

local function known(e)
    if e.always then return e.name ~= nil end
    for _, id in ipairs(e.ids) do
        if (IsPlayerSpell and IsPlayerSpell(id)) or (IsSpellKnown and IsSpellKnown(id)) then return true end
    end
    -- Forever könnte andere Nummern haben: dann über den Namen im Zauberbuch
    if e.name then
        if C_Spell and C_Spell.GetSpellInfo then
            local ok, info = pcall(C_Spell.GetSpellInfo, e.name)
            if ok and info then return true end
        end
        if GetSpellInfo and GetSpellInfo(e.name) then return true end
    end
    return false
end

local function prepare()
    byName = {}
    for _, kind in ipairs({ "remind", "dots" }) do
        for _, e in ipairs(set[kind] or {}) do
            e.kind = kind
            e.name, e.icon = nil, nil
            for _, id in ipairs(e.ids) do         -- erste Nummer, die der Client kennt
                local n = spellName(id)
                if n then e.name, e.icon = n, spellIcon(id) break end
            end
            e.icon = e.icon or spellIcon(e.ids[1])
            e.names = {}
            for _, id in ipairs(e.ids) do
                local n = spellName(id)
                if n then e.names[n] = true; byName[n] = { e = e } end
            end
            for _, id in ipairs(e.also or {}) do
                local n = spellName(id)
                if n then e.names[n] = true; byName[n] = { e = e, isAlso = true } end
            end
            e.known = known(e)
        end
    end
end

local function enabled(e)
    local t = (e.kind == "remind") and db.remind or db.dots
    if e.defaultOff then return t[e.key] == true end
    return t[e.key] ~= false
end

local function learnedDuration(e, isAlso, spellID)
    local key = e.key .. (isAlso and "_also" or "")
    if db.learned[key] then return db.learned[key] end
    if spellID then
        local d = durationFromText(spellID)
        if d then return d end
    end
    return isAlso and e.alsoDefault or e.default
end

---------------------------------------------------------------------------
-- Lesen (nur wenn Forever es herausgibt)
---------------------------------------------------------------------------
-- liefert { [Name] = { exp, dur } } oder nil = gerade nicht lesbar
local function readAuras(unit, filter)
    local found, readable = {}, false
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 40 do
            local ok, d = pcall(C_UnitAuras.GetAuraDataByIndex, unit, i, filter)
            if not ok or not d then break end
            local name = d.name
            if name == nil or isSecret(name) then return nil end
            readable = true
            found[name] = { exp = clean(d.expirationTime) or 0, dur = clean(d.duration) or 0 }
        end
    end
    if not readable and UnitAura then
        for i = 1, 40 do
            local ok, name, _, _, _, dur, exp = pcall(UnitAura, unit, i, filter)
            if not ok or not name then break end
            if isSecret(name) then return nil end
            readable = true
            found[name] = { exp = clean(exp) or 0, dur = clean(dur) or 0 }
        end
    end
    -- im Kampf heißt „leer“ bei Forever „nichts herausgegeben“
    if not readable and InCombatLockdown() then return nil end
    return found
end

---------------------------------------------------------------------------
-- Nachbuffen
---------------------------------------------------------------------------
local rstate = {}   -- [key] = { present = true/false/nil, expires = Zeit oder 0 }

local function updateRemind()
    local list = readAuras("player", "HELPFUL")
    local now = GetTime()
    for _, e in ipairs(set.remind or {}) do
        local st = rstate[e.key] or {}
        rstate[e.key] = st
        if list then
            local hit, hitName
            for n in pairs(e.names) do
                if list[n] then hit, hitName = list[n], n break end
            end
            if hit then
                st.present = true
                st.expires = (hit.exp and hit.exp > 0) and hit.exp or 0
                if hit.dur and hit.dur > 0 then
                    local also = byName[hitName] and byName[hitName].isAlso
                    db.learned[e.key .. (also and "_also" or "")] = hit.dur
                end
            else
                st.present, st.expires = false, nil
            end
        elseif st.present and st.expires and st.expires > 0 and st.expires <= now then
            st.present = false   -- Eieruhr abgelaufen
        end
    end
end

local function makeMedal(i)
    local m = CreateFrame("Frame", nil, remindFrame)
    m:SetSize(64, 64)
    m.glow = m:CreateTexture(nil, "BACKGROUND")
    m.glow:SetTexture(MEDIA .. "punkt")
    m.glow:SetBlendMode("ADD")
    m.glow:SetPoint("CENTER")
    m.glow:SetSize(118, 118)
    m.icon = m:CreateTexture(nil, "ARTWORK")
    m.icon:SetPoint("CENTER")
    m.icon:SetSize(48, 48)
    local mask = m:CreateMaskTexture()
    mask:SetTexture(MEDIA .. "rund_maske", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(m.icon)
    m.icon:AddMaskTexture(mask)
    m.ring = m:CreateTexture(nil, "OVERLAY")
    m.ring:SetTexture(MEDIA .. "zauber_ring")
    m.ring:SetPoint("CENTER")
    m.ring:SetSize(66, 66)
    m.name = m:CreateFontString(nil, "OVERLAY")
    m.name:SetFont(FONT, 13, "OUTLINE")
    m.name:SetPoint("TOP", m, "BOTTOM", 0, -2)
    m.name:SetTextColor(1, 0.82, 0.25)
    m.sub = m:CreateFontString(nil, "OVERLAY")
    m.sub:SetFont(FONT, 11, "OUTLINE")
    m.sub:SetPoint("TOP", m.name, "BOTTOM", 0, -1)
    m:Hide()
    medals[i] = m
    return m
end

local function remindBlocked()
    if UnitIsDeadOrGhost("player") then return true end
    -- Ben 25.11. 10:10: in Städten und Gasthäusern (Ruhebereich) nicht erinnern
    if db.hideResting ~= false and IsResting and IsResting() then return true end
    if UnitOnTaxi and UnitOnTaxi("player") then return true end
    if UnitInVehicle and UnitInVehicle("player") then return true end
    return false
end

-- Eigener Platz je Erinnerung (Ben 25.11. 10:10): sonst teilen sich alle die
-- Mitte und stehen nebeneinander
local ownFrames = {}
local function ownOn(key) return db.remindOwn and db.remindOwn[key] and db.remindOwn[key].on end
local function applyOwn()
    db.remindOwn = db.remindOwn or {}
    local i = 0
    for _, e in ipairs(set.remind or {}) do
        i = i + 1
        local o = db.remindOwn[e.key]
        if o and o.on then
            local f = ownFrames[e.key]
            if not f then
                f = CreateFrame("Frame", "MondhainRemind_" .. e.key, UIParent)
                f:SetSize(100, 100)
                f:SetFrameStrata("HIGH")
                if not o.point then
                    local x, y = remindFrame:GetCenter()
                    o.point = { "CENTER", "UIParent", "BOTTOMLEFT", (x or 0) + (i - 1) * 110 - 110, (y or 0) + 120 }
                end
                f:SetPoint(o.point[1], UIParent, o.point[3], o.point[4], o.point[5])
                ns.MakeMovable(f, o, "Nachbuffen: " .. (e.name or e.key))
                ownFrames[e.key] = f
            end
            f:Show()
        elseif ownFrames[e.key] then
            ownFrames[e.key]:Hide()
        end
    end
end

local function showRemind()
    local now = GetTime()
    local list = {}
    local test = now < testUntil
    if test then
        for _, e in ipairs(set.remind or {}) do list[#list + 1] = { e = e, missing = (#list == 0), left = 24 } end
    elseif not remindBlocked() then
        for _, e in ipairs(set.remind or {}) do
            local st = rstate[e.key]
            if e.known and enabled(e) and st then
                if st.present == false then
                    list[#list + 1] = { e = e, missing = true }
                elseif st.present and st.expires and st.expires > 0 and not InCombatLockdown()
                    and (db.warnBefore or 0) > 0 and st.expires - now <= db.warnBefore then
                    list[#list + 1] = { e = e, missing = false, left = st.expires - now }
                end
            end
        end
    end
    local gap = 92
    local shared = 0
    for _, it in ipairs(list) do if not ownOn(it.e.key) then shared = shared + 1 end end
    local si = 0
    for i, it in ipairs(list) do
        local m = medals[i] or makeMedal(i)
        m:ClearAllPoints()
        local own = ownOn(it.e.key) and ownFrames[it.e.key]
        if own then
            m:SetPoint("CENTER", own, "CENTER", 0, 0)
        else
            si = si + 1
            m:SetPoint("CENTER", remindFrame, "CENTER", (si - (shared + 1) / 2) * gap, 0)
        end
        if m.key ~= it.e.key then
            m.key = it.e.key
            m.icon:SetTexture(it.e.icon)
            m.name:SetText(it.e.name or it.e.key)
        end
        m.missing = it.missing
        if it.missing then
            m.sub:SetText("nachbuffen!")
            m.sub:SetTextColor(1, 0.35, 0.25)
            m.glow:SetVertexColor(0.55, 1, 0.45)
        else
            local s = math.max(0, math.floor(it.left + 0.5))
            m.sub:SetText(("noch %d:%02d"):format(math.floor(s / 60), s % 60))
            m.sub:SetTextColor(0.9, 0.9, 0.9)
            m.glow:SetVertexColor(1, 0.85, 0.45)
        end
        if not m:IsShown() then m.born = now; m:Show() end
    end
    for i = #list + 1, #medals do medals[i]:Hide(); medals[i].key = nil end
end

-- Aufspringen und Blinken (ohne Animationsgruppen, läuft überall gleich)
local function animateMedals()
    local now = GetTime()
    for _, m in ipairs(medals) do
        if m:IsShown() then
            local t = now - (m.born or now)
            local s = 1
            if t < 0.14 then s = 0.55 + 0.6 * (t / 0.14)
            elseif t < 0.26 then s = 1.15 - 0.15 * ((t - 0.14) / 0.12) end
            m.icon:SetSize(48 * s, 48 * s)
            m.ring:SetSize(66 * s, 66 * s)
            if m.missing then
                local w = 0.5 + 0.5 * math.cos(t * math.pi * 2 / 0.9)
                m.icon:SetAlpha(0.55 + 0.45 * w)
                m.glow:SetAlpha(0.25 + 0.75 * w)
                m.glow:SetSize(118 * s, 118 * s)
            else
                m.icon:SetAlpha(0.9)
                m.glow:SetAlpha(0.35)
                m.glow:SetSize(96 * s, 96 * s)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Zeiten am Gegner
---------------------------------------------------------------------------
local timers = {}   -- [Zielschlüssel] = { [key] = { start, dur, exp } }

local function targetKey()
    if not UnitExists("target") then return nil end
    local ok, g = pcall(UnitGUID, "target")
    if ok and g and not isSecret(g) then return g end
    return "target"
end

local function readTargetDots()
    local key = targetKey()
    if not key then return end
    local list = readAuras("target", "HARMFUL|PLAYER")
    if not list then return end
    local t = timers[key] or {}
    for _, e in ipairs(set.dots or {}) do
        local hit
        for n in pairs(e.names) do if list[n] then hit = list[n] break end end
        if hit and hit.exp and hit.exp > 0 then
            t[e.key] = { exp = hit.exp, dur = (hit.dur and hit.dur > 0) and hit.dur or learnedDuration(e) }
            if hit.dur and hit.dur > 0 then db.learned[e.key] = hit.dur end
        else
            t[e.key] = nil
        end
    end
    timers[key] = t
end

local function makeRow(i)
    local r = CreateFrame("StatusBar", nil, dotFrame)
    r:SetStatusBarTexture(WHITE)
    r:SetMinMaxValues(0, 1)
    r.bg = r:CreateTexture(nil, "BACKGROUND")
    r.bg:SetAllPoints()
    r.bg:SetColorTexture(0.04, 0.04, 0.04, 0.85)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    r.name = r:CreateFontString(nil, "OVERLAY")
    r.name:SetFont(FONT, 11, "OUTLINE")
    r.name:SetPoint("LEFT", 5, 0)
    r.name:SetTextColor(0.95, 0.92, 0.85)
    r.time = r:CreateFontString(nil, "OVERLAY")
    r.time:SetFont(FONT, 11, "OUTLINE")
    r.time:SetPoint("RIGHT", -5, 0)
    r.spark = r:CreateTexture(nil, "OVERLAY")
    r.spark:SetTexture(MEDIA .. "punkt")
    r.spark:SetBlendMode("ADD")
    r.spark:SetSize(10, 26)
    if ns.WoodFrame then ns.WoodFrame(r, 10) end
    r:Hide()
    rows[i] = r
    return r
end

local function layoutRows(list)
    local w = dotFrame:GetWidth()
    local h = db.rowHeight or 18
    for i, it in ipairs(list) do
        local r = rows[i] or makeRow(i)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", dotFrame, "TOPLEFT", h + 4, -(i - 1) * (h + 6))
        r:SetSize(w - h - 4, h)
        r.icon:ClearAllPoints()
        r.icon:SetPoint("RIGHT", r, "LEFT", -4, 0)
        r.icon:SetSize(h, h)
        if r.key ~= it.e.key then
            r.key = it.e.key
            r.icon:SetTexture(it.e.icon)
            r.name:SetText(it.e.name or it.e.key)
            local c = it.e.color
            r.col = c
        end
        local frac = math.max(0, math.min(1, it.left / math.max(it.dur, 0.1)))
        r:SetValue(frac)
        local c = r.col
        local k = 1
        if it.left <= 3 then k = 0.75 + 0.45 * (0.5 + 0.5 * math.cos(GetTime() * math.pi * 2 / 0.5)) end
        r:SetStatusBarColor(math.min(1, c[1] * k), math.min(1, c[2] * k), math.min(1, c[3] * k))
        r.time:SetText(it.left >= 10 and ("%d"):format(it.left) or ("%.1f"):format(it.left))
        r.time:SetTextColor(it.left <= 3 and 1 or 0.95, it.left <= 3 and 0.45 or 0.92, it.left <= 3 and 0.3 or 0.85)
        r.spark:ClearAllPoints()
        r.spark:SetPoint("CENTER", r, "LEFT", (w - h - 4) * frac, 0)
        r:Show()
    end
    for i = #list + 1, #rows do rows[i]:Hide(); rows[i].key = nil end
end

local function showDots()
    local now = GetTime()
    local list = {}
    if now < testUntil then
        for i, e in ipairs(set.dots or {}) do
            local dur = learnedDuration(e)
            list[#list + 1] = { e = e, dur = dur, left = dur * (i == 1 and 0.3 or 0.75) }
        end
    else
        local key = targetKey()
        local t = key and timers[key]
        if t then
            for _, e in ipairs(set.dots or {}) do
                local x = t[e.key]
                if x and e.known and enabled(e) then
                    local left = x.exp - now
                    if left > 0 then list[#list + 1] = { e = e, dur = x.dur, left = left }
                    else t[e.key] = nil end
                end
            end
        end
    end
    layoutRows(list)
end

---------------------------------------------------------------------------
-- Eigene Zauber: Eieruhr starten
---------------------------------------------------------------------------
local sentTarget = {}   -- [castGUID] = Zielname

local function onSent(unit, target, castGUID)
    if unit ~= "player" or not castGUID or isSecret(castGUID) then return end
    sentTarget[castGUID] = clean(target) or ""
end

local function castOnSelf(castGUID)
    local tn = castGUID and sentTarget[castGUID]
    if castGUID then sentTarget[castGUID] = nil end
    if tn ~= nil and tn ~= "" then
        return tn == UnitName("player")
    end
    -- kein Zielname: auf sich selbst, außer ein anderer Freund ist im Ziel
    if UnitExists("target") and not UnitIsUnit("target", "player") then
        local ok, friend = pcall(UnitIsFriend, "player", "target")
        if ok and friend and not isSecret(friend) then return false end
    end
    return true
end

local function onSucceeded(unit, castGUID, spellID)
    if unit ~= "player" or not spellID or isSecret(spellID) then return end
    local n = spellName(spellID)
    local hit = n and byName[n]
    if not hit then return end
    local e = hit.e
    local now = GetTime()
    if e.kind == "remind" then
        if hit.isAlso or castOnSelf(castGUID) then
            local st = rstate[e.key] or {}
            rstate[e.key] = st
            st.present = true
            st.expires = now + learnedDuration(e, hit.isAlso, spellID)
        end
        C_Timer.After(0.3, updateRemind)
    else
        local key = targetKey()
        if not key then return end
        timers[key] = timers[key] or {}
        local dur = learnedDuration(e, nil, spellID)
        timers[key][e.key] = { exp = now + dur, dur = dur }
        C_Timer.After(0.3, readTargetDots)
    end
end

---------------------------------------------------------------------------
-- Rahmen, Platz und Start
---------------------------------------------------------------------------
-- Zwischen Spieler- und Zielrahmen, auf deren Mitte (wenn nicht verschoben)
local function placeDotsDefault()
    if db.dotFrame.point then return end
    local p, t = _G.MondhainUnit_player, _G.MondhainUnit_target
    local k = UIParent:GetEffectiveScale()
    if p and t and p:GetRight() and t:GetLeft() then
        local ps, ts = p:GetEffectiveScale() / k, t:GetEffectiveScale() / k
        local x1, x2 = p:GetRight() * ps, t:GetLeft() * ts
        local yTop = math.max(p:GetTop() * ps, t:GetTop() * ts)
        local gapW = x2 - x1
        -- links 10 px Luft, rechts 34 px: dort ragt die Stufen-Plakette des Ziels hinein
        local l, r = x1 + 10, x2 - 34
        if r - l > 80 then
            db.dotWidth = math.floor(math.min(220, r - l))
            dotFrame:SetWidth(db.dotWidth)
            local s = dotFrame:GetScale()
            dotFrame:ClearAllPoints()
            dotFrame:SetPoint("TOP", UIParent, "BOTTOMLEFT", (l + r) / 2 / s, (yTop - 4) / s)
            return
        end
    end
    dotFrame:ClearAllPoints()
    dotFrame:SetPoint("CENTER", UIParent, "CENTER", 0, -60)
end

local function build()
    remindFrame = CreateFrame("Frame", "MondhainRemind", UIParent)
    remindFrame:SetSize(200, 100)
    remindFrame:SetFrameStrata("HIGH")
    local rp = db.remindFrame.point
    remindFrame:SetPoint(rp[1], UIParent, rp[3], rp[4], rp[5])
    ns.MakeMovable(remindFrame, db.remindFrame, "Nachbuffen")

    dotFrame = CreateFrame("Frame", "MondhainDots", UIParent)
    dotFrame:SetSize(db.dotWidth or 200, 2 * ((db.rowHeight or 18) + 6))
    dotFrame:SetFrameStrata("MEDIUM")
    local dp = db.dotFrame.point
    if dp then
        dotFrame:SetPoint(dp[1], UIParent, dp[3], dp[4], dp[5])
    else
        dotFrame:SetPoint("CENTER", UIParent, "CENTER", 0, -60)
        C_Timer.After(2, placeDotsDefault)
    end
    ns.MakeMovable(dotFrame, db.dotFrame, "Zeiten am Gegner")
end

function mod:Test()
    testUntil = GetTime() + 8
end

function mod:Refresh()
    if not set then return end
    prepare()
    updateRemind()
end

function mod:Entries(kind)
    return set and set[kind] or {}
end

function mod:SetOwn(key, on)
    if not set then return end
    db.remindOwn = db.remindOwn or {}
    db.remindOwn[key] = db.remindOwn[key] or {}
    db.remindOwn[key].on = on and true or nil
    applyOwn()
end
function mod:IsOwn(key) return ownOn(key) and true or false end

function mod:OnEnable()
    db = ns.db.watch
    if not db or not db.enabled then return end
    local _, class = UnitClass("player")
    local cs = SETS[class] or {}
    set = { remind = {}, dots = {} }
    for _, e in ipairs(cs.remind or {}) do set.remind[#set.remind + 1] = e end
    for _, e in ipairs(COMMON.remind) do set.remind[#set.remind + 1] = e end
    for _, e in ipairs(cs.dots or {}) do set.dots[#set.dots + 1] = e end
    db.remind, db.dots, db.learned = db.remind or {}, db.dots or {}, db.learned or {}
    prepare()
    build()
    applyOwn()

    local ev = CreateFrame("Frame")
    ev:RegisterUnitEvent("UNIT_AURA", "player", "target")
    ev:RegisterUnitEvent("UNIT_SPELLCAST_SENT", "player")
    ev:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")
    ev:RegisterUnitEvent("UNIT_HEALTH", "target")
    ev:RegisterEvent("PLAYER_TARGET_CHANGED")
    ev:RegisterEvent("PLAYER_REGEN_ENABLED")
    ev:RegisterEvent("PLAYER_ENTERING_WORLD")
    ev:RegisterEvent("SPELLS_CHANGED")
    ev:RegisterEvent("PLAYER_UPDATE_RESTING")
    ev:SetScript("OnEvent", function(_, e, a, b, c, d)
        if e == "UNIT_AURA" then
            if a == "player" then updateRemind() else readTargetDots() end
        elseif e == "UNIT_SPELLCAST_SENT" then
            onSent(a, b, c)
        elseif e == "UNIT_SPELLCAST_SUCCEEDED" then
            onSucceeded(a, b, c)
        elseif e == "UNIT_HEALTH" then
            local ok, dead = pcall(UnitIsDead, "target")
            if ok and dead and not isSecret(dead) then
                local key = targetKey()
                if key then timers[key] = nil end
            end
        elseif e == "PLAYER_TARGET_CHANGED" then
            timers.target = nil       -- ohne lesbare Kennung lässt sich nicht zuordnen
            readTargetDots()
        elseif e == "PLAYER_REGEN_ENABLED" then
            -- Kampf vorbei: Gegner sind tot oder weg, Eieruhren aufräumen, genau lesen
            wipe(timers)
            updateRemind()
        elseif e == "SPELLS_CHANGED" or e == "PLAYER_ENTERING_WORLD" then
            prepare()
            updateRemind()
        end
    end)

    -- sanft nachsehen: Lesen zweimal pro Sekunde, Zeichnen flüssig
    local acc = 0
    remindFrame:SetScript("OnUpdate", function(_, el)
        acc = acc + el
        if acc >= 0.5 then
            acc = 0
            updateRemind()
            showRemind()
        end
        animateMedals()
    end)
    local acc2 = 0
    dotFrame:SetScript("OnUpdate", function(_, el)
        acc2 = acc2 + el
        if acc2 < 0.05 then return end
        acc2 = 0
        showDots()
    end)
    updateRemind()
end
