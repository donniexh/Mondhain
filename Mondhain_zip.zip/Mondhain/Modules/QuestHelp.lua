-- Mondhain – Questhilfe (Ben 25.11. 13:49)
--  · Stufe der Quest auf der Annahmetafel (wie im Questlog): „[24] Titel“ in
--    der Schwierigkeitsfarbe
--  · Belohnungswahl: die Belohnung, die beim Händler am meisten bringt
--    (Verkaufswert × Menge), bekommt eine kleine Goldmünze
--  · Gruppe (Ben 25.11. 15:52): im Questlog steht, wer aus der Gruppe die
--    Quest auch hat; eigener Fortschritt wird im Gruppenchat gemeldet

local _, ns = ...
local mod = ns.NewModule("QuestHelp")
local db

---------------------------------------------------------------------------
-- Questlevel
---------------------------------------------------------------------------
local levelByID, levelByTitle = {}, {}

local function remember(id, title, lv)
    if type(lv) ~= "number" or lv <= 0 then return end
    if id and id > 0 then levelByID[id] = lv end
    if title and title ~= "" then levelByTitle[title] = lv end
end

-- Gesprächsliste und Begrüßung kennen die Stufe der angebotenen Quests
local function cacheGossip()
    if C_GossipInfo and C_GossipInfo.GetAvailableQuests then
        for _, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do remember(q.questID, q.title, q.questLevel) end
        for _, q in ipairs(C_GossipInfo.GetActiveQuests and C_GossipInfo.GetActiveQuests() or {}) do
            remember(q.questID, q.title, q.questLevel)
        end
    end
end
local function cacheGreeting()
    for i = 1, (GetNumAvailableQuests and GetNumAvailableQuests() or 0) do
        local lv = GetAvailableLevel and GetAvailableLevel(i)
        local id = GetAvailableQuestInfo and select(5, GetAvailableQuestInfo(i))
        remember(id, GetAvailableTitle and GetAvailableTitle(i), lv)
    end
    for i = 1, (GetNumActiveQuests and GetNumActiveQuests() or 0) do
        local lv = GetActiveLevel and GetActiveLevel(i)
        remember(GetActiveQuestID and GetActiveQuestID(i), GetActiveTitle and GetActiveTitle(i), lv)
    end
end

local function questLevel(id, title)
    if id and id > 0 then
        if C_QuestLog and C_QuestLog.GetQuestDifficultyLevel then
            local ok, lv = pcall(C_QuestLog.GetQuestDifficultyLevel, id)
            if ok and type(lv) == "number" and lv > 0 then return lv end
        end
        if levelByID[id] then return levelByID[id] end
        if C_QuestLog and C_QuestLog.GetLogIndexForQuestID and C_QuestLog.GetInfo then
            local idx = C_QuestLog.GetLogIndexForQuestID(id)
            local info = idx and C_QuestLog.GetInfo(idx)
            if info and info.level and info.level > 0 then return info.level end
        end
    end
    return title and levelByTitle[title]
end

local function colorFor(lv)
    local c = GetQuestDifficultyColor and GetQuestDifficultyColor(lv)
    if not c then return "ffd100" end
    return ("%02x%02x%02x"):format(c.r * 255, c.g * 255, c.b * 255)
end

local function showLevel()
    local h = _G.QuestInfoTitleHeader
    if not (h and h:IsVisible()) then return end
    local title = h:GetText()
    if not title or title == "" or title:find("^|c%x+%[%d+%]") then return end
    local fromLog = _G.QuestInfoFrame and _G.QuestInfoFrame.questLog
    local id
    if fromLog then
        id = C_QuestLog and C_QuestLog.GetSelectedQuest and C_QuestLog.GetSelectedQuest()
    else
        id = GetQuestID and GetQuestID()
    end
    local lv = questLevel(id, title)
    if not lv and fromLog and GetQuestLogSelection and GetQuestLogTitle then   -- ältere Schnittstelle
        local _, l = GetQuestLogTitle(GetQuestLogSelection())
        if type(l) == "number" and l > 0 then lv = l end
    end
    if lv then h:SetText(("|cff%s[%d]|r %s"):format(colorFor(lv), lv, title)) end
end

---------------------------------------------------------------------------
-- Belohnung mit dem höchsten Verkaufswert
---------------------------------------------------------------------------
local waiting = false
local function coinTex(b)
    if b.mhCoin then return b.mhCoin end
    local t = b:CreateTexture(nil, "OVERLAY", nil, 7)
    local atlasOK = C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo("coin-gold")
    if atlasOK then t:SetAtlas("coin-gold") else t:SetTexture("Interface\\MoneyFrame\\UI-GoldIcon") end
    t:SetSize(16, 16)
    local icon = b.Icon or b.icon or (b.GetName and b:GetName() and _G[b:GetName() .. "IconTexture"])
    t:SetPoint("TOPLEFT", icon or b, "TOPLEFT", -4, 4)
    b.mhCoin = t
    return t
end

local function rewardButtons()
    local list, seen = {}, {}
    local function add(b)
        if b and not seen[b] then seen[b] = true; list[#list + 1] = b end
    end
    for _, holder in ipairs({ _G.QuestInfoRewardsFrame, _G.MapQuestInfoRewardsFrame }) do
        if holder and holder.RewardButtons then for _, b in ipairs(holder.RewardButtons) do add(b) end end
    end
    for i = 1, 12 do add(_G["QuestInfoRewardsFrameQuestInfoItem" .. i]) end
    return list
end

local function sellPrice(link)
    if not link then return end
    local price
    if C_Item and C_Item.GetItemInfo then price = select(11, C_Item.GetItemInfo(link)) end
    if price == nil and GetItemInfo then price = select(11, GetItemInfo(link)) end
    return price
end

local function markBestReward()
    if db and db.bestReward == false then return end
    local fromLog = _G.QuestInfoFrame and _G.QuestInfoFrame.questLog
    local best, bestVal, choices, unknown = nil, 0, 0, false
    for _, b in ipairs(rewardButtons()) do
        if b.mhCoin then b.mhCoin:Hide() end
        if b:IsVisible() and b.type == "choice" and (b.objectType == nil or b.objectType == "item") then
            choices = choices + 1
            local id = b:GetID()
            local link = fromLog and GetQuestLogItemLink and GetQuestLogItemLink("choice", id)
                or (GetQuestItemLink and GetQuestItemLink("choice", id))
            local price = sellPrice(link)
            if price == nil then
                unknown = true
            else
                local qty
                if fromLog and GetQuestLogChoiceInfo then qty = select(3, GetQuestLogChoiceInfo(id))
                elseif GetQuestItemInfo then qty = select(3, GetQuestItemInfo("choice", id)) end
                qty = tonumber(qty) or tonumber(b.count) or 1
                if qty < 1 then qty = 1 end
                if price * qty > bestVal then best, bestVal = b, price * qty end
            end
        end
    end
    if choices >= 2 and best then coinTex(best):Show() end
    -- Gegenstandsdaten noch nicht da: kurz warten und neu schauen
    if unknown and not waiting then
        waiting = true
        C_Timer.After(0.5, function() waiting = false; pcall(markBestReward) end)
    end
end

---------------------------------------------------------------------------
-- Gruppe: wer hat die Quest auch?
-- 1. Blizzard fragen (C_QuestLog.IsUnitOnQuest bzw. alt IsUnitOnQuest)
-- 2. sonst, was Mondhain bei den anderen meldet (Addon-Nachricht, Präfix MondhainQ)
---------------------------------------------------------------------------
local PREFIX = "MondhainQ"
local remote = {}            -- [Name] = { [questID] = true }
local function on(key) return not db or db[key] ~= false end

local function partyUnits()
    local list = {}
    if IsInRaid and IsInRaid() then return list end
    for i = 1, 4 do
        local u = "party" .. i
        if UnitExists(u) and UnitIsPlayer(u) then list[#list + 1] = u end
    end
    return list
end

-- eigene Quests: { questID, title, logIndex }
local function myQuests()
    local list = {}
    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
        for i = 1, C_QuestLog.GetNumQuestLogEntries() do
            local info = C_QuestLog.GetInfo(i)
            if info and not info.isHeader and info.questID and info.questID > 0 then
                list[#list + 1] = { id = info.questID, title = info.title, index = i }
            end
        end
    elseif GetNumQuestLogEntries and GetQuestLogTitle then
        for i = 1, GetNumQuestLogEntries() do
            local title, _, _, isHeader, _, _, _, id = GetQuestLogTitle(i)
            if not isHeader and id then list[#list + 1] = { id = id, title = title, index = i } end
        end
    end
    return list
end

local function unitOnQuest(unit, id, index)
    local name = UnitName(unit)
    if name and remote[name] and remote[name][id] then return true end
    if C_QuestLog and C_QuestLog.IsUnitOnQuest then
        local ok, res = pcall(C_QuestLog.IsUnitOnQuest, unit, id)
        if ok and res then return true end
    end
    if IsUnitOnQuest and index then
        local ok, res = pcall(IsUnitOnQuest, index, unit)
        if ok and res and res ~= 0 then return true end
    end
    return false
end

-- Questie (Ben 26.11. 06:02): hat man Questie, liegen die Questlogs der
-- Gruppe dort schon ausgepackt (QuestieComms.remoteQuestLogs, Abfrage über
-- QuestieComms:GetQuest). Nur lesen; fehlt Questie oder ändert es sich, still aus.
local function questieComms()
    local L = _G.QuestieLoader
    local mods = L and type(L._modules) == "table" and L._modules
    local qc = mods and mods.QuestieComms
    if type(qc) == "table" and type(qc.GetQuest) == "function" then return qc end
end
-- { [kurzer Name] = "4/6 · 1/1" oder "fertig" }
local function questieParty(id)
    local qc = id and questieComms()
    if not qc then return nil end
    local ok, players = pcall(qc.GetQuest, qc, id)
    if not ok or type(players) ~= "table" then return nil end
    local out = {}
    for name, objs in pairs(players) do
        local short = (Ambiguate and Ambiguate(name, "short")) or name
        local parts, done, any = {}, true, false
        if type(objs) == "table" then
            for _, o in ipairs(objs) do
                if type(o) == "table" and o.required then
                    any = true
                    parts[#parts + 1] = ("%s/%s"):format(tostring(o.fulfilled or 0), tostring(o.required))
                    if not o.finished then done = false end
                end
            end
        end
        out[short] = (any and done) and "fertig" or (#parts > 0 and table.concat(parts, " · ") or "")
    end
    return out
end

local function partyOnQuest(id, index)
    local names = {}
    if not id then return names end
    local seen = {}
    local qp = questieParty(id)
    for _, u in ipairs(partyUnits()) do
        local n = UnitName(u)
        if unitOnQuest(u, id, index) or (qp and n and qp[n]) then
            seen[n] = true
            local prog = qp and n and qp[n]
            names[#names + 1] = (prog and prog ~= "") and (n .. " (" .. prog .. ")") or n
        end
    end
    -- Questie kennt evtl. Gruppenmitglieder, die gerade nicht als Einheit da sind
    if qp and not (IsInRaid and IsInRaid()) then
        for n, prog in pairs(qp) do
            if not seen[n] then names[#names + 1] = (prog ~= "") and (n .. " (" .. prog .. ")") or n end
        end
    end
    return names
end

-- eigene Questliste an die Gruppe (für Mitspieler mit Mondhain)
local sendPending = false
local function sendList()
    sendPending = false
    if not (IsInGroup and IsInGroup()) or (IsInRaid and IsInRaid()) then return end
    if not (C_ChatInfo and C_ChatInfo.SendAddonMessage) then return end
    local ids = {}
    for _, q in ipairs(myQuests()) do ids[#ids + 1] = tostring(q.id) end
    local msg, first = "", true
    local function flush()
        C_ChatInfo.SendAddonMessage(PREFIX, (first and "L:" or "M:") .. msg, "PARTY")
        first, msg = false, ""
    end
    for _, id in ipairs(ids) do
        if #msg + #id + 1 > 240 then flush() end
        msg = (msg == "") and id or (msg .. "," .. id)
    end
    flush()
end
local function requestSend()
    if sendPending then return end
    sendPending = true
    C_Timer.After(2, sendList)
end

---------------------------------------------------------------------------
-- Fortschritt im Gruppenchat (eigene Worte, angelehnt an Questie)
---------------------------------------------------------------------------
local lastObj, primed = {}, false
local announceQueue, announceTimer = {}, nil

local function objectives(q)
    local out = {}
    if C_QuestLog and C_QuestLog.GetQuestObjectives then
        for i, o in ipairs(C_QuestLog.GetQuestObjectives(q.id) or {}) do
            out[i] = { text = o.text or "", done = o.finished and true or false }
        end
    elseif GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
        for i = 1, GetNumQuestLeaderBoards(q.index) or 0 do
            local text, _, done = GetQuestLogLeaderBoard(i, q.index)
            out[i] = { text = text or "", done = done and true or false }
        end
    end
    return out
end

-- Wohin? (Ben 26.11.: an mich, an die Gruppe, an den Schlachtzug – Gilde nicht)
-- Gruppe/Schlachtzug gehen in den passenden Kanal; „an mich“ zeigt die Zeile nur
-- im eigenen Chat, wenn sie nicht ohnehin schon in einen Kanal ging
local function flushAnnounce()
    announceTimer = nil
    local raid = IsInRaid and IsInRaid()
    local party = not raid and IsInGroup and IsInGroup()
    local chan
    if raid and db.announceRaid then chan = "RAID"
    elseif party and db.announceParty ~= false then chan = "PARTY" end
    for _, line in ipairs(announceQueue) do
        if chan then
            pcall(SendChatMessage, line, chan)
        elseif db.announceSelf then
            ns.Print("|cffd8b26e" .. line .. "|r")
        end
    end
    wipe(announceQueue)
end
local function announce(line)
    announceQueue[#announceQueue + 1] = line
    if not announceTimer then announceTimer = C_Timer.After(0.8, flushAnnounce) end
end

-- Ben 26.11. 07:01: Annahme nur mit Titel, Fortschritt abschaltbar,
-- „fertig“ erst, wenn wirklich alle Ziele erfüllt sind.
local lastDone, justAccepted = {}, {}
local function countOf(text)
    local a, b = (text or ""):match("(%d+)%s*/%s*(%d+)")
    return a and (a .. "/" .. b) or nil
end
local function questDone(q, objs)
    if C_QuestLog and C_QuestLog.IsComplete then
        local ok, v = pcall(C_QuestLog.IsComplete, q.id)
        if ok and type(v) == "boolean" then return v end
    end
    if #objs == 0 then return false end
    for _, o in ipairs(objs) do if not o.done then return false end end
    return true
end

local function scanProgress()
    local seen = {}
    local talk = on("announce")
    for _, q in ipairs(myQuests()) do
        seen[q.id] = true
        local objs = objectives(q)
        local before = lastObj[q.id]
        local done = questDone(q, objs)
        if primed and talk then
            if before then
                if db.announceProgress == true then
                    for i, o in ipairs(objs) do
                        local b = before[i]
                        local cNow, cOld = countOf(o.text), b and countOf(b.text)
                        if b and cNow and cOld and cNow ~= cOld and not done then
                            announce(("[%s] %s"):format(q.title or "?", o.text))
                        end
                    end
                end
            end
            local wasOpen = lastDone[q.id] == false or (lastDone[q.id] == nil and justAccepted[q.id])
            if done and wasOpen and on("announceDone") then
                announce(("Quest fertig: [%s] – kann abgegeben werden"):format(q.title or "?"))
            end
        end
        lastObj[q.id] = objs
        lastDone[q.id] = done
        justAccepted[q.id] = nil
    end
    if not next(seen) then primed = true return end      -- Questlog beim Laden kurz leer: Stand behalten
    for id in pairs(lastObj) do if not seen[id] then lastObj[id] = nil; lastDone[id] = nil end end
    primed = true
end

---------------------------------------------------------------------------
-- Anzeige im Questlog: Liste „(+2)“, Details „Auch in deiner Gruppe: …“
---------------------------------------------------------------------------
local MARK = "|cff66ccff"
local function showPartyInDetail()
    if not on("party") then return end
    local obj = _G.QuestInfoObjectivesText
    if not (obj and obj:IsVisible()) then return end
    local text = obj:GetText() or ""
    if text:find(MARK .. "Auch in deiner Gruppe", 1, true) then return end
    local fromLog = _G.QuestInfoFrame and _G.QuestInfoFrame.questLog
    local id, index
    if fromLog then
        id = C_QuestLog and C_QuestLog.GetSelectedQuest and C_QuestLog.GetSelectedQuest()
        index = GetQuestLogSelection and GetQuestLogSelection()
        if not id and index and GetQuestLogTitle then id = select(8, GetQuestLogTitle(index)) end
    else
        id = GetQuestID and GetQuestID()
    end
    local names = partyOnQuest(id, index)
    if #names > 0 then
        obj:SetText(text .. "\n\n" .. MARK .. "Auch in deiner Gruppe: " .. table.concat(names, ", ") .. "|r")
    end
end

-- Questlog-Einträge: klassische Namen „QuestLogTitleN“ oder Rollliste
local function titleButtons()
    local list = {}
    for i = 1, 40 do
        local b = _G["QuestLogTitle" .. i]
        if not b then break end
        list[#list + 1] = b
    end
    if #list == 0 then
        local sf = _G.QuestLogListScrollFrame
        if sf and type(sf.buttons) == "table" then for _, b in ipairs(sf.buttons) do list[#list + 1] = b end end
    end
    return list
end

local function updateList()
    if not on("party") then return end
    local grouped = IsInGroup and IsInGroup() and not (IsInRaid and IsInRaid())
    for _, b in ipairs(titleButtons()) do
        if b:IsShown() and grouped and GetQuestLogTitle then
            local index = b:GetID()
            local _, _, _, isHeader, _, _, _, id = GetQuestLogTitle(index)
            if not isHeader and id then
                local n = #partyOnQuest(id, index)
                local fs = b.normalText or b:GetFontString()
                local t = (fs and fs:GetText()) or b:GetText() or ""
                if n > 0 and not t:find(MARK, 1, true) then
                    if fs then fs:SetText(t .. " " .. MARK .. "(+" .. n .. ")|r") else b:SetText(t .. " " .. MARK .. "(+" .. n .. ")|r") end
                end
            end
        end
    end
end

-- für den Mondhain-Questtracker: wie viele aus der Gruppe haben die Quest?
function ns.QuestPartyCount(id)
    if not db or not on("party") or not id then return 0 end
    if not (IsInGroup and IsInGroup()) or (IsInRaid and IsInRaid()) then return 0 end
    local ok, names = pcall(partyOnQuest, id)
    return ok and #names or 0
end

-- /mh questgruppe: woher die Gruppen-Infos kommen
function ns.DebugQuestParty()
    ns.Print("Quests in der Gruppe:")
    for _, u in ipairs(partyUnits()) do
        local n = UnitName(u) or "?"
        local c = 0
        if remote[n] then for _ in pairs(remote[n]) do c = c + 1 end end
        print(("  %s: Mondhain meldet %s Quests"):format(n, remote[n] and c or "keine"))
    end
    print("  Questie: " .. (questieComms() and "ja" or "nein") .. " · IsUnitOnQuest: "
        .. ((C_QuestLog and C_QuestLog.IsUnitOnQuest or IsUnitOnQuest) and "ja" or "nein"))
end

---------------------------------------------------------------------------
-- Automatisch annehmen / abgeben (Ben 25.11. 16:19, getrennt schaltbar)
-- Shift gedrückt halten = diesmal nichts automatisch. Graue (triviale) Quests
-- werden nicht von selbst angenommen. Bei mehreren Belohnungen wählst du selbst.
---------------------------------------------------------------------------
local function auto(key) return on(key) and not IsShiftKeyDown() end

local function gossipAuto()
    if not (C_GossipInfo and C_GossipInfo.GetActiveQuests) then return end
    if auto("autoTurnIn") then
        for _, q in ipairs(C_GossipInfo.GetActiveQuests() or {}) do
            if q.isComplete and q.questID then C_GossipInfo.SelectActiveQuest(q.questID) return end
        end
    end
    if auto("autoAccept") then
        for _, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do
            if q.questID and not q.isTrivial then C_GossipInfo.SelectAvailableQuest(q.questID) return end
        end
    end
end

local function greetingAuto()
    if auto("autoTurnIn") and GetNumActiveQuests then
        for i = 1, GetNumActiveQuests() do
            local _, complete = GetActiveTitle(i)
            if complete then SelectActiveQuest(i) return end
        end
    end
    if auto("autoAccept") and GetNumAvailableQuests then
        for i = 1, GetNumAvailableQuests() do
            local trivial = GetAvailableQuestInfo and GetAvailableQuestInfo(i)
            if not trivial then SelectAvailableQuest(i) return end
        end
    end
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.questHelp
    if db and db.enabled == false then return end
    local function refresh()
        pcall(showLevel)
        pcall(markBestReward)
        pcall(showPartyInDetail)
    end
    if QuestInfo_Display then
        hooksecurefunc("QuestInfo_Display", function() C_Timer.After(0, refresh) end)
    end
    ns.RegisterEvent("GOSSIP_SHOW", function() pcall(cacheGossip); pcall(gossipAuto) end)
    ns.RegisterEvent("QUEST_GREETING", function() pcall(cacheGreeting); pcall(greetingAuto) end)
    ns.RegisterEvent("QUEST_DETAIL", function()
        if auto("autoAccept") then
            if QuestGetAutoAccept and QuestGetAutoAccept() then
                if AcknowledgeAutoAcceptQuest then pcall(AcknowledgeAutoAcceptQuest) end
            else
                pcall(AcceptQuest)
            end
        end
    end)
    ns.RegisterEvent("QUEST_ACCEPT_CONFIRM", function()           -- Begleitquests von Mitspielern
        if auto("autoAccept") and ConfirmAcceptQuest then pcall(ConfirmAcceptQuest) end
    end)
    ns.RegisterEvent("QUEST_PROGRESS", function()
        if auto("autoTurnIn") and IsQuestCompletable and IsQuestCompletable() then pcall(CompleteQuest) end
    end)
    ns.RegisterEvent("QUEST_COMPLETE", function()
        if not auto("autoTurnIn") then return end
        local n = GetNumQuestChoices and GetNumQuestChoices() or 0
        if n <= 1 then pcall(GetQuestReward, n) end              -- bei Auswahl: du entscheidest (Münze zeigt den Wert)
    end)
    for _, e in ipairs({ "QUEST_DETAIL", "QUEST_COMPLETE", "QUEST_PROGRESS" }) do
        ns.RegisterEvent(e, function() C_Timer.After(0.05, refresh) end)
    end
    -- Gruppe
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(PREFIX) end
    ns.RegisterEvent("CHAT_MSG_ADDON", function(_, prefix, msg, _, sender)
        if prefix ~= PREFIX or type(msg) ~= "string" then return end
        local name = Ambiguate and Ambiguate(sender or "", "none") or sender
        if not name or name == UnitName("player") then return end
        local kind, body = msg:match("^(%a):(.*)$")
        if kind == "L" then remote[name] = {} end
        if (kind == "L" or kind == "M") and remote[name] then
            for id in body:gmatch("%d+") do remote[name][tonumber(id)] = true end
            if QuestLog_Update and _G.QuestLogFrame and _G.QuestLogFrame:IsShown() then pcall(QuestLog_Update) end
            if ns.QuestTracker and ns.QuestTracker.Refresh then pcall(ns.QuestTracker.Refresh, ns.QuestTracker) end
        end
    end)
    ns.RegisterEvent("GROUP_ROSTER_UPDATE", function()
        if not (IsInGroup and IsInGroup()) then wipe(remote) end
        requestSend()
    end)
    -- Annahme: nur der Titel (Ben 26.11. 07:01)
    ns.RegisterEvent("QUEST_ACCEPTED", function(_, a, b)
        local id = (type(b) == "number" and b > 0) and b or a
        local title
        if C_QuestLog and C_QuestLog.GetTitleForQuestID then
            local ok, t = pcall(C_QuestLog.GetTitleForQuestID, id); if ok then title = t end
        end
        if not title and GetQuestLogTitle and type(a) == "number" then
            local t, _, _, isHeader, _, _, _, qid = GetQuestLogTitle(a)
            if t and not isHeader then title = t; id = qid or id end
        end
        if type(id) == "number" then justAccepted[id] = true end
        if on("announce") and on("announceAccept") and title then
            announce(("Quest angenommen: [%s]"):format(title))
        end
    end)
    ns.RegisterEvent("QUEST_LOG_UPDATE", function()
        requestSend()
        C_Timer.After(0.3, function() pcall(scanProgress) end)
    end)
    ns.RegisterEvent("PLAYER_ENTERING_WORLD", function() C_Timer.After(3, function() pcall(scanProgress); requestSend() end) end)
    if QuestLog_Update then hooksecurefunc("QuestLog_Update", function() pcall(updateList) end) end

    ns.RegisterEvent("GET_ITEM_INFO_RECEIVED", function()
        if _G.QuestInfoRewardsFrame and _G.QuestInfoRewardsFrame:IsVisible() then pcall(markBestReward) end
    end)
end
