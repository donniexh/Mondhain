-- Mondhain – schlanker Chat
-- Unten links, ohne Kasten und ohne Seitenknöpfe. Die Schrift bekommt einen
-- Schatten und schwebt frei über der Welt. Reiter (Allgemein, Kampflog …)
-- bleiben als reine Schrift. Platz und Größe kommen aus Mondhain, nicht mehr
-- aus Blizzards HUD-Bearbeitung.
--
-- Der Chat wird NICHT umgehängt (das würde das Andocken der Reiter stören),
-- sondern nur festgehalten: Setzt Blizzard ihn woanders hin, holt Mondhain ihn zurück.
-- Unten im Halter bleibt Platz für die Eingabezeile.

local _, ns = ...
local mod = ns.NewModule("Chat")
ns.Chat = mod

local EDIT_H = 28 -- Platz für die Eingabezeile unter dem Text

-- Hintergrundfarben zur Auswahl (Blizzards eigener Chat-Hintergrund ist aus)
local BG_COLORS = {
    { key = "schwarz",   label = "Schwarz",    rgb = { 0, 0, 0 } },
    { key = "nacht",     label = "Nachtblau",  rgb = { 0.03, 0.06, 0.14 } },
    { key = "moos",      label = "Moosgrün",   rgb = { 0.04, 0.10, 0.05 } },
    { key = "mahagoni",  label = "Mahagoni",   rgb = { 0.16, 0.06, 0.03 } },
}
mod.BG_COLORS = BG_COLORS
local db, holder
local hider = CreateFrame("Frame")
hider:Hide()

---------------------------------------------------------------------------
-- Unsichtbar machen (ohne Blizzard-Funktionen aufzurufen)
---------------------------------------------------------------------------
-- Textur dauerhaft durchsichtig: setzt Blizzard sie wieder sichtbar, geht sie zurück auf 0
local function zero(tex)
    if not tex or tex.mondhainZero then return end
    tex.mondhainZero = true
    tex:SetAlpha(0)
    hooksecurefunc(tex, "SetAlpha", function(self, a)
        if a and a ~= 0 then self:SetAlpha(0) end
    end)
end

local function stripTextures(frame)
    if not frame or not frame.GetRegions then return end
    for _, r in ipairs({ frame:GetRegions() }) do
        if r.GetObjectType and r:GetObjectType() == "Texture" then zero(r) end
    end
end

local function stash(f)
    if f and f.SetParent and f:GetParent() ~= hider then f:SetParent(hider) end
end

local SIDE_BUTTONS = {
    "ChatFrameMenuButton", "ChatFrameChannelButton", "QuickJoinToastButton",
    "ChatFrameToggleVoiceDeafenButton", "ChatFrameToggleVoiceMuteButton",
    "TextToSpeechButtonFrame", "TextToSpeechButton",
}

local function styleChatFrame(i)
    local name = "ChatFrame" .. i
    local cf = _G[name]
    if not cf then return end

    -- Kasten weg
    stripTextures(cf)
    if CHAT_FRAME_TEXTURES then
        for _, sfx in ipairs(CHAT_FRAME_TEXTURES) do zero(_G[name .. sfx]) end
    end
    if cf.Background then zero(cf.Background) end

    -- Knopfleiste am Rand (hoch/runter/minimieren) weg
    stash(_G[name .. "ButtonFrame"])
    stash(cf.buttonFrame)

    -- Reiter: nur noch Schrift
    local tab = _G[name .. "Tab"]
    if tab then stripTextures(tab) end

    -- Schatten für die Schrift, damit sie auf hellem Boden lesbar bleibt
    cf:SetShadowOffset(1, -1)
    cf:SetShadowColor(0, 0, 0, 1)
end

local function styleAll()
    for i = 1, (NUM_CHAT_WINDOWS or 10) do styleChatFrame(i) end
    for _, n in ipairs(SIDE_BUTTONS) do stash(_G[n]) end
end

---------------------------------------------------------------------------
-- Platz und Größe
---------------------------------------------------------------------------
local busy = false
local hookedEdit = {}
local function anchorEditBoxes()
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local eb = _G["ChatFrame" .. i .. "EditBox"]
        if eb then
            eb:ClearAllPoints()
            eb:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", 0, 0)
            eb:SetPoint("BOTTOMRIGHT", holder, "BOTTOMRIGHT", 0, 0)
            if not hookedEdit[eb] then
                hookedEdit[eb] = true
                hooksecurefunc(eb, "SetPoint", function()
                    if not busy then busy = true; anchorEditBoxes(); busy = false end
                end)
            end
        end
    end
end

local function anchor()
    if busy or not holder then return end
    busy = true
    local cf = ChatFrame1
    cf:ClearAllPoints()
    cf:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", 0, EDIT_H)
    cf:SetSize(db.width, math.max(db.height - EDIT_H, 40))
    anchorEditBoxes()
    busy = false
end

-- Schleier hinter dem Text: Mitte gleichmäßig, nach oben und rechts weich
-- auslaufend – keine harte Kante, die sich auf dem Holz abzeichnet
local FADE = 46
local function gradient(t, dir, r, g, b, a1, a2)
    t:SetColorTexture(1, 1, 1, 1)
    if CreateColor and t.SetGradient then
        pcall(t.SetGradient, t, dir, CreateColor(r, g, b, a1), CreateColor(r, g, b, a2))
    elseif t.SetGradientAlpha then
        t:SetGradientAlpha(dir, r, g, b, a1, r, g, b, a2)
    end
end

function mod:UpdateBackground()
    if not holder or not holder.bg then return end
    local c = BG_COLORS[1]
    for _, e in ipairs(BG_COLORS) do if e.key == db.bgColor then c = e end end
    local r, g, b = c.rgb[1], c.rgb[2], c.rgb[3]
    local a = (db.bgAlpha or 0) / 100
    holder.bg:SetColorTexture(r, g, b, a)
    gradient(holder.bgTop, "VERTICAL", r, g, b, a, 0)      -- unten voll, oben weg
    gradient(holder.bgRight, "HORIZONTAL", r, g, b, a, 0)  -- links voll, rechts weg
    gradient(holder.bgCorner, "HORIZONTAL", r, g, b, a * 0.45, 0)
end

-- Nächste Farbe in der Liste; gibt den Namen zurück
function mod:NextColor()
    db = db or ns.db.chat
    local idx = 1
    for i, e in ipairs(BG_COLORS) do if e.key == db.bgColor then idx = i end end
    local nxt = BG_COLORS[idx % #BG_COLORS + 1]
    db.bgColor = nxt.key
    self:UpdateBackground()
    return nxt.label
end

function mod:ColorLabel()
    db = db or ns.db.chat
    for _, e in ipairs(BG_COLORS) do if e.key == db.bgColor then return e.label end end
    return BG_COLORS[1].label
end

function mod:SetSize(w, h)
    if w then db.width = w end
    if h then db.height = h end
    if not holder then return end
    holder:SetSize(db.width, db.height)
    anchor()
end

---------------------------------------------------------------------------
-- Reiter einrichten: Allgemein (ohne Handel) · Kampflog · Handel
-- Läuft einmalig. Danach speichert Blizzard die Reiter selbst.
---------------------------------------------------------------------------
local TRADE_NAMES = { "Handel", "Trade" }

-- Blizzard-Chatfunktionen: neue Versionen als Methode am Fenster, alte global
local function call(frame, method, ...)
    if frame[method] then return frame[method](frame, ...) end
    local g = _G["ChatFrame_" .. method]
    if g then return g(frame, ...) end
end

-- Wie heißt der Handelskanal hier? (Forever kann z. B. „Handel - Stadt“ melden)
local function tradeChannelName()
    local list = { GetChannelList() }
    for i = 1, #list, 3 do
        local name = list[i + 1]
        if type(name) == "string" then
            for _, t in ipairs(TRADE_NAMES) do
                if name:find("^" .. t) then return name:match("^(%S+)") or name end
            end
        end
    end
    return TRADE_NAMES[1]
end

local function findWindow(title)
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local name, _, _, _, _, _, shown, _, docked = GetChatWindowInfo(i)
        if name == title and (shown or docked) then return _G["ChatFrame" .. i] end
    end
end

function mod:SetupTabs()
    if InCombatLockdown() then
        ns.Print("Chat-Reiter lassen sich nur außerhalb des Kampfes einrichten.")
        return
    end
    if not FCF_OpenNewWindow then
        ns.Print("Neue Chat-Reiter kann Mondhain hier nicht anlegen.")
        return
    end
    local trade = tradeChannelName()

    -- Handel aus „Allgemein“ herausnehmen
    call(ChatFrame1, "RemoveChannel", trade)

    -- Reiter „Handel“ anlegen (oder vorhandenen weiterverwenden), nur Handelskanal
    local tf = findWindow("Handel") or FCF_OpenNewWindow("Handel")
    if tf then
        call(tf, "RemoveAllMessageGroups")
        if tf.channelList then
            for _, ch in ipairs({ unpack(tf.channelList) }) do call(tf, "RemoveChannel", ch) end
        end
        call(tf, "AddChannel", trade)
    end

    db.tabsDone = true
    styleAll()
    anchor()
    if FCF_SelectDockFrame then FCF_SelectDockFrame(ChatFrame1) end -- wieder auf „Allgemein“
    ns.Print("Chat-Reiter eingerichtet: Allgemein · Kampflog · Handel (Kanal: " .. trade .. ").")
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.chat
    if not db.enabled or not ChatFrame1 then return end

    holder = CreateFrame("Frame", "MondhainChatHolder", UIParent)
    holder:SetSize(db.width, db.height)
    holder:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    holder:SetFrameStrata("BACKGROUND")
    holder:SetFrameLevel(6) -- über der Wurzel (die liegt ganz hinten)

    -- Eigener Hintergrund hinter dem Text, reicht etwas über die Reiter hinaus nach oben
    holder.bg = holder:CreateTexture(nil, "BACKGROUND")
    holder.bg:SetPoint("BOTTOMLEFT", -8, -8)
    holder.bg:SetPoint("TOPRIGHT", 0, 0)
    holder.bgTop = holder:CreateTexture(nil, "BACKGROUND")
    holder.bgTop:SetPoint("BOTTOMLEFT", holder.bg, "TOPLEFT")
    holder.bgTop:SetPoint("BOTTOMRIGHT", holder.bg, "TOPRIGHT")
    holder.bgTop:SetHeight(FADE)
    holder.bgRight = holder:CreateTexture(nil, "BACKGROUND")
    holder.bgRight:SetPoint("TOPLEFT", holder.bg, "TOPRIGHT")
    holder.bgRight:SetPoint("BOTTOMLEFT", holder.bg, "BOTTOMRIGHT")
    holder.bgRight:SetWidth(FADE)
    holder.bgCorner = holder:CreateTexture(nil, "BACKGROUND")
    holder.bgCorner:SetPoint("BOTTOMLEFT", holder.bg, "TOPRIGHT")
    holder.bgCorner:SetSize(FADE, FADE)
    mod:UpdateBackground()

    if ChatFrame1.SetClampRectInsets then ChatFrame1:SetClampRectInsets(0, 0, 0, 0) end
    hooksecurefunc(ChatFrame1, "SetPoint", function() if not busy then anchor() end end)
    hooksecurefunc(ChatFrame1, "SetSize", function() if not busy then anchor() end end)
    anchor()

    -- Eingabezeile nur beim Schreiben (Enter), sonst unsichtbar
    if db.imStyle and GetCVar and GetCVar("chatStyle") ~= "im" then
        SetCVar("chatStyle", "im")
    end

    styleAll()
    C_Timer.After(1, function() styleAll() anchor() end)
    -- Neue Chatfenster (z. B. Flüstern als eigener Reiter) ebenfalls schlank machen
    ns.RegisterEvent("UPDATE_CHAT_WINDOWS", styleAll)
    ns.RegisterEvent("UPDATE_FLOATING_CHAT_WINDOWS", function() styleAll() anchor() end)

    ns.MakeMovable(holder, db, "Chat", nil, true, {
        set = function(w, h) mod:SetSize(w, h) end, minW = 200, minH = 80 })

    -- Rechtsklick auf einen Chat-Reiter: Mondhain-Eintrag oben im Blizzard-Menü
    local menuSeen = false
    if Menu and Menu.ModifyMenu then
        Menu.ModifyMenu("MENU_FCF_TAB", function(_, root)
            menuSeen = true
            root:CreateDivider()
            root:CreateTitle(ns.IconText(16) .. " Mondhain")
            root:CreateButton("Hintergrund, Farbe, Größe …", function() ns.OpenOptions("chat") end)
        end)
    end
    -- Notweg: Kennt Forever das Menü nicht, öffnet der Rechtsklick direkt Mondhains Chat-Seite
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local tab = _G["ChatFrame" .. i .. "Tab"]
        if tab then
            tab:HookScript("OnClick", function(_, btn)
                if btn == "RightButton" and not menuSeen then ns.OpenOptions("chat") end
                menuSeen = false
            end)
        end
    end

    -- Einmalig die Reiter einrichten (etwas später, wenn die Kanäle stehen)
    if not db.tabsDone then
        C_Timer.After(4, function()
            if InCombatLockdown() then
                ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
                    if not db.tabsDone then mod:SetupTabs() end
                end)
            else
                mod:SetupTabs()
            end
        end)
    end
end
