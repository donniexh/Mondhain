-- Mondhain – Händler
-- Kacheln wie bei Blizzard (zwei Spalten, Seiten), dazu Suche, Filter und
-- Sortierung – für alle Händler. Bekannte Rezepte, Reittiere usw. sind grün
-- hinterlegt, nicht benutzbare Waren rot. „Lernbar“ = Rezept/Reittier/Haustier,
-- das du noch nicht kennst und benutzen kannst.
-- Kaufen läuft über Blizzards eigene Knöpfe (mit Rückfrage bei Sonderwährung).
--   Rechtsklick          kaufen
--   Umschalt+Rechtsklick Menge wählen
--   Umschalt+Linksklick  in den Chat verlinken
--   Strg+Linksklick      anprobieren

local _, ns = ...
local mod = ns.NewModule("Merchant")
ns.Merchant = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local COLS = 2
local KNOWN_TEXT = ITEM_SPELL_KNOWN or "Bereits bekannt"
local FILTERS = { "all", "learnable", "usable", "known" }
local FILTER_LABEL = { all = "Alle", learnable = "Lernbar", usable = "Benutzbar", known = "Bekannt" }
local SORTS = { "default", "learnable", "name", "price", "quality" }
local SORT_LABEL = { default = "Händler", learnable = "Lernbar zuerst", name = "Name", price = "Preis", quality = "Seltenheit" }

local db, panel
local rows = {}
local items, view = {}, {}
local page = 1
local scanTip

---------------------------------------------------------------------------
-- Daten
---------------------------------------------------------------------------
local function perPage() return MERCHANT_ITEMS_PER_PAGE or 10 end

local function itemInfo(i)
    if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
        local d = C_MerchantFrame.GetItemInfo(i)
        if d then
            return d.name, d.texture, d.price or 0, d.stackCount or 1, d.numAvailable or -1,
                d.isUsable ~= false, d.hasExtendedCost
        end
    end
    local name, tex, price, qty, avail, _, usable, ext = GetMerchantItemInfo(i)
    return name, tex, price or 0, qty or 1, avail or -1, usable ~= false, ext
end

-- Plätze (Blizzards eigene, übersetzte Bezeichnungen)
local SLOTS = {
    { key = "head",     inv = { "INVTYPE_HEAD" },     words = { "helm", "kappe", "haube", "maske", "kopf" } },
    { key = "neck",     inv = { "INVTYPE_NECK" },     words = { "halskette", "amulett", "anhänger" } },
    { key = "shoulder", inv = { "INVTYPE_SHOULDER" }, words = { "schulter" } },
    { key = "back",     inv = { "INVTYPE_CLOAK" },    words = { "umhang", "mantel" } },
    { key = "chest",    inv = { "INVTYPE_CHEST", "INVTYPE_ROBE" }, words = { "weste", "tunika", "harnisch", "brust", "robe", "wams", "rüstung" } },
    { key = "wrist",    inv = { "INVTYPE_WRIST" },    words = { "armschiene", "armbinde", "manschette" } },
    { key = "hands",    inv = { "INVTYPE_HAND" },     words = { "handschuh", "stulpen", "fäustling" } },
    { key = "waist",    inv = { "INVTYPE_WAIST" },    words = { "gürtel", "gurt" } },
    { key = "legs",     inv = { "INVTYPE_LEGS" },     words = { "kilt", "beinschützer", "hose", "gamaschen", "beinkleid", "beinplatten" } },
    { key = "feet",     inv = { "INVTYPE_FEET" },     words = { "stiefel", "schuhe", "sandalen", "treter" } },
    { key = "finger",   inv = { "INVTYPE_FINGER" },   words = { "ring" } },
    { key = "trinket",  inv = { "INVTYPE_TRINKET" },  words = {} },
    { key = "weapon",   label = "Waffen", inv = { "INVTYPE_WEAPON", "INVTYPE_2HWEAPON", "INVTYPE_WEAPONMAINHAND",
        "INVTYPE_WEAPONOFFHAND", "INVTYPE_RANGED", "INVTYPE_RANGEDRIGHT", "INVTYPE_THROWN" }, words = {} },
    { key = "offhand",  label = "Schild / Nebenhand", inv = { "INVTYPE_SHIELD", "INVTYPE_HOLDABLE" }, words = { "schild" } },
}
local SLOT_BY_INV, SLOT_BY_TEXT = {}, {}
for _, sl in ipairs(SLOTS) do
    for _, inv in ipairs(sl.inv) do
        SLOT_BY_INV[inv] = sl.key
        local txt = _G[inv]
        if type(txt) == "string" and txt ~= "" and not SLOT_BY_TEXT[txt] then SLOT_BY_TEXT[txt] = sl.key end
    end
    sl.label = sl.label or _G[sl.inv[1]] or sl.key
end

-- Tooltip einmal lesen: bekannt? gesamter Text (für die Suche nach Werten), Platz
local tipCache = {}
local function readTooltip(i)
    if tipCache[i] then return tipCache[i] end
    local known, parts, slot = false, {}, nil
    local function line(l, r)
        if l and not ns.isSecret(l) then
            if l == KNOWN_TEXT then known = true end
            if not slot and SLOT_BY_TEXT[l] then slot = SLOT_BY_TEXT[l] end
            parts[#parts + 1] = l
        end
        if r and not ns.isSecret(r) then parts[#parts + 1] = r end
    end
    if C_TooltipInfo and C_TooltipInfo.GetMerchantItem then
        local data = C_TooltipInfo.GetMerchantItem(i)
        for _, ln in ipairs(data and data.lines or {}) do line(ln.leftText, ln.rightText) end
    else
        if not scanTip then
            scanTip = CreateFrame("GameTooltip", "MondhainMerchantScan", UIParent, "GameTooltipTemplate")
        end
        scanTip:SetOwner(UIParent, "ANCHOR_NONE")
        scanTip:SetMerchantItem(i)
        for l = 1, scanTip:NumLines() do
            local a, b = _G["MondhainMerchantScanTextLeft" .. l], _G["MondhainMerchantScanTextRight" .. l]
            line(a and a:GetText(), b and b:IsShown() and b:GetText() or nil)
        end
        scanTip:Hide()
    end
    local t = { known = known, text = table.concat(parts, "\n"):lower(), slot = slot }
    tipCache[i] = t
    return t
end
local function isKnown(i) return readTooltip(i).known end

-- Set aus dem Namen: „… des Sturmreiters“, „… der Weisheit“, „Totemikerleder…“
local function setOf(name)
    local n = (name or ""):gsub("^[^:]+:%s*", "")
    local suffix = n:match("%s(des%s.+)$") or n:match("%s(der%s.+)$") or n:match("%s(den%s.+)$")
    if suffix then return suffix end
    for _, mat in ipairs({ "leder", "stoff", "ketten", "platten", "seiden", "runenstoff" }) do
        local pre = n:match("^(.-)" .. mat)
        if pre and #pre >= 5 and not pre:find("%s") then return pre end
    end
end

local function slotOf(link, name, tip)
    if link then
        local equipLoc
        if C_Item and C_Item.GetItemInfoInstant then equipLoc = select(4, C_Item.GetItemInfoInstant(link))
        elseif GetItemInfoInstant then equipLoc = select(4, GetItemInfoInstant(link)) end
        if equipLoc and SLOT_BY_INV[equipLoc] then return SLOT_BY_INV[equipLoc] end
    end
    if tip.slot then return tip.slot end
    local n = (name or ""):lower():gsub("^[^:]+:%s*", "")
    for _, sl in ipairs(SLOTS) do
        for _, w in ipairs(sl.words) do
            if n:find(w, 1, true) then return sl.key end
        end
    end
end

local function costText(i, price, ext)
    local parts = {}
    if price and price > 0 then parts[#parts + 1] = ns.CoinString(price) end
    if ext and GetMerchantItemCostInfo then
        for c = 1, (GetMerchantItemCostInfo(i) or 0) do
            local tex, value = GetMerchantItemCostItem(i, c)
            if tex and value then parts[#parts + 1] = ("%d |T%s:0|t"):format(value, tex) end
        end
    end
    return table.concat(parts, "  ")
end

local function sortPrice(i, price, ext)
    if price and price > 0 then return price end
    if ext and GetMerchantItemCostInfo and (GetMerchantItemCostInfo(i) or 0) > 0 then
        local _, value = GetMerchantItemCostItem(i, 1)
        return (value or 0) * 1e6 -- Sonderwährung hinter Gold einsortieren
    end
    return 0
end

-- Rezept, Reittier oder Haustier? (das sind die Dinge, die man „lernt“)
local function teachable(link)
    if not link then return false end
    local classID, subID
    if C_Item and C_Item.GetItemInfoInstant then
        classID, subID = select(6, C_Item.GetItemInfoInstant(link))
    elseif GetItemInfoInstant then
        classID, subID = select(6, GetItemInfoInstant(link))
    end
    if classID == 9 then return true end                          -- Rezept/Muster/Pläne
    if classID == 15 and (subID == 2 or subID == 5) then return true end -- Haustier, Reittier
    return false
end

local collectOne
local function collect()
    wipe(items)
    for i = 1, (GetMerchantNumItems() or 0) do
        local ok, err = pcall(collectOne, i)
        if not ok and not mod.warned then
            mod.warned = true
            ns.Print("|cffff5555Händler-Fehler:|r " .. tostring(err))
        end
    end
end

function collectOne(i)
    do
        local name, tex, price, qty, avail, usable, ext = itemInfo(i)
        local link = GetMerchantItemLink(i)
        local quality = 1
        if link then
            local q = C_Item and C_Item.GetItemQualityByID and C_Item.GetItemQualityByID(link)
            if not q then
                local gi = (C_Item and C_Item.GetItemInfo) or GetItemInfo
                if gi then q = select(3, gi(link)) end
            end
            quality = q or 1
        end
        items[#items + 1] = {
            index = i, name = name or "…", tex = tex, price = price, qty = qty, avail = avail,
            usable = usable, ext = ext, link = link, quality = quality,
            known = isKnown(i), cost = costText(i, price, ext), sortPrice = sortPrice(i, price, ext),
        }
        local it = items[#items]
        it.learnable = teachable(link) and not it.known and it.usable
        local tip = readTooltip(i)
        it.text = tip.text
        it.slot = slotOf(link, name, tip)
        it.set = setOf(name)
    end
end

local function buildView()
    wipe(view)
    local q = panel.search:GetText():lower()
    local f = db.filter or "all"
    for _, it in ipairs(items) do
        local ok = (q == "" or it.name:lower():find(q, 1, true) or (it.text and it.text:find(q, 1, true)))
        if ok and mod.slot then ok = it.slot == mod.slot end
        if ok and mod.set then ok = it.set == mod.set end
        if ok and f == "learnable" then ok = it.learnable end
        if ok and f == "usable" then ok = it.usable and not it.known end
        if ok and f == "known" then ok = it.known end
        if ok then view[#view + 1] = it end
    end
    local s = db.sort or "default"
    if s ~= "default" then
        table.sort(view, function(a, b)
            if s == "name" then return a.name < b.name end
            if s == "price" then
                if a.sortPrice ~= b.sortPrice then return a.sortPrice < b.sortPrice end
                return a.name < b.name
            end
            if s == "quality" then
                if a.quality ~= b.quality then return a.quality > b.quality end
                return a.name < b.name
            end
            -- lernbar → benutzbar → nicht benutzbar → bekannt
            local function rank(x)
                if x.learnable then return 0 end
                if x.known then return 3 end
                return x.usable and 1 or 2
            end
            local ra, rb = rank(a), rank(b)
            if ra ~= rb then return ra < rb end
            return a.index < b.index
        end)
    end
end

---------------------------------------------------------------------------
-- Kaufen über Blizzards eigenen Knopf (mit dessen Rückfragen)
---------------------------------------------------------------------------
local function blizzButton(index)
    local page = math.ceil(index / perPage())
    if MerchantFrame.page ~= page then
        MerchantFrame.page = page
        if MerchantFrame_Update then MerchantFrame_Update() end
    end
    local slot = (index - 1) % perPage() + 1
    return _G["MerchantItem" .. slot .. "ItemButton"]
end

local function rowClick(self, button)
    local it = self.item
    if not it then return end
    if button == "LeftButton" then
        if IsModifiedClick("CHATLINK") and it.link then
            ChatEdit_InsertLink(it.link)
        elseif IsModifiedClick("DRESSUP") and it.link then
            DressUpItemLink(it.link)
        end
        return
    end
    -- Rechtsklick: kaufen (Umschalt = Menge wählen) – Blizzard fragt bei Sonderwährung nach
    local b = blizzButton(it.index)
    if b then
        if IsShiftKeyDown() and MerchantItemButton_OnModifiedClick then
            MerchantItemButton_OnModifiedClick(b, "RightButton")
        elseif MerchantItemButton_OnClick then
            MerchantItemButton_OnClick(b, "RightButton")
        else
            b:Click("RightButton")
        end
    end
end

---------------------------------------------------------------------------
-- Anzeige
---------------------------------------------------------------------------
local function perView() return #rows end

local function paint()
    if not panel then return end
    local n = perView()
    local pages = math.max(1, math.ceil(#view / n))
    page = math.max(1, math.min(page, pages))
    for r = 1, n do
        local t = rows[r]
        local it = view[(page - 1) * n + r]
        t.item = it
        if it then
            t.icon:SetTexture(it.tex)
            local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[it.quality]
            t.name:SetText(it.name)
            if c then
                t.name:SetTextColor(c.r, c.g, c.b)
                t.border:SetVertexColor(c.r, c.g, c.b, it.quality > 1 and 0.9 or 0.35)
            else
                t.name:SetTextColor(1, 1, 1)
                t.border:SetVertexColor(1, 1, 1, 0.35)
            end
            t.cost:SetText(it.cost)
            t.count:SetText((it.qty and it.qty > 1) and it.qty or "")
            t.stock:SetText((it.avail and it.avail >= 0) and ("(" .. it.avail .. ")") or "")
            t.known:SetShown(it.known)
            if it.known then
                t.bg:SetColorTexture(0.10, 0.42, 0.12, 0.35)
                t.icon:SetVertexColor(0.8, 1, 0.8)
            elseif not it.usable then
                t.bg:SetColorTexture(0.50, 0.05, 0.05, 0.35)
                t.icon:SetVertexColor(1, 0.4, 0.4)
            elseif it.learnable then
                t.bg:SetColorTexture(0.45, 0.35, 0.10, 0.25) -- lernbar: warm hervorgehoben
                t.icon:SetVertexColor(1, 1, 1)
            else
                t.bg:SetColorTexture(0, 0, 0, 0.35)
                t.icon:SetVertexColor(1, 1, 1)
            end
            t:Show()
        else
            t:Hide()
        end
    end
    local known, learn = 0, 0
    for _, it in ipairs(items) do
        if it.known then known = known + 1 end
        if it.learnable then learn = learn + 1 end
    end
    if panel.empty then
        local none = #view == 0 and #items > 0
        panel.empty:SetShown(none)
    end
    panel.pageText:SetText(("Seite %d von %d"):format(page, pages))
    panel.prev:SetEnabled(page > 1)
    panel.next:SetEnabled(page < pages)
    panel.count:SetText(("%d Waren · %d lernbar · %d bekannt"):format(#view, learn, known))
    local bits = { FILTER_LABEL[db.filter or "all"] }
    if mod.slot then
        for _, sl in ipairs(SLOTS) do if sl.key == mod.slot then bits[#bits + 1] = sl.label end end
    end
    if mod.set then bits[#bits + 1] = mod.set end
    panel.filterBtn.text:SetText("Filter: " .. table.concat(bits, " · ") .. "  |TInterface\\Buttons\\Arrow-Down-Up:12:12:0:-2|t")
    panel.sortBtn.text:SetText(SORT_LABEL[db.sort or "default"] .. "  |TInterface\\Buttons\\Arrow-Down-Up:12:12:0:-2|t")
end

local function refresh(rescan)
    if not panel or not panel:IsShown() then return end
    if rescan then wipe(tipCache) end
    collect()
    buildView()
    paint()
end
mod.Refresh = refresh

local function smallButton(parent, w)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(w, 20)
    b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    b:SetBackdropColor(0.12, 0.09, 0.06, 0.95)
    b:SetBackdropBorderColor(0.45, 0.32, 0.18, 1)
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.text:SetPoint("CENTER")
    b:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(0.9, 0.7, 0.35, 1) end)
    b:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(0.45, 0.32, 0.18, 1) end)
    return b
end

local function cycle(list, cur)
    for i, v in ipairs(list) do if v == cur then return list[i % #list + 1] end end
    return list[1]
end

local function place()
    -- über Blizzards Raster legen: von der Zeile unter dem Titel bis zu den Seitenknöpfen
    local first, second = _G.MerchantItem1, _G.MerchantItem2
    local prevBtn = _G.MerchantPrevPageButton
    panel:ClearAllPoints()
    local l = first and first:GetLeft()
    local r = second and second:GetRight()
    local t = first and first:GetTop()
    local b = prevBtn and prevBtn:GetBottom()
    if l and r and t and b then
        -- alle sind Kinder des Händlerfensters, gleiche Skalierung
        panel:SetPoint("TOPLEFT", first, "TOPLEFT", -6, 46)
        panel:SetWidth(r - l + 12)
        panel:SetHeight(math.max(200, (t + 46) - (b - 4)))
    else
        panel:SetPoint("TOPLEFT", MerchantFrame, "TOPLEFT", 8, -62)
        panel:SetPoint("BOTTOMRIGHT", MerchantFrame, "BOTTOMRIGHT", -8, 92)
    end
end

local function buildRows()
    -- Raster wie Blizzard: 2 Spalten, Höhe passend zum Fenster
    local top, foot = 58, 30
    local w = (panel:GetWidth() - 16 - 6) / COLS
    local th = 46
    local per = math.max(2, math.floor((panel:GetHeight() - top - foot) / (th + 4)))
    local n = per * COLS
    for r = 1, n do
        local t = rows[r]
        if not t then
            t = CreateFrame("Button", nil, panel)
            t:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            t.bg = t:CreateTexture(nil, "BACKGROUND")
            t.bg:SetAllPoints()
            t.hl = t:CreateTexture(nil, "HIGHLIGHT")
            t.hl:SetAllPoints()
            t.hl:SetColorTexture(1, 0.85, 0.4, 0.12)
            t.icon = t:CreateTexture(nil, "ARTWORK")
            t.icon:SetSize(36, 36)
            t.icon:SetPoint("LEFT", 5, 0)
            t.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            t.border = t:CreateTexture(nil, "OVERLAY")
            t.border:SetPoint("TOPLEFT", t.icon, -2, 2)
            t.border:SetPoint("BOTTOMRIGHT", t.icon, 2, -2)
            t.border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
            t.border:SetBlendMode("ADD")
            t.border:SetTexCoord(0.2, 0.8, 0.2, 0.8)
            t.count = t:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
            t.count:SetPoint("BOTTOMRIGHT", t.icon, "BOTTOMRIGHT", -1, 2)
            t.known = t:CreateTexture(nil, "OVERLAY", nil, 2)
            t.known:SetSize(16, 16)
            t.known:SetPoint("TOPLEFT", t.icon, "TOPLEFT", -4, 4)
            t.known:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
            t.name = t:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            t.name:SetPoint("TOPLEFT", t.icon, "TOPRIGHT", 6, 1)
            t.name:SetPoint("RIGHT", -4, 0)
            t.name:SetJustifyH("LEFT")
            t.name:SetJustifyV("TOP")
            t.name:SetHeight(24)
            t.name:SetWordWrap(true)
            t.cost = t:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            t.cost:SetPoint("BOTTOMLEFT", t.icon, "BOTTOMRIGHT", 6, 0)
            t.stock = t:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            t.stock:SetPoint("BOTTOMRIGHT", -4, 3)
            t:SetScript("OnClick", rowClick)
            t:SetScript("OnEnter", function(self)
                if not self.item then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetMerchantItem(self.item.index)
                GameTooltip:AddLine("Rechtsklick: kaufen · Umschalt+Rechtsklick: Menge", 0.6, 0.6, 0.6)
                GameTooltip:Show()
                -- Kauf-Mauszeiger (Säckchen) wie bei Blizzards Kacheln
                if ShowMerchantSellCursor then
                    ShowMerchantSellCursor(self.item.index)
                elseif SetCursor then
                    local poor = (self.item.price or 0) > GetMoney()
                    SetCursor((poor or not self.item.usable) and "BUY_ERROR_CURSOR" or "BUY_CURSOR")
                end
            end)
            t:SetScript("OnLeave", function()
                GameTooltip_Hide()
                if ResetCursor then ResetCursor() end
            end)
            rows[r] = t
        end
        local col = (r - 1) % COLS
        local line = math.floor((r - 1) / COLS)
        t:ClearAllPoints()
        t:SetSize(w, th)
        t:SetPoint("TOPLEFT", panel, "TOPLEFT", 8 + col * (w + 6), -top - line * (th + 4))
    end
    for r = n + 1, #rows do rows[r]:Hide(); rows[r] = nil end
end

local function build()
    panel = CreateFrame("Frame", "MondhainMerchant", MerchantFrame, "BackdropTemplate")
    panel:SetFrameLevel(MerchantFrame:GetFrameLevel() + 60)
    panel:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    panel:SetBackdropColor(0.05, 0.045, 0.04, 1)
    panel:SetBackdropBorderColor(0.35, 0.25, 0.15, 1)
    panel:EnableMouse(true)
    panel:EnableMouseWheel(true)
    panel:SetScript("OnMouseWheel", function(_, d)
        page = page - d
        paint()
    end)

    -- Suche
    local search = CreateFrame("EditBox", "MondhainMerchantSearch", panel, "SearchBoxTemplate")
    search:SetHeight(20)
    search:SetPoint("TOPLEFT", 62, -8)
    search:SetPoint("TOPRIGHT", -10, -8)
    search:SetAutoFocus(false)
    if search.Instructions then search.Instructions:SetText("Suchen …") end
    search:HookScript("OnTextChanged", function() page = 1; buildView(); paint() end)
    search:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    panel.search = search

    panel.filterBtn = smallButton(panel, 190)
    panel.filterBtn:SetPoint("TOPLEFT", 8, -32)
    panel.filterBtn:SetScript("OnClick", function(self) mod:FilterMenu(self) end)
    panel.sortBtn = smallButton(panel, 130)
    panel.sortBtn:SetPoint("LEFT", panel.filterBtn, "RIGHT", 6, 0)
    panel.sortBtn:SetScript("OnClick", function(self) mod:SortMenu(self) end)
    -- leere Ansicht: ein Klick zeigt wieder alles
    panel.empty = smallButton(panel, 220)
    panel.empty:SetPoint("CENTER", 0, 10)
    panel.empty.text:SetText("Nichts passt – alles zeigen")
    panel.empty:SetScript("OnClick", function()
        db.filter, mod.slot, mod.set = "all", nil, nil
        panel.search:SetText("")
        page = 1; buildView(); paint()
    end)
    panel.empty:Hide()
    panel.count = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.count:SetPoint("BOTTOMRIGHT", -8, 9)

    -- Seiten wie bei Blizzard
    panel.prev = CreateFrame("Button", nil, panel)
    panel.prev:SetSize(26, 26)
    panel.prev:SetPoint("BOTTOMLEFT", 8, 2)
    panel.prev:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up")
    panel.prev:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Down")
    panel.prev:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Disabled")
    panel.prev:SetScript("OnClick", function() page = page - 1; paint() end)
    panel.next = CreateFrame("Button", nil, panel)
    panel.next:SetSize(26, 26)
    panel.next:SetPoint("LEFT", panel.prev, "RIGHT", 4, 0)
    panel.next:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
    panel.next:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Down")
    panel.next:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Disabled")
    panel.next:SetScript("OnClick", function() page = page + 1; paint() end)
    panel.pageText = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    panel.pageText:SetPoint("LEFT", panel.next, "RIGHT", 6, 0)
end

-- Ausklappmenüs (Blizzards Menüsystem); ohne das: durchschalten wie bisher
local function changed() page = 1; buildView(); paint() end

function mod:FilterMenu(owner)
    if not (MenuUtil and MenuUtil.CreateContextMenu) then
        db.filter = cycle(FILTERS, db.filter or "all"); changed(); return
    end
    -- Sets mit Fortschritt: bekannt / gesamt
    local sets, order = {}, {}
    for _, it in ipairs(items) do
        if it.set then
            if not sets[it.set] then sets[it.set] = { n = 0, k = 0 }; order[#order + 1] = it.set end
            sets[it.set].n = sets[it.set].n + 1
            if it.known then sets[it.set].k = sets[it.set].k + 1 end
        end
    end
    table.sort(order)
    local slotsHere = {}
    for _, it in ipairs(items) do if it.slot then slotsHere[it.slot] = (slotsHere[it.slot] or 0) + 1 end end

    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle("Zeigen")
        for _, f in ipairs(FILTERS) do
            root:CreateRadio(FILTER_LABEL[f], function() return (db.filter or "all") == f end,
                function() db.filter = f; changed() end)
        end
        local slotMenu = root:CreateButton("Platz")
        slotMenu:CreateRadio("Alle Plätze", function() return mod.slot == nil end, function() mod.slot = nil; changed() end)
        for _, sl in ipairs(SLOTS) do
            if slotsHere[sl.key] then
                slotMenu:CreateRadio(("%s (%d)"):format(sl.label, slotsHere[sl.key]),
                    function() return mod.slot == sl.key end, function() mod.slot = sl.key; changed() end)
            end
        end
        if #order > 0 then
            local setMenu = root:CreateButton("Set")
            setMenu:CreateRadio("Alle Sets", function() return mod.set == nil end, function() mod.set = nil; changed() end)
            for _, name in ipairs(order) do
                local st = sets[name]
                local done = st.k >= st.n and "|TInterface\\RaidFrame\\ReadyCheck-Ready:0|t " or ""
                setMenu:CreateRadio(("%s%s  |cffaaaaaa%d/%d|r"):format(done, name, st.k, st.n),
                    function() return mod.set == name end, function() mod.set = name; changed() end)
            end
        end
        root:CreateDivider()
        root:CreateButton("Alles zurücksetzen", function()
            db.filter, mod.slot, mod.set = "all", nil, nil
            panel.search:SetText("")
            changed()
        end)
    end)
end

function mod:SortMenu(owner)
    if not (MenuUtil and MenuUtil.CreateContextMenu) then
        db.sort = cycle(SORTS, db.sort or "default"); changed(); return
    end
    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle("Sortierung")
        for _, k in ipairs(SORTS) do
            root:CreateRadio(SORT_LABEL[k], function() return (db.sort or "default") == k end,
                function() db.sort = k; changed() end)
        end
    end)
end

local function blizzTiles(alpha)
    for i = 1, 12 do
        local f = _G["MerchantItem" .. i]
        if f then f:SetAlpha(alpha) end
    end
    for _, n in ipairs({ "MerchantPrevPageButton", "MerchantNextPageButton", "MerchantPageText" }) do
        local f = _G[n]
        if f then f:SetAlpha(alpha) end
    end
end

local function updateShown()
    if not panel then return end
    -- nur im Händler-Reiter, nicht beim Rückkauf
    local onMerchant = MerchantFrame:IsShown() and (MerchantFrame.selectedTab or 1) == 1
    if onMerchant then
        if not panel:IsShown() then
            place()
            buildRows()
            panel:Show()
            refresh(true)
        end
        blizzTiles(0)
    else
        panel:Hide()
        blizzTiles(1)
    end
end

function mod:OnEnable()
    db = ns.db.merchant
    if not db.enabled or not MerchantFrame then return end
    build()
    panel:Hide()
    MerchantFrame:HookScript("OnShow", function()
        page = 1
        mod.slot, mod.set = nil, nil
        db.filter = "all" -- jeder Händler zeigt erst einmal alles
        panel.search:SetText("")
        C_Timer.After(0, updateShown)
    end)
    MerchantFrame:HookScript("OnHide", function() panel:Hide() end)
    if MerchantFrame_Update then hooksecurefunc("MerchantFrame_Update", updateShown) end
    ns.RegisterEvent("MERCHANT_UPDATE", function() refresh(false) end)
    ns.RegisterEvent("GET_ITEM_INFO_RECEIVED", function()
        if panel:IsShown() and not mod.pending then
            mod.pending = true
            C_Timer.After(0.4, function() mod.pending = false; refresh(true) end)
        end
    end)
    for _, ev in ipairs({ "NEW_RECIPE_LEARNED", "LEARNED_SPELL_IN_TAB", "NEW_MOUNT_ADDED", "NEW_PET_ADDED", "NEW_TOY_ADDED" }) do
        ns.RegisterEvent(ev, function() C_Timer.After(0.3, function() refresh(true) end) end)
    end
end
