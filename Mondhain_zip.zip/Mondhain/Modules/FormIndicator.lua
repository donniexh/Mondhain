-- Mondhain – Gestalt-Anzeige
-- Erster Test-Baustein: ein Balken, der die aktuelle Gestalt in ihrer
-- Farbe zeigt. Prüft, ob Fundament, Speichern und Verschieben klappen.

local _, ns = ...
local mod = ns.NewModule("FormIndicator")

local WHITE = "Interface\\Buttons\\WHITE8x8"

function mod:OnEnable()
    local db = ns.db.formIndicator
    if not db.enabled then return end

    local f = CreateFrame("Frame", "MondhainFormIndicator", UIParent, "BackdropTemplate")
    f:SetSize(db.width, db.height)
    f:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    f:SetBackdropColor(unpack(ns.colors.background))
    f:SetBackdropBorderColor(unpack(ns.colors.border))

    -- Farbiger Streifen links (wie ein Lesezeichen)
    local stripe = f:CreateTexture(nil, "ARTWORK")
    stripe:SetTexture(WHITE)
    stripe:SetPoint("TOPLEFT", 1, -1)
    stripe:SetPoint("BOTTOMLEFT", 1, 1)
    stripe:SetWidth(4)

    -- Sanfter Farbschimmer über die ganze Breite
    local glow = f:CreateTexture(nil, "BORDER")
    glow:SetTexture(WHITE)
    glow:SetPoint("TOPLEFT", 5, -1)
    glow:SetPoint("BOTTOMRIGHT", -1, 1)

    local text = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("CENTER", 2, 0)

    local function paint(key)
        local r, g, b = ns.GetFormColor(key)
        stripe:SetVertexColor(r, g, b)
        glow:SetGradient("HORIZONTAL",
            CreateColor(r, g, b, 0.35),
            CreateColor(r, g, b, 0.0))
        f:SetBackdropBorderColor(r * 0.6, g * 0.6, b * 0.6, 1)
        text:SetText(ns.palette[key].name)
        text:SetTextColor(r, g, b)
    end

    ns.On("FORM_CHANGED", paint)
    paint(select(2, ns.GetForm()))

    -- Verschieben: Bearbeitungsmodus oder /mh unlock
    ns.MakeMovable(f, db, "Gestalt")
end
