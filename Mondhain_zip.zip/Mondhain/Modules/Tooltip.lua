-- Mondhain – Tooltip
-- Fester Platz für alle Tooltips, die Blizzard „an der Standardstelle“ zeigt
-- (Einheiten in der Welt, Taschen, Leisten, Rahmen). Der Platz ist im
-- Bearbeitungsmodus als Schablone „Tooltip“ verschiebbar. Der Tooltip wächst
-- von der Ecke des Ankers weg, die zur Bildschirmmitte zeigt.
-- Dazu der Mondhain-Look: dunkler Grund mit Holzrahmen statt Blizzard-Grau.

local _, ns = ...
local mod = ns.NewModule("Tooltip")
ns.Tooltip = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local db, anchor

---------------------------------------------------------------------------
-- Anker
---------------------------------------------------------------------------
-- Ecke des Ankers, an der der Tooltip hängt: rechts auf dem Bildschirm →
-- rechte Kante, unten → untere Kante (Tooltip wächst nach oben)
local function corner()
    local cx, cy = anchor:GetCenter()
    local W, H = UIParent:GetWidth(), UIParent:GetHeight()
    if not cx or not W then return "BOTTOMRIGHT" end
    local v = (cy < H / 2) and "BOTTOM" or "TOP"
    local h = (cx > W / 2) and "RIGHT" or "LEFT"
    return v .. h
end

local function buildAnchor()
    anchor = CreateFrame("Frame", "MondhainTooltipAnchor", UIParent)
    anchor:SetSize(240, 70)
    local p = db.point
    anchor:SetPoint(p[1], UIParent, p[3], p[4], p[5])
    ns.MakeMovable(anchor, db, "Tooltip", nil, true)
end

local function placeTooltip(tt)
    if not anchor or not db.enabled then return end
    if tt.IsForbidden and tt:IsForbidden() then return end
    local c = corner()
    tt:ClearAllPoints()
    tt:SetPoint(c, anchor, c)
end

---------------------------------------------------------------------------
-- Aussehen
---------------------------------------------------------------------------
local TIPS = {
    "GameTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2",
    "ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2",
}

local function hideBlizzBorder(tt)
    if tt.NineSlice then tt.NineSlice:SetAlpha(0) end
    if tt.SetBackdrop and tt.GetBackdrop and tt:GetBackdrop() then
        pcall(tt.SetBackdropColor, tt, 0, 0, 0, 0)
        pcall(tt.SetBackdropBorderColor, tt, 0, 0, 0, 0)
    end
end

local function skin(tt)
    if not tt or tt.mondhainSkin then return end
    if tt.IsForbidden and tt:IsForbidden() then return end
    -- Grund direkt am Tooltip (unter dessen Schrift), Holzrahmen darüber an den Kanten
    local t = tt:CreateTexture(nil, "BACKGROUND", nil, -8)
    t:SetAllPoints()
    t:SetColorTexture(0.04, 0.05, 0.05, 0.93)
    ns.WoodFrame(tt, 16)
    tt.mondhainSkin = t
    hideBlizzBorder(tt)
    tt:HookScript("OnShow", hideBlizzBorder)
end

local function skinAll()
    if not db.skin then return end
    for _, n in ipairs(TIPS) do skin(_G[n]) end
    -- Lebensbalken unter Einheiten-Tooltips: flach statt Blizzard-Glanz
    local sb = GameTooltipStatusBar
    if sb and not sb.mondhainSkin then
        sb.mondhainSkin = true
        pcall(sb.SetStatusBarTexture, sb, WHITE)
    end
end

---------------------------------------------------------------------------
-- IDs im Tooltip (Ben 25.11. 10:03/13:24): nur Zauber (auch Buffs/Debuffs)
-- und Gegenstände
---------------------------------------------------------------------------
local function addID(tt, label, id)
    if not db.ids or id == nil or ns.isSecret(id) then return end
    if tt.IsForbidden and tt:IsForbidden() then return end
    local text = label .. ": " .. tostring(id)
    local name = tt.GetName and tt:GetName()
    if name then                                   -- nicht doppelt (manche rufen mehrfach)
        for i = 1, tt:NumLines() do
            local fs = _G[name .. "TextLeft" .. i]
            local ok, cur = pcall(fs and fs.GetText or function() end, fs)
            if ok and cur == text then return end
        end
    end
    tt:AddLine(text, 0.55, 0.75, 1)
    tt:Show()
end

local function hookIDs()
    local TDP, T = TooltipDataProcessor, Enum and Enum.TooltipDataType
    if TDP and TDP.AddTooltipPostCall and T then
        -- nicht jede Art gibt es in jedem Client → nur vorhandene einhängen
        -- Ben 25.11. 13:24: nur Gegenstände und Zauber (inkl. Buffs/Debuffs)
        local labels = {
            Spell = "Zauber-ID", UnitAura = "Zauber-ID", Totem = "Zauber-ID", PetAction = "Zauber-ID",
            Item = "Item-ID", Toy = "Item-ID",
        }
        for key, label in pairs(labels) do
            local kind = T[key]
            if kind ~= nil then
                TDP.AddTooltipPostCall(kind, function(tt, data)
                    if tt ~= GameTooltip and tt ~= ItemRefTooltip then return end
                    pcall(addID, tt, label, data and data.id)
                end)
            end
        end
        return
    end
    -- ältere Schnittstelle
    local function auraHook(method, getter)
        if not GameTooltip[method] then return end
        hooksecurefunc(GameTooltip, method, function(tt, ...)
            local ok, id = pcall(getter, ...)
            if ok then pcall(addID, tt, "Zauber-ID", id) end
        end)
    end
    auraHook("SetUnitAura", function(u, i, f) return select(10, UnitAura(u, i, f)) end)
    auraHook("SetUnitBuff", function(u, i, f) return select(10, UnitBuff(u, i, f)) end)
    auraHook("SetUnitDebuff", function(u, i, f) return select(10, UnitDebuff(u, i, f)) end)
    GameTooltip:HookScript("OnTooltipSetSpell", function(tt)
        local _, id = tt:GetSpell()
        pcall(addID, tt, "Zauber-ID", id)
    end)
    GameTooltip:HookScript("OnTooltipSetItem", function(tt)
        local _, link = tt:GetItem()
        pcall(addID, tt, "Item-ID", link and tonumber(link:match("item:(%d+)")))
    end)
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.tooltip
    if not db then return end
    pcall(hookIDs)
    if db.enabled then
        buildAnchor()
        hooksecurefunc("GameTooltip_SetDefaultAnchor", function(tt)
            pcall(placeTooltip, tt)
        end)
    end
    if db.skin then
        skinAll()
        -- Blizzard setzt den Rahmen bei manchen Inhalten neu → wieder verstecken
        if SharedTooltip_SetBackdropStyle then
            hooksecurefunc("SharedTooltip_SetBackdropStyle", function(tt)
                if tt and tt.mondhainSkin then hideBlizzBorder(tt) end
            end)
        end
        -- spät geladene Tooltips (Blizzard-Addons) nachziehen
        C_Timer.After(2, skinAll)
    end
end
