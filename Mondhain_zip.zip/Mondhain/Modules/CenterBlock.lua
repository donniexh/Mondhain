-- Mondhain – die Mitte
-- Ein ruhiger, dunkler Grund hinter den drei Leisten fasst sie zu einem Block
-- zusammen; die Wurzel umrankt ihn wie die Tafeln (siehe Root.lua).
--   · Schwung- und Zauberleiste sitzen gestapelt direkt über dem Block,
--     genauso breit wie die Leisten. Wer eine davon selbst verschiebt, löst sie.
--   · Der Schwungtimer erscheint nur im Kampf (und beim Verschieben).
--   · Unten im Grund ein schmaler EP-Balken (ersetzt die EP-Ranke).

local _, ns = ...
local mod = ns.NewModule("CenterBlock")
ns.CenterBlock = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local PAD = 8
local STACK = { "swingMain", "cast", "swingOff", "swingRanged" }
local SWING = { swingMain = true, swingOff = true, swingRanged = true }
local db, plate, xp, hover

-- Lage eines Rahmens in UIParent-Einheiten
local function uiRect(f)
    local l, r, t, b = f:GetLeft(), f:GetRight(), f:GetTop(), f:GetBottom()
    if not (l and r and t and b) then return end
    local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return l * s, r * s, t * s, b * s
end

-- Oberkante des Wurzelstrangs am unteren Rand
function mod.Floor()
    if ns.UseBranch() then return 6 end
    local r = ns.db.root
    if r and r.enabled then return math.floor((r.thickness or 24) * 0.75 - 2) end
    return 8
end

local function wrapped()
    if ns.UseBranch() then return false end
    local r = ns.db.root
    return r and r.enabled and db.wrap ~= false
end

---------------------------------------------------------------------------
-- Grund hinter den Leisten
---------------------------------------------------------------------------
local function fitPlate()
    local bars = _G.MondhainBars_center
    if not (plate and bars) then return end
    local l, r, t, b = uiRect(bars)
    if not l then return end
    local fl = mod.Floor()
    -- stehen die Leisten weit oben, folgt der Grund ihnen statt bis zur Wurzel zu reichen
    local bottom = (b - fl > 60) and (b - PAD) or fl
    plate:ClearAllPoints()
    plate:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", l - PAD, bottom)
    plate:SetSize(r - l + 2 * PAD, t + PAD - bottom)
end

local function buildPlate()
    plate = CreateFrame("Frame", "MondhainCenterPlate", UIParent, "BackdropTemplate")
    plate:SetFrameStrata("LOW")
    plate:SetFrameLevel(1)
    plate:SetBackdrop({ bgFile = WHITE })
    if ns.UseBranch() then
        -- im Stamm nur eine leichte Vertiefung
        plate:SetBackdropColor(0, 0, 0, 0.22)
    else
        plate:SetBackdropColor(0.035, 0.04, 0.035, (db.alpha or 88) / 100)
        if not wrapped() then ns.WoodFrame(plate, 22) end
    end
    fitPlate()
end

function mod:SetAlpha(n)
    db.alpha = n
    if plate and not ns.UseBranch() then plate:SetBackdropColor(0.035, 0.04, 0.035, n / 100) end
end

---------------------------------------------------------------------------
-- Schwung und Zauber über dem Block
---------------------------------------------------------------------------
local function target(key)
    local bf = ns.BlizzardFrames
    return bf and bf.GetTarget and bf:GetTarget(key)
end

-- Schwungtimer direkt unter dem Spielerrahmen (untereinander, so breit wie der Rahmen)
local function underPlayer()
    return db.swingUnderPlayer ~= false and _G.MondhainUnit_player
end

local function stackSwings()
    local pf = underPlayer()
    if not pf then return end
    local y = -6
    for _, key in ipairs({ "swingMain", "swingOff", "swingRanged" }) do
        local h = _G["MondhainHolder_" .. key]
        local bdb = ns.db.blizz[key]
        if h and not (bdb and bdb.free) then
            local s = h:GetScale()
            if not h.mhMoving and not (InCombatLockdown() and h:IsProtected()) then
                h:ClearAllPoints()
                h:SetPoint("TOPLEFT", pf, "BOTTOMLEFT", 0, y / s)
            end
            y = y - h:GetHeight() * s - 4
        end
    end
end

local function stack()
    pcall(stackSwings)
    if not (plate and db.stack) then return end
    local y = wrapped() and 16 or 6 -- über dem oberen Wurzelstrang
    if ns.UseBranch() then y = (ns.db.branch.thickness or 28) * 1.05 + 6 end -- über dem Ast
    -- mit Zauber-Ast: Zauberleiste fällt weg, Schwung sitzt über dem Zauber-Zweig
    local castBranch = ns.UseBranch() and ns.db.branch.castBranch ~= false
    if castBranch and ns.Branch and ns.Branch.CastTop then
        local ct = ns.Branch.CastTop()
        local pt = plate:GetTop() and plate:GetTop() * plate:GetEffectiveScale() / UIParent:GetEffectiveScale()
        if ct and pt then y = math.max(y, ct - pt + 6) end
    end
    for _, key in ipairs(STACK) do
        local h = _G["MondhainHolder_" .. key]
        local bdb = ns.db.blizz[key]
        if h and not (bdb and bdb.free) and not (castBranch and key == "cast")
            and not (SWING[key] and underPlayer()) then
            local s = h:GetScale()
            if not h.mhMoving and not (InCombatLockdown() and h:IsProtected()) then
                h:ClearAllPoints()
                h:SetPoint("BOTTOM", plate, "TOP", 0, y / s)
            end
            y = y + h:GetHeight() * s + 6
        end
    end
end

local function widen()
    if not db.matchWidth then return end
    local bars = _G.MondhainBars_center
    if not bars then return end
    local l, r = uiRect(bars) -- (nicht „bars and uiRect(...)“: das liefert nur einen Wert)
    if not (l and r) then return end
    local W = r - l
    -- unter dem Spieler: so breit wie dessen Rahmen
    local pf = underPlayer()
    local PW
    if pf then
        local pl, pr = uiRect(pf)
        if pl and pr then PW = pr - pl end
    end
    for _, key in ipairs(STACK) do
        local bdb = ns.db.blizz[key]
        local t = target(key)
        if t and not (bdb and bdb.free) and not (InCombatLockdown() and t:IsProtected()) then
            local ww = (SWING[key] and PW) or W
            local w = ww * UIParent:GetEffectiveScale() / t:GetEffectiveScale()
            if math.abs((t:GetWidth() or 0) - w) > 1 then pcall(t.SetWidth, t, w) end
        end
    end
end

---------------------------------------------------------------------------
-- Schwungtimer im Mondhain-Look: Forevers eigene Balken behalten ihre
-- Funktion, bekommen aber dunkle Spur, warme Füllung, helle Vorderkante und
-- einen schmalen Holzrahmen – passend zum Zauber-Zweig darunter.
---------------------------------------------------------------------------
local SWING_COLORS = {
    swingMain   = { 0.86, 0.62, 0.22 },  -- Bernstein
    swingOff    = { 0.66, 0.50, 0.30 },  -- Eichenholz
    swingRanged = { 0.40, 0.66, 0.86 },  -- Mondlicht
}

local function findStatusBar(f, depth)
    if f.GetObjectType and f:GetObjectType() == "StatusBar" then return f end
    if depth <= 0 or not f.GetChildren then return end
    for _, c in ipairs({ f:GetChildren() }) do
        local sb = findStatusBar(c, depth - 1)
        if sb then return sb end
    end
end

local function skinSwing(key, t)
    if not t or t.mhSkinned or db.swingSkin == false then return end
    if InCombatLockdown() and t:IsProtected() then return end
    local sb = findStatusBar(t, 3)
    if not sb then return end
    t.mhSkinned = true
    sb:SetStatusBarTexture(WHITE)
    local fill = sb:GetStatusBarTexture()
    -- Blizzard-Rahmen, -Glanz und -Funke ausblenden (alles außer der Füllung)
    local function hideArt(fr)
        for _, r in ipairs({ fr:GetRegions() }) do
            if r.GetObjectType and r:GetObjectType() == "Texture" and r ~= fill then r:SetAlpha(0) end
        end
    end
    hideArt(t)
    if sb ~= t then hideArt(sb) end
    for _, c in ipairs({ t:GetChildren() }) do
        if c ~= sb then hideArt(c) end
    end
    local col = SWING_COLORS[key] or SWING_COLORS.swingMain
    local busy = false
    local function paint()
        if busy then return end
        busy = true
        sb:SetStatusBarColor(col[1], col[2], col[3], 1)
        busy = false
    end
    paint()
    hooksecurefunc(sb, "SetStatusBarColor", paint)
    local bg = sb:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetAllPoints()
    bg:SetColorTexture(0.06, 0.045, 0.035, 0.92)
    local spark = sb:CreateTexture(nil, "OVERLAY", nil, 6)
    spark:SetTexture("Interface\\AddOns\\Mondhain\\media\\weich")
    spark:SetBlendMode("ADD")
    spark:SetVertexColor(1, 0.95, 0.75, 0.9)
    spark:SetWidth(6)
    spark:SetPoint("TOP", sb:GetStatusBarTexture(), "TOPRIGHT", 0, 0)
    spark:SetPoint("BOTTOM", sb:GetStatusBarTexture(), "BOTTOMRIGHT", 0, 0)
    ns.WoodFrame(sb, 12)
    -- Schrift: klar und mit Kontur
    for _, fr in ipairs({ t, sb }) do
        for _, r in ipairs({ fr:GetRegions() }) do
            if r.GetObjectType and r:GetObjectType() == "FontString" then
                local font, size = r:GetFont()
                if font then r:SetFont(font, math.min(size or 11, 11), "OUTLINE") end
                r:SetShadowOffset(0, 0)
            end
        end
    end
end

local function skinSwings()
    for key in pairs(SWING) do pcall(skinSwing, key, target(key)) end
end

---------------------------------------------------------------------------
-- Schwungtimer unter dem Spielerrahmen als eigener Spiegel-Balken.
-- Blizzard setzt seinen Balken im Kampf zurück an die Stelle aus dem
-- HUD-Bearbeitungsmodus (samt Breite) – und im Kampf darf Mondhain ihn nicht
-- zurückholen. Darum bleibt Blizzards Balken unsichtbar, und Mondhain zeigt
-- unter dem Rahmen einen eigenen, der jedes Bild Wert, Grenzen und Texte von
-- Blizzards Balken übernimmt (geheime Werte darf ein Balken anzeigen).
-- Klappt das Übernehmen nicht, fällt Mondhain auf Blizzards Balken zurück.
---------------------------------------------------------------------------
local mirrors = {}
local mirrorBroken = {}
local MIRROR_ORDER = { "swingMain", "swingOff", "swingRanged" }

local function mirrorActive()
    if not (db and db.swingUnderPlayer ~= false and _G.MondhainUnit_player) then return false end
    for _, k in ipairs(MIRROR_ORDER) do if mirrorBroken[k] then return false end end
    return true
end
function mod.SwingMirrored() return mirrorActive() end

local function texts(t, sb)
    local list = {}
    for _, fr in ipairs({ t, sb }) do
        if fr then
            for _, r in ipairs({ fr:GetRegions() }) do
                if r.GetObjectType and r:GetObjectType() == "FontString" then list[#list + 1] = r end
            end
        end
    end
    -- links = Name, rechts = Zeit
    table.sort(list, function(a, b) return (a:GetLeft() or 0) < (b:GetLeft() or 0) end)
    return list[1], list[#list] ~= list[1] and list[#list] or nil
end

local function makeMirror(key)
    local m = CreateFrame("StatusBar", "MondhainSwing_" .. key, UIParent)
    m:SetFrameStrata("MEDIUM")
    m:SetStatusBarTexture(WHITE)
    local col = SWING_COLORS[key] or SWING_COLORS.swingMain
    m:SetStatusBarColor(col[1], col[2], col[3], 1)
    m:SetMinMaxValues(0, 1)
    m:SetValue(0)
    local bg = m:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetAllPoints()
    bg:SetColorTexture(0.06, 0.045, 0.035, 0.92)
    local spark = m:CreateTexture(nil, "OVERLAY", nil, 6)
    spark:SetTexture("Interface\\AddOns\\Mondhain\\media\\weich")
    spark:SetBlendMode("ADD")
    spark:SetVertexColor(1, 0.95, 0.75, 0.9)
    spark:SetWidth(6)
    spark:SetPoint("TOP", m:GetStatusBarTexture(), "TOPRIGHT", 0, 0)
    spark:SetPoint("BOTTOM", m:GetStatusBarTexture(), "BOTTOMRIGHT", 0, 0)
    m.label = m:CreateFontString(nil, "OVERLAY")
    m.label:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")
    m.label:SetPoint("LEFT", 6, 0)
    m.time = m:CreateFontString(nil, "OVERLAY")
    m.time:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")
    m.time:SetPoint("RIGHT", -6, 0)
    ns.WoodFrame(m, 12)
    m:Hide()
    mirrors[key] = m
    return m
end

local mirrorShow = true
local function updateMirrors()
    local pf = _G.MondhainUnit_player
    if not (pf and mirrorActive()) then
        for _, m in pairs(mirrors) do m:Hide() end
        return
    end
    local pl, pr = uiRect(pf)
    local w = (pl and pr) and (pr - pl) or 240
    local y = -6
    for _, key in ipairs(MIRROR_ORDER) do
        local t = target(key)
        local sb = t and findStatusBar(t, 3)
        local m = mirrors[key]
        if t and sb and t:IsShown() and mirrorShow then
            m = m or makeMirror(key)
            local h = math.max(12, math.min(24, sb:GetHeight() or 18))
            m:SetSize(w, h)
            m:ClearAllPoints()
            m:SetPoint("TOPLEFT", pf, "BOTTOMLEFT", 0, y)
            y = y - h - 6
            local ok = pcall(function()
                m:SetMinMaxValues(sb:GetMinMaxValues())
                m:SetValue(sb:GetValue())
            end)
            if not ok then
                mirrorBroken[key] = true      -- zurück zu Blizzards Balken
                m:Hide()
                return
            end
            if not m.src then m.src = { texts(t, sb) } end
            local a, b = m.src[1], m.src[2]
            if a then pcall(m.label.SetText, m.label, a:GetText()) end
            if b then pcall(m.time.SetText, m.time, b:GetText()) end
            m:Show()
        elseif m then
            m:Hide()
        end
    end
end

local inCombat = false
local swingShown = true
local hooked = {}
local function fade()
    local show = not db.swingCombatOnly or inCombat or not ns.db.locked
    mirrorShow = show
    if mirrorActive() then show = false end   -- Mondhains Spiegel zeigt ihn
    swingShown = show
    for key in pairs(SWING) do
        local h = _G["MondhainHolder_" .. key]
        if h then h:SetAlpha(show and 1 or 0) end
        -- Blizzards Balken ignoriert teils die Deckkraft des Halters → direkt setzen
        local t = target(key)
        if t then
            if t.SetIgnoreParentAlpha then t:SetIgnoreParentAlpha(false) end
            if not hooked[t] then
                hooked[t] = true
                hooksecurefunc(t, "SetAlpha", function(self, a)
                    if not swingShown and a and a > 0 and not self.mhFading then
                        self.mhFading = true
                        self:SetAlpha(0)
                        self.mhFading = nil
                    end
                end)
            end
            t.mhFading = true
            t:SetAlpha(show and 1 or 0)
            t.mhFading = nil
        end
    end
end

---------------------------------------------------------------------------
-- EP-Balken unten im Grund
---------------------------------------------------------------------------
local function updateXP()
    if not xp then return end
    local max = UnitXPMax("player")
    local cur = UnitXP("player")
    if ns.isSecret(max) or ns.isSecret(cur) then
        xp:SetMinMaxValues(0, max); xp:SetValue(cur); xp.rested:Hide()
        return
    end
    local atCap = (IsPlayerAtEffectiveMaxLevel and IsPlayerAtEffectiveMaxLevel()) or not max or max == 0
    xp:SetShown(not atCap)
    hover:SetShown(not atCap)
    if atCap then return end
    xp:SetMinMaxValues(0, max)
    xp:SetValue(cur)
    local rested = GetXPExhaustion() or 0
    if rested > 0 then
        local rp = math.min(1, (cur + rested) / max)
        xp.rested:SetWidth(math.max(1, xp:GetWidth() * rp))
        xp.rested:Show()
    else
        xp.rested:Hide()
    end
end

local function hideBlizzXP()
    if ns.db.root.hideXPBar == false then return end
    local h = _G.MondhainHolder_xp
    if h and not h.mhHidden then
        h.mhHidden = true
        h:Hide()
        h:HookScript("OnShow", function(self) self:Hide() end)
    end
end

local function buildXP()
    local bars = _G.MondhainBars_center
    if not bars then return end
    xp = CreateFrame("StatusBar", "MondhainXPBar", plate)
    xp:SetFrameStrata("MEDIUM")
    xp:SetStatusBarTexture(WHITE)
    xp:SetStatusBarColor(0.36, 0.60, 0.30, 0.95)
    xp:SetHeight(5)
    xp:SetPoint("TOPLEFT", bars, "BOTTOMLEFT", 0, -5)
    xp:SetPoint("TOPRIGHT", bars, "BOTTOMRIGHT", 0, -5)
    local bg = xp:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.6)
    xp.rested = xp:CreateTexture(nil, "BORDER")
    xp.rested:SetPoint("TOPLEFT"); xp.rested:SetPoint("BOTTOMLEFT")
    xp.rested:SetColorTexture(0.40, 0.50, 0.85, 0.45)

    -- größere Fläche für den Tooltip
    hover = CreateFrame("Frame", nil, xp)
    hover:SetPoint("TOPLEFT", xp, "TOPLEFT", 0, 4)
    hover:SetPoint("BOTTOMRIGHT", xp, "BOTTOMRIGHT", 0, -6)
    hover:EnableMouse(true)
    hover:SetScript("OnEnter", function(self)
        local cur, max = UnitXP("player"), UnitXPMax("player")
        local rested = GetXPExhaustion() or 0
        local f = ns.FormatNumber or tostring
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Stufe " .. UnitLevel("player"), 1, 0.82, 0)
        if not ns.isSecret(max) and max and max > 0 then
            GameTooltip:AddLine(("%s / %s EP  (%d %%)"):format(f(cur), f(max), math.floor(cur / max * 100)), 1, 1, 1)
            GameTooltip:AddLine("Bis zur nächsten Stufe: " .. f(max - cur), 0.8, 0.8, 0.8)
            if rested > 0 then GameTooltip:AddLine("Ausgeruht: " .. f(rested), 0.75, 0.85, 1) end
        end
        GameTooltip:Show()
    end)
    hover:SetScript("OnLeave", GameTooltip_Hide)
    xp:HookScript("OnSizeChanged", updateXP)

    updateXP()
    ns.RegisterEvent("PLAYER_XP_UPDATE", updateXP)
    ns.RegisterEvent("UPDATE_EXHAUSTION", updateXP)
    ns.RegisterEvent("PLAYER_LEVEL_UP", function() C_Timer.After(0.5, updateXP) end)
    C_Timer.After(1.5, hideBlizzXP)
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.centerBlock
    if not db.enabled then return end
    -- 0.37.0: Schwungtimer passgenau unter den Spielerrahmen – auch wenn er
    -- früher einmal von Hand verschoben wurde (danach zählt Verschieben wieder)
    if not db.swingUnderVer then
        db.swingUnderVer = 1
        db.swingUnderPlayer = true
        for key in pairs(SWING) do
            local b = ns.db.blizz and ns.db.blizz[key]
            if b then b.free = nil end
        end
    end
    C_Timer.After(0.2, function()
        if not _G.MondhainBars_center then return end
        buildPlate()
        -- mit Ast übernimmt der Erfahrungs-Ast (Efeu) die EP-Anzeige
        local branchXP = ns.UseBranch() and ns.db.branch.xpBranch ~= false
        if db.xp and not branchXP then buildXP() end
        C_Timer.NewTicker(1, function()
            pcall(fitPlate)
            pcall(stack)
            pcall(widen)
            skinSwings()
        end)
        C_Timer.After(0.8, function()
            fade()
            pcall(stack)
            pcall(widen)
        end)
    end)
    -- Spiegel-Balken jedes Bild nachführen
    local drv = CreateFrame("Frame")
    drv:SetScript("OnUpdate", function()
        local ok = pcall(updateMirrors)
        if not ok or not mirrorActive() then
            if drv.wasActive then drv.wasActive = false; fade() end
        else
            drv.wasActive = true
        end
    end)
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function() inCombat = true; fade() end)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function() inCombat = false; fade() end)
    ns.On("LOCK_CHANGED", fade)
end
