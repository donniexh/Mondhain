-- Mondhain – Einheitenfenster
-- Spieler links und Ziel rechts neben den Leisten, so dass ein 16:9-Ausschnitt
-- aus der Bildmitte alles Wichtige zeigt. Dazu Ziel des Ziels, Begleiter und
-- (abschaltbar) Fokus.
--
--   Spieler: Porträt · Leben · Ressource · Druiden-Mana in Gestalt · Kombopunkte
--   Ziel:    Stufe als Plakette oben links · Leben · Ressource · Auren darüber
--
-- Werte absolut („1.240 / 1.800“). Unter den Midnight-Regeln können Leben/Mana
-- im Kampf „geheime Werte“ sein: Balken laufen trotzdem, Texte werden dann
-- vereinfacht angezeigt statt mit ihnen zu rechnen.

local _, ns = ...
local mod = ns.NewModule("UnitFrames")
ns.UnitFrames = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local CIRCLE = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local FONT = STANDARD_TEXT_FONT
local db
local frames = {}

-- Aussehen (in den Optionen einstellbar)
local function look() return db.look end
local function dim(r, g, b, extra)
    local k = math.max(0.2, math.min(1, (look().colorPct or 55) / 100 + (extra or 0)))
    return r * k, g * k, b * k
end

local function isSecret(v) return ns.isSecret(v) end

---------------------------------------------------------------------------
-- Zahlen und Farben
---------------------------------------------------------------------------
-- 2.783 · 45.210 · 1,2 M  (Tausenderpunkt, ab einer Million „M“)
local function fmt(v)
    if v == nil then return nil end
    if isSecret(v) then
        -- Geheime Werte darf nur Blizzards eigener Formatierer anfassen
        if BreakUpLargeNumbers then
            local ok, s = pcall(BreakUpLargeNumbers, v)
            if ok and s then return s end
        end
        return nil
    end
    local ok, s = pcall(function()
        if v >= 1000000 then
            return (("%.1f M"):format(v / 1000000):gsub("%.", ","))
        end
        local str = tostring(math.floor(v + 0.5))
        local out = str:reverse():gsub("(%d%d%d)", "%1."):reverse()
        return (out:gsub("^%.", ""))
    end)
    return ok and s or nil
end
ns.FormatNumber = fmt

-- Wert als „aktuell / Höchstwert“ aus drei Textfeldern. So klappt es auch mit
-- geheimen Werten: die darf das Spiel anzeigen, nur nicht zusammenrechnen.
local function setValue(v, cur, max, hideMax)
    local a, b = fmt(cur), fmt(max)
    if not pcall(v.cur.SetText, v.cur, a or cur) then v.cur:SetText("") end
    if hideMax or max == nil then
        v.sep:Hide(); v.max:Hide()
        return
    end
    if not pcall(v.max.SetText, v.max, b or max) then v.max:SetText("") end
    v.sep:Show(); v.max:Show()
end

local function setBar(bar, cur, max)
    pcall(bar.SetMinMaxValues, bar, 0, max or 1)
    pcall(bar.SetValue, bar, cur or 0)
end

local function rawHealthColor(u)
    if UnitIsTapDenied and UnitIsTapDenied(u) and not UnitPlayerControlled(u) then return 0.5, 0.5, 0.5 end
    if UnitIsPlayer(u) then
        local _, class = UnitClass(u)
        local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
        if c then return c.r, c.g, c.b end
    end
    if u == "player" or u == "pet" then return 0.25, 0.72, 0.30 end
    local r = UnitReaction(u, "player")
    if r and not isSecret(r) then
        if r <= 3 then return 0.85, 0.25, 0.20 end
        if r == 4 then return 0.90, 0.78, 0.25 end
    end
    return 0.25, 0.72, 0.30
end

local function healthColor(u) return dim(rawHealthColor(u)) end

local function powerColor(ptype, token)
    local c = PowerBarColor and (PowerBarColor[token] or PowerBarColor[ptype])
    if c then return dim(c.r, c.g, c.b, 0.15) end
    return dim(0.2, 0.4, 0.9, 0.15)
end

---------------------------------------------------------------------------
-- Bausteine
---------------------------------------------------------------------------
local allBars, allTexts = {}, {}

local function makeBar(parent, h)
    local b = CreateFrame("StatusBar", nil, parent)
    b:SetStatusBarTexture(WHITE)
    b:SetHeight(h)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.7)
    b.bgTex = bg
    allBars[#allBars + 1] = b
    return b
end

local function applyFont(t)
    local l = look()
    local size = t.baseSize + ((l.fontSize or 13) - 13)
    t:SetFont(FONT, math.max(8, size), l.outline and "OUTLINE" or "")
end

local function makeText(parent, size, justify)
    local t = parent:CreateFontString(nil, "OVERLAY")
    t.baseSize = size
    applyFont(t)
    t:SetShadowOffset(1, -1)
    t:SetShadowColor(0, 0, 0, 1)
    t:SetJustifyH(justify or "LEFT")
    t:SetWordWrap(false)
    allTexts[#allTexts + 1] = t
    return t
end

-- „aktuell / Höchstwert“ rechtsbündig in einem Balken
local function makeValue(bar, size)
    local v = {}
    v.max = makeText(bar, size, "RIGHT")
    v.max:SetPoint("RIGHT", -4, 0)
    v.sep = makeText(bar, size, "RIGHT")
    v.sep:SetPoint("RIGHT", v.max, "LEFT", -2, 0)
    v.sep:SetText("/")
    v.cur = makeText(bar, size, "RIGHT")
    v.cur:SetPoint("RIGHT", v.sep, "LEFT", -2, 0)
    return v
end

local function circleTex(parent, layer, inset)
    local t = parent:CreateTexture(nil, layer)
    t:SetPoint("TOPLEFT", inset, -inset)
    t:SetPoint("BOTTOMRIGHT", -inset, inset)
    local m = parent:CreateMaskTexture()
    m:SetTexture(CIRCLE, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    m:SetAllPoints(t)
    t:AddMaskTexture(m)
    return t
end

-- Stufe als runde Plakette (Blizzard-Art): Goldring, dunkle Mitte, Zahl in Schwierigkeitsfarbe
local function makeLevelBadge(f)
    local lv = CreateFrame("Frame", nil, f)
    lv:SetSize(32, 32)
    lv:SetPoint("CENTER", f, "TOPLEFT", 4, -4)
    lv:SetFrameLevel(f:GetFrameLevel() + 8)
    lv.ring = circleTex(lv, "BACKGROUND", 0)
    lv.ring:SetColorTexture(0.80, 0.62, 0.25, 1)
    lv.fill = circleTex(lv, "BORDER", 2)
    lv.fill:SetColorTexture(0.06, 0.05, 0.05, 1)
    lv.text = lv:CreateFontString(nil, "OVERLAY")
    lv.text:SetFont(FONT, 15, "OUTLINE")
    lv.text:SetPoint("CENTER", 0, 0)
    f.levelBadge = lv
end

-- Elite-/Rare-Drache um das Porträt (Blizzard-Grafiken, mehrere Namen je nach Spielversion)
local DRAGON = {
    elite = { "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Gold-Winged", "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Gold", "nameplates-icon-elite-gold" },
    rare  = { "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Rare-Silver", "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Silver", "nameplates-icon-elite-silver" },
}
local function hasAtlas(name)
    return C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(name) ~= nil
end

local function updateDragon(f)
    local d = f.dragon
    if not d then return end
    local cls = UnitClassification and UnitClassification(f.unit)
    local kind = (cls == "rare" or cls == "rareelite") and "rare"
        or ((cls == "elite" or cls == "worldboss") and "elite") or nil
    if not kind then d:Hide() return end
    for i, name in ipairs(DRAGON[kind]) do
        if hasAtlas(name) then
            d:SetAtlas(name, true)
            local w, h = d:GetSize()
            local target = f.portrait and (f.portrait:GetHeight() * 1.9) or 34
            if i == #DRAGON[kind] then target = 26 end -- kleines Symbol
            local k = target / math.max(w, h, 1)
            d:SetSize(w * k, h * k)
            d:ClearAllPoints()
            if f.portrait and i < #DRAGON[kind] then
                d:SetPoint("CENTER", f.portrait, "CENTER", 10, 2)
            else
                d:SetPoint("LEFT", f.levelBadge or f, "RIGHT", -6, 0)
            end
            d:Show()
            return
        end
    end
    d:Hide()
end

local function updateLevel(f)
    local lv, u = f.levelBadge, f.unit
    if not lv then return end
    local level = UnitLevel(u)
    local cls = UnitClassification and UnitClassification(u)
    if isSecret(level) then
        pcall(lv.text.SetText, lv.text, level)
        return
    end
    if not level or level < 0 then
        lv.text:SetText("??")
        lv.text:SetTextColor(1, 0.2, 0.15)
    else
        local plus = (cls == "elite" or cls == "rareelite" or cls == "worldboss") and "+" or ""
        lv.text:SetText(level .. plus)
        local c = GetQuestDifficultyColor and GetQuestDifficultyColor(level)
        if c then lv.text:SetTextColor(c.r, c.g, c.b) else lv.text:SetTextColor(1, 0.82, 0) end
    end
    -- Rare: Silberring statt Gold
    if cls == "rare" or cls == "rareelite" then
        lv.ring:SetColorTexture(0.78, 0.80, 0.85, 1)
    else
        lv.ring:SetColorTexture(0.80, 0.62, 0.25, 1)
    end
end

---------------------------------------------------------------------------
-- PvP-Wappen: Schild der Fraktion oben in der Porträt-Ecke (Spieler links,
-- Ziel und Fokus rechts), über einem Elite-/Rare-Drachen.
---------------------------------------------------------------------------
local PVP_ATLAS = {
    Alliance = "UI-HUD-UnitFrame-Player-PVP-AllianceIcon",
    Horde    = "UI-HUD-UnitFrame-Player-PVP-HordeIcon",
    FFA      = "UI-HUD-UnitFrame-Player-PVP-FFAIcon",
}
local PVP_TEX = {
    Alliance = "Interface\\TargetingFrame\\UI-PVP-Alliance",
    Horde    = "Interface\\TargetingFrame\\UI-PVP-Horde",
    FFA      = "Interface\\TargetingFrame\\UI-PVP-FFA",
}

-- Ben 25.11. 10:29: Wappen aus seiner Vorlage (freigestellt, Edelstein statt
-- Zahl) oben in der Porträt-Ecke – Spieler links, Ziel rechts, Fokus rechts
-- oben am Rahmen. Stufe bleibt links in ihrer Plakette.
local CREST = {
    Alliance = { tex = "Interface\\AddOns\\Mondhain\\media\\schild_allianz", w = 178 },
    Horde    = { tex = "Interface\\AddOns\\Mondhain\\media\\schild_horde", w = 186 },
}
local function makePvP(f, corner, size)
    local b = CreateFrame("Frame", nil, f)
    b:SetSize(size, size)
    local anchor = f.portrait or f
    if corner == "left" then
        b:SetPoint("CENTER", anchor, "TOPLEFT", 3, -4)
    else
        b:SetPoint("CENTER", anchor, "TOPRIGHT", -3, -4)
    end
    b:SetFrameLevel(f:GetFrameLevel() + 10)   -- über dem Elite-Drachen
    b.icon = b:CreateTexture(nil, "OVERLAY")
    b.icon:SetPoint("CENTER", 0, 0)
    b.size = size
    b:Hide()
    f.pvp = b
end

-- Abfrage, die nie einen Fehler wirft und geheime Werte als „unbekannt“ behandelt
local function ask(fn, u)
    if not fn then return nil end
    local ok, v = pcall(fn, u)
    if not ok or isSecret(v) then return nil end
    return v
end

local function updatePvP(f)
    local b = f.pvp
    if not b then return end
    local u = f.unit
    local kind
    if db.pvpIcon ~= false and UnitExists(u) then
        if ask(UnitIsPVPFreeForAll, u) then
            kind = "FFA"
        elseif ask(UnitIsPVP, u) then
            local fac = ask(UnitFactionGroup, u)
            if fac == "Alliance" or fac == "Horde" then kind = fac else kind = "FFA" end
        end
    end
    if not kind then b:Hide() return end
    if b.kind ~= kind then
        b.kind = kind
        local cr = CREST[kind]
        if cr then
            -- Schild im 256er-Bild: mittig, 248 hoch, cr.w breit
            local u0 = (256 - cr.w) / 2 / 256
            b.icon:SetTexture(cr.tex)
            b.icon:SetTexCoord(u0, 1 - u0, 4 / 256, 252 / 256)
            b.icon:SetSize(b.size * cr.w / 248, b.size)
        elseif hasAtlas(PVP_ATLAS[kind]) then
            b.icon:SetTexCoord(0, 1, 0, 1)
            b.icon:SetAtlas(PVP_ATLAS[kind], true)
            local w, h = b.icon:GetSize()
            local k = b.size / math.max(w, h, 1)
            b.icon:SetSize(w * k, h * k)
        else
            b.icon:SetTexture(PVP_TEX[kind])
            b.icon:SetTexCoord(0.03, 0.62, 0.02, 0.64)
            b.icon:SetSize(b.size, b.size)
        end
    end
    b:Show()
end

---------------------------------------------------------------------------
-- Auren über dem Ziel: Größe, Anzahl und Filter in den Optionen
-- (Einheiten → Auren am Ziel). Reihen wachsen nach oben, so breit wie der Rahmen.
---------------------------------------------------------------------------
local function auraCfg()
    local c = db.targetAuras or {}
    db.targetAuras = c
    return c
end

local function makeAuras(f)
    local a = CreateFrame("Frame", nil, f)
    a:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 22, 6)
    a:SetSize(f:GetWidth() - 22, 22)
    a.icons = {}
    f.auras = a
end

local function auraIcon(a, i)
    if a.icons[i] then return a.icons[i] end
    local b = CreateFrame("Frame", nil, a)
    b.edge = b:CreateTexture(nil, "BACKGROUND")
    b.edge:SetAllPoints()
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 1, -1)
    b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cd:SetAllPoints(b.icon)
    b.cd:SetDrawEdge(false)
    b.cd:SetHideCountdownNumbers(true)
    -- abgelaufener Teil dunkel (war andersherum: dunkel = Restzeit)
    b.cd:SetReverse(true)
    if b.cd.SetDrawBling then b.cd:SetDrawBling(false) end
    if b.cd.SetSwipeColor then b.cd:SetSwipeColor(0, 0, 0, 0.65) end
    b.cd.noCooldownCount = true
    b.count = b:CreateFontString(nil, "OVERLAY")
    b.count:SetPoint("BOTTOMRIGHT", 1, -1)
    b:EnableMouse(true)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        pcall(GameTooltip.SetUnitAura, GameTooltip, self.unit, self.index, self.filter)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    a.icons[i] = b
    return b
end

local function placeAura(a, b, i, size, per)
    local col, row = (i - 1) % per, math.floor((i - 1) / per)
    b:SetSize(size, size)
    b:ClearAllPoints()
    b:SetPoint("BOTTOMLEFT", a, "BOTTOMLEFT", col * (size + 3), row * (size + 3))
    b.count:SetFont(FONT, math.max(9, math.floor(size * 0.45)), "OUTLINE")
end

-- Stärkung am Gegner bannbar/stehlbar? (nil = nicht lesbar → zeigen)
local function dispellable(data)
    local ok, v = pcall(function()
        if data.isStealable then return true end
        return data.dispelName == "Magic"
    end)
    if ok then return v end
end

---------------------------------------------------------------------------
-- Ziel-Auren aus Blizzards eigenem Zielfenster: Forever gibt Addons im Kampf
-- keine Aurendaten, Blizzards (verstecktes) Zielfenster bekommt sie aber und
-- aktualisiert seine Symbole weiter. Mondhain hängt diese Symbole in seine
-- Auren-Leiste um und ordnet sie im eigenen Raster (Größe, Anzahl, Filter
-- aus den Optionen). Wie oben rechts bei den eigenen Stärkungen.
---------------------------------------------------------------------------
local function useBlizzAuras()
    local c = db and db.targetAuras
    return c and c.blizzard ~= false and _G.TargetFrame ~= nil
end

local regOrder, regN = setmetatable({}, { __mode = "k" }), 0

local function blizzAuraList()
    local list, seen = {}, {}
    local tf = _G.TargetFrame
    if not tf then return list end
    local function add(fr, debuff)
        if type(fr) ~= "table" or not fr.GetObjectType or seen[fr] then return end
        if fr.IsForbidden and fr:IsForbidden() then return end
        seen[fr] = true
        if not regOrder[fr] then regN = regN + 1; regOrder[fr] = regN end
        list[#list + 1] = { f = fr, debuff = debuff }
    end
    for _, pre in ipairs({ { "TargetFrameDebuff", true }, { "TargetFrameBuff", false } }) do
        for i = 1, 40 do
            local b = _G[pre[1] .. i]
            if b then add(b, pre[2]) elseif i > 3 then break end
        end
    end
    local pools = tf.auraPools
    if pools and pools.EnumerateActive then
        pcall(function()
            for fr in pools:EnumerateActive() do
                -- Schwächungen haben einen (nach Art gefärbten) Rand, Stärkungen „Stealable“
                local deb = fr.mhDebuff
                if deb == nil then
                    deb = (fr.Border ~= nil and fr.Stealable == nil) or false
                    fr.mhDebuff = deb
                end
                add(fr, deb)
            end
        end)
    end
    return list
end

local function clean(v) if v == nil or isSecret(v) then return nil end return v end

-- außerhalb des Kampfs lesbar: von mir? bannbar?
local function blizzAuraData(fr)
    local id = clean(fr.auraInstanceID)
    if not id or not (C_UnitAuras and C_UnitAuras.GetAuraDataByAuraInstanceID) then return nil end
    local ok, d = pcall(C_UnitAuras.GetAuraDataByAuraInstanceID, "target", id)
    if ok and type(d) == "table" then return d end
end

local function skinBlizzAura(fr)
    if fr.mhSkinned then return end
    fr.mhSkinned = true
    local name = fr.GetName and fr:GetName()
    local icon = fr.Icon or fr.icon or (name and _G[name .. "Icon"])
    if icon and icon.SetTexCoord then icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
    fr.mhIcon = icon
    local border = fr.Border or (name and _G[name .. "Border"])
    if border and border.ClearAllPoints then
        border:ClearAllPoints()
        border:SetPoint("TOPLEFT", fr, "TOPLEFT", -1, 1)
        border:SetPoint("BOTTOMRIGHT", fr, "BOTTOMRIGHT", 1, -1)
    end
    if not border then
        local e = fr:CreateTexture(nil, "BACKGROUND", nil, -7)
        e:SetPoint("TOPLEFT", -1, 1)
        e:SetPoint("BOTTOMRIGHT", 1, -1)
        e:SetColorTexture(unpack(ns.colors.border))
    end
    if icon and icon.ClearAllPoints then
        icon:ClearAllPoints()
        icon:SetAllPoints(fr)
    end
    local cd = fr.Cooldown or fr.cooldown or (name and _G[name .. "Cooldown"])
    if cd and cd.ClearAllPoints then
        cd:ClearAllPoints()
        cd:SetAllPoints(fr)
        if cd.SetReverse then cd:SetReverse(true) end
        if cd.SetDrawEdge then cd:SetDrawEdge(false) end
        if cd.SetSwipeColor then cd:SetSwipeColor(0, 0, 0, 0.65) end
    end
    fr.mhCount = fr.Count or fr.count or (name and _G[name .. "Count"])
end

local blizzLaying = false
local blizzStats = {}
local blizzMissing = false                 -- Blizzard liefert keine Symbole → eigener Weg
local ownAuras                             -- eigener Weg (weiter unten)
local function layoutInner(f)
    local a = f.auras
    local c = auraCfg()
    local size = c.size or 22
    local maxN = c.max or 16
    local per = math.max(3, math.floor((f:GetWidth() - 22 + 3) / (size + 3)))
    local list = blizzAuraList()
    -- Ben 25.11. 10:37: Auren waren weg – findet Blizzards Zielfenster keine
    -- Symbole, zeichnet Mondhain sie selbst (geht außerhalb des Kampfs immer)
    local anyShown = 0
    for _, it in ipairs(list) do if it.f:IsShown() then anyShown = anyShown + 1 end end
    if anyShown == 0 then
        blizzMissing = true
        blizzStats = { found = #list, shown = 0, placed = 0, own = true }
        if ownAuras then ownAuras(f) end
        return
    end
    if blizzMissing then
        blizzMissing = false
        for i = 1, #a.icons do a.icons[i]:Hide() end
    end
    local items = {}
    local st = { found = #list, shown = 0, placed = 0 }
    local enemy = false
    pcall(function() enemy = UnitCanAttack("player", "target") and true or false end)
    for _, it in ipairs(list) do
        local fr = it.f
        if fr:IsShown() then
            st.shown = st.shown + 1
            local want = (it.debuff and c.debuffs ~= false) or (not it.debuff and c.buffs ~= false)
            if want and (c.onlyMine and it.debuff or (c.enemyDispel and enemy and not it.debuff)) then
                local d = blizzAuraData(fr)          -- nur prüfbar, wenn lesbar
                if d then
                    local ok, keep = pcall(function()
                        if it.debuff then return d.isFromPlayerOrPlayerPet or d.sourceUnit == "player" or d.sourceUnit == "pet" end
                        return d.isStealable or d.dispelName == "Magic"
                    end)
                    if ok and keep == false then want = false end
                    if ok and keep == nil then want = false end
                end
            end
            local key = clean(fr.auraInstanceID)
            if type(key) ~= "number" then key = (fr.GetID and fr:GetID() or 0) * 1000 + regOrder[fr] end
            items[#items + 1] = { fr = fr, debuff = it.debuff, want = want, key = key }
        end
    end
    table.sort(items, function(x, y)
        if x.debuff ~= y.debuff then return x.debuff end
        return x.key < y.key
    end)
    local n = 0
    for _, it in ipairs(items) do
        local fr = it.fr
        if fr:GetParent() ~= a then fr:SetParent(a) end
        fr:SetFrameLevel(a:GetFrameLevel() + 2)
        skinBlizzAura(fr)
        if not fr.mhHooked then
            fr.mhHooked = true
            hooksecurefunc(fr, "SetPoint", function() if not blizzLaying then mod:RequestTargetAuras() end end)
        end
        if it.want and n < maxN then
            n = n + 1
            local col, row = (n - 1) % per, math.floor((n - 1) / per)
            fr:SetSize(size, size)
            fr:ClearAllPoints()
            fr:SetPoint("BOTTOMLEFT", a, "BOTTOMLEFT", col * (size + 3), row * (size + 3))
            fr:SetAlpha(1)
            if fr.EnableMouse then fr:EnableMouse(true) end
            if fr.mhCount and fr.mhCount.SetFont then
                fr.mhCount:SetFont(FONT, math.max(9, math.floor(size * 0.45)), "OUTLINE")
                fr.mhCount:ClearAllPoints()
                fr.mhCount:SetPoint("BOTTOMRIGHT", fr, "BOTTOMRIGHT", 1, -1)
            end
        else
            fr:SetAlpha(0)
            if fr.EnableMouse then fr:EnableMouse(false) end
        end
    end
    st.placed = n
    blizzStats = st
    local rows = math.max(1, math.ceil(n / per))
    a:SetSize(per * (size + 3), rows * (size + 3))
end
-- ein Fehler darf die Anordnung nicht für immer sperren
local function layoutBlizzAuras(f)
    if not (f and f.auras) or blizzLaying then return end
    blizzLaying = true
    local ok, err = pcall(layoutInner, f)
    blizzLaying = false
    if not ok then blizzStats.err = tostring(err) end
end

local auraDirty = false
local auraDriver = CreateFrame("Frame")
auraDriver:Hide()
auraDriver:SetScript("OnUpdate", function(self)
    self:Hide()
    auraDirty = false
    local f = frames.target
    if f and useBlizzAuras() then pcall(layoutBlizzAuras, f) end
end)
function mod:RequestTargetAuras()
    if auraDirty then return end
    auraDirty = true
    auraDriver:Show()
end

function mod:TargetAuraStats()
    return blizzStats
end

ownAuras = function(f)
    local a, u = f.auras, f.unit
    if not a or not C_UnitAuras or not C_UnitAuras.GetAuraDataByIndex then return end
    local c = auraCfg()
    local size = c.size or 22
    local maxN = c.max or 16
    local per = math.max(3, math.floor((f:GetWidth() - 22 + 3) / (size + 3)))
    local enemy = false
    pcall(function() enemy = UnitCanAttack("player", u) and true or false end)
    local passes = {}
    if c.debuffs ~= false then passes[#passes + 1] = c.onlyMine and "HARMFUL|PLAYER" or "HARMFUL" end
    if c.buffs ~= false then passes[#passes + 1] = "HELPFUL" end
    local n = 0
    for _, filter in ipairs(passes) do
        for idx = 1, 40 do
            if n >= maxN then break end
            local ok, data = pcall(C_UnitAuras.GetAuraDataByIndex, u, idx, filter)
            if not ok or not data then break end
            local show = true
            if filter == "HELPFUL" and enemy and c.enemyDispel then
                show = dispellable(data) ~= false
            end
            if show then
                n = n + 1
                local b = auraIcon(a, n)
                placeAura(a, b, n, size, per)
                b.unit, b.index, b.filter = u, idx, filter
                pcall(b.icon.SetTexture, b.icon, data.icon)
                if filter ~= "HELPFUL" then
                    b.edge:SetColorTexture(0.75, 0.15, 0.10, 1)
                else
                    b.edge:SetColorTexture(unpack(ns.colors.border))
                end
                if not pcall(function()
                    if data.duration and data.duration > 0 then
                        local start = data.expirationTime - data.duration
                        if b.cd.mhS ~= start or b.cd.mhD ~= data.duration then
                            b.cd.mhS, b.cd.mhD = start, data.duration
                            b.cd:SetCooldown(start, data.duration)
                        end
                    else
                        b.cd.mhS, b.cd.mhD = nil, nil
                        b.cd:Clear()
                    end
                end) then
                    -- geheime Werte: Blizzards Dauer-Objekt kann die Uhr trotzdem stellen
                    b.cd.mhS, b.cd.mhD = nil, nil
                    local ok2 = pcall(function()
                        local obj = C_UnitAuras.GetAuraDuration(u, data.auraInstanceID)
                        b.cd:SetCooldownFromDurationObject(obj)
                    end)
                    if not ok2 then b.cd:Clear() end
                end
                if not pcall(function()
                    b.count:SetText((data.applications and data.applications > 1) and data.applications or "")
                end) then b.count:SetText("") end
                b:Show()
            end
        end
    end
    for i = n + 1, #a.icons do a.icons[i]:Hide() end
    local rows = math.max(1, math.ceil(n / per))
    a:SetSize(per * (size + 3), rows * (size + 3))
    if u == "target" then blizzStats.ownShown = n end
end

local function updateAuras(f)
    local a, u = f.auras, f.unit
    if a and u == "target" and useBlizzAuras() then
        if blizzMissing then pcall(ownAuras, f) end
        mod:RequestTargetAuras()
        return
    end
    pcall(ownAuras, f)
end

function mod:RefreshAuras()
    for _, f in pairs(frames) do
        if f.auras and f:IsVisible() then updateAuras(f) end
    end
    if useBlizzAuras() then mod:RequestTargetAuras() end
end

---------------------------------------------------------------------------
-- Kombopunkte (Katze) über dem Spielerfenster
---------------------------------------------------------------------------
local function makeCombo(f)
    local c = CreateFrame("Frame", nil, f)
    c:SetSize(5 * 18 + 4 * 4, 8)
    c:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -4, 4)
    c.pips = {}
    for i = 1, 5 do
        local p = c:CreateTexture(nil, "ARTWORK")
        p:SetSize(18, 8)
        p:SetPoint("LEFT", (i - 1) * 22, 0)
        p:SetTexture(WHITE)
        c.pips[i] = p
    end
    f.combo = c
end

local function updateCombo(f)
    local c = f.combo
    if not c then return end
    local cp = 0
    if GetComboPoints then
        local ok, v = pcall(GetComboPoints, "player", "target")
        if ok and v and not isSecret(v) then cp = v end
    end
    if cp == 0 and Enum and Enum.PowerType and Enum.PowerType.ComboPoints then
        local ok, v = pcall(UnitPower, "player", Enum.PowerType.ComboPoints)
        if ok and v and not isSecret(v) then cp = v end
    end
    local energy = (select(1, UnitPowerType("player")) == 3)
    c:SetShown(energy or cp > 0)
    for i, p in ipairs(c.pips) do
        if i <= cp then
            p:SetVertexColor(0.95, 0.78, 0.25, 1)
        else
            p:SetVertexColor(0.15, 0.12, 0.08, 0.8)
        end
    end
end

---------------------------------------------------------------------------
-- Ein Einheitenfenster
---------------------------------------------------------------------------
local function updateHealth(f)
    local u = f.unit
    setBar(f.health, UnitHealth(u), UnitHealthMax(u))
    ns.UpdateHealPrediction(f.health, u)
    if UnitIsDeadOrGhost and UnitIsDeadOrGhost(u) then
        f.hp.cur:SetText("tot"); f.hp.sep:Hide(); f.hp.max:Hide()
    else
        setValue(f.hp, UnitHealth(u), UnitHealthMax(u), f.small)
    end
end

local function updatePower(f)
    if not f.power then return end
    local u = f.unit
    local ptype, token = UnitPowerType(u)
    f.power:SetStatusBarColor(powerColor(ptype, token))
    setBar(f.power, UnitPower(u), UnitPowerMax(u))
    if f.pw then
        -- Ziele ohne Ressource: keine „0“ anzeigen
        local okE, empty = pcall(function() return (UnitPowerMax(u) or 0) == 0 end)
        if okE and empty then
            f.pw.cur:SetText(""); f.pw.sep:Hide(); f.pw.max:Hide()
        else
            setValue(f.pw, UnitPower(u), UnitPowerMax(u))
        end
    end
    -- Druiden-Mana: dünner Balken, solange eine andere Ressource angezeigt wird
    if f.mana then
        local okM, hasMana = pcall(function() return (UnitPowerMax(u, 0) or 0) > 0 end)
        local showMana = ptype ~= 0 and (not okM or hasMana)
        f.mana:SetShown(showMana and true or false)
        if showMana then
            setBar(f.mana, UnitPower(u, 0), UnitPowerMax(u, 0))
            if f.mv then setValue(f.mv, UnitPower(u, 0), UnitPowerMax(u, 0)) end
        end
    end
end

local function updateAll(f)
    local u = f.unit
    if not UnitExists(u) then return end
    pcall(f.name.SetText, f.name, UnitName(u))
    f.health:SetStatusBarColor(healthColor(u))
    updateHealth(f)
    updatePower(f)
    if f.portrait then SetPortraitTexture(f.portrait, u) end
    updateLevel(f)
    updateDragon(f)
    updatePvP(f)
    if f.auras then updateAuras(f) end
    if f.combo then updateCombo(f) end
end

local UNIT_EVENTS = {
    UNIT_HEALTH = updateHealth, UNIT_MAXHEALTH = updateHealth,
    UNIT_HEAL_PREDICTION = updateHealth, UNIT_ABSORB_AMOUNT_CHANGED = updateHealth,
    UNIT_HEAL_ABSORB_AMOUNT_CHANGED = updateHealth,
    UNIT_POWER_FREQUENT = updatePower, UNIT_MAXPOWER = updatePower, UNIT_DISPLAYPOWER = updatePower,
    UNIT_NAME_UPDATE = updateAll, UNIT_PORTRAIT_UPDATE = updateAll, UNIT_LEVEL = updateAll,
    UNIT_FACTION = updateAll, UNIT_CLASSIFICATION_CHANGED = updateAll,
    UNIT_AURA = function(f) if f.auras then updateAuras(f) end end,
}

-- opts: w, h, healthH, powerH, portrait ("left"/"right"), druidMana, level, auras, combo, label
local function createFrame(unit, key, opts)
    local cfg = db[key]
    local f = CreateFrame("Button", "MondhainUnit_" .. key, UIParent, "SecureUnitButtonTemplate,BackdropTemplate")
    f.unit, f.key = unit, key
    f:SetAttribute("unit", unit)
    f:SetAttribute("type1", "target")
    f:SetAttribute("type2", "togglemenu")
    f:RegisterForClicks("AnyUp")
    f:SetSize(opts.w, opts.h)
    f:SetPoint(cfg.point[1], UIParent, cfg.point[3], cfg.point[4], cfg.point[5])
    f:SetFrameStrata("LOW")
    f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    f:SetBackdropColor(0.04, 0.05, 0.05, (look().frameAlpha or 85) / 100)
    f:SetBackdropBorderColor(0, 0, 0, 0)
    ns.WoodFrame(f, opts.small and 14 or 20)

    local left, right = 2, -2
    if opts.portrait and cfg.portrait ~= false then
        local p = f:CreateTexture(nil, "ARTWORK")
        p:SetSize(opts.h - 4, opts.h - 4)
        if opts.portrait == "left" then
            p:SetPoint("TOPLEFT", 2, -2)
            left = opts.h
        else
            p:SetPoint("TOPRIGHT", -2, -2)
            right = -opts.h
        end
        p:SetTexCoord(0.15, 0.85, 0.15, 0.85)
        f.portrait = p
    end

    f.health = makeBar(f, opts.healthH)
    f.health:SetPoint("TOPLEFT", left, -2)
    f.health:SetPoint("TOPRIGHT", right, -2)
    local nameX = opts.level and 20 or 4
    f.small = opts.small
    f.name = makeText(f.health, opts.small and 11 or 13, "LEFT")
    f.name:SetPoint("LEFT", nameX, 0)
    f.hp = makeValue(f.health, opts.small and 10 or 12)
    f.name:SetPoint("RIGHT", f.hp.cur, "LEFT", -6, 0)

    local below = f.health
    if opts.powerH then
        f.power = makeBar(f, opts.powerH)
        f.power:SetPoint("TOPLEFT", f.health, "BOTTOMLEFT", 0, -1)
        f.power:SetPoint("TOPRIGHT", f.health, "BOTTOMRIGHT", 0, -1)
        if opts.powerH >= 10 then f.pw = makeValue(f.power, 10) end
        below = f.power
    end
    if opts.druidMana then
        f.mana = makeBar(f, 6)
        f.mana:SetPoint("TOPLEFT", below, "BOTTOMLEFT", 0, -1)
        f.mana:SetPoint("TOPRIGHT", below, "BOTTOMRIGHT", 0, -1)
        f.mana:SetStatusBarColor(powerColor(0, "MANA"))
        f.mana:SetHeight(9)
        f.mv = makeValue(f.mana, 9) -- Zahlen hängen am Balken und verschwinden mit ihm
        f.mana:Hide()
    end
    ns.AttachHealPrediction(f.health)
    if opts.level then makeLevelBadge(f) end
    if opts.dragon then
        local holder = CreateFrame("Frame", nil, f)
        holder:SetAllPoints()
        holder:SetFrameLevel(f:GetFrameLevel() + 6)
        f.dragon = holder:CreateTexture(nil, "OVERLAY")
        f.dragon:Hide()
    end
    -- Ben 25.11. 13:40: so groß wie die Stufen-Plakette, damit man das Wappen erkennt
    if opts.pvp then makePvP(f, opts.pvp, opts.small and 26 or (opts.h >= 50 and 40 or 32)) end
    if opts.auras then makeAuras(f) end
    if opts.combo then makeCombo(f) end
    if opts.combat then
        -- Gekreuzte Schwerter an der Porträt-Ecke, pulsieren im Kampf (Ben 25.11.
        -- 13:40: Blizzards Bild fehlt in Forever → eigenes Bild, mit rotem Schein)
        local holder = CreateFrame("Frame", nil, f)
        holder:SetSize(28, 28)
        holder:SetPoint("CENTER", f.portrait or f, "BOTTOMRIGHT", -4, 4)
        holder:SetFrameLevel(f:GetFrameLevel() + 9)
        local glow = holder:CreateTexture(nil, "ARTWORK")
        glow:SetPoint("CENTER")
        glow:SetSize(46, 46)
        glow:SetTexture("Interface\\AddOns\\Mondhain\\media\\punkt")
        glow:SetBlendMode("ADD")
        glow:SetVertexColor(1, 0.25, 0.15, 0.8)
        local t = holder:CreateTexture(nil, "OVERLAY")
        t:SetAllPoints()
        t:SetTexture("Interface\\AddOns\\Mondhain\\media\\kampf_schwerter")
        local ag = holder:CreateAnimationGroup()
        ag:SetLooping("BOUNCE")
        local a = ag:CreateAnimation("Alpha")
        a:SetFromAlpha(1); a:SetToAlpha(0.35); a:SetDuration(0.7)
        holder.anim = ag
        holder:Hide()
        f.combat = holder
    end

    -- Ereignisse nur für diese Einheit
    if unit ~= "targettarget" then
        local ev = CreateFrame("Frame")
        for e in pairs(UNIT_EVENTS) do ev:RegisterUnitEvent(e, unit) end
        ev:SetScript("OnEvent", function(_, e) if f:IsVisible() or unit == "player" then UNIT_EVENTS[e](f) end end)
    end

    if unit ~= "player" then RegisterUnitWatch(f) end
    f:HookScript("OnShow", updateAll)
    -- Tooltip beim Drüberfahren (wie bei Blizzard), am Mondhain-Tooltipanker
    f:HookScript("OnEnter", function(self)
        if not UnitExists(self.unit) then return end
        GameTooltip_SetDefaultAnchor(GameTooltip, self)
        if pcall(GameTooltip.SetUnit, GameTooltip, self.unit) then GameTooltip:Show() end
    end)
    f:HookScript("OnLeave", function() GameTooltip:Hide() end)
    ns.MakeMovable(f, cfg, opts.label, opts.onMoved)
    frames[key] = f
    updateAll(f)
    return f
end

---------------------------------------------------------------------------
-- Blizzards Einheitenfenster wegstecken
---------------------------------------------------------------------------
local hider
local function hideBlizzard()
    if InCombatLockdown() then return end
    hider = hider or CreateFrame("Frame")
    hider:Hide()
    local list = { "PlayerFrame", "TargetFrame", "PetFrame", "TargetFrameToT" }
    if db.focus.enabled then list[#list + 1] = "FocusFrame" end
    for _, n in ipairs(list) do
        local f = _G[n]
        if f and f.SetParent and f:GetParent() ~= hider then
            f:SetParent(hider)
            if not f.mondhainHooked then
                f.mondhainHooked = true
                hooksecurefunc(f, "SetParent", function(self, parent)
                    if parent ~= hider and not self.mondhainBusy and not InCombatLockdown() then
                        self.mondhainBusy = true
                        self:SetParent(hider)
                        self.mondhainBusy = false
                    end
                end)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Aussehen neu anwenden (aus den Optionen, sofort sichtbar)
---------------------------------------------------------------------------
function mod:ApplyLook()
    if not db then return end
    local l = look()
    for _, t in ipairs(allTexts) do applyFont(t) end
    for _, b in ipairs(allBars) do b.bgTex:SetColorTexture(0, 0, 0, (l.barBgAlpha or 70) / 100) end
    for _, f in pairs(frames) do
        f:SetBackdropColor(0.04, 0.05, 0.05, (l.frameAlpha or 85) / 100)
        if f.mana then f.mana:SetStatusBarColor(powerColor(0, "MANA")) end
        if UnitExists(f.unit) then updateAll(f) end
    end
end

---------------------------------------------------------------------------
-- Spiegeln: das andere Fenster steht auf gleicher Höhe, gespiegelt an der
-- Mitte der Aktionsleisten (gleiche Größe)
---------------------------------------------------------------------------
function mod:Mirror(fromKey, toKey)
    if db.mirror == false or InCombatLockdown() then return end
    local a, b = frames[fromKey], frames[toKey]
    if not (a and b) then return end
    local k = UIParent:GetEffectiveScale()
    local bars = _G.MondhainBars_center
    local axis = UIParent:GetWidth() / 2
    if bars and bars:GetCenter() then axis = bars:GetCenter() * bars:GetEffectiveScale() / k end
    local r, bo = a:GetRight(), a:GetBottom()
    local l = a:GetLeft()
    if not (r and bo and l) then return end
    local as = a:GetEffectiveScale() / k
    l, r, bo = l * as, r * as, bo * as
    db[toKey].scale = db[fromKey].scale
    b:SetScale(db[fromKey].scale or 1)
    local bs = b:GetEffectiveScale() / k
    local nx, ny = (2 * axis - r) / bs, bo / bs
    b:ClearAllPoints()
    b:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", nx, ny)
    db[toKey].point = { "BOTTOMLEFT", "UIParent", "BOTTOMLEFT", nx, ny }
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.unitFrames
    if not db.enabled then return end

    createFrame("player", "player", { w = 260, h = 54, healthH = 28, powerH = 12, portrait = "left",
        druidMana = true, combo = true, combat = true, pvp = "left", label = "Spieler",
        onMoved = function() mod:Mirror("player", "target") end })
    createFrame("target", "target", { w = 260, h = 54, healthH = 34, powerH = 14, portrait = "right",
        level = true, auras = true, dragon = true, pvp = "right", label = "Ziel",
        onMoved = function() mod:Mirror("target", "player") end })
    -- Spieler und Ziel spiegelgleich zur Mitte der Leisten
    C_Timer.After(1.5, function() mod:Mirror("player", "target") end)
    ns.On("LOCK_CHANGED", function()
        if ns.db.locked then C_Timer.After(0.1, function() mod:Mirror("player", "target") end) end
    end)
    if db.targettarget.enabled then
        createFrame("targettarget", "targettarget", { w = 130, h = 26, healthH = 22, small = true, label = "Ziel des Ziels" })
    end
    if db.pet.enabled then
        createFrame("pet", "pet", { w = 150, h = 30, healthH = 18, powerH = 7, small = true, label = "Begleiter" })
    end
    if db.focus.enabled then
        createFrame("focus", "focus", { w = 200, h = 40, healthH = 26, powerH = 9, level = true, dragon = true, pvp = "right", label = "Fokus" })
    end

    mod:ApplyLook()

    if db.hideBlizzard then
        hideBlizzard()
        C_Timer.After(1, hideBlizzard)
    end

    local function refresh(key) if frames[key] and frames[key]:IsVisible() then updateAll(frames[key]) end end
    ns.RegisterEvent("PLAYER_ENTERING_WORLD", function()
        for _, f in pairs(frames) do updateAll(f) end
    end)
    ns.RegisterEvent("PLAYER_TARGET_CHANGED", function()
        refresh("target"); refresh("targettarget")
        if frames.player then updateCombo(frames.player) end
        mod:RequestTargetAuras()
    end)
    -- Blizzards verstecktes Zielfenster ordnet seine Symbole neu → wir ziehen nach
    local tf = _G.TargetFrame
    if tf and type(tf.UpdateAuras) == "function" then
        hooksecurefunc(tf, "UpdateAuras", function() mod:RequestTargetAuras() end)
    end
    if type(_G.TargetFrame_UpdateAuras) == "function" then
        hooksecurefunc("TargetFrame_UpdateAuras", function() mod:RequestTargetAuras() end)
    end
    if type(_G.TargetFrame_UpdateAuraPositions) == "function" then
        hooksecurefunc("TargetFrame_UpdateAuraPositions", function() mod:RequestTargetAuras() end)
    end
    C_Timer.NewTicker(0.5, function()
        if useBlizzAuras() and UnitExists("target") then mod:RequestTargetAuras() end
    end)
    ns.RegisterEvent("PLAYER_FOCUS_CHANGED", function() refresh("focus") end)
    ns.RegisterEvent("UNIT_PET", function(_, u) if u == "player" then refresh("pet") end end)
    ns.RegisterEvent("UNIT_TARGET", function(_, u) if u == "target" then refresh("targettarget") end end)
    ns.RegisterEvent("UNIT_POWER_FREQUENT", function(_, u, kind)
        if u == "player" and frames.player and (kind == "COMBO_POINTS" or kind == "ENERGY") then updateCombo(frames.player) end
    end)
    ns.RegisterEvent("UNIT_COMBO_POINTS", function() if frames.player then updateCombo(frames.player) end end)
    ns.RegisterEvent("UPDATE_SHAPESHIFT_FORM", function() if frames.player then updateAll(frames.player) end end)
    -- PvP an/aus (eigenes Flag; bei anderen kommt UNIT_FACTION)
    local function pvpAll() for _, f in pairs(frames) do if (f.pvp or f.levelBadge) and f:IsVisible() then updatePvP(f) end end end
    ns.RegisterEvent("PLAYER_FLAGS_CHANGED", pvpAll)
    ns.RegisterEvent("UNIT_FACTION", pvpAll)
    function mod:RefreshPvP() pvpAll() end

    -- Kampfsymbol am Spieler
    local function combatIcon(on)
        local c = frames.player and frames.player.combat
        if not c then return end
        if on and db.combatIcon ~= false then c:Show(); c.anim:Play() else c.anim:Stop(); c:Hide() end
    end
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function() combatIcon(true) end)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function() combatIcon(false) end)
    combatIcon(UnitAffectingCombat("player"))

    -- Ziel des Ziels meldet keine eigenen Ereignisse: leise alle 0,25 s nachsehen
    if frames.targettarget then
        C_Timer.NewTicker(0.25, function()
            local f = frames.targettarget
            if f:IsVisible() then updateAll(f) end
        end)
    end
end
