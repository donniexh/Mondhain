-- Mondhain – eigener Tastenbelegungs-Modus (wie bei ElvUI)
-- Maus über eine Mondhain-Taste, dann Taste oder Kombination drücken:
-- Strg/Alt/Shift + Taste, F-Tasten, Maustasten 3–5, Mausrad.
-- Esc über einer Taste löscht ihre Belegung, Esc ins Leere beendet den Modus.
--
-- Liest die Tasten direkt ab, statt Blizzards Schnellbelegung zu benutzen –
-- dort gehen manche Kombinationen (z. B. Strg + F8 von einer Maustaste) nicht durch.

local _, ns = ...
local mod = ns.NewModule("KeyBind")
ns.KeyBind = mod

local active, target, catcher, banner = false, nil, nil, nil
local overlays = {}

local MODIFIERS = { LSHIFT = true, RSHIFT = true, LCTRL = true, RCTRL = true, LALT = true, RALT = true, UNKNOWN = true }
local MOUSE = { MiddleButton = "BUTTON3", Button4 = "BUTTON4", Button5 = "BUTTON5" }

local function combo(key)
    local s = ""
    if IsAltKeyDown() then s = s .. "ALT-" end
    if IsControlKeyDown() then s = s .. "CTRL-" end
    if IsShiftKeyDown() then s = s .. "SHIFT-" end
    return s .. key
end

local function keysOf(b)
    local list = {}
    for _, k in ipairs({ GetBindingKey(b.commandName) }) do list[#list + 1] = ns.ShortKey(k) end
    return #list > 0 and table.concat(list, ", ") or "|cff888888nichts|r"
end

local function showTip(o, b)
    GameTooltip:SetOwner(o, "ANCHOR_TOP")
    GameTooltip:AddLine(b.bindLabel or "Taste", 1, 0.82, 0)
    GameTooltip:AddLine("Belegt mit: " .. keysOf(b), 1, 1, 1)
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Taste oder Kombination drücken", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("Esc: Belegung löschen", 0.7, 0.7, 0.7)
    GameTooltip:Show()
end

local function bind(key)
    local b = target
    if not b or InCombatLockdown() then return end
    if key == "ESCAPE" then
        for _, k in ipairs({ GetBindingKey(b.commandName) }) do SetBinding(k) end
        ns.Print((b.bindLabel or "Taste") .. ": Belegung gelöscht.")
    else
        local full = combo(key)
        if SetBinding(full, b.commandName) then
            ns.Print(("%s → |cffffd100%s|r"):format(b.bindLabel or "Taste", ns.ShortKey(full)))
        else
            ns.Print("Diese Taste lässt sich nicht belegen: " .. full)
        end
    end
    if b.bindOverlay and b.bindOverlay:IsMouseOver() then showTip(b.bindOverlay, b) end
end

local function overlayFor(b)
    if overlays[b] then return overlays[b] end
    local o = CreateFrame("Button", nil, b)
    o:SetAllPoints()
    o:SetFrameLevel(b:GetFrameLevel() + 15)
    local t = o:CreateTexture(nil, "OVERLAY")
    t:SetAllPoints()
    t:SetColorTexture(0.58, 0.45, 0.92, 0.30)
    o:EnableMouseWheel(true)
    o:SetScript("OnEnter", function(self) target = b; showTip(self, b) end)
    o:SetScript("OnLeave", function() target = nil; GameTooltip:Hide() end)
    o:SetScript("OnMouseDown", function(_, btn)
        local k = MOUSE[btn]
        if k then target = b; bind(k) end
    end)
    o:SetScript("OnMouseWheel", function(_, d)
        target = b
        bind(d > 0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN")
    end)
    b.bindOverlay = o
    overlays[b] = o
    o:Hide()
    return o
end

local function allTargets()
    local list = {}
    for _, src in ipairs({ ns.ActionBars, ns.StanceBar }) do
        if src and src.GetBindButtons then
            for _, b in ipairs(src:GetBindButtons()) do list[#list + 1] = b end
        end
    end
    return list
end

function mod:SetActive(on)
    if on and InCombatLockdown() then
        ns.Print("Tasten lassen sich nur außerhalb des Kampfes belegen.")
        return
    end
    if not catcher then
        catcher = CreateFrame("Frame", nil, UIParent)
        catcher:SetFrameStrata("TOOLTIP")
        catcher:SetScript("OnKeyDown", function(_, key)
            if MODIFIERS[key] then return end
            if not target then
                if key == "ESCAPE" then mod:SetActive(false) end
                return
            end
            bind(key)
        end)
        catcher:Hide()
        banner = ns.MakeBanner("Tasten belegen",
            "Maus über eine Taste, dann Taste oder Kombination drücken · Esc: Belegung löschen",
            0.58, 0.45, 0.92, function() mod:SetActive(false) end)
    end
    active = on
    for b, o in pairs(overlays) do o:Hide() end
    if on then
        for _, b in ipairs(allTargets()) do overlayFor(b):Show() end
        catcher:Show()
        catcher:EnableKeyboard(true)
        catcher:SetPropagateKeyboardInput(false)
    else
        catcher:EnableKeyboard(false)
        catcher:Hide()
        target = nil
        GameTooltip:Hide()
        SaveBindings(GetCurrentBindingSet())
    end
    banner:SetShown(on)
end

function mod:IsActive() return active end

function mod:OnEnable()
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function()
        if active then mod:SetActive(false) end
    end)
end
