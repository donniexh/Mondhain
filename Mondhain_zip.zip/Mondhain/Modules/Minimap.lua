-- Mondhain – Minikarte
-- Eckig statt rund, unten links neben dem Chat, frei verschieb- und skalierbar.
-- Die Karte wird aus Blizzards Kartengruppe herausgenommen und in einen eigenen
-- Halter gesteckt (wie bei den anderen Blizzard-Teilen). Der runde Rahmen,
-- Zoom-Knöpfe und die Kopfleiste verschwinden.
--
-- Mausrad über der Karte: zoomen · Ortsname erscheint beim Drüberfahren.
-- Briefsymbol und Verfolgungs-Menü kommen später als eigene Knoten an die Wurzel.

local _, ns = ...
local mod = ns.NewModule("Minimap")
ns.Minimap = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local db, holder

-- Andere Addons (Knöpfe am Kartenrand) fragen hiernach
function GetMinimapShape() return "SQUARE" end

local DECOR = {
    "MinimapBorder", "MinimapBorderTop", "MinimapBackdrop", "MinimapCompassTexture",
    "MinimapNorthTag", "MinimapZoomIn", "MinimapZoomOut", "MiniMapWorldMapButton",
}

local hider
local function hideDecor()
    for _, n in ipairs(DECOR) do
        local f = _G[n]
        if f and f.SetAlpha then
            f:SetAlpha(0)
            if f.EnableMouse then f:EnableMouse(false) end
        end
    end
    for _, k in ipairs({ "ZoomIn", "ZoomOut", "ZoomHitArea" }) do
        local f = Minimap[k]
        if f and f.SetAlpha then
            f:SetAlpha(0)
            if f.EnableMouse then f:EnableMouse(false) end
        end
    end
    -- Kopfleiste mit Ortsnamen, Uhr, Kalender: ganze Kartengruppe wegstecken
    if MinimapCluster and not InCombatLockdown() then
        hider = hider or CreateFrame("Frame")
        hider:Hide()
        if MinimapCluster:GetParent() ~= hider then MinimapCluster:SetParent(hider) end
    end
end

---------------------------------------------------------------------------
-- Verfolgung (Kräutersuche usw.) und Post-Hinweis zurückholen
-- Es werden Blizzards eigene Knöpfe genommen und nur umgesetzt – ihr Menü
-- bleibt das von Blizzard. Mehrere Namen, weil Forever teils anders benennt.
---------------------------------------------------------------------------
local RESCUE = {
    { key = "tracking", point = "TOPLEFT",  x = 3,  y = -3, size = 26,
      find = function()
          local c = MinimapCluster
          return (c and (c.Tracking or c.TrackingFrame)) or _G.MiniMapTrackingFrame
              or _G.MiniMapTracking or _G.MiniMapTrackingButton
      end },
    { key = "mail", point = "TOPRIGHT", x = -3, y = -3,
      find = function()
          local c = MinimapCluster
          return (c and c.IndicatorFrame) or _G.MiniMapMailFrame
      end },
}

local function rescueButtons(overlay)
    for _, r in ipairs(RESCUE) do
        local f = r.find()
        if f and f.SetParent then
            local busy = false
            local function place()
                if busy then return end
                busy = true
                if f:GetParent() ~= overlay then f:SetParent(overlay) end
                f:ClearAllPoints()
                f:SetPoint(r.point, overlay, r.point, r.x, r.y)
                if r.size and f.SetSize then f:SetSize(r.size, r.size) end
                if f.SetAlpha then f:SetAlpha(1) end
                busy = false
            end
            if not f.mondhainRescued then
                f.mondhainRescued = true
                hooksecurefunc(f, "SetPoint", function() if not busy then place() end end)
                hooksecurefunc(f, "SetParent", function() if not busy then place() end end)
            end
            place()
        end
    end
end

function mod:OnEnable()
    db = ns.db.minimapFrame
    if not db.enabled or not Minimap then return end

    holder = CreateFrame("Frame", "MondhainMinimapHolder", UIParent)
    holder:SetSize(db.size, db.size)
    holder:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    holder:SetFrameStrata("LOW")

    -- Platzhalter-Rahmen (dunkles Holz), bis die Wurzel-Grafik kommt
    -- Holzrahmen um die Karte
    if ns.UseBranch() then
        -- im Stamm: schlichte dunkle Kante statt Holzrahmen
        local edge = CreateFrame("Frame", nil, holder, "BackdropTemplate")
        edge:SetPoint("TOPLEFT", -2, 2)
        edge:SetPoint("BOTTOMRIGHT", 2, -2)
        edge:SetFrameLevel(holder:GetFrameLevel() + 12)
        edge:SetBackdrop({ edgeFile = WHITE, edgeSize = 2 })
        edge:SetBackdropBorderColor(0.02, 0.015, 0.03, 0.95)
    else
        local wood = ns.WoodFrame(holder, 26)
        wood.holder:SetFrameLevel(holder:GetFrameLevel() + 12)
    end

    local busy = false
    local function anchor()
        if busy then return end
        busy = true
        if Minimap:GetParent() ~= holder then Minimap:SetParent(holder) end
        Minimap:ClearAllPoints()
        Minimap:SetPoint("CENTER", holder, "CENTER")
        Minimap:SetSize(db.size, db.size)
        Minimap:SetFrameStrata("LOW")
        Minimap:SetFrameLevel(holder:GetFrameLevel() + 2)
        busy = false
    end
    hooksecurefunc(Minimap, "SetPoint", function() if not busy then anchor() end end)
    hooksecurefunc(Minimap, "SetParent", function() if not busy then anchor() end end)
    anchor()

    Minimap:SetMaskTexture(WHITE)
    hideDecor()
    C_Timer.After(1, hideDecor)

    -- Mausrad zoomt
    Minimap:EnableMouseWheel(true)
    Minimap:SetScript("OnMouseWheel", function(self, d)
        local z = self:GetZoom() + (d > 0 and 1 or -1)
        local maxZ = (self.GetZoomLevels and self:GetZoomLevels() or 6) - 1
        if z < 0 then z = 0 elseif z > maxZ then z = maxZ end
        self:SetZoom(z)
    end)

    -- Ortsname beim Drüberfahren
    local zone = holder:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    mod.zone = zone
    zone:SetPoint("TOP", holder, "TOP", 0, -4)
    zone:SetWidth(db.size - 8)
    zone:SetWordWrap(false)
    zone:SetShadowOffset(1, -1)
    zone:Hide()
    local textLayer = CreateFrame("Frame", "MondhainMinimapOverlay", holder)
    textLayer:SetAllPoints()
    textLayer:SetFrameLevel(Minimap:GetFrameLevel() + 5)
    zone:SetParent(textLayer)

    -- Knöpfe über der Karte: Verfolgung links oben, Post rechts oben
    rescueButtons(textLayer)
    C_Timer.After(1.5, function() rescueButtons(textLayer) end)
    Minimap:HookScript("OnEnter", function()
        zone:SetText(GetMinimapZoneText and GetMinimapZoneText() or "")
        zone:Show()
    end)
    Minimap:HookScript("OnLeave", function() zone:Hide() end)

    -- Tafeln (Inhalte folgen später):
    --   links: zwischen Chat und Karte, oben und unten bündig mit dem Chat
    --   rechts: rechts neben den Aktionsleisten, so hoch wie die drei Reihen
    if db.boards then
        C_Timer.After(0.3, function() mod:BuildBoards(holder) end)
    end

    -- Größe ändern über die Schablone (Mausrad) skaliert den ganzen Halter
    ns.MakeMovable(holder, db, "Minikarte")
    mod.anchor = anchor
end

local function makeBoard(name)
    local b = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
    b:SetFrameStrata("LOW")
    b:SetWidth(db.boardWidth or 150)
    b:SetBackdrop({ bgFile = WHITE })
    local r = ns.db.root
    if ns.UseBranch() then
        b:SetBackdropColor(0, 0, 0, 0.28) -- eingelassen in den Stamm
    else
        b:SetBackdropColor(0.05, 0.05, 0.04, 0.82)
        if not (r and r.enabled and r.wrapBoards ~= false) then ns.WoodFrame(b, 22) end
    end
    b.title = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.title:SetPoint("TOP", 0, -9)
    b.title:SetTextColor(0.95, 0.80, 0.42)
    b.title:SetText("Tafel")
    b.hint = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    b.hint:SetPoint("CENTER")
    b.hint:SetText("Inhalt folgt")
    return b
end

function mod:BuildBoards(holder)
    ns.Boards = ns.Boards or {}
    local k = UIParent:GetEffectiveScale()
    local function top(fr) return fr:GetTop() and fr:GetTop() * fr:GetEffectiveScale() / k end
    local function bottom(fr) return fr:GetBottom() and fr:GetBottom() * fr:GetEffectiveScale() / k end

    db.boardLeft = db.boardLeft or {}
    db.boardRight = db.boardRight or {}
    -- selbst verschoben? dann bleibt die Tafel dort (Höhe passt sich weiter an)
    local function placed(fr, bdb)
        if fr.mhMoving then return true end
        local p = bdb.point
        if not p then return false end
        fr:ClearAllPoints()
        fr:SetPoint(p[1], UIParent, p[3], p[4], p[5])
        return true
    end

    -- links: rechte Kante an der Karte, Höhe wie der Chat
    local left = makeBoard("MondhainBoardLeft")
    local function fitLeft()
        local chat = _G.MondhainChatHolder
        local t, b = chat and top(chat), chat and bottom(chat)
        if not (t and b) then t, b = top(holder), bottom(holder) end
        if not (t and b) then return end
        local s = left:GetScale()
        -- eigene Größe (Ränder im Bearbeiten-Modus gezogen) geht vor
        if db.boardLeft.w then left:SetWidth(db.boardLeft.w) end
        if db.boardLeft.h then left:SetHeight(db.boardLeft.h) else left:SetHeight(math.max(40, t - b) / s) end
        if placed(left, db.boardLeft) then return end
        left:ClearAllPoints()
        if db.boardLeftSide == "right" then
            -- schmales Bild (Ben 26.11.): links ist der Chat, die Tafel kommt rechts an die Karte
            local hr = holder:GetRight() * holder:GetEffectiveScale() / k
            left:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", (hr + 12) / s, b / s)
        else
            local hx = holder:GetLeft() * holder:GetEffectiveScale() / k
            left:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMLEFT", (hx - 12) / s, b / s)
        end
    end
    C_Timer.NewTicker(1, fitLeft)
    fitLeft()
    ns.MakeMovable(left, db.boardLeft, "Linke Tafel", nil, nil, {
        set = function(w, h) left:SetSize(w, h); db.boardLeft.w, db.boardLeft.h = w, h end, minW = 60, minH = 40 })
    ns.Boards.left = left

    -- rechts: neben den Aktionsleisten
    local bars = _G.MondhainBars_center
    if bars then
        -- oben bündig mit den Leisten, unten sitzt sie auf dem Wurzelstrang
        local right = makeBoard("MondhainBoardRight")
        right.title:Hide()
        right.hint:Hide()
        local function fitRight()
            -- mit Mittelblock: oben und unten bündig mit ihm, Wurzeln Seite an Seite
            local plate = _G.MondhainCenterPlate
            local ref = (plate and plate:IsShown() and plate:GetRight()) and plate or bars
            local t = top(ref)
            if not t or not ref:GetRight() then return end
            local x = ref:GetRight() * ref:GetEffectiveScale() / k + (ref == plate and 26 or 16)
            local r = ns.db.root
            local floor = (r and r.enabled) and math.floor((r.thickness or 24) * 0.75 - 2) or 8
            if ref == plate then floor = bottom(plate) or floor end
            local s = right:GetScale()
            if db.boardRight.w then right:SetWidth(db.boardRight.w) end
            if db.boardRight.h then right:SetHeight(db.boardRight.h) else right:SetHeight(math.max(40, t - floor) / s) end
            if placed(right, db.boardRight) then return end
            right:ClearAllPoints()
            right:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x / s, floor / s)
        end
        C_Timer.NewTicker(1, fitRight)
        fitRight()
        ns.MakeMovable(right, db.boardRight, "Rechte Tafel", nil, nil, {
            set = function(w, h) right:SetSize(w, h); db.boardRight.w, db.boardRight.h = w, h end, minW = 60, minH = 40 })
        ns.Boards.right = right
    end
end

-- Kantenlänge der Karte ändern (Optionen); Vorratsleiste rückt automatisch mit
function mod:SetSize(n)
    db.size = n
    if not holder then return end
    holder:SetSize(n, n)
    if self.anchor then self.anchor() end
    if self.zone then self.zone:SetWidth(n - 8) end
end
