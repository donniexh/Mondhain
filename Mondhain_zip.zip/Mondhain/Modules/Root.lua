-- Mondhain – die Wurzel
-- Ein alter Baum, dessen Wurzel quer am Boden liegt; alles wächst aus ihr:
--   Strang:  dünner Wurzelstrang über die ganze Breite am unteren Rand
--   Knoten:  die Wurzel schlingt sich um die Ecke der Karte
--   Mulde:   flache Schale unter den Aktionsleisten
--   Triebe:  wachsen hinter Spieler- und Zielfenster hoch
--   Ende:    rechts in der Ecke läuft die Wurzel in Spitzen aus
--   EP-Ranke: grüne Ranke in der Mulde, wächst mit deinen Erfahrungspunkten;
--             eine silberne Knospe zeigt, wie weit „ausgeruht“ reicht
--
-- Alle Teile hängen an ihren Elementen: wird etwas verschoben, wandert die
-- Wurzel mit. Liegt hinter allem (unterste Ebene).

local _, ns = ...
local mod = ns.NewModule("Root")
ns.Root = mod

local MEDIA = "Interface\\AddOns\\Mondhain\\media\\"
local TINT = { 0.82, 0.74, 0.70 } -- Holz etwas dunkler, passend zum Mahagoni-Rahmen
local db, base
local mulde -- Mulde unter den Leisten (Wurzelbett und EP-Ranke richten sich danach)

-- Inhaltsbereiche der Texturen (wo im Bild das Holz liegt)
local STRANG_V = { 0.20, 0.80 }   -- 1024 x 128, Holz in der Mitte
local STRANG_TILE = 1024 / 76     -- Kachellänge im Verhältnis zur Höhe
local MULDE_V = { 0.15, 0.85 }
local MULDE_ASPECT = 1024 / 179
local EP_U = { 0.144, 0.856 }

local function tex(parent, file, layer, sub)
    local t = parent:CreateTexture(nil, layer or "ARTWORK", nil, sub or 0)
    t:SetTexture(MEDIA .. file)
    t:SetVertexColor(TINT[1], TINT[2], TINT[3])
    return t
end

---------------------------------------------------------------------------
-- Strang und Ende
---------------------------------------------------------------------------
local function buildStrang()
    local h = db.thickness
    local ende = tex(base, "wurzel_ende", "ARTWORK", 1)
    ende:SetSize(h * 2.2 * 4.1, h * 2.2)                 -- Spitzen rechts unten
    ende:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", 0, -h * 0.55)
    ende:SetTexCoord(0, 1, 0.01, 0.99)

    local s = base:CreateTexture(nil, "ARTWORK", nil, 0)
    s:SetTexture(MEDIA .. "wurzel_strang", "REPEAT", "CLAMP")
    s:SetVertexColor(TINT[1], TINT[2], TINT[3])
    s:SetHeight(h)
    s:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 0, -h * 0.25)
    s:SetPoint("RIGHT", ende, "LEFT", h * 0.9, 0)
    local function retile()
        local w = s:GetWidth()
        if w and w > 0 then
            s:SetTexCoord(0, w / (h * STRANG_TILE), STRANG_V[1], STRANG_V[2])
        end
    end
    base:HookScript("OnSizeChanged", retile)
    C_Timer.After(0.5, retile)
    retile()
end

---------------------------------------------------------------------------
-- Wurzelbett links: dicke Wurzelmasse hinter Chat und Karte, fällt zur
-- Mitte hin ab und läuft in die Mulde unter den Leisten aus
---------------------------------------------------------------------------
local BED_ASPECT = 2047 / 508
local function bedTexture(flip)
    local bed = base:CreateTexture(nil, "ARTWORK", nil, 3)
    bed:SetTexture(MEDIA .. "wurzel_bett")
    bed:SetVertexColor(TINT[1], TINT[2], TINT[3])
    if flip then
        bed:SetTexCoord(2047 / 2048, 0, 4 / 512, 1)
    else
        bed:SetTexCoord(0, 2047 / 2048, 4 / 512, 1)
    end
    return bed
end

-- Links: vom Rand bis unter die erste Taste von Leiste 2.
-- Rechts: gespiegelt, von der letzten Taste bis zum rechten Rand (unter den Tracker).
local function buildBeds()
    local bars = _G.MondhainBars_center
    local left = bedTexture(false)
    left:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 0, -4)
    local right
    if db.bedRight then
        right = bedTexture(true)
        right:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", 0, -4)
    end
    local k = UIParent:GetEffectiveScale()
    local function fit()
        local lw, rw = 720, 720
        if bars and bars:GetLeft() then
            local s2 = bars:GetEffectiveScale() / k
            lw = bars:GetLeft() * s2 + 14
            rw = UIParent:GetWidth() - bars:GetRight() * s2 + 14
        end
        left:SetSize(math.max(200, lw), db.bedHeight or 240)
        if right then right:SetSize(math.max(200, rw), db.bedHeightRight or 180) end
    end
    C_Timer.NewTicker(1, fit)
    fit()
end

---------------------------------------------------------------------------
-- Knoten um die Kartenecke
---------------------------------------------------------------------------
local function buildKnot()
    local holder = _G.MondhainMinimapHolder
    if not holder then return end
    local f = CreateFrame("Frame", nil, holder)
    f:SetFrameLevel(holder:GetFrameLevel() + 14)
    local size = holder:GetHeight() * 0.62
    local t = tex(f, "wurzel_knoten", "OVERLAY")
    t:SetSize(size, size)
    -- Ecke im Bild liegt bei etwa 7 % von links / 5 % von unten
    t:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", -size * 0.10, -size * 0.07)
    f:SetAllPoints(holder)
    holder:HookScript("OnSizeChanged", function()
        local s2 = holder:GetHeight() * 0.62
        t:SetSize(s2, s2)
        t:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", -s2 * 0.10, -s2 * 0.07)
    end)
end

---------------------------------------------------------------------------
-- Mulde unter den Leisten (drei Teile: Enden fest, Mitte dehnbar)
---------------------------------------------------------------------------
-- Bogen: Ranken wachsen von links über die oberste Tastenreihe und rechts
-- wieder hinunter (das Mulde-Bild, auf den Kopf gestellt). Liegt hinter den Tasten.
local function buildArch()
    local bars = _G.MondhainBars_center
    if not bars then return end
    local H = db.archHeight or 165
    local endW = H * MULDE_ASPECT * 0.22
    mulde = CreateFrame("Frame", nil, base)
    mulde:SetHeight(H)
    mulde:SetPoint("BOTTOMLEFT", bars, "BOTTOMLEFT", -endW * 0.45, -6)
    mulde:SetPoint("BOTTOMRIGHT", bars, "BOTTOMRIGHT", endW * 0.45, -6)
    local vT, vB = MULDE_V[2], MULDE_V[1] -- senkrecht gespiegelt
    local l = tex(mulde, "wurzel_mulde", "ARTWORK", 2)
    l:SetPoint("TOPLEFT"); l:SetPoint("BOTTOMLEFT"); l:SetWidth(endW)
    l:SetTexCoord(0, 0.22, vT, vB)
    local r = tex(mulde, "wurzel_mulde", "ARTWORK", 2)
    r:SetPoint("TOPRIGHT"); r:SetPoint("BOTTOMRIGHT"); r:SetWidth(endW)
    r:SetTexCoord(0.78, 1, vT, vB)
    local m = tex(mulde, "wurzel_mulde", "ARTWORK", 2)
    m:SetPoint("TOPLEFT", l, "TOPRIGHT"); m:SetPoint("BOTTOMRIGHT", r, "BOTTOMLEFT")
    m:SetTexCoord(0.22, 0.78, vT, vB)
    mulde.endW = endW
end

---------------------------------------------------------------------------
-- Umrankung des Questtrackers: links steigt die Wurzel vom Strang auf,
-- schlingt sich oben herüber und rechts wieder hinunter; Knoten an den Ecken
---------------------------------------------------------------------------
local function buildWrap(q, name, thick)
    if not q then return end
    local th = thick or db.wrapThickness or 26
    local c = th * 0.2          -- Mittellinie der Ranke etwas außerhalb des Rands
    local K = th * 4.4          -- Größe der Eckknoten (deutlich sichtbar)
    local qw = q:GetWidth() or 0
    if qw > 0 then K = math.min(K, qw * 0.45) end -- schmale Tafeln: kleinere Knoten
    local qh = q:GetHeight() or 0
    if thick and qh > 0 then K = math.min(K, qh * 0.35) end
    local L = th * STRANG_TILE  -- Kachellänge

    local f = CreateFrame("Frame", name, UIParent)
    f:SetFrameStrata("LOW")
    f:SetFrameLevel(q:GetFrameLevel() + 60)
    f:SetAllPoints(q)

    local function strip()
        local t = f:CreateTexture(nil, "ARTWORK")
        t:SetTexture(MEDIA .. "wurzel_strang", "REPEAT", "CLAMP")
        t:SetVertexColor(TINT[1], TINT[2], TINT[3])
        return t
    end
    local top, left, right = strip(), strip(), strip()
    top:SetHeight(th)
    top:SetPoint("LEFT", f, "TOPLEFT", -c, c)
    top:SetPoint("RIGHT", f, "TOPRIGHT", c, c)
    left:SetWidth(th)
    left:SetPoint("TOP", f, "TOPLEFT", -c, c)
    left:SetPoint("BOTTOM", f, "BOTTOMLEFT", -c, -c)
    right:SetWidth(th)
    right:SetPoint("TOP", f, "TOPRIGHT", c, c)
    right:SetPoint("BOTTOM", f, "BOTTOMRIGHT", c, -c)

    local function retile()
        local w, h = f:GetWidth(), f:GetHeight()
        if not w or w <= 0 then return end
        local V1, V2 = STRANG_V[1], STRANG_V[2]
        top:SetTexCoord(0, (w + 2 * c) / L, V1, V2)
        -- senkrecht: Textur um 90° gedreht (Länge läuft nach unten)
        local n = (h + 2 * c) / L
        left:SetTexCoord(0, V1, n, V1, 0, V2, n, V2)
        right:SetTexCoord(0, V2, n, V2, 0, V1, n, V1)
    end
    f:SetScript("OnSizeChanged", retile)
    retile()

    -- Eckknoten (Bild zeigt die linke untere Ecke; gespiegelt für die anderen)
    local function knot(point, fx, fy, dx, dy)
        local t = f:CreateTexture(nil, "OVERLAY")
        t:SetTexture(MEDIA .. "wurzel_knoten")
        t:SetVertexColor(TINT[1], TINT[2], TINT[3])
        t:SetSize(K, K)
        local l, r, tp, bt = 0, 1, 0, 1
        if fx then l, r = 1, 0 end
        if fy then tp, bt = 1, 0 end
        t:SetTexCoord(l, r, tp, bt)
        t:SetPoint(point, f, point, dx, dy)
    end
    knot("BOTTOMLEFT",  false, false, -c - 0.07 * K, -c - 0.05 * K)
    knot("TOPLEFT",     false, true,  -c - 0.07 * K,  c + 0.05 * K)
    knot("TOPRIGHT",    true,  true,   c + 0.07 * K,  c + 0.05 * K)
    knot("BOTTOMRIGHT", true,  false,  c + 0.07 * K, -c - 0.05 * K)

    q:HookScript("OnShow", function() f:Show() end)
    q:HookScript("OnHide", function() f:Hide() end)
    f:SetShown(q:IsShown())
end

---------------------------------------------------------------------------
-- Triebe hinter Spieler- und Zielfenster
---------------------------------------------------------------------------
local function buildShoot(frameName, side)
    local f = _G[frameName]
    if not f then return end
    local t = tex(base, "wurzel_trieb", "ARTWORK", 1)
    t:SetWidth(db.thickness * 1.6)
    if side == "left" then
        t:SetPoint("TOP", f, "TOPRIGHT", -26, 26)
        t:SetTexCoord(0, 1, 0, 1)
    else
        t:SetPoint("TOP", f, "TOPLEFT", 26, 26)
        t:SetTexCoord(1, 0, 0, 1) -- gespiegelt
    end
    -- Höhe: von knapp über dem Fenster bis hinunter zum Strang
    local function fix()
        local top = f:GetTop()
        if not top then return end
        top = top * f:GetEffectiveScale() / UIParent:GetEffectiveScale()
        t:SetHeight(math.max(20, top + 26))
    end
    C_Timer.NewTicker(1, fix) -- folgt, wenn das Fenster verschoben wird
    fix()
end

---------------------------------------------------------------------------
-- EP-Ranke in der Mulde
---------------------------------------------------------------------------
local ep
local function buildXP()
    local bars = _G.MondhainBars_center
    if not bars then return end
    ep = CreateFrame("Frame", nil, base)
    ep:SetPoint("TOPLEFT", bars, "BOTTOMLEFT", 6, -2)
    ep:SetPoint("TOPRIGHT", bars, "BOTTOMRIGHT", -6, -2)
    ep:SetHeight(20)
    ep:SetFrameLevel(base:GetFrameLevel() + 5)

    ep.vine = ep:CreateTexture(nil, "OVERLAY")
    ep.vine:SetTexture(MEDIA .. "ep_ranke")
    ep.vine:SetPoint("TOPLEFT"); ep.vine:SetPoint("BOTTOMLEFT")
    ep.bud = ep:CreateTexture(nil, "OVERLAY", nil, 2)
    ep.bud:SetTexture(MEDIA .. "ep_knospe")
    ep.bud:SetSize(db.thickness * 0.9, db.thickness * 0.9)

    -- Tooltip: Maus auf die Mulde unterhalb der Tasten
    ep:EnableMouse(true)
    ep:SetScript("OnEnter", function(self)
        local cur, max = UnitXP("player"), UnitXPMax("player")
        local rested = GetXPExhaustion() or 0
        local f = ns.FormatNumber or tostring
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Stufe " .. UnitLevel("player"), 1, 0.82, 0)
        if max and max > 0 then
            GameTooltip:AddLine(("%s / %s EP  (%d %%)"):format(f(cur), f(max), math.floor(cur / max * 100)), 1, 1, 1)
            GameTooltip:AddLine(("Bis zur nächsten Stufe: %s"):format(f(max - cur)), 0.8, 0.8, 0.8)
            if rested > 0 then GameTooltip:AddLine("Ausgeruht: " .. f(rested), 0.75, 0.85, 1) end
        end
        GameTooltip:Show()
    end)
    ep:SetScript("OnLeave", GameTooltip_Hide)
end

local function updateXP()
    if not ep then return end
    local max = UnitXPMax("player")
    local atCap = (IsPlayerAtEffectiveMaxLevel and IsPlayerAtEffectiveMaxLevel()) or not max or max == 0
    if atCap then ep:Hide() return end
    ep:Show()
    local p = math.min(1, UnitXP("player") / max)
    local w = ep:GetWidth()
    local vw = math.max(0.5, w * p)
    ep.vine:SetWidth(vw)
    ep.vine:SetTexCoord(EP_U[1], EP_U[1] + (EP_U[2] - EP_U[1]) * p, 0, 1)
    ep.vine:SetShown(p > 0.002)
    local rested = GetXPExhaustion() or 0
    if rested > 0 then
        local rp = math.min(1, (UnitXP("player") + rested) / max)
        ep.bud:ClearAllPoints()
        ep.bud:SetPoint("CENTER", ep, "LEFT", w * rp, 0)
        ep.bud:Show()
    else
        ep.bud:Hide()
    end
end

---------------------------------------------------------------------------
-- Blizzards EP-Balken weg (die Ranke ersetzt ihn)
---------------------------------------------------------------------------
local function hideXPBar()
    local h = _G.MondhainHolder_xp
    if h then h:Hide() end
end

---------------------------------------------------------------------------
-- Start (etwas verzögert, damit Karte, Leisten und Fenster schon stehen)
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.root
    if not db.enabled or ns.UseBranch() then return end
    C_Timer.After(0.6, function()
        base = CreateFrame("Frame", "MondhainRoot", UIParent)
        base:SetAllPoints(UIParent)
        base:SetFrameStrata("BACKGROUND")
        base:SetFrameLevel(0) -- ganz hinten, alles andere liegt darüber

        buildStrang()
        if db.knot then buildKnot() end
        if db.arch then buildArch() end
        if db.bed then buildBeds() end
        if db.questWrap then buildWrap(_G.MondhainQuestTracker, "MondhainRootWrap") end
        if db.wrapBoards ~= false then
            local bt = math.floor((db.wrapThickness or 34) * 0.6)
            buildWrap(_G.MondhainBoardLeft, "MondhainRootWrapLeft", bt)
            buildWrap(_G.MondhainBoardRight, "MondhainRootWrapRight", bt)
        end
        local cb = ns.db.centerBlock
        if cb and cb.enabled and cb.wrap ~= false and _G.MondhainCenterPlate then
            buildWrap(_G.MondhainCenterPlate, "MondhainRootWrapCenter",
                math.floor((db.wrapThickness or 34) * 0.6))
        end
        if db.shoots then
            buildShoot("MondhainUnit_player", "left")
            buildShoot("MondhainUnit_target", "right")
        end
        if db.xp then
            buildXP()
            updateXP()
            ns.RegisterEvent("PLAYER_XP_UPDATE", updateXP)
            ns.RegisterEvent("UPDATE_EXHAUSTION", updateXP)
            ns.RegisterEvent("PLAYER_LEVEL_UP", function() C_Timer.After(0.5, updateXP) end)
            if ep then ep:HookScript("OnSizeChanged", updateXP) end
            if db.hideXPBar then
                hideXPBar()
                C_Timer.After(1, hideXPBar)
            end
        end
    end)
end
