-- Mondhain – Kontobuch (pro Charakter)
-- Merkt sich jede Goldbewegung und ordnet sie zu: Beute, Quests, Händler,
-- Auktionshaus, Reparaturen, Flüge, Lehrer, Post, Handel, Sonstiges.
-- Gespeichert wird pro Tag, damit sich Zeiträume auswerten lassen:
-- Sitzung · 1–4 Wochen · Monat · halbes Jahr · gesamt.

local _, ns = ...
local mod = ns.NewModule("GoldLedger")
ns.Ledger = mod

local book            -- Daten dieses Charakters
local lastMoney
local session = { income = {}, expense = {} }

mod.INCOME = {
    { key = "loot",   label = "Beute" },
    { key = "quest",  label = "Quests" },
    { key = "vendor", label = "Händler (Verkauf)" },
    { key = "ah",     label = "Auktionshaus" },
    { key = "mail",   label = "Post" },
    { key = "trade",  label = "Handel" },
    { key = "other",  label = "Sonstiges" },
}
mod.EXPENSE = {
    { key = "repair",   label = "Reparaturen" },
    { key = "vendor",   label = "Händler (Kauf)" },
    { key = "ah",       label = "Auktionshaus" },
    { key = "flight",   label = "Flüge" },
    { key = "training", label = "Lehrer" },
    { key = "mail",     label = "Post" },
    { key = "trade",    label = "Handel" },
    { key = "other",    label = "Sonstiges" },
}

---------------------------------------------------------------------------
-- Wo bin ich gerade? (bestimmt, wohin eine Goldbewegung gehört)
---------------------------------------------------------------------------
local ctx = {}
local pending = { quest = 0, repairAt = 0, taxiAt = 0, lootAt = 0, mailCat = nil, mailAt = 0 }

local function now() return GetTime() end

local function book_add(kind, cat, amount)
    local day = date("%Y-%m-%d")
    book.days[day] = book.days[day] or { income = {}, expense = {} }
    local d = book.days[day][kind]
    d[cat] = (d[cat] or 0) + amount
    book.total[kind][cat] = (book.total[kind][cat] or 0) + amount
    session[kind][cat] = (session[kind][cat] or 0) + amount
end

local function classify(delta)
    local t = now()
    if delta > 0 then
        if pending.quest > 0 then
            local q = math.min(delta, pending.quest)
            pending.quest = pending.quest - q
            book_add("income", "quest", q)
            delta = delta - q
            if delta <= 0 then return end
        end
        if pending.mailCat and t - pending.mailAt < 3 then
            book_add("income", pending.mailCat, delta); pending.mailCat = nil
        elseif ctx.loot or t - pending.lootAt < 2 then
            book_add("income", "loot", delta)
        elseif ctx.merchant then
            book_add("income", "vendor", delta)
        elseif ctx.trade then
            book_add("income", "trade", delta)
        elseif ctx.mail then
            book_add("income", "mail", delta)
        else
            book_add("income", "other", delta)
        end
    else
        local amount = -delta
        local repairing = InRepairMode and InRepairMode()
        if ctx.merchant and (repairing or t - pending.repairAt < 2) then
            book_add("expense", "repair", amount)
        elseif ctx.merchant then
            book_add("expense", "vendor", amount)
        elseif ctx.ah then
            book_add("expense", "ah", amount)
        elseif ctx.taxi or t - pending.taxiAt < 12 then
            book_add("expense", "flight", amount)
        elseif ctx.trainer then
            book_add("expense", "training", amount)
        elseif ctx.mail then
            book_add("expense", "mail", amount)
        elseif ctx.trade then
            book_add("expense", "trade", amount)
        else
            book_add("expense", "other", amount)
        end
    end
end

-- Ben 25.11. 13:49: Händlerbesuch zusammenfassen – beim Schließen steht im
-- Chat, wofür verkauft, repariert (auch über die Gildenbank) und eingekauft wurde
local visit          -- { sold, repair, guild, buy } solange der Händler offen ist (+ kurz danach)
local repairCost = 0
local function noteRepairCost()
    if GetRepairAllCost then
        local ok, c = pcall(GetRepairAllCost)
        if ok and type(c) == "number" then repairCost = c end
    end
end
local function visitMoney(d)
    if not visit then return end
    if d > 0 then
        visit.sold = visit.sold + d
    else
        local repairing = InRepairMode and InRepairMode()
        if repairing or now() - pending.repairAt < 2 then visit.repair = visit.repair - d
        else visit.buy = visit.buy - d end
    end
end
local function visitReport()
    local v = visit
    visit = nil
    if not v or (ns.db.ledger and ns.db.ledger.merchantChat == false) then return end
    local parts = {}
    if v.sold > 0 then parts[#parts + 1] = "verkauft für " .. ns.CoinString(v.sold) end
    if v.repair > 0 then parts[#parts + 1] = "repariert für " .. ns.CoinString(v.repair) end
    if v.guild > 0 then parts[#parts + 1] = "repariert über die Gildenbank für " .. ns.CoinString(v.guild) end
    if v.buy > 0 then parts[#parts + 1] = "eingekauft für " .. ns.CoinString(v.buy) end
    if #parts > 0 then ns.Print("Händler: " .. table.concat(parts, " · ")) end
end

local function onMoney()
    local m = GetMoney()
    if lastMoney then
        local d = m - lastMoney
        if d ~= 0 then classify(d); visitMoney(d) end
    end
    lastMoney = m
    if mod.window and mod.window:IsShown() then mod:UpdateWindow() end
    ns.Fire("GOLD_CHANGED", m)
end

---------------------------------------------------------------------------
-- Auswertung
---------------------------------------------------------------------------
-- days: nil = gesamt, 0 = Sitzung, sonst Anzahl Tage zurück (inkl. heute)
function mod:Sum(days)
    local inc, exp = {}, {}
    if days == 0 then
        for k, v in pairs(session.income) do inc[k] = v end
        for k, v in pairs(session.expense) do exp[k] = v end
    elseif not days then
        for k, v in pairs(book.total.income) do inc[k] = v end
        for k, v in pairs(book.total.expense) do exp[k] = v end
    else
        local cutoff = date("%Y-%m-%d", time() - (days - 1) * 86400)
        for day, d in pairs(book.days) do
            if day >= cutoff then
                for k, v in pairs(d.income) do inc[k] = (inc[k] or 0) + v end
                for k, v in pairs(d.expense) do exp[k] = (exp[k] or 0) + v end
            end
        end
    end
    local ti, te = 0, 0
    for _, v in pairs(inc) do ti = ti + v end
    for _, v in pairs(exp) do te = te + v end
    return inc, exp, ti, te
end

function mod:SessionNet()
    local _, _, ti, te = self:Sum(0)
    return ti - te
end

local function coins(c)
    c = math.floor(math.abs(c or 0))
    if GetCoinTextureString then return GetCoinTextureString(c) end
    if ns.CoinString then return ns.CoinString(c) end
    return ("%dg %ds %dk"):format(math.floor(c / 10000), math.floor(c / 100) % 100, c % 100)
end
mod.Coins = coins

---------------------------------------------------------------------------
-- Fenster
---------------------------------------------------------------------------
local PERIODS = {
    { label = "Sitzung", days = 0 }, { label = "1 Wo.", days = 7 }, { label = "2 Wo.", days = 14 },
    { label = "3 Wo.", days = 21 }, { label = "4 Wo.", days = 28 }, { label = "Monat", days = 30 },
    { label = "½ Jahr", days = 182 }, { label = "Gesamt", days = nil },
}
local period = 1

local function buildWindow()
    local w = CreateFrame("Frame", "MondhainLedger", UIParent, "BackdropTemplate")
    w:SetSize(520, 380)
    w:SetPoint("CENTER")
    w:SetFrameStrata("FULLSCREEN_DIALOG")
    w:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    w:SetBackdropColor(0.04, 0.05, 0.05, 0.96)
    ns.WoodFrame(w, 26)
    w:EnableMouse(true); w:SetMovable(true); w:RegisterForDrag("LeftButton")
    w:SetScript("OnDragStart", w.StartMoving)
    w:SetScript("OnDragStop", w.StopMovingOrSizing)
    tinsert(UISpecialFrames, "MondhainLedger")

    local title = w:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 20, -16)
    title:SetTextColor(0.95, 0.80, 0.42)
    title:SetText("Kontobuch – " .. UnitName("player"))
    local since = w:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    since:SetPoint("TOPRIGHT", -40, -20)
    w.since = since
    local close = CreateFrame("Button", nil, w, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 2, 2)

    -- Zeitraum-Knöpfe
    w.tabs = {}
    for i, p in ipairs(PERIODS) do
        local b = CreateFrame("Button", nil, w, "UIPanelButtonTemplate")
        b:SetSize(58, 22)
        b:SetPoint("TOPLEFT", 18 + (i - 1) * 61, -48)
        b:SetText(p.label)
        b:SetScript("OnClick", function() period = i; mod:UpdateWindow() end)
        w.tabs[i] = b
    end

    local function column(x, head, r, g, b)
        local h = w:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        h:SetPoint("TOPLEFT", x, -86)
        h:SetText(head)
        h:SetTextColor(r, g, b)
        local rows = {}
        for i = 1, 8 do
            local l = w:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            l:SetPoint("TOPLEFT", x, -86 - i * 22)
            local v = w:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            v:SetPoint("TOPRIGHT", w, "TOPLEFT", x + 225, -86 - i * 22)
            rows[i] = { l = l, v = v }
        end
        return rows
    end
    w.inc = column(20, "Einnahmen", 0.35, 0.90, 0.35)
    w.exp = column(275, "Ausgaben", 1, 0.45, 0.35)

    local line = w:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(1, 0.49, 0.04, 0.35)
    line:SetHeight(1)
    line:SetPoint("BOTTOMLEFT", 18, 64)
    line:SetPoint("BOTTOMRIGHT", -18, 64)
    w.sumIn = w:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    w.sumIn:SetPoint("BOTTOMLEFT", 20, 40)
    w.sumOut = w:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    w.sumOut:SetPoint("BOTTOMLEFT", 275, 40)
    w.net = w:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    w.net:SetPoint("BOTTOM", 0, 14)
    w:Hide()
    mod.window = w
end

local function fillColumn(rows, defs, data)
    for i, def in ipairs(defs) do
        local r = rows[i]
        if r then
            r.l:SetText(def.label)
            local v = data[def.key] or 0
            r.v:SetText(v > 0 and coins(v) or "|cff666666–|r")
        end
    end
    for i = #defs + 1, #rows do rows[i].l:SetText(""); rows[i].v:SetText("") end
end

function mod:UpdateWindow()
    local w = self.window
    if not w then return end
    local inc, exp, ti, te = self:Sum(PERIODS[period].days)
    for i, b in ipairs(w.tabs) do
        if i == period then b:LockHighlight() else b:UnlockHighlight() end
    end
    fillColumn(w.inc, self.INCOME, inc)
    fillColumn(w.exp, self.EXPENSE, exp)
    w.sumIn:SetText("Summe: |cff59e659" .. coins(ti) .. "|r")
    w.sumOut:SetText("Summe: |cffff7759" .. coins(te) .. "|r")
    local net = ti - te
    if net >= 0 then
        w.net:SetText("Gewinn: |cff59e659" .. coins(net) .. "|r")
    else
        w.net:SetText("Verlust: |cffff5555" .. coins(net) .. "|r")
    end
    local y, m, d = (book.since or ""):match("(%d+)-(%d+)-(%d+)")
    w.since:SetText(y and ("aufgezeichnet seit " .. d .. "." .. m .. "." .. y) or "")
end

function mod:Toggle()
    if not self.window then buildWindow() end
    if self.window:IsShown() then self.window:Hide() else self:UpdateWindow(); self.window:Show() end
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    local key = UnitName("player") .. "-" .. GetRealmName()
    ns.db.ledger = ns.db.ledger or {}
    ns.db.ledger[key] = ns.db.ledger[key] or {}
    book = ns.db.ledger[key]
    book.days = book.days or {}
    book.total = book.total or { income = {}, expense = {} }
    book.since = book.since or date("%Y-%m-%d")
    -- alte Tage aufräumen (älter als ein gutes Jahr)
    local cutoff = date("%Y-%m-%d", time() - 400 * 86400)
    for day in pairs(book.days) do if day < cutoff then book.days[day] = nil end end

    lastMoney = GetMoney()

    local function flag(open, close, key)
        ns.RegisterEvent(open, function() ctx[key] = true end)
        ns.RegisterEvent(close, function() ctx[key] = false end)
    end
    flag("MERCHANT_SHOW", "MERCHANT_CLOSED", "merchant")
    flag("AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED", "ah")
    flag("MAIL_SHOW", "MAIL_CLOSED", "mail")
    flag("TRAINER_SHOW", "TRAINER_CLOSED", "trainer")
    flag("TRADE_SHOW", "TRADE_CLOSED", "trade")
    flag("LOOT_OPENED", "LOOT_CLOSED", "loot")
    flag("TAXIMAP_OPENED", "TAXIMAP_CLOSED", "taxi")
    ns.RegisterEvent("TAXIMAP_CLOSED", function() pending.taxiAt = now() end)
    ns.RegisterEvent("CHAT_MSG_MONEY", function() pending.lootAt = now() end)
    ns.RegisterEvent("QUEST_TURNED_IN", function(_, _, _, money)
        if money and money > 0 then pending.quest = pending.quest + money end
    end)
    if RepairAllItems then
        hooksecurefunc("RepairAllItems", function(guildBank)
            pending.repairAt = now()
            if guildBank and visit then visit.guild = visit.guild + repairCost end
            C_Timer.After(0.5, noteRepairCost)
        end)
    end
    ns.RegisterEvent("MERCHANT_SHOW", function()
        if not visit then visit = { sold = 0, repair = 0, guild = 0, buy = 0 } end
        noteRepairCost()
    end)
    ns.RegisterEvent("UPDATE_INVENTORY_DURABILITY", noteRepairCost)
    ns.RegisterEvent("MERCHANT_CLOSED", function()
        -- Geld kommt manchmal erst nach dem Schließen an
        if visit and not visit.closing then
            visit.closing = true
            C_Timer.After(0.6, visitReport)
        end
    end)
    if TakeInboxMoney then
        hooksecurefunc("TakeInboxMoney", function(index)
            local cat = "mail"
            local ok, invoiceType = pcall(GetInboxInvoiceInfo, index)
            if ok and invoiceType == "seller" then cat = "ah" end
            pending.mailCat, pending.mailAt = cat, now()
        end)
    end
    ns.RegisterEvent("PLAYER_MONEY", onMoney)
end
