-- Mondhain – Infos auf der linken Tafel
--   Haltbarkeit   → Maus drüber: je Gegenstand + Reparatur · Klick öffnet Charakterfenster
--   Gilde online  → Maus drüber: wer, Stufe, Zone · Klick öffnet Gildenfenster
--   Gold          → Maus drüber: Gewinn/Verlust dieser Sitzung · Klick öffnet Kontobuch
--   Taschenplätze → Klick öffnet Taschen
-- (In den Tooltips selbst steht kein „Klick: …“ – die Zeilen erklären sich beim Klicken.)
-- Fenster werden direkt über Blizzards Umschalt-Funktionen geöffnet (wie ElvUI);
-- Charakter und Gilde nicht im Kampf.

local _, ns = ...
local mod = ns.NewModule("InfoBoard")

local ROW_H = 26
local rows = {}

local function firstFrame(...)
    for i = 1, select("#", ...) do
        local f = _G[select(i, ...)]
        if f then return f end
    end
end

local function try(...)
    for i = 1, select("#", ...) do
        local fn = select(i, ...)
        if fn and pcall(fn) then return true end
    end
end

local function noCombat()
    if InCombatLockdown() then
        ns.Print("Im Kampf geht das nicht.")
        return false
    end
    return true
end

local function openCharacter()
    if not noCombat() then return end
    try(_G.ToggleCharacter and function() ToggleCharacter("PaperDollFrame") end,
        _G.CharacterMicroButton and function() CharacterMicroButton:Click() end)
end

local function openGuild()
    if not noCombat() then return end
    try(_G.ToggleGuildFrame and function() ToggleGuildFrame() end,
        _G.ToggleCommunitiesFrame and function() ToggleCommunitiesFrame() end,
        _G.ToggleFriendsFrame and function() ToggleFriendsFrame(3) end)
end

local function openBags()
    try(_G.ToggleAllBags and function() ToggleAllBags() end,
        _G.OpenAllBags and function() OpenAllBags() end)
end

local function makeRow(board, i, icon, action)
    local r = CreateFrame("Button", nil, board)
    r:SetHeight(ROW_H)
    r:SetPoint("TOPLEFT", board, "TOPLEFT", 10, -30 - (i - 1) * (ROW_H + 4))
    r:SetPoint("TOPRIGHT", board, "TOPRIGHT", -10, -30 - (i - 1) * (ROW_H + 4))
    r:RegisterForClicks("LeftButtonUp")
    if action then r:SetScript("OnClick", action) end
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(ROW_H - 4, ROW_H - 4)
    r.icon:SetPoint("LEFT", 0, 0)
    r.icon:SetTexture(icon)
    r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.text:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
    r.text:SetPoint("RIGHT", 0, 0)
    r.text:SetJustifyH("LEFT")
    r.text:SetWordWrap(false)
    local hl = r:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 0.82, 0.4, 0.08)
    r:SetScript("OnLeave", GameTooltip_Hide)
    return r
end

---------------------------------------------------------------------------
-- Werte
---------------------------------------------------------------------------
local function durability()
    local low
    for slot = 1, 18 do
        local cur, max = GetInventoryItemDurability(slot)
        if cur and max and max > 0 then
            local p = cur / max
            if not low or p < low then low = p end
        end
    end
    return low
end

local function updateDurability()
    local r = rows.dura
    if not r then return end
    local p = durability()
    if not p then r.text:SetText("Haltbarkeit |cff888888–|r") return end
    local pct = math.floor(p * 100 + 0.5)
    local c = pct > 50 and "59e659" or (pct > 25 and "ffd100" or "ff5555")
    r.text:SetText(("Haltbarkeit |cff%s%d %%|r"):format(c, pct))
end

local function updateGuild()
    local r = rows.guild
    if not r then return end
    if not IsInGuild() then r.text:SetText("|cff888888Keine Gilde|r") return end
    local total, online = GetNumGuildMembers()
    r.text:SetText(("Gilde |cff59e659%d|r online"):format(online or 0))
end

local function updateGold()
    local r = rows.gold
    if not r then return end
    r.text:SetText(ns.Ledger and ns.Ledger.Coins(GetMoney()) or GetMoney())
end

local function freeSlots()
    local free, total = 0, 0
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        local n = C_Container.GetContainerNumSlots(bag) or 0
        local f = C_Container.GetContainerNumFreeSlots(bag) or 0
        free, total = free + f, total + n
    end
    return free, total
end

local function updateBags()
    local r = rows.bags
    if not r then return end
    local free, total = freeSlots()
    local c = free > 5 and "59e659" or (free > 0 and "ffd100" or "ff5555")
    r.text:SetText(("Taschen |cff%s%d|r frei / %d"):format(c, free, total))
end

---------------------------------------------------------------------------
-- Tooltips
---------------------------------------------------------------------------
local function guildTooltip(self)
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
    GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT")
    if not IsInGuild() then
        GameTooltip:AddLine("Keine Gilde", 1, 1, 1)
        GameTooltip:Show()
        return
    end
    GameTooltip:AddLine(GetGuildInfo("player") or "Gilde", 1, 0.82, 0)
    local total = GetNumGuildMembers()
    local shown = 0
    for i = 1, total or 0 do
        local name, rank, _, level, _, zone, _, _, online, _, class = GetGuildRosterInfo(i)
        if online and name then
            shown = shown + 1
            if shown <= 25 then
                local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
                local short = name:match("^[^-]+") or name
                GameTooltip:AddDoubleLine(("%s |cff888888%s|r"):format(short, level or ""), zone or "",
                    c and c.r or 1, c and c.g or 1, c and c.b or 1, 0.8, 0.8, 0.8)
            end
        end
    end
    if shown > 25 then GameTooltip:AddLine(("… und %d weitere"):format(shown - 25), 0.6, 0.6, 0.6) end
    GameTooltip:Show()
end

local function goldTooltip(self)
    GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT")
    GameTooltip:AddLine("Gold", 1, 0.82, 0)
    if ns.Ledger then
        local net = ns.Ledger:SessionNet()
        local coins = ns.Ledger.Coins
        if net >= 0 then
            GameTooltip:AddLine("Diese Sitzung: |cff59e659+" .. coins(net) .. "|r", 1, 1, 1)
        else
            GameTooltip:AddLine("Diese Sitzung: |cffff5555-" .. coins(net) .. "|r", 1, 1, 1)
        end
    end
    GameTooltip:Show()
end

-- Haltbarkeit je Gegenstand (schlechteste zuerst), dazu geschätzte Reparaturkosten
local DURA_SLOTS = {
    { 1, "HEADSLOT" }, { 3, "SHOULDERSLOT" }, { 5, "CHESTSLOT" }, { 9, "WRISTSLOT" }, { 10, "HANDSSLOT" },
    { 6, "WAISTSLOT" }, { 7, "LEGSSLOT" }, { 8, "FEETSLOT" }, { 16, "MAINHANDSLOT" }, { 17, "SECONDARYHANDSLOT" },
    { 18, "RANGEDSLOT" },
}
local repairTip
local function repairCost(slot)
    if C_TooltipInfo and C_TooltipInfo.GetInventoryItem then
        local d = C_TooltipInfo.GetInventoryItem("player", slot)
        if d and d.repairCost and not ns.isSecret(d.repairCost) then return d.repairCost end
    end
    if not repairTip then
        repairTip = CreateFrame("GameTooltip", "MondhainRepairScan", UIParent, "GameTooltipTemplate")
    end
    repairTip:SetOwner(UIParent, "ANCHOR_NONE")
    local ok, _, _, cost = pcall(repairTip.SetInventoryItem, repairTip, "player", slot)
    repairTip:Hide()
    if ok and type(cost) == "number" then return cost end
end

local function durabilityTooltip(self)
    GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT")
    GameTooltip:AddLine("Haltbarkeit", 1, 0.82, 0)
    local list, total = {}, 0
    for _, s in ipairs(DURA_SLOTS) do
        local slot = s[1]
        local cur, max = GetInventoryItemDurability(slot)
        if cur and max and max > 0 then
            local link = GetInventoryItemLink("player", slot)
            local name = link and (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(link)) or nil
            if not name and link then name = link:match("%[(.-)%]") end
            local q = link and ((C_Item and C_Item.GetItemQualityByID and C_Item.GetItemQualityByID(link)) or 1) or 1
            list[#list + 1] = { p = cur / max, cur = cur, max = max, name = name or (_G[s[2]] or "?"),
                slotName = _G[s[2]] or "", q = q }
            total = total + (repairCost(slot) or 0)
        end
    end
    if #list == 0 then
        GameTooltip:AddLine("Nichts mit Haltbarkeit angelegt.", 0.7, 0.7, 0.7)
    else
        table.sort(list, function(a, b) return a.p < b.p end)
        for _, e in ipairs(list) do
            local pct = math.floor(e.p * 100 + 0.5)
            local r, g, b = 0.35, 0.9, 0.35
            if pct <= 25 then r, g, b = 1, 0.33, 0.33 elseif pct <= 50 then r, g, b = 1, 0.82, 0 end
            local qc = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[e.q]
            local nameText = qc and (qc.hex .. e.name .. "|r") or e.name
            GameTooltip:AddDoubleLine(nameText .. "  |cff888888" .. e.slotName .. "|r",
                ("%d %%  |cff888888%d/%d|r"):format(pct, e.cur, e.max), 1, 1, 1, r, g, b)
        end
        if total > 0 then
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine("Reparatur etwa", ns.CoinString(total), 0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
    GameTooltip:Show()
end

---------------------------------------------------------------------------
-- Aufbau
---------------------------------------------------------------------------
local function build()
    local board = ns.Boards and ns.Boards.left
    if not board then return end
    if board.hint then board.hint:Hide() end
    if board.title then board.title:SetText("Hain-Tafel") end

    rows.dura = makeRow(board, 1, "Interface\\Icons\\Trade_BlackSmithing", openCharacter)
    rows.dura:SetScript("OnEnter", durabilityTooltip)
    rows.guild = makeRow(board, 2, "Interface\\Icons\\INV_Shirt_GuildTabard_01", openGuild)
    rows.guild:SetScript("OnEnter", guildTooltip)
    rows.gold = makeRow(board, 3, "Interface\\Icons\\INV_Misc_Coin_01",
        function() if ns.Ledger then ns.Ledger:Toggle() end end)
    rows.gold:SetScript("OnEnter", goldTooltip)
    rows.bags = makeRow(board, 4, "Interface\\Icons\\INV_Misc_Bag_08", openBags)

    updateDurability(); updateGuild(); updateGold(); updateBags()
    ns.RegisterEvent("UPDATE_INVENTORY_DURABILITY", updateDurability)
    ns.RegisterEvent("PLAYER_EQUIPMENT_CHANGED", updateDurability)
    ns.RegisterEvent("GUILD_ROSTER_UPDATE", updateGuild)
    ns.RegisterEvent("PLAYER_GUILD_UPDATE", updateGuild)
    ns.RegisterEvent("PLAYER_MONEY", updateGold)
    ns.RegisterEvent("BAG_UPDATE_DELAYED", updateBags)
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
end

function mod:OnEnable()
    if not ns.db.minimapFrame.boards then return end
    C_Timer.After(0.5, build)
end
