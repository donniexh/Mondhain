-- Mondhain – Gestaltleiste
-- Eigene Tasten für die Druidengestalten (Bär, Katze, Reise, Wasser, Mondkin …).
-- Die aktive Gestalt leuchtet in ihrer Farbe – damit ersetzt die Leiste
-- den alten Gestalt-Balken.
--
-- Tastenbelegung: übernimmt Blizzards „Gestaltleiste“-Tasten (SHAPESHIFTBUTTON1 …).
-- Neue Gestalten (gelernt) werden außerhalb des Kampfes nachgetragen.

local _, ns = ...
local mod = ns.NewModule("StanceBar")
ns.StanceBar = mod

local SIZE, GAP, MAX = 30, 4, 10
local db, bar
local buttons = {}
local bindOwner = CreateFrame("Frame")
local pendingBuild = false
local shownCount = 0

local function isSecret(v) return ns.isSecret(v) end

---------------------------------------------------------------------------
-- Anzeige
---------------------------------------------------------------------------
local function activeIndex()
    local ok, idx = pcall(GetShapeshiftForm)
    if ok and idx and not isSecret(idx) then return idx end
end

local function updateButton(b)
    local i = b.index
    local ok, icon, active, castable, spellID = pcall(GetShapeshiftFormInfo, i)
    if not ok then return end
    if icon then b.icon:SetTexture(icon) end

    -- Nutzbar? (grau, wenn nicht)
    if isSecret(castable) or castable or castable == nil then
        b.icon:SetDesaturated(false)
        b.icon:SetVertexColor(1, 1, 1)
    else
        b.icon:SetDesaturated(true)
        b.icon:SetVertexColor(0.6, 0.6, 0.6)
    end

    -- Abklingzeit über Dauer-Objekt (Midnight-tauglich), sonst klassisch
    local id = b.spellID
    local done = false
    if id and C_Spell and C_Spell.GetSpellCooldownDuration then
        local ok2, d = pcall(C_Spell.GetSpellCooldownDuration, id)
        if ok2 and d then
            pcall(b.cooldown.SetCooldownFromDurationObject, b.cooldown, d, true)
            done = true
        end
    end
    if not done then
        local ok3, start, dur = pcall(GetShapeshiftFormCooldown, i)
        if ok3 and start then
            pcall(b.cooldown.SetCooldown, b.cooldown, start, dur)
        else
            b.cooldown:Clear()
        end
    end
end

-- Aktive Gestalt: Rahmen in Gestaltfarbe, Rest dunkles Holz
local function paintActive()
    local idx = activeIndex()
    local r, g, bl = ns.GetFormColor()
    for _, b in ipairs(buttons) do
        if b:IsShown() and idx and b.index == idx then
            b.border:SetColorTexture(r, g, bl, 1)
            b.glow:SetVertexColor(r, g, bl, 0.35)
            b.glow:Show()
        else
            b.border:SetColorTexture(unpack(ns.colors.border))
            b.glow:Hide()
        end
    end
end

local function updateAll()
    for _, b in ipairs(buttons) do
        if b:IsShown() then updateButton(b) end
    end
    paintActive()
end

---------------------------------------------------------------------------
-- Tastenbelegung
---------------------------------------------------------------------------
local function setHotkey(b)
    local key = GetBindingKey("SHAPESHIFTBUTTON" .. b.index)
    if key and ns.ShowHotKeys() then
        b.HotKey:SetText(ns.ShortKey(key))
        b.HotKey:Show()
    else
        b.HotKey:SetText("")
        b.HotKey:Hide()
    end
end

local function applyBindings()
    if InCombatLockdown() then return end
    ClearOverrideBindings(bindOwner)
    for _, b in ipairs(buttons) do
        if b:IsShown() then
            for _, key in ipairs({ GetBindingKey("SHAPESHIFTBUTTON" .. b.index) }) do
                SetOverrideBindingClick(bindOwner, false, key, b:GetName(), "LeftButton")
            end
        end
        setHotkey(b)
    end
end

---------------------------------------------------------------------------
-- Aufbau
---------------------------------------------------------------------------
local function createButton(i)
    local b = CreateFrame("CheckButton", "MondhainStanceButton" .. i, bar, "SecureActionButtonTemplate")
    ns.SkinButton(b, SIZE)
    b.index = i
    b.commandName = "SHAPESHIFTBUTTON" .. i
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("useOnKeyDown", GetCVarBool("ActionButtonUseKeyDown"))
    b:SetAttribute("type", "spell")

    -- Schimmer der aktiven Gestalt
    b.glow = b:CreateTexture(nil, "OVERLAY")
    b.glow:SetTexture("Interface\\Buttons\\WHITE8x8")
    b.glow:SetPoint("TOPLEFT", b.icon, "TOPLEFT")
    b.glow:SetPoint("BOTTOMRIGHT", b.icon, "BOTTOMRIGHT")
    b.glow:SetBlendMode("ADD")
    b.glow:Hide()

    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        if not pcall(GameTooltip.SetShapeshift, GameTooltip, self.index) then
            GameTooltip:AddLine(self.spellName or "Gestalt", 1, 1, 1)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    b:Hide()
    buttons[i] = b
    return b
end

-- Anzahl Gestalten, abgesichert (geheime oder fehlende Werte → 0)
local function formCount()
    if not GetNumShapeshiftForms then return 0 end
    local ok, n = pcall(GetNumShapeshiftForms)
    if not ok or isSecret(n) or type(n) ~= "number" then return 0 end
    return math.min(n, MAX)
end

-- Tasten passend zu den gelernten Gestalten anlegen (nur außerhalb des Kampfes)
local function build()
    if InCombatLockdown() then
        pendingBuild = true
        return
    end
    pendingBuild = false
    local n = formCount()
    shownCount = n
    for i = 1, MAX do
        local b = buttons[i]
        if i <= n then
            b = b or createButton(i)
            local okInfo, _, _, _, spellID = pcall(GetShapeshiftFormInfo, i)
            if not okInfo or isSecret(spellID) then spellID = nil end
            local name
            if spellID and C_Spell and C_Spell.GetSpellName then
                local okName, n2 = pcall(C_Spell.GetSpellName, spellID)
                if okName and not isSecret(n2) then name = n2 end
            elseif spellID and GetSpellInfo then
                name = GetSpellInfo(spellID)
            end
            b.spellID = spellID
            b.spellName = name
            if name or spellID then
                b:SetAttribute("type", "spell")
                b:SetAttribute("spell", name or spellID)
            else
                -- Notweg: Blizzards eigener Gestaltknopf übernimmt den Klick
                b:SetAttribute("type", "click")
                b:SetAttribute("clickbutton", _G["StanceButton" .. i])
            end
            b:ClearAllPoints()
            b:SetPoint("LEFT", bar, "LEFT", (i - 1) * (SIZE + GAP), 0)
            b:Show()
        elseif b then
            b:Hide()
        end
    end
    bar:SetSize(math.max(n, 1) * (SIZE + GAP) - GAP, SIZE)
    bar:SetShown(n > 0)
    applyBindings()
    updateAll()
end

---------------------------------------------------------------------------
-- Blizzards Gestaltleiste verstecken
---------------------------------------------------------------------------
local hider
local function hideBlizzard()
    if InCombatLockdown() then return end
    hider = hider or CreateFrame("Frame")
    hider:Hide()
    for _, n in ipairs({ "StanceBar", "StanceBarFrame" }) do
        local f = _G[n]
        if f and f.SetParent and f:GetParent() ~= hider then
            f:SetParent(hider)
            if not f.mondhainHooked then
                f.mondhainHooked = true
                hooksecurefunc(f, "SetParent", function(self, parent)
                    if parent ~= hider and not self.mondhainBusy and not InCombatLockdown() then
                        self.mondhainBusy = true
                        self:SetParent(hider)
                        self.mondhainBusy = false
                    end
                end)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Test: /mh gestalten
---------------------------------------------------------------------------
-- Für den Belegungsmodus
function mod:GetBindButtons()
    local out = {}
    for _, b in ipairs(buttons) do
        if b:IsShown() then
            b.bindLabel = b.spellName or ("Gestalt " .. b.index)
            out[#out + 1] = b
        end
    end
    return out
end

-- zurück an ihren Platz in der rechten Tafel (Optionen, /mh gestalten tafel)
function mod:BackToBoard()
    if not db then return end
    if InCombatLockdown() then ns.Print("Im Kampf nicht möglich.") return end
    db.inBoard = true
    if bar then bar.mhMoving = nil end
    if self.FitBoard then self.FitBoard() end
    ns.Print("Gestaltleiste: " .. (self.where or "zurück an ihrem Platz"))
end

function mod:Debug()
    ns.Print(("Gestaltleiste: Platz %s · in der Tafel %s · rechte Tafel %s"):format(tostring(self.where or "eigener Platz"),
        tostring(db and db.inBoard), (ns.Boards and ns.Boards.right) and "da" or "|cffff5555fehlt|r"))
    local n = GetNumShapeshiftForms and GetNumShapeshiftForms()
    ns.Print(("Gestaltleiste: %s · gefundene Gestalten: %s · Tasten sichtbar: %d"):format(
        bar and (bar:IsShown() and "da" or "versteckt") or "|cffff5555nicht gebaut|r",
        tostring(n), shownCount))
    for i = 1, (tonumber(n) or 0) do
        local ok, icon, active, castable, spellID = pcall(GetShapeshiftFormInfo, i)
        print(("   %d: ok=%s Zauber=%s aktiv=%s nutzbar=%s"):format(i, tostring(ok),
            tostring(spellID), tostring(active), tostring(castable)))
    end
    if bar then
        local p, _, rp, x, y = bar:GetPoint()
        print(("   Lage: %s → %s  %d / %d  ·  Größe %d x %d"):format(tostring(p), tostring(rp),
            x or 0, y or 0, bar:GetWidth(), bar:GetHeight()))
    end
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.stanceBar
    if not db.enabled then return end

    bar = CreateFrame("Frame", "MondhainStanceBar", UIParent)
    bar:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    bar:SetSize(SIZE, SIZE)
    -- Ben 26.11. „Haltungsleiste verschwunden“: immer über Tafel und Questliste
    bar:SetFrameStrata("MEDIUM")
    bar:SetFrameLevel(40)

    build()
    ns.MakeMovable(bar, db, "Gestaltleiste", function() db.inBoard = false end)
    -- in der rechten Tafel: unten mittig, so groß wie die Tafel es zulässt
    -- Ben 26.11.: saß bei Steve mitten in den Leisten, beim Druiden „verschwunden“
    -- (lag hinter dem Leistengrund) – die Tafel-Anpassung lief nicht immer an.
    -- Jetzt: immer prüfen; ohne rechte Tafel mittig über den Leisten.
    local function fitBoard()
        if not db.inBoard or InCombatLockdown() or bar.mhMoving then return end
        local right = ns.Boards and ns.Boards.right
        local k = UIParent:GetEffectiveScale()
        local bw = right and (right:GetWidth() or 0) * right:GetEffectiveScale() / k or 0
        local w = bar:GetWidth() or 0
        if w <= 0 then return end
        if not right or bw <= 0 or not right:IsShown() then
            local plate = _G.MondhainCenterPlate
            local ref = (plate and plate:IsShown()) and plate or _G.MondhainBars_center
            if ref and ref:GetTop() then
                if math.abs(bar:GetScale() - 1) > 0.01 then bar:SetScale(1) end
                bar:ClearAllPoints()
                bar:SetPoint("BOTTOM", ref, "TOP", 0, 6)
                mod.where = "über den Leisten (keine rechte Tafel)"
            end
            return
        end
        local s = math.max(0.6, math.min(1.6, (bw - 24) / w))
        if math.abs(bar:GetScale() - s) > 0.01 then bar:SetScale(s) end
        bar:ClearAllPoints()
        bar:SetPoint("BOTTOM", right, "BOTTOM", 0, 14 / s)
        if bar:GetFrameLevel() <= right:GetFrameLevel() then bar:SetFrameLevel(right:GetFrameLevel() + 20) end
        mod.where = "rechte Tafel, unten mittig"
    end
    mod.FitBoard = fitBoard
    C_Timer.After(0.7, fitBoard)
    C_Timer.NewTicker(2, fitBoard)

    hideBlizzard()
    C_Timer.After(1, hideBlizzard)
    -- Gestalten kommen beim Einloggen manchmal erst spät: nachfassen, und
    -- alle 3 s prüfen, ob die Zahl noch stimmt (kostet nichts)
    C_Timer.After(2, function() if formCount() ~= shownCount then build() end end)
    C_Timer.After(6, function() if formCount() ~= shownCount then build() end end)
    C_Timer.NewTicker(3, function()
        if not InCombatLockdown() and formCount() ~= shownCount then build() end
    end)

    ns.On("FORM_CHANGED", paintActive)
    ns.RegisterEvent("UPDATE_SHAPESHIFT_FORMS", build)
    ns.RegisterEvent("SPELLS_CHANGED", function()
        if formCount() ~= shownCount then build() end
    end)
    ns.RegisterEvent("PLAYER_ENTERING_WORLD", build)
    ns.RegisterEvent("UPDATE_SHAPESHIFT_FORM", updateAll)
    ns.RegisterEvent("UPDATE_SHAPESHIFT_USABLE", updateAll)
    ns.RegisterEvent("UPDATE_SHAPESHIFT_COOLDOWN", updateAll)
    ns.RegisterEvent("SPELL_UPDATE_COOLDOWN", updateAll)
    ns.RegisterEvent("UPDATE_BINDINGS", applyBindings)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
        if pendingBuild then build() end
    end)
end
