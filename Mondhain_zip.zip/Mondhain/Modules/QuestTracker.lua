-- Mondhain – Questtracker (Variante B: Zeitungsspalten)
-- Unten rechts, 2 Spalten. Quests liegen paarweise in Zeilen nebeneinander
-- (1 links, 2 rechts, 3 links ...). Einklappen ändert nur die eigene Zeile,
-- nichts wechselt die Spalte. Mausrad schiebt um eine Zeile weiter.
--
-- Kopfzeile:  [Zone ▼]        [Lupe: Quest suchen]        [12 Quests]
--   Zone       → Menü: aktuelle Zone (automatisch) oder feste Zone
--   Suche      → durchsucht alle Quests im Questlog (Titel und Ziele)
--   Buch-Icon  → öffnet das komplette Questlog
-- Größe:     Anfasser unten rechts ziehen (Breite/Höhe, Spalten passen sich an)
-- Zoom:      Strg + Mausrad über dem Tracker (alles wird größer/kleiner)
--
-- Quest:  Linksklick  = auf der Karte zeigen und anpinnen
--         Rechtsklick = Menü (Karte, Questlog, verfolgen, Ziele klappen, teilen)
--         Mittelklick = verfolgen an/aus
--         [+]/[-]     = alle Ziele zeigen / auf ein Ziel einklappen

local _, ns = ...
local mod = ns.NewModule("QuestTracker")
ns.QuestTracker = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local FONT = STANDARD_TEXT_FONT
local COLS = 2          -- wird aus der Breite berechnet (1–3)
local COL_MIN_W = 300   -- ab dieser Spaltenbreite kommt eine weitere Spalte dazu
local COL_MIN_2 = 190   -- zwei Spalten schon ab dieser Breite (Ben 26.11.: auch bei 16:9 zwei Quests nebeneinander)
local PAD = 8

-- Werden in OnEnable aus der Schriftgröße berechnet
local FONT_SIZE, TITLE_H, OBJ_H, HEADER_H, CELL_W = 14, 18, 15, 28, 300

local db
local quests = {}
local offset, lastVisible = 0, 0
local searchText = ""
local f, zoneButton, zoneText, counterText, searchBox
local entries = {}
local seps = {}

---------------------------------------------------------------------------
-- Zonen
---------------------------------------------------------------------------
local function currentZone()
    local z = GetRealZoneText()
    if not z or z == "" then z = GetZoneText() end
    return z or ""
end

local function activeZone()
    if db.zone and db.zone ~= "" then return db.zone, true end
    return currentZone(), false
end

-- Alle Überschriften im Questlog mit Anzahl der Quests darunter
local function zoneList()
    local list, counts, header = {}, {}, nil
    for i = 1, C_QuestLog.GetNumQuestLogEntries() do
        local info = C_QuestLog.GetInfo(i)
        if info then
            if info.isHeader then
                header = info.title
                if header and not counts[header] then
                    counts[header] = 0
                    list[#list + 1] = header
                end
            elseif header and info.questID and not info.isHidden then
                counts[header] = counts[header] + 1
            end
        end
    end
    return list, counts
end

-- Quests, die auf der Karte der aktuellen Zone Ziele oder Abgaben haben
local function questsOnMap()
    local set = {}
    local mapID = C_Map.GetBestMapForUnit("player")
    if mapID and C_QuestLog.GetQuestsOnMap then
        local list = C_QuestLog.GetQuestsOnMap(mapID)
        if list then
            for _, q in ipairs(list) do
                if q.questID then set[q.questID] = true end
            end
        end
    end
    return set
end

local function matchesSearch(info, q)
    if info.title and info.title:lower():find(q, 1, true) then return true end
    local obj = C_QuestLog.GetQuestObjectives(info.questID)
    if obj then
        for _, o in ipairs(obj) do
            if o.text and o.text:lower():find(q, 1, true) then return true end
        end
    end
    return false
end

-- Suche aktiv: alle Quests im Log, die passen.
-- Sonst automatisch: Überschrift = aktuelle Zone ODER Ziel/Abgabe auf der Zonenkarte;
-- fest gewählt: nur die Quests unter dieser Überschrift.
local function collect()
    wipe(quests)
    local q = searchText:lower()
    local searching = q ~= ""
    local zone, pinned = activeZone()
    local onMap = (pinned or searching) and {} or questsOnMap()
    local inZone = false
    for i = 1, C_QuestLog.GetNumQuestLogEntries() do
        local info = C_QuestLog.GetInfo(i)
        if info then
            if info.isHeader then
                inZone = (info.title == zone)
            elseif info.questID and not info.isHidden then
                local take
                if searching then
                    take = matchesSearch(info, q)
                else
                    take = inZone or onMap[info.questID]
                end
                if take and db.hideDone and C_QuestLog.IsComplete(info.questID) then
                    take = false
                end
                if take then quests[#quests + 1] = info end
            end
        end
    end

    -- Sortieren: nach Level, dann Titel (oder unverändert wie im Questlog)
    if (db.sort or "level") ~= "log" then
        local function byLevel(list)
            for i, info in ipairs(list) do info._order = i end
            table.sort(list, function(a, b)
                if (a.level or 0) ~= (b.level or 0) then
                    return (a.level or 0) < (b.level or 0)
                end
                if a.title ~= b.title then
                    return (a.title or "") < (b.title or "")
                end
                return a._order < b._order
            end)
        end
        byLevel(quests)
    end
end

local function levelColor(level)
    if GetQuestDifficultyColor and level then
        local c = GetQuestDifficultyColor(level)
        if c then return c.r, c.g, c.b end
    end
    return 1, 0.82, 0
end

local function colorHex(r, g, b)
    return ("%02x%02x%02x"):format(math.floor(r * 255), math.floor(g * 255), math.floor(b * 255))
end

local function isTracked(id)
    return C_SuperTrack and C_SuperTrack.GetSuperTrackedQuestID
        and C_SuperTrack.GetSuperTrackedQuestID() == id
end

---------------------------------------------------------------------------
-- Aktionen
---------------------------------------------------------------------------
-- Hinweis: Mondhain öffnet Karte und Questlog NICHT selbst. Seit den
-- Midnight-Regeln „verschmutzt“ das Blizzards Fensterverwaltung, und später
-- werfen andere Fenster (z. B. das Zauberbuch) Fehler. Stattdessen wird die
-- Quest angepinnt (Pfeil + Wegpunkt); die Karte öffnet man mit M.
local function pinQuest(id)
    if C_SuperTrack and C_SuperTrack.SetSuperTrackedQuestID then
        C_SuperTrack.SetSuperTrackedQuestID(id)
    end
    mod:Refresh()
end

local function toggleTrack(id)
    if not (C_SuperTrack and C_SuperTrack.SetSuperTrackedQuestID) then return end
    C_SuperTrack.SetSuperTrackedQuestID(isTracked(id) and 0 or id)
    mod:Refresh()
end

local function toggleCollapse(id)
    db.collapsed[id] = (not db.collapsed[id]) or nil
    mod:Refresh()
end

local function openQuestMenu(owner, id)
    if not (MenuUtil and MenuUtil.CreateContextMenu) then
        toggleCollapse(id)
        return
    end
    local obj = C_QuestLog.GetQuestObjectives(id) or {}
    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle(C_QuestLog.GetTitleForQuestID(id) or "Quest")
        root:CreateButton(isTracked(id) and "Nicht mehr verfolgen" or "Verfolgen",
            function() toggleTrack(id) end)
        if #obj > 1 and not C_QuestLog.IsComplete(id) then
            root:CreateButton(db.collapsed[id] and "Alle Ziele zeigen" or "Ziele einklappen",
                function() toggleCollapse(id) end)
        end
        root:CreateDivider()
        local share = root:CreateButton("Mit Gruppe teilen", function()
            C_QuestLog.SetSelectedQuest(id)
            QuestLogPushQuest()
        end)
        local canShare = IsInGroup() and (not C_QuestLog.IsPushableQuest or C_QuestLog.IsPushableQuest(id))
        if not canShare and share and share.SetEnabled then pcall(share.SetEnabled, share, false) end
        root:CreateButton("|cffff6060Quest abbrechen|r", function() mod:ConfirmAbandon(id) end)
    end)
end

-- Eigene Rückfrage vor dem Abbrechen (statt Blizzards Fenster)
local confirm
function mod:ConfirmAbandon(id)
    if not confirm then
        confirm = CreateFrame("Frame", "MondhainAbandonConfirm", UIParent, "BackdropTemplate")
        confirm:SetSize(340, 104)
        confirm:SetPoint("CENTER", 0, 120)
        confirm:SetFrameStrata("DIALOG")
        confirm:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
        confirm:SetBackdropColor(0.04, 0.05, 0.05, 0.96)
        confirm:SetBackdropBorderColor(0, 0, 0, 0)
        ns.WoodFrame(confirm, 22)
        confirm.text = confirm:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        confirm.text:SetPoint("TOP", 0, -18)
        confirm.text:SetWidth(300)
        local yes = CreateFrame("Button", nil, confirm, "UIPanelButtonTemplate")
        yes:SetSize(120, 24); yes:SetPoint("BOTTOMLEFT", 40, 16); yes:SetText("Abbrechen")
        local no = CreateFrame("Button", nil, confirm, "UIPanelButtonTemplate")
        no:SetSize(120, 24); no:SetPoint("BOTTOMRIGHT", -40, 16); no:SetText("Behalten")
        no:SetScript("OnClick", function() confirm:Hide() end)
        yes:SetScript("OnClick", function()
            local qid = confirm.questID
            confirm:Hide()
            if not qid then return end
            C_QuestLog.SetSelectedQuest(qid)
            if C_QuestLog.SetAbandonQuest then C_QuestLog.SetAbandonQuest() end
            if C_QuestLog.AbandonQuest then C_QuestLog.AbandonQuest() end
        end)
        tinsert(UISpecialFrames, "MondhainAbandonConfirm")
    end
    confirm.questID = id
    confirm.text:SetText(("Quest wirklich abbrechen?\n|cffffd100%s|r"):format(C_QuestLog.GetTitleForQuestID(id) or "?"))
    confirm:Show()
end

local function openZoneMenu(owner)
    local list, counts = zoneList()
    local function setZone(name)
        db.zone = name
        offset = 0
        mod:Refresh()
    end
    if not (MenuUtil and MenuUtil.CreateContextMenu) then
        -- Notlösung ohne Menü: bei jedem Klick eine Zone weiter
        local nextZone
        if not db.zone then
            nextZone = list[1]
        else
            for i, name in ipairs(list) do
                if name == db.zone then nextZone = list[i + 1] end
            end
        end
        setZone(nextZone)
        return
    end
    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle("Quests anzeigen für")
        root:CreateRadio("Aktuelle Zone (automatisch)",
            function() return not db.zone end,
            function() setZone(nil) end)
        root:CreateDivider()
        for _, name in ipairs(list) do
            if counts[name] > 0 then
                root:CreateRadio(("%s |cff888888(%d)|r"):format(name, counts[name]),
                    function() return db.zone == name end,
                    function() setZone(name) end)
            end
        end
        root:CreateDivider()
        root:CreateCheckbox("Abgeschlossene Quests ausblenden",
            function() return db.hideDone end,
            function() db.hideDone = not db.hideDone; offset = 0; mod:Refresh() end)
        root:CreateCheckbox("Position und Größe sperren",
            function() return db.posLocked end,
            function() db.posLocked = not db.posLocked; mod:UpdateLock() end)
        root:CreateDivider()
        root:CreateTitle("Sortieren nach")
        local function sortRadio(label, key)
            root:CreateRadio(label,
                function() return (db.sort or "level") == key end,
                function() db.sort = key; offset = 0; mod:Refresh() end)
        end
        sortRadio("Level", "level")
        sortRadio("Wie im Questlog", "log")
    end)
end

---------------------------------------------------------------------------
-- Direkt verschieben: Tracker an einer freien Stelle oder an einer Quest
-- anfassen und ziehen (ein kurzer Klick bleibt ein Klick)
---------------------------------------------------------------------------
local function dragStart()
    if db.posLocked or InCombatLockdown() then return end
    GameTooltip:Hide()
    f:StartMoving()
end

local function dragStop()
    f:StopMovingOrSizing()
    local p, _, rp, x, y = f:GetPoint()
    db.point = { p, "UIParent", rp, x, y }
end

---------------------------------------------------------------------------
-- Einträge (werden bei Bedarf angelegt und wiederverwendet)
---------------------------------------------------------------------------
local scroll -- weiter unten definiert

-- Abgabe-Hinweis aus dem Questlog („Sprecht mit … in …“)
local function completionText(id)
    if not GetQuestLogCompletionText then return nil end
    local idx = C_QuestLog.GetLogIndexForQuestID(id)
    if not idx then return nil end
    local ok, t = pcall(GetQuestLogCompletionText, idx)
    if ok and t and t ~= "" then return t end
end

-- Wer aus der Gruppe hat die Quest auch? (Fortschritt der anderen ist ohne
-- Addon bei ihnen nicht abrufbar, nur ob sie die Quest haben.)
local function groupNames(id)
    if not (IsInGroup() and C_QuestLog.IsUnitOnQuest) then return nil end
    local names = {}
    local ok = pcall(function()
        local prefix, num = "party", GetNumSubgroupMembers()
        if IsInRaid() then prefix, num = "raid", GetNumGroupMembers() end
        for i = 1, num do
            local unit = prefix .. i
            if UnitExists(unit) and not UnitIsUnit(unit, "player")
                and C_QuestLog.IsUnitOnQuest(unit, id) then
                names[#names + 1] = UnitName(unit)
            end
        end
    end)
    if ok and #names > 0 then return table.concat(names, ", ") end
end

local function questTooltip(owner, id)
    GameTooltip:SetOwner(owner, "ANCHOR_TOPLEFT")
    GameTooltip:AddLine(C_QuestLog.GetTitleForQuestID(id) or "", 1, 0.82, 0)
    if C_QuestLog.IsComplete(id) then
        GameTooltip:AddLine(completionText(id) or "Bereit zur Abgabe", 0.35, 0.90, 0.35, true)
    else
        local obj = C_QuestLog.GetQuestObjectives(id)
        if obj then
            for _, o in ipairs(obj) do
                if o.finished then
                    GameTooltip:AddLine("- " .. (o.text or ""), 0.5, 0.5, 0.5)
                else
                    GameTooltip:AddLine("- " .. (o.text or ""), 1, 1, 1)
                end
            end
        end
    end
    local group = groupNames(id)
    if group then
        GameTooltip:AddLine(" ")
        pcall(GameTooltip.AddLine, GameTooltip, "Auch in deiner Gruppe: " .. group, 0.55, 0.75, 1, true)
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Linksklick: auf der Karte zeigen", 0.6, 0.6, 0.6)
    GameTooltip:AddLine("Rechtsklick: Menü (teilen, abbrechen …)  ·  Mittelklick: anpinnen", 0.6, 0.6, 0.6)
    GameTooltip:Show()
end

local function entryOnEnter(self)
    if self.questID then questTooltip(self, self.questID) end
end

-- Linksklick öffnet die Karte direkt bei dieser Quest (der sichere Klick auf
-- Blizzards Mikroknopf kam nicht an – der Knopf liegt versteckt im Mikromenü)
local function openMapTo(id)
    if InCombatLockdown() then
        ns.Print("Im Kampf öffnet sich die Karte nicht über den Tracker – nimm M.")
        return
    end
    C_QuestLog.SetSelectedQuest(id)
    local function try(fn, ...)
        if type(fn) ~= "function" then return false end
        return pcall(fn, ...)
    end
    if try(_G.QuestMapFrame_OpenToQuestDetails, id) then return end
    if _G.WorldMapFrame and not WorldMapFrame:IsShown() then
        if try(_G.ToggleWorldMap) then return end
        if try(_G.ShowUIPanel, WorldMapFrame) then return end
    end
    try(_G.QuestMapFrame_ShowQuestDetails, id)
end

local function entryPreClick(self, button)
    if button == "LeftButton" and self.questID then
        C_QuestLog.SetSelectedQuest(self.questID) -- Karte zeigt diese Quest
    end
end

local function entryPostClick(self, button)
    local id = self.questID
    if not id then return end
    if button == "RightButton" then
        openQuestMenu(self, id)
    elseif button == "MiddleButton" then
        toggleTrack(id)
    elseif button == "LeftButton" then
        openMapTo(id)
    end
end

local function getEntry(i)
    if entries[i] then return entries[i] end

    local e = CreateFrame("Button", nil, f, "SecureActionButtonTemplate")
    e:SetWidth(CELL_W)
    e:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")

    local hl = e:CreateTexture(nil, "HIGHLIGHT")
    hl:SetTexture(WHITE)
    hl:SetAllPoints()
    hl:SetVertexColor(ns.Accent(0.10))

    e.prog = e:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    e.prog:SetFont(FONT, FONT_SIZE - 1, "")
    e.prog:SetPoint("TOPRIGHT", -4, -3)
    e.prog:SetJustifyH("RIGHT")

    e.title = e:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    e.title:SetFont(FONT, FONT_SIZE, "")
    e.title:SetPoint("TOPLEFT", 4, -3)
    e.title:SetPoint("RIGHT", e.prog, "LEFT", -6, 0)
    e.title:SetHeight(TITLE_H)
    e.title:SetJustifyH("LEFT")
    e.title:SetWordWrap(false)

    e.lines = {}

    -- Kleiner Knopf [+]/[-] zum Auf- und Zuklappen der Ziele
    local t = CreateFrame("Button", nil, e, "BackdropTemplate")
    t:SetSize(16, 14)
    t:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    t:SetBackdropColor(0, 0, 0, 0.5)
    t:SetBackdropBorderColor(ns.Accent(0.6))
    t.text = t:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    t.text:SetFont(FONT, FONT_SIZE - 1, "")
    t.text:SetPoint("CENTER", 0, 1)
    t:SetScript("OnClick", function() if e.questID then toggleCollapse(e.questID) end end)
    t:SetScript("OnEnter", function(self)
        self:SetBackdropColor(ns.Accent(0.3))
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(db.collapsed[e.questID] and "Alle Ziele zeigen" or "Ziele einklappen", 1, 1, 1)
        GameTooltip:Show()
    end)
    t:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0, 0, 0, 0.5)
        GameTooltip:Hide()
    end)
    t:EnableMouseWheel(true)
    t:SetScript("OnMouseWheel", function(_, d) scroll(d) end)
    e.toggle = t

    e:SetScript("OnEnter", entryOnEnter)
    e:SetScript("OnLeave", GameTooltip_Hide)
    e:SetScript("PreClick", entryPreClick)
    e:SetScript("PostClick", entryPostClick)
    e:RegisterForDrag("LeftButton")
    e:SetScript("OnDragStart", dragStart)
    e:SetScript("OnDragStop", dragStop)
    e:EnableMouseWheel(true)
    e:SetScript("OnMouseWheel", function(_, d) scroll(d) end)

    entries[i] = e
    return e
end

local function getLine(e, j)
    if e.lines[j] then return e.lines[j] end
    local l = e:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    l:SetFont(FONT, FONT_SIZE - 2, "")
    l:SetPoint("TOPLEFT", e, "TOPLEFT", 16, -(3 + TITLE_H + (j - 1) * OBJ_H))
    l:SetPoint("RIGHT", e, "RIGHT", -24, 0)
    l:SetHeight(OBJ_H)
    l:SetJustifyH("LEFT")
    l:SetWordWrap(false)
    e.lines[j] = l
    return l
end

-- Füllt einen Eintrag und gibt seine Höhe zurück
local function fillEntry(e, info)
    local id = info.questID
    e.questID = id

    local r, g, b = levelColor(info.level)
    local mark = isTracked(id) and "|cffff7c0a»|r " or ""
    local party = ns.QuestPartyCount and ns.QuestPartyCount(id) or 0
    e.title:SetText(("%s|cff%s[%s]|r %s%s"):format(
        mark, colorHex(r, g, b), tostring(info.level or "?"), info.title or "?",
        party > 0 and (" |cff66ccff(+" .. party .. ")|r") or ""))

    local obj = C_QuestLog.GetQuestObjectives(id) or {}
    local texts = {}
    local canToggle = false

    if C_QuestLog.IsComplete(id) then
        e.prog:SetText("|cff59e659fertig|r")
        texts[1] = { "Bereit zur Abgabe", 0.35, 0.90, 0.35 }
    else
        local done, first = 0, nil
        for _, o in ipairs(obj) do
            if o.finished then done = done + 1 else first = first or o end
        end
        e.prog:SetText(#obj > 1 and (done .. "/" .. #obj) or "")
        canToggle = #obj > 1

        if canToggle and db.collapsed[id] then
            local text = first and first.text or ""
            texts[1] = { text .. ("  |cff888888(+%d weitere)|r"):format(#obj - 1), 0.78, 0.76, 0.70 }
        else
            for _, o in ipairs(obj) do
                if o.finished then
                    texts[#texts + 1] = { o.text or "", 0.45, 0.45, 0.45 }
                else
                    texts[#texts + 1] = { o.text or "", 0.78, 0.76, 0.70 }
                end
            end
        end
    end

    for j, t in ipairs(texts) do
        local l = getLine(e, j)
        l:SetText(t[1])
        l:SetTextColor(t[2], t[3], t[4])
        l:Show()
    end
    for j = #texts + 1, #e.lines do e.lines[j]:Hide() end

    e.toggle:SetShown(canToggle)
    if canToggle then
        e.toggle.text:SetText(db.collapsed[id] and "+" or "-")
        e.toggle:ClearAllPoints()
        e.toggle:SetPoint("RIGHT", e, "TOPRIGHT", -4, -(3 + TITLE_H + OBJ_H / 2))
    end

    local h = 3 + TITLE_H + #texts * OBJ_H + 5
    e:SetHeight(h)
    return h
end

---------------------------------------------------------------------------
-- Anzeige
---------------------------------------------------------------------------
local refreshAfterCombat = false
function mod:Refresh()
    if not f then return end
    if InCombatLockdown() then
        refreshAfterCombat = true
        return
    end
    refreshAfterCombat = false
    collect()

    -- Fest gewählte Zone hat keine Quests mehr → zurück auf automatisch
    if db.zone and #quests == 0 and searchText == "" and not db.hideDone then
        local _, counts = zoneList()
        if not counts[db.zone] or counts[db.zone] == 0 then
            db.zone = nil
            collect()
        end
    end

    local n = #quests
    if offset > n - 1 then offset = math.max(0, n - 1) end
    offset = offset - (offset % COLS) -- immer am Zeilenanfang

    -- Kopfzeile links
    if searchText ~= "" then
        zoneText:SetText("Alle Zonen |cff888888(Suche)|r")
    else
        local zone, pinned = activeZone()
        zoneText:SetText(zone .. (pinned and "  |cff888888(fixiert)|r" or ""))
    end
    local tw = zoneText.GetUnboundedStringWidth and zoneText:GetUnboundedStringWidth() or zoneText:GetStringWidth()
    zoneButton:SetWidth(math.min(tw + 30, f:GetWidth() / 2 - searchBox:GetWidth() / 2 - 12))

    -- Layout
    local availH = f:GetHeight() - HEADER_H - 4 - PAD
    local y, used = 0, 0
    for _, e in ipairs(entries) do
        e:Hide()
        e.questID = nil
    end
    lastVisible = offset

    if n == 0 then
        local e = getEntry(1)
        e.questID = nil
        local msg
        if searchText ~= "" then
            msg = "Keine Treffer"
        elseif db.hideDone then
            msg = "Keine offenen Quests"
        else
            msg = "Keine Quests in dieser Zone"
        end
        e.title:SetText("|cff888888" .. msg .. "|r")
        e.prog:SetText("")
        local l = getLine(e, 1)
        if searchText ~= "" then
            l:SetText("Anderen Suchbegriff probieren.")
        else
            l:SetText("Oben links kannst du eine andere Zone wählen.")
        end
        l:SetTextColor(0.45, 0.45, 0.45)
        l:Show()
        for j = 2, #e.lines do e.lines[j]:Hide() end
        e.toggle:Hide()
        e:SetHeight(3 + TITLE_H + OBJ_H + 5)
        e:ClearAllPoints()
        e:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, -HEADER_H - 4)
        e:Show()
        used = 1
    else
        -- Zeilen-Layout: je Zeile ein Paar, Zeilenhöhe = höhere der beiden Quests
        for i = offset + 1, n, COLS do
            local rowH, row = 0, {}
            for c = 1, COLS do
                local info = quests[i + c - 1]
                if info then
                    local e = getEntry(used + c)
                    local h = fillEntry(e, info)
                    row[c] = e
                    if h > rowH then rowH = h end
                end
            end
            if y + rowH > availH and y > 0 then break end
            for c, e in pairs(row) do
                e:ClearAllPoints()
                e:SetPoint("TOPLEFT", f, "TOPLEFT", PAD + (c - 1) * (CELL_W + PAD), -HEADER_H - 4 - y)
                e:Show()
                lastVisible = i + c - 1
            end
            used = used + COLS
            y = y + rowH
        end
    end


    -- Zähler rechts
    local label = (searchText ~= "") and "Treffer" or ((n == 1) and "Quest" or "Quests")
    if n > 0 and (offset > 0 or lastVisible < n) then
        counterText:SetText(("%d–%d von %d"):format(offset + 1, lastVisible, n))
    else
        counterText:SetText(n .. " " .. label)
    end
    mod:FitHeader()
end

-- Kopfzeile: Suche + Haken dürfen den Zähler nicht überdecken (Ben 26.11. 08:13).
-- Erst die Suche nach links schieben, reicht das nicht, weicht der Zähler.
function mod:FitHeader()
    if not (f and searchBox and counterText and mod.autoChecks) then return end
    local W = f:GetWidth() or 0
    if W <= 0 then return end
    local cAcc, cTurn = mod.autoChecks[1], mod.autoChecks[2]
    local sw = searchBox:GetWidth() or 200
    local checksW = 10 + 20 + cAcc.text:GetStringWidth() + 8 + 20 + cTurn.text:GetStringWidth()
    local bookW = (mod.bookBtn and mod.bookBtn:GetWidth() or 24)
    local leftMin = 150                      -- Platz für den Zonennamen
    local function dxFor(counterW)
        local reserve = PAD + bookW + 8 + counterW + 12
        return math.min(0, W - reserve - (W / 2 + sw / 2 + checksW))
    end
    local wantCounter = W >= 600
    local dx = dxFor(wantCounter and (counterText:GetStringWidth() or 0) or 0)
    if wantCounter and (W / 2 + dx - sw / 2) < leftMin then
        wantCounter = false
        dx = dxFor(0)
    end
    dx = math.max(dx, leftMin - (W / 2 - sw / 2))
    searchBox:ClearAllPoints()
    searchBox:SetPoint("TOP", f, "TOP", dx, -5)
    counterText:SetShown(wantCounter)
end

-- Quest-Ereignisse kommen in Schüben: kurz sammeln, dann einmal neu zeichnen
local pending
local function requestRefresh()
    if pending then return end
    pending = true
    C_Timer.After(0.15, function()
        pending = false
        mod:Refresh()
    end)
end

scroll = function(delta)
    if IsControlKeyDown() then
        if InCombatLockdown() then return end
        local s = (db.scale or 1) + delta * 0.05
        if s < 0.6 then s = 0.6 elseif s > 1.6 then s = 1.6 end
        db.scale = s
        f:SetScale(s)
        return
    end
    if delta > 0 then
        if offset > 0 then
            offset = math.max(0, offset - COLS)
            mod:Refresh()
        end
    elseif lastVisible < #quests then
        offset = offset + COLS
        mod:Refresh()
    end
end

function mod:UpdateLock()
    if f and f.grip then f.grip:SetShown(not db.posLocked) end
end

---------------------------------------------------------------------------
-- Größe: Spaltenzahl, Spaltenbreite, Trennlinien und Kopfzeile anpassen
---------------------------------------------------------------------------
function mod:Relayout()
    if not f then return end
    local w = f:GetWidth()
    COLS = math.max(1, math.min(3, math.floor((w - PAD) / (COL_MIN_W + PAD))))
    if COLS < 2 and w - PAD >= 2 * (COL_MIN_2 + PAD) then COLS = 2 end
    CELL_W = (w - PAD * (COLS + 1)) / COLS

    for _, e in ipairs(entries) do e:SetWidth(CELL_W) end

    for c = 1, 2 do
        local sep = seps[c]
        if not sep then
            sep = f:CreateTexture(nil, "ARTWORK")
            sep:SetTexture(WHITE)
            sep:SetWidth(1)
            sep:SetVertexColor(1, 1, 1, 0.08)
            seps[c] = sep
        end
        sep:ClearAllPoints()
        local x = PAD + c * (CELL_W + PAD) - PAD / 2
        sep:SetPoint("TOPLEFT", f, "TOPLEFT", x, -HEADER_H - 4)
        sep:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", x, PAD)
        sep:SetShown(c < COLS)
    end

    -- Suchfeld schrumpft bei schmalem Tracker mit; ist es eng, weicht die
    -- Questzahl den Haken „annehmen/abgeben“ (Ben 26.11. 06:20, Steves 16:9)
    searchBox:SetWidth(math.max(110, math.min(220, w * 0.3)))
    mod:FitHeader()

    self:Refresh()
end

---------------------------------------------------------------------------
-- Diagnose für /mh quests
---------------------------------------------------------------------------
function ns.DebugQuests()
    local zone, pinned = activeZone()
    local mapID = C_Map.GetBestMapForUnit("player")
    local mapInfo = mapID and C_Map.GetMapInfo(mapID)
    local onMap = questsOnMap()
    ns.Print(("Zone: |cffffd100%s|r%s   Karte: |cffffd100%s|r (%s)"):format(
        zone, pinned and " (fixiert)" or "", mapInfo and mapInfo.name or "?", tostring(mapID)))
    local header = "?"
    for i = 1, C_QuestLog.GetNumQuestLogEntries() do
        local info = C_QuestLog.GetInfo(i)
        if info then
            if info.isHeader then
                header = info.title or "?"
                local same = (header == zone) and " |cff33ff33= Zone|r" or ""
                print(("  |cffff7c0a# %s|r%s"):format(header, same))
            elseif info.questID then
                local tags = {}
                if header == zone then tags[#tags + 1] = "Überschrift" end
                if onMap[info.questID] then tags[#tags + 1] = "Karte" end
                if info.isHidden then tags[#tags + 1] = "versteckt" end
                local t = #tags > 0 and ("|cff33ff33[" .. table.concat(tags, ", ") .. "]|r")
                    or "|cff888888[nicht dabei]|r"
                print(("     %s %s"):format(info.title or "?", t))
            end
        end
    end
    ns.Print(("Im Tracker: %d Quests"):format(#quests))
end

---------------------------------------------------------------------------
-- Aufbau
---------------------------------------------------------------------------
-- Blizzards Questtracker in einen unsichtbaren Rahmen stecken.
-- Mehrere mögliche Namen, weil Forever teils andere Rahmen nutzt; versucht es
-- mehrmals, weil der Tracker manchmal erst später geladen wird. Holt Blizzard
-- ihn wieder hervor, wird er erneut weggesteckt.
local trackerHider
local TRACKER_NAMES = { "ObjectiveTrackerFrame", "QuestWatchFrame", "WatchFrame", "QuestObjectiveTracker" }

local function hideBlizzardTracker()
    if InCombatLockdown() then return end
    trackerHider = trackerHider or CreateFrame("Frame")
    trackerHider:Hide()
    for _, n in ipairs(TRACKER_NAMES) do
        local fr = _G[n]
        if fr and fr.SetParent and fr:GetParent() ~= trackerHider then
            fr:SetParent(trackerHider)
            if not fr.mondhainHooked then
                fr.mondhainHooked = true
                hooksecurefunc(fr, "SetParent", function(self, parent)
                    if parent ~= trackerHider and not self.mondhainBusy and not InCombatLockdown() then
                        self.mondhainBusy = true
                        self:SetParent(trackerHider)
                        self.mondhainBusy = false
                    end
                end)
            end
        end
    end
end

function mod:OnEnable()
    db = ns.db.questTracker
    if not db.enabled then return end
    db.collapsed = db.collapsed or {}

    FONT_SIZE = db.fontSize
    TITLE_H = FONT_SIZE + 4
    OBJ_H = FONT_SIZE + 1
    HEADER_H = FONT_SIZE + 16

    local width = db.width
    -- Standardhöhe: 5 Quests mit je einer Zielzeile pro Spalte
    local height = db.height or (HEADER_H + 4 + 5 * (3 + TITLE_H + OBJ_H + 5) + PAD)

    f = CreateFrame("Frame", "MondhainQuestTracker", UIParent, "BackdropTemplate")
    f:SetSize(width, height)
    f:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    f:SetBackdropColor(unpack(ns.colors.background))
    f:SetBackdropBorderColor(0, 0, 0, 0)
    f:SetFrameStrata("LOW")
    f:SetClipsChildren(true)

    -- Links: Zone als Menü-Knopf
    zoneButton = CreateFrame("Button", nil, f)
    zoneButton:SetPoint("TOPLEFT", PAD - 2, -5)
    zoneButton:SetHeight(HEADER_H - 8)

    zoneText = zoneButton:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    zoneText:SetFont(FONT, FONT_SIZE + 2, "")
    zoneText:SetPoint("LEFT", 4, 0)
    zoneText:SetPoint("RIGHT", -22, 0)
    zoneText:SetJustifyH("LEFT")
    zoneText:SetWordWrap(false)
    zoneText:SetTextColor(ns.Accent())

    local arrow = zoneButton:CreateTexture(nil, "OVERLAY")
    arrow:SetTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
    arrow:SetTexCoord(0.2, 0.8, 0.25, 0.75)
    arrow:SetSize(14, 12)
    arrow:SetPoint("RIGHT", -4, -1)

    local zhl = zoneButton:CreateTexture(nil, "HIGHLIGHT")
    zhl:SetTexture(WHITE)
    zhl:SetAllPoints()
    zhl:SetVertexColor(ns.Accent(0.12))
    mod.zhl = zhl

    zoneButton:SetScript("OnClick", function(self) openZoneMenu(self) end)

    -- Mitte: Suche mit Lupe (Blizzard-Vorlage bringt Lupe und X mit)
    searchBox = CreateFrame("EditBox", "MondhainQuestSearch", f, "SearchBoxTemplate")
    searchBox:SetSize(200, 20)
    searchBox:SetPoint("TOP", f, "TOP", 0, -5)
    searchBox:SetAutoFocus(false)
    if searchBox.Instructions then searchBox.Instructions:SetText("Quest suchen") end
    searchBox:HookScript("OnTextChanged", function(self)
        local text = self:GetText() or ""
        if text ~= searchText then
            searchText = text
            offset = 0
            mod:Refresh()
        end
    end)

    -- Rechts: Buch-Icon → komplettes Questlog, links daneben der Zähler
    local book = CreateFrame("Button", "MondhainQuestLogButton", f, "BackdropTemplate")
    book:RegisterForClicks("LeftButtonUp")
    book:SetScript("OnClick", function()
        if InCombatLockdown() then ns.Print("Im Kampf öffnet sich das Questlog nicht über den Tracker – nimm L.") return end
        for _, fn in ipairs({ _G.ToggleQuestLog, _G.ToggleWorldMap }) do
            if type(fn) == "function" and pcall(fn) then return end
        end
    end)
    book:SetSize(HEADER_H - 8, HEADER_H - 8)
    book:SetPoint("TOPRIGHT", -PAD + 2, -5)
    mod.bookBtn = book
    book:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
    book:SetBackdropBorderColor(ns.Accent(0.5))
    mod.book = book
    local icon = book:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\Icons\\INV_Misc_Book_09")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    icon:SetPoint("TOPLEFT", 1, -1)
    icon:SetPoint("BOTTOMRIGHT", -1, 1)
    local bhl = book:CreateTexture(nil, "HIGHLIGHT")
    bhl:SetTexture(WHITE)
    bhl:SetAllPoints()
    bhl:SetVertexColor(1, 0.85, 0.4, 0.25)
    book:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Questlog öffnen", 1, 0.82, 0)
        GameTooltip:Show()
    end)
    book:SetScript("OnLeave", GameTooltip_Hide)

    counterText = f:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    counterText:SetFont(FONT, FONT_SIZE - 1, "")
    counterText:SetPoint("RIGHT", book, "LEFT", -8, 0)

    -- Ben 26.11. 05:59: rechts neben der Suche zwei Haken – automatisch annehmen / abgeben
    local function autoCheck(key, label, tip)
        local c = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
        c:SetSize(20, 20)
        c.text = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        c.text:SetFont(FONT, FONT_SIZE - 1, "")
        c.text:SetPoint("LEFT", c, "RIGHT", 0, 1)
        c.text:SetText(label)
        c:SetHitRectInsets(0, -(c.text:GetStringWidth() + 4), 0, 0)
        local function q() return ns.db.questHelp end
        c:SetChecked(q()[key] ~= false)
        c:SetScript("OnShow", function(self) self:SetChecked(q()[key] ~= false) end)
        c:SetScript("OnClick", function(self) q()[key] = self:GetChecked() and true or false end)
        c:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:AddLine(tip, 1, 1, 1)
            GameTooltip:AddLine("Shift beim Ansprechen: diesmal nicht", 0.6, 0.6, 0.6)
            GameTooltip:Show()
        end)
        c:SetScript("OnLeave", GameTooltip_Hide)
        return c
    end
    local cAcc = autoCheck("autoAccept", "annehmen", "Quests automatisch annehmen")
    local cTurn = autoCheck("autoTurnIn", "abgeben", "Quests automatisch abgeben (bei Belohnungswahl wählst du)")
    cAcc:SetPoint("LEFT", searchBox, "RIGHT", 10, 0)
    cTurn:SetPoint("LEFT", cAcc.text, "RIGHT", 8, -1)
    mod.autoChecks = { cAcc, cTurn }
    -- auch nach Änderungen in den Optionen stimmen
    C_Timer.NewTicker(1, function()
        if not f:IsVisible() then return end
        cAcc:SetChecked(ns.db.questHelp.autoAccept ~= false)
        cTurn:SetChecked(ns.db.questHelp.autoTurnIn ~= false)
    end)

    local line = f:CreateTexture(nil, "ARTWORK")
    line:SetTexture(WHITE)
    line:SetHeight(1)
    line:SetPoint("TOPLEFT", PAD, -HEADER_H)
    line:SetPoint("TOPRIGHT", -PAD, -HEADER_H)
    line:SetVertexColor(ns.Accent(0.4))
    mod.accentLine = line

    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel", function(_, d) scroll(d) end)
    f:SetScale(db.scale or 1)

    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", dragStart)
    f:SetScript("OnDragStop", dragStop)
    zoneButton:RegisterForDrag("LeftButton")
    zoneButton:SetScript("OnDragStart", dragStart)
    zoneButton:SetScript("OnDragStop", dragStop)

    -- Anfasser unten rechts zum Aufziehen
    f:SetResizable(true)
    if f.SetResizeBounds then
        f:SetResizeBounds(360, 140, 1600, 1000)
    else
        f:SetMinResize(360, 140)
        f:SetMaxResize(1600, 1000)
    end
    local grip = CreateFrame("Button", nil, f)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    grip:SetFrameLevel(f:GetFrameLevel() + 30)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetAlpha(0.5)
    f.grip = grip
    grip:SetScript("OnEnter", function(self)
        self:SetAlpha(1)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Größe ändern", 1, 0.82, 0)
        GameTooltip:AddLine("Ziehen: Breite und Höhe", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Strg + Mausrad über dem Tracker: Zoom", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Rechtsklick: Größe und Zoom zurücksetzen", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave", function(self)
        self:SetAlpha(0.5)
        GameTooltip:Hide()
    end)
    grip:RegisterForClicks("RightButtonUp")
    grip:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" and not InCombatLockdown() then f:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp", function(_, button)
        if button ~= "LeftButton" then return end
        f:StopMovingOrSizing()
        db.width, db.height = math.floor(f:GetWidth() + 0.5), math.floor(f:GetHeight() + 0.5)
        local p, _, rp, x, y = f:GetPoint()
        db.point = { p, "UIParent", rp, x, y }
    end)
    grip:SetScript("OnClick", function()
        db.width, db.height, db.scale = ns.defaults.questTracker.width, nil, 1
        f:SetScale(1)
        f:SetSize(db.width, HEADER_H + 4 + 5 * (3 + TITLE_H + OBJ_H + 5) + PAD)
    end)

    f:SetScript("OnSizeChanged", function() mod:Relayout() end)

    -- Holzrahmen: eigener Halter außerhalb des Trackers, weil der seine Kinder beschneidet
    local woodHolder = CreateFrame("Frame", nil, UIParent)
    woodHolder:SetAllPoints(f)
    woodHolder:SetFrameStrata("LOW")
    woodHolder:SetFrameLevel(f:GetFrameLevel() + 40)
    f:HookScript("OnShow", function() woodHolder:Show() end)
    f:HookScript("OnHide", function() woodHolder:Hide() end)
    if not ns.UseBranch() then ns.WoodFrame(woodHolder, 24) end
    self:UpdateLock()
    self:Relayout()

    -- Verschieben: Bearbeitungsmodus (Esc → Bearbeitungsmodus) oder /mh unlock
    ns.MakeMovable(f, db, "Questtracker", nil, nil, {
        set = function(w, h) f:SetSize(w, h); db.width, db.height = w, h end, minW = 180, minH = 60 })

    if db.hideBlizzard then
        hideBlizzardTracker()
        C_Timer.After(2, hideBlizzardTracker)
        ns.RegisterEvent("PLAYER_ENTERING_WORLD", hideBlizzardTracker)
        ns.RegisterEvent("ADDON_LOADED", function() hideBlizzardTracker() end)
    end

    local function zoneChanged()
        if not db.zone and searchText == "" then offset = 0 end
        requestRefresh()
    end
    ns.RegisterEvent("ZONE_CHANGED_NEW_AREA", zoneChanged)
    ns.RegisterEvent("PLAYER_ENTERING_WORLD", zoneChanged)
    ns.RegisterEvent("QUEST_LOG_UPDATE", requestRefresh)
    ns.RegisterEvent("QUEST_ACCEPTED", requestRefresh)
    ns.RegisterEvent("QUEST_REMOVED", function(_, questID)
        if questID then db.collapsed[questID] = nil end
        requestRefresh()
    end)
    ns.RegisterEvent("SUPER_TRACKING_CHANGED", requestRefresh)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
        if refreshAfterCombat then mod:Refresh() end
    end)
    -- Einträge vorab anlegen (geschützte Knöpfe lassen sich im Kampf nicht neu einrichten)
    for i = 1, 30 do getEntry(i):Hide() end

    self:Refresh()
end

-- Akzentfarbe des Gewands neu setzen (Branch ruft das nach einem Farbwechsel)
function mod:ApplyAccent()
    if zoneText then zoneText:SetTextColor(ns.Accent()) end
    if self.zhl then self.zhl:SetVertexColor(ns.Accent(0.12)) end
    if self.book then self.book:SetBackdropBorderColor(ns.Accent(0.5)) end
    if self.accentLine then self.accentLine:SetVertexColor(ns.Accent(0.4)) end
end
