-- Mondhain – Fenster verschieben
-- Blizzard-Fenster (Beruf, Charakter, Zauberbuch, Händler, Post, Bank …) lassen
-- sich mit gedrückter linker Maustaste an einer freien Stelle verschieben.
-- Mondhain merkt sich den Platz und stellt ihn wieder her, auch wenn Blizzard
-- das Fenster beim Öffnen an seine Standardstelle schieben will.
-- /mh fenster  → alle Fenster wieder an Blizzards Standardplatz

local _, ns = ...
local mod = ns.NewModule("Windows")
ns.Windows = mod

local db
local done = {}

-- Fenster, die viele Spieler verschieben wollen; was es im Spiel nicht gibt,
-- wird einfach übersprungen. Später geladene (Beruf, Talente …) kommen beim
-- Laden ihres Blizzard-Addons dazu.
local NAMES = {
    "CharacterFrame", "SpellBookFrame", "PlayerSpellsFrame", "PlayerTalentFrame", "TalentFrame",
    "TradeSkillFrame", "CraftFrame", "ProfessionsFrame", "ClassTrainerFrame",
    "QuestLogFrame", "QuestFrame", "GossipFrame", "ItemTextFrame",
    "MerchantFrame", "MailFrame", "OpenMailFrame", "BankFrame", "GuildBankFrame",
    "FriendsFrame", "GuildFrame", "CommunitiesFrame", "RaidFrame",
    "AuctionFrame", "AuctionHouseFrame", "TradeFrame", "InspectFrame", "DressUpFrame",
    "TaxiFrame", "FlightMapFrame", "PetStableFrame", "TabardFrame", "GuildRegistrarFrame",
    "PVPFrame", "PVEFrame", "LFGParentFrame", "LFGListFrame", "HonorFrame",
    "AchievementFrame", "CollectionsJournal", "EncounterJournal", "CalendarFrame",
    "MacroFrame", "KeyBindingFrame", "AddonList", "TimeManagerFrame", "ChannelFrame",
    "ItemSocketingFrame", "ItemUpgradeFrame", "ReforgingFrame", "TransmogFrame",
    "WardrobeFrame", "BarberShopFrame", "LootFrame", "GroupLootHistoryFrame",
}

local function canMove(f)
    return not (InCombatLockdown() and f:IsProtected())
end

local function apply(f, name)
    local p = db[name]
    if not p or f.mhMoving or not canMove(f) then return end
    f:ClearAllPoints()
    f:SetPoint(p[1], UIParent, p[2], p[3], p[4])
end

-- Ziehen beginnen/beenden (auch von Hilfsflächen aus, z. B. dem breiteren
-- Grund des Charakterfensters)
function mod:BeginDrag(f)
    if not canMove(f) then return end
    f.mhMoving = true
    f:StartMoving()
end

function mod:EndDrag(f, name)
    if not f.mhMoving then return end
    f:StopMovingOrSizing()
    f.mhMoving = nil
    -- nicht in Blizzards Layout-Speicher (der verträgt sich nicht mit Fensterwechseln)
    if f.SetUserPlaced then pcall(f.SetUserPlaced, f, false) end
    local p, _, rp, x, y = f:GetPoint()
    if p and db then db[name] = { p, rp, x, y } end
end

local function hook(name)
    if done[name] then return end
    local f = _G[name]
    if not f or type(f) ~= "table" or not f.SetMovable or not f.GetObjectType then return end
    if f.IsForbidden and f:IsForbidden() then return end
    if InCombatLockdown() and f:IsProtected() then return end -- nach dem Kampf erneut
    done[name] = true
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    if f.IsMouseEnabled and not f:IsMouseEnabled() then f:EnableMouse(true) end
    f:RegisterForDrag("LeftButton")
    f:HookScript("OnDragStart", function(self) mod:BeginDrag(self) end)
    f:HookScript("OnDragStop", function(self) mod:EndDrag(self, name) end)
    -- Blizzard setzt Fenster beim Öffnen neu → danach wieder an unseren Platz
    f:HookScript("OnShow", function(self)
        apply(self, name)
        C_Timer.After(0, function() if self:IsShown() then apply(self, name) end end)
    end)
    if f:IsShown() then apply(f, name) end
end

local function hookAll()
    for _, n in ipairs(NAMES) do hook(n) end
end

function mod:Reset()
    wipe(db)
    ns.Print("Fenster stehen beim nächsten Öffnen wieder an Blizzards Standardplatz.")
end

function mod:OnEnable()
    ns.db.windows = ns.db.windows or {}
    db = ns.db.windows
    if ns.db.moveWindows == false then return end
    hookAll()
    ns.RegisterEvent("ADDON_LOADED", function() hookAll() end)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function() hookAll() end)
    -- Blizzards Fensterverwaltung schiebt offene Fenster beim Öffnen anderer zurecht
    if UpdateUIPanelPositions then
        hooksecurefunc("UpdateUIPanelPositions", function()
            for name in pairs(done) do
                local f = _G[name]
                if f and f:IsShown() then apply(f, name) end
            end
        end)
    end
end
