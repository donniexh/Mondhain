-- Mondhain – Stufenaufstieg (Ben 26.11. 08:14)
--  · kurzer Lichtblitz über den ganzen Bildschirm (Akzentfarbe des Gewands)
--  · oben die neue Stufe in Morpheus, schwebt groß ein
--  · in der Mitte wächst halbtransparent das Zeichen der Spezialisierung auf
--    (Druide: Bär/Mondkin/Baum, Paladin: Wappen aus dem Gewand)
--  · Blizzards eigenes Stufenbanner wird ausgeblendet (abschaltbar)
-- Test: /mh levelup

local _, ns = ...
local mod = ns.NewModule("LevelUp")
ns.LevelUp = mod

local MEDIA = "Interface\\AddOns\\Mondhain\\media\\"
local FONT = "Fonts\\MORPHEUS.TTF"
local MASK = "Interface\\CharacterFrame\\TempPortraitAlphaMask"

-- Eigene Silhouetten je Talentbaum (Reihenfolge wie im Talentfenster).
-- Fehlt ein Bild, nimmt Mondhain das Baum-Symbol rund ausgeschnitten.
-- Gewänder geben eigene über palette.levelUp = { [1] = Bild, … }.
local EMBLEMS = {
    DRUID = {},     -- [1] Gleichgewicht, [2] Wilder Kampf, [3] Wiederherstellung – Bilder folgen
}

local db, frame

local function clamp(x) return x < 0 and 0 or (x > 1 and 1 or x) end
local function phase(t, a, b) return clamp((t - a) / (b - a)) end
local function easeOut(x) x = clamp(x); return 1 - (1 - x) * (1 - x) end

---------------------------------------------------------------------------
-- Spezialisierung: Talentbaum mit den meisten Punkten
---------------------------------------------------------------------------
local function specTab()
    if GetSpecialization then
        local ok, s = pcall(GetSpecialization)
        if ok and type(s) == "number" and s > 0 then
            local icon
            if GetSpecializationInfo then
                local ok2, _, _, _, ic = pcall(GetSpecializationInfo, s)
                if ok2 then icon = ic end
            end
            return s, icon
        end
    end
    if not (GetNumTalentTabs and GetTalentTabInfo) then return nil end
    local best, bestPts, bestIcon = nil, -1, nil
    for i = 1, GetNumTalentTabs() or 0 do
        local r = { pcall(GetTalentTabInfo, i) }
        if r[1] then
            -- Classic: name, icon, punkte, …  ·  neuere: id, name, beschr., icon, punkte, …
            local pts, icon
            if type(r[4]) == "number" and type(r[3]) ~= "number" then pts, icon = r[4], r[3]
            else
                for k = 2, #r do
                    if pts == nil and type(r[k]) == "number" and k >= 4 then pts = r[k] end
                end
                icon = (type(r[5]) ~= "nil" and r[5]) or r[3]
            end
            pts = pts or 0
            if pts > bestPts then best, bestPts, bestIcon = i, pts, icon end
        end
    end
    if bestPts <= 0 then return nil end
    return best, bestIcon
end

local function emblem()
    local tab, icon = specTab()
    local pal = ns.ActivePalette and ns.ActivePalette()
    local own = pal and type(pal.levelUp) == "table" and pal.levelUp or nil
    local _, class = UnitClass("player")
    local list = own or EMBLEMS[class or ""]
    if tab and list and list[tab] then return list[tab], false end
    if list and list.default then return list.default, false end
    return icon, true          -- Notlösung: Baum-Symbol, rund
end

---------------------------------------------------------------------------
-- Aufbau
---------------------------------------------------------------------------
local function build()
    frame = CreateFrame("Frame", "MondhainLevelUp", UIParent)
    frame:SetAllPoints(UIParent)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:EnableMouse(false)
    frame:Hide()

    local flash = frame:CreateTexture(nil, "BACKGROUND")
    flash:SetAllPoints()
    flash:SetTexture("Interface\\Buttons\\WHITE8x8")
    flash:SetBlendMode("ADD")
    frame.flash = flash

    local em = frame:CreateTexture(nil, "ARTWORK")
    em:SetPoint("CENTER", 0, 20)
    frame.emblem = em
    local mask
    if em.AddMaskTexture and frame.CreateMaskTexture then
        mask = frame:CreateMaskTexture()
        mask:SetTexture(MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        mask:SetAllPoints(em)
    end
    frame.mask = mask

    local holder = CreateFrame("Frame", nil, frame)
    holder:SetSize(10, 10)
    holder:SetPoint("TOP", UIParent, "TOP", 0, -150)
    frame.holder = holder
    local big = holder:CreateFontString(nil, "OVERLAY")
    if not big:SetFont(FONT, 96, "OUTLINE") then big:SetFont(STANDARD_TEXT_FONT, 80, "OUTLINE") end
    big:SetPoint("TOP")
    big:SetShadowOffset(3, -3)
    big:SetShadowColor(0, 0, 0, 1)
    frame.big = big
    local sub = holder:CreateFontString(nil, "OVERLAY")
    if not sub:SetFont(FONT, 30, "OUTLINE") then sub:SetFont(STANDARD_TEXT_FONT, 26, "OUTLINE") end
    sub:SetPoint("TOP", big, "BOTTOM", 0, -4)
    sub:SetText("Stufe erreicht")
    frame.sub = sub
end

---------------------------------------------------------------------------
-- Ablauf (ca. 4 s)
---------------------------------------------------------------------------
function mod:Play(level)
    if not frame then build() end
    level = level or UnitLevel("player")
    local r, g, b = ns.Accent()
    frame.flash:SetVertexColor(r, g, b)
    frame.big:SetText(tostring(level))
    frame.big:SetTextColor(math.min(1, r + 0.1), math.min(1, g + 0.15), math.min(1, b + 0.25))
    frame.sub:SetTextColor(0.92, 0.88, 0.78)

    local tex, isIcon = emblem()
    local em = frame.emblem
    if tex then
        em:SetTexture(tex)
        if frame.mask then
            if isIcon then em:AddMaskTexture(frame.mask) else em:RemoveMaskTexture(frame.mask) end
        end
        em:SetTexCoord(isIcon and 0.08 or 0, isIcon and 0.92 or 1, isIcon and 0.08 or 0, isIcon and 0.92 or 1)
        em:SetBlendMode(isIcon and "BLEND" or "ADD")
        em:Show()
    else
        em:Hide()
    end
    local H = UIParent:GetHeight()

    local t0 = GetTime()
    frame:Show()
    frame:SetScript("OnUpdate", function()
        local t = GetTime() - t0
        -- Blitz: schnell an, weich aus
        frame.flash:SetAlpha(0.55 * phase(t, 0, 0.08) * (1 - phase(t, 0.08, 0.7)))
        -- Stufe: fällt groß ein und setzt sich, später ausblenden
        local a = easeOut(phase(t, 0.15, 0.55)) * (1 - phase(t, 3.2, 4.0))
        frame.holder:SetScale(1 + 0.6 * (1 - easeOut(phase(t, 0.15, 0.6))))
        frame.holder:SetAlpha(a)
        -- Zeichen: wächst aus der Mitte, halbtransparent, löst sich auf
        if tex then
            local p = easeOut(phase(t, 0.1, 3.4))
            local size = H * (0.15 + 0.75 * p)
            em:SetSize(size, size)
            em:SetAlpha((isIcon and 0.30 or 0.45) * phase(t, 0.1, 0.5) * (1 - phase(t, 2.0, 3.4)))
        end
        if t > 4.0 then
            frame:SetScript("OnUpdate", nil)
            frame:Hide()
        end
    end)
end

---------------------------------------------------------------------------
-- Blizzards Banner aus
---------------------------------------------------------------------------
local function hideBlizzard()
    for _, n in ipairs({ "LevelUpDisplay", "EventToastManagerFrame" }) do
        local f = _G[n]
        if f and not f.mhLevelHook then
            f.mhLevelHook = true
            hooksecurefunc(f, "Show", function(self)
                if db.hideBlizzard ~= false and mod.recent and GetTime() - mod.recent < 6 then self:Hide() end
            end)
        end
    end
end

function mod:OnEnable()
    ns.db.levelUp = ns.db.levelUp or {}
    db = ns.db.levelUp
    if db.enabled == false then return end
    ns.RegisterEvent("PLAYER_LEVEL_UP", function(_, level)
        mod.recent = GetTime()
        pcall(hideBlizzard)
        local f = _G.LevelUpDisplay
        if f and db.hideBlizzard ~= false then f:Hide() end
        mod:Play(level)
    end)
    pcall(hideBlizzard)
end
