-- Mondhain – Aktionsleisten
--
-- Mitte unten:  Leiste 1 (8 Tasten), Leiste 2 und 3 (je 9 Tasten)
-- Zusätzlich:   Parkleiste (Blizzard-Leiste 6, waagerecht) – an/aus
-- Tastenzahl jeder Leiste ist einstellbar (1–12), nur außerhalb des Kampfes.
--
-- Gestaltseiten: Normal, Katze, Schleichen, Bär, Mondkin
--   Leiste 1 wechselt immer komplett mit der Gestalt (Blizzard-Seiten, Inhalt bleibt erhalten).
--   In allen anderen Leisten kann jede Taste einzeln zur „Wandeltaste“ werden:
--   Sie bekommt dann pro Gestalt einen eigenen Aktionsplatz.
--
-- Tastenbelegung: Jede Leiste übernimmt die Blizzard-Belegung der passenden
-- Blizzard-Leiste (Aktionsleiste 1 = ACTIONBUTTON1… usw.).
--
-- Das Umblättern läuft über die geschützte Spiellogik und funktioniert im Kampf.
-- Wandeltasten umstellen geht nur außerhalb des Kampfes.

local _, ns = ...
local mod = ns.NewModule("ActionBars")
ns.ActionBars = mod

local FORMS = { "cat", "prowl", "bear", "moonkin" }
local FORM_LABEL = { normal = "Normal", cat = "Katze", prowl = "Schleichen", bear = "Bär", moonkin = "Mondkin" }
local STATE_DRIVER = "[bonusbar:1,stealth] prowl; [bonusbar:1] cat; [bonusbar:3] bear; [bonusbar:4] moonkin; normal"

-- Leiste 1 nutzt die Blizzard-Gestaltseiten (dort liegen deine Katze-/Bär-Fähigkeiten schon)
local BAR1_OFFSET = { cat = 72, prowl = 84, bear = 96, moonkin = 108 }

-- max = Tasten, die angelegt werden; sichtbar sind db.counts[ckey] davon
local MAX = 12
local BARS = {
    { id = 1, ckey = "bar1", base = 1,   bind = "ACTIONBUTTON",          group = "center", row = 1, allWandel = true },
    { id = 2, ckey = "bar2", base = 61,  bind = "MULTIACTIONBAR1BUTTON", group = "center", row = 2 },
    { id = 3, ckey = "bar3", base = 49,  bind = "MULTIACTIONBAR2BUTTON", group = "center", row = 3 },
    { id = 6, ckey = "park", base = 145, bind = "MULTIACTIONBAR5BUTTON", group = "park" },
}

-- Freie Aktionsplätze für Wandeltasten: Seite 2 der Hauptleiste und Blizzard-Leisten 7–8.
-- Es werden nur Plätze genommen, die leer sind – nichts von dir wird überschrieben.
local POOL = {}
for s = 13, 24 do POOL[#POOL + 1] = s end
for s = 157, 180 do POOL[#POOL + 1] = s end

local GAP = 4
local db
local buttons = {}
local headers = {}
local groups = {}
local bindOwner = CreateFrame("Frame")
local bindPending = false
local wandelMode = false
local wandelBanner

---------------------------------------------------------------------------
-- Hilfen
---------------------------------------------------------------------------
local function barEnabled(def)
    if def.group == "center" then return true end
    return db[def.group].enabled
end

local function countOf(def)
    local n = tonumber(db.counts[def.ckey]) or MAX
    if n < 1 then n = 1 elseif n > MAX then n = MAX end
    return n
end

-- Taste aktiv = Leiste an und Taste innerhalb der eingestellten Anzahl
local function buttonActive(b)
    return barEnabled(b.def) and b.index <= countOf(b.def)
end

local function usedPoolSlots()
    local used = {}
    for _, w in pairs(db.wandel) do
        for _, s in pairs(w) do used[s] = true end
    end
    return used
end

local function freeSlots(n)
    local used, out = usedPoolSlots(), {}
    for _, s in ipairs(POOL) do
        if not used[s] and not HasAction(s) then
            out[#out + 1] = s
            if #out == n then return out end
        end
    end
    return nil
end

local function clearSlot(slot)
    if slot and HasAction(slot) then
        ClearCursor()
        PickupAction(slot)
        ClearCursor()
    end
end

local function setHotkey(b)
    if not b.HotKey then return end
    local key = GetBindingKey(b.commandName)
    if key and ns.ShowHotKeys() then
        b.HotKey:SetText(ns.ShortKey(key))
        b.HotKey:Show()
    else
        b.HotKey:SetText("")
        b.HotKey:Hide()
    end
end

---------------------------------------------------------------------------
-- Tastenbelegung: Blizzard-Belegung auf unsere Tasten umlenken
---------------------------------------------------------------------------
local function applyBindings()
    if InCombatLockdown() then
        bindPending = true
        return
    end
    bindPending = false
    ClearOverrideBindings(bindOwner)
    for _, b in ipairs(buttons) do
        if buttonActive(b) then
            for _, key in ipairs({ GetBindingKey(b.commandName) }) do
                SetOverrideBindingClick(bindOwner, false, key, b:GetName(), "LeftButton")
            end
        end
        setHotkey(b)
    end
end

---------------------------------------------------------------------------
-- Aktionsplätze je Gestalt auf eine Taste schreiben
---------------------------------------------------------------------------
local function updateOverlay(b)
    local o = b.wandelOverlay
    if not o then return end
    if b.def.allWandel then
        o.tex:SetColorTexture(1, 0.49, 0.04, 0.35)
        o.label:SetText("immer")
    elseif db.wandel[b.key] then
        o.tex:SetColorTexture(0.30, 0.85, 0.35, 0.45)
        o.label:SetText("wandelt")
    else
        o.tex:SetColorTexture(0, 0, 0, 0.55)
        o.label:SetText("fest")
    end
end

local function configure(b)
    local base = b.baseSlot
    b:SetAttribute("slot-normal", base)
    local w = db.wandel[b.key]
    for _, f in ipairs(FORMS) do
        local slot
        if b.def.allWandel then
            slot = b.index + BAR1_OFFSET[f]
        else
            slot = (w and w[f]) or base
        end
        b:SetAttribute("slot-" .. f, slot)
    end
    -- Mouseover-Aufkleber: hängt am Aktionsplatz (also je Gestalt getrennt)
    local mo = ns.db.mouseover
    b:SetAttribute("mo-" .. base, mo[base] and 1 or nil)
    for _, f in ipairs(FORMS) do
        local sl = b:GetAttribute("slot-" .. f)
        if sl then b:SetAttribute("mo-" .. sl, mo[sl] and 1 or nil) end
    end
    local state = b:GetParent():GetAttribute("state-form") or "normal"
    b:SetAttribute("action", b:GetAttribute("slot-" .. state) or base)
    mod.PaintWandel(b)
    updateOverlay(b)
end

-- Kennzeichnung der Wandeltasten (nicht Leiste 1), immer in der Farbe der
-- aktiven Gestalt (Normalgestalt: Druidenorange). Art, Dicke und Aufleuchten
-- sind in den Optionen einstellbar (db.wandelLook).
local formKey = "caster"
local WHITE_TEX = "Interface\\Buttons\\WHITE8x8"
local LEAF_TEX = "Interface\\Icons\\INV_Misc_Herb_10"

mod.MARKS = {
    { key = "frame",  label = "Rahmen" },
    { key = "corner", label = "Ecke" },
    { key = "line",   label = "Unterstrich" },
    { key = "leaf",   label = "Blatt" },
    { key = "none",   label = "Keine (nur Aufleuchten)" },
}

local function marksOf(b)
    if b.wMarks then return b.wMarks end
    local m = { edges = {} }
    for i = 1, 4 do
        local t = b:CreateTexture(nil, "OVERLAY", nil, 6)
        t:SetTexture(WHITE_TEX)
        m.edges[i] = t
    end
    m.corner = b:CreateTexture(nil, "OVERLAY", nil, 6)
    m.corner:SetTexture(WHITE_TEX)
    m.corner:SetPoint("TOPRIGHT")
    m.leaf = b:CreateTexture(nil, "OVERLAY", nil, 6)
    m.leaf:SetTexture(LEAF_TEX)
    m.leaf:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    m.leaf:SetPoint("TOPLEFT", 2, -2)
    b.wMarks = m
    return m
end

local function hideMarks(m)
    for _, t in ipairs(m.edges) do t:Hide() end
    m.corner:Hide()
    m.leaf:Hide()
end

function mod.PaintWandel(b)
    local isWandel = not b.def.allWandel and db.wandel[b.key]
    if not isWandel then
        if b.wMarks then hideMarks(b.wMarks) end
        return
    end
    local look = db.wandelLook
    local m = marksOf(b)
    hideMarks(m)
    local r, g, bl = ns.GetFormColor(formKey)
    local px = math.max(1, math.min(4, look.thickness or 2))
    local e = m.edges
    if look.mark == "frame" then
        e[1]:ClearAllPoints(); e[1]:SetPoint("TOPLEFT"); e[1]:SetPoint("TOPRIGHT"); e[1]:SetHeight(px)
        e[2]:ClearAllPoints(); e[2]:SetPoint("BOTTOMLEFT"); e[2]:SetPoint("BOTTOMRIGHT"); e[2]:SetHeight(px)
        e[3]:ClearAllPoints(); e[3]:SetPoint("TOPLEFT"); e[3]:SetPoint("BOTTOMLEFT"); e[3]:SetWidth(px)
        e[4]:ClearAllPoints(); e[4]:SetPoint("TOPRIGHT"); e[4]:SetPoint("BOTTOMRIGHT"); e[4]:SetWidth(px)
        for _, t in ipairs(e) do t:SetVertexColor(r, g, bl, 0.95); t:Show() end
    elseif look.mark == "line" then
        e[2]:ClearAllPoints()
        e[2]:SetPoint("BOTTOMLEFT", 4, 2)
        e[2]:SetPoint("BOTTOMRIGHT", -4, 2)
        e[2]:SetHeight(px)
        e[2]:SetVertexColor(r, g, bl, 0.95)
        e[2]:Show()
    elseif look.mark == "corner" then
        m.corner:SetSize(4 + px * 2, 4 + px * 2)
        m.corner:SetVertexColor(r, g, bl, 0.95)
        m.corner:Show()
    elseif look.mark == "leaf" then
        m.leaf:SetSize(8 + px * 2, 8 + px * 2)
        m.leaf:SetAlpha(0.85)
        m.leaf:Show()
    end
end

function mod:RepaintWandel()
    for _, b in ipairs(buttons) do mod.PaintWandel(b) end
end

-- Aufleuchten mit den eingestellten Werten abspielen
local function flashButton(b, r, g, bl)
    local look = db.wandelLook
    if not (look.flash and b.flashAnim) then return end
    local a = math.max(0.1, math.min(1, (look.flashAlpha or 85) / 100))
    local t = math.max(0.3, math.min(2, (look.flashTime or 9) / 10))
    b.flashUp:SetToAlpha(a)
    b.flashDown:SetFromAlpha(a)
    b.flashUp:SetDuration(t * 0.18)
    b.flashDown:SetDuration(t * 0.82)
    b.flash:SetVertexColor(r, g, bl)
    b.flashAnim:Stop()
    b.flashAnim:Play()
end

-- Vorschau für die Optionen: alle Wandeltasten einmal aufleuchten lassen
function mod:PreviewFlash()
    local r, g, bl = ns.GetFormColor(formKey)
    for _, b in ipairs(buttons) do
        if not b.def.allWandel and db.wandel[b.key] and b:IsVisible() then flashButton(b, r, g, bl) end
    end
end

local function onFormChanged(key)
    local changed = (key or "caster") ~= formKey -- beim Einloggen nicht aufleuchten
    formKey = key or "caster"
    local r, g, bl = ns.GetFormColor(formKey)
    for _, b in ipairs(buttons) do
        mod.PaintWandel(b)
        if changed and not b.def.allWandel and db.wandel[b.key] and b:IsVisible() then
            flashButton(b, r, g, bl)
        end
    end
end

function mod:ToggleWandel(b)
    if InCombatLockdown() then
        ns.Print("Wandeltasten lassen sich nur außerhalb des Kampfes umstellen.")
        return
    end
    if b.def.allWandel then
        ns.Print("Leiste 1 wechselt immer mit der Gestalt.")
        return
    end
    local w = db.wandel[b.key]
    if w then
        -- Zurück auf fest: die Gestaltseiten dieser Taste wieder freigeben
        for _, f in ipairs(FORMS) do clearSlot(w[f]) end
        db.wandel[b.key] = nil
    else
        local free = freeSlots(#FORMS)
        if not free then
            ns.Print("Keine freien Aktionsplätze mehr für weitere Wandeltasten.")
            return
        end
        w = {}
        for i, f in ipairs(FORMS) do w[f] = free[i] end
        db.wandel[b.key] = w
    end
    configure(b)
end

---------------------------------------------------------------------------
-- Wandeltasten-Modus
---------------------------------------------------------------------------
local function buildBanner()
    wandelBanner = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    wandelBanner:SetSize(460, 64)
    wandelBanner:SetPoint("TOP", 0, -120)
    wandelBanner:SetFrameStrata("DIALOG")
    wandelBanner:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    wandelBanner:SetBackdropColor(unpack(ns.colors.background))
    wandelBanner:SetBackdropBorderColor(0.30, 0.85, 0.35, 0.8)

    local t = wandelBanner:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOP", 0, -10)
    t:SetText("Wandeltasten")
    t:SetTextColor(0.30, 0.85, 0.35)

    local d = wandelBanner:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    d:SetPoint("TOP", t, "BOTTOM", 0, -6)
    d:SetText("Klick auf eine Taste: wechselt mit der Gestalt / wieder fest")

    local done = CreateFrame("Button", nil, wandelBanner, "UIPanelButtonTemplate")
    done:SetSize(80, 22)
    done:SetPoint("RIGHT", -10, 0)
    done:SetText("Fertig")
    done:SetScript("OnClick", function() mod:SetWandelMode(false) end)
    wandelBanner:Hide()
end

function mod:SetWandelMode(on)
    if on and InCombatLockdown() then
        ns.Print("Wandeltasten lassen sich nur außerhalb des Kampfes umstellen.")
        return
    end
    wandelMode = on
    if not wandelBanner then buildBanner() end
    wandelBanner:SetShown(on)
    for _, b in ipairs(buttons) do
        updateOverlay(b)
        b.wandelOverlay:SetShown(on and buttonActive(b))
    end
end

function mod:IsWandelMode() return wandelMode end

---------------------------------------------------------------------------
-- Mouseover-Modus: Aufkleber an Zauber kleben (je Gestalt)
---------------------------------------------------------------------------
local moMode, moBanner = false, nil
local moOverlays = {}

local function moOverlay(b)
    if moOverlays[b] then return moOverlays[b] end
    local o = CreateFrame("Button", nil, b)
    o:SetAllPoints()
    o:SetFrameLevel(b:GetFrameLevel() + 12)
    o.tex = o:CreateTexture(nil, "OVERLAY")
    o.tex:SetAllPoints()
    o.label = o:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    o.label:SetPoint("BOTTOM", 0, 3)
    o.refresh = function()
        local slot = b:GetAttribute("action")
        if slot and ns.db.mouseover[slot] then
            o.tex:SetColorTexture(0.30, 0.85, 0.45, 0.45)
            o.label:SetText("Maus")
        else
            o.tex:SetColorTexture(0, 0, 0, 0.55)
            o.label:SetText("")
        end
    end
    o:SetScript("OnClick", function()
        if InCombatLockdown() then return end
        local slot = b:GetAttribute("action")
        if not slot then return end
        ns.db.mouseover[slot] = (not ns.db.mouseover[slot]) or nil
        for _, other in ipairs(buttons) do configure(other) end
        for _, ov in pairs(moOverlays) do ov.refresh() end
    end)
    o:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        local slot = b:GetAttribute("action")
        if slot and ns.db.mouseover[slot] then
            GameTooltip:AddLine("Mouseover an", 0.30, 0.85, 0.45)
            GameTooltip:AddLine("Liegt die Maus über einem Freund, wirkt der Zauber dort.", 0.8, 0.8, 0.8, true)
            GameTooltip:AddLine("Klick: aus", 0.6, 0.6, 0.6)
        else
            GameTooltip:AddLine("Mouseover aus", 1, 1, 1)
            GameTooltip:AddLine("Klick: an (gilt nur für diese Gestalt)", 0.6, 0.6, 0.6)
        end
        GameTooltip:Show()
    end)
    o:SetScript("OnLeave", GameTooltip_Hide)
    moOverlays[b] = o
    return o
end

function mod:SetMouseoverMode(on)
    if on and InCombatLockdown() then
        ns.Print("Mouseover lässt sich nur außerhalb des Kampfes einstellen.")
        return
    end
    if on and wandelMode then self:SetWandelMode(false) end
    moMode = on
    if not moBanner then
        moBanner = ns.MakeBanner("Mouseover-Zauber",
            "Klick auf eine Taste: Heilzauber wirkt auf den Freund unter der Maus · gilt je Gestalt",
            0.30, 0.85, 0.45, function() mod:SetMouseoverMode(false) end)
    end
    moBanner:SetShown(on)
    for _, b in ipairs(buttons) do
        local o = moOverlay(b)
        o:SetShown(on and buttonActive(b))
        if on then o.refresh() end
    end
end

-- Gestalt wechseln, während der Modus offen ist: Anzeige mitziehen
ns.On("FORM_CHANGED", function()
    if moMode then for _, o in pairs(moOverlays) do o.refresh() end end
end)

---------------------------------------------------------------------------
-- Tasten und Leisten bauen
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- Anzeige der Tasten
-- Eigene Tasten ohne Blizzards Tastenvorlage: Blizzards Vorlage läuft in
-- Addon-Tasten „verschmutzt“ und scheitert an den geheimen Werten von Midnight.
-- Abklingzeiten laufen über Dauer-Objekte (SetCooldownFromDurationObject) –
-- der von Blizzard vorgesehene Weg für Addons. Geheime Werte werden nie
-- verglichen, nur angezeigt.
---------------------------------------------------------------------------
local BTN = 36
local WHITE = "Interface\\Buttons\\WHITE8x8"
local isSecret = issecretvalue or function() return false end

local function actionOf(b)
    return b:GetAttribute("action") or b.baseSlot
end

local function updateIcon(b)
    local slot = actionOf(b)
    local tex = GetActionTexture(slot)
    if tex then
        b.icon:SetTexture(tex)
        b.icon:Show()
    else
        b.icon:Hide()
    end
    local ok, txt = pcall(GetActionText, slot)
    pcall(b.Name.SetText, b.Name, ok and txt or "")
end

local function updateCooldown(b)
    local slot = actionOf(b)
    if not HasAction(slot) then
        b.cooldown:Clear()
        b.chargeCooldown:Clear()
        return
    end
    local ok, d = pcall(C_ActionBar.GetActionCooldownDuration, slot)
    if ok and d then
        b.cooldown:SetCooldownFromDurationObject(d, true)
    else
        b.cooldown:Clear()
    end
    if C_ActionBar.GetActionChargeDuration then
        local ok2, cd = pcall(C_ActionBar.GetActionChargeDuration, slot)
        if ok2 and cd then
            b.chargeCooldown:SetCooldownFromDurationObject(cd, true)
        else
            b.chargeCooldown:Clear()
        end
    end
end

local function updateCount(b)
    local slot = actionOf(b)
    local text = ""
    pcall(function()
        if IsConsumableAction(slot) or IsStackableAction(slot) then
            text = GetActionCount(slot)
        elseif C_ActionBar.GetActionCharges then
            local ch = C_ActionBar.GetActionCharges(slot)
            if ch and ch.maxCharges and ch.maxCharges > 1 then text = ch.currentCharges end
        end
    end)
    if not pcall(b.Count.SetText, b.Count, text) then b.Count:SetText("") end
end

local function updateUsable(b)
    local slot = actionOf(b)
    local usable, noMana = IsUsableAction(slot)
    if isSecret(usable) or isSecret(noMana) then
        b.icon:SetVertexColor(1, 1, 1)
    elseif usable then
        b.icon:SetVertexColor(1, 1, 1)
    elseif noMana then
        b.icon:SetVertexColor(0.45, 0.55, 1)
    else
        b.icon:SetVertexColor(0.4, 0.4, 0.4)
    end
end

local function updateChecked(b)
    local slot = actionOf(b)
    local cur, rep = IsCurrentAction(slot), IsAutoRepeatAction(slot)
    -- nicht lesbar → lieber aus als dauerhaft „gedrückt“
    local ok, on = pcall(function() return (cur or rep) and true or false end)
    b:SetChecked(ok and on or false)
end

local function updateAll(b)
    updateIcon(b)
    updateCooldown(b)
    updateCount(b)
    updateUsable(b)
    updateChecked(b)
end

-- Ein einziger Ereignis-Empfänger für alle Mondhain-Tasten
local events = CreateFrame("Frame")
local EVENT_LIST = {
    "PLAYER_ENTERING_WORLD", "ACTIONBAR_SLOT_CHANGED", "ACTIONBAR_UPDATE_COOLDOWN",
    "SPELL_UPDATE_COOLDOWN", "ACTIONBAR_UPDATE_USABLE", "SPELL_UPDATE_USABLE",
    "ACTIONBAR_UPDATE_STATE", "UPDATE_SHAPESHIFT_FORM", "SPELL_UPDATE_CHARGES",
    "BAG_UPDATE_DELAYED", "PLAYER_TARGET_CHANGED", "UNIT_INVENTORY_CHANGED",
    "LOSS_OF_CONTROL_UPDATE", "UPDATE_MACROS",
}
events:SetScript("OnEvent", function(_, event, arg1)
    if event == "ACTIONBAR_SLOT_CHANGED" then
        for _, b in ipairs(buttons) do
            if arg1 == 0 or actionOf(b) == arg1 then updateAll(b) end
        end
    elseif event == "ACTIONBAR_UPDATE_COOLDOWN" or event == "SPELL_UPDATE_COOLDOWN"
        or event == "LOSS_OF_CONTROL_UPDATE" then
        for _, b in ipairs(buttons) do updateCooldown(b) end
    elseif event == "ACTIONBAR_UPDATE_USABLE" or event == "SPELL_UPDATE_USABLE" then
        for _, b in ipairs(buttons) do updateUsable(b) end
    elseif event == "ACTIONBAR_UPDATE_STATE" then
        for _, b in ipairs(buttons) do updateChecked(b) end
    elseif event == "SPELL_UPDATE_CHARGES" or event == "BAG_UPDATE_DELAYED" then
        for _, b in ipairs(buttons) do updateCount(b) end
    else
        for _, b in ipairs(buttons) do updateAll(b) end
    end
end)

local function buttonOnEnter(self)
    local slot = actionOf(self)
    if not HasAction(slot) then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetAction(slot)
    GameTooltip:Show()
end

local function createButton(def, i, header)
    local name = ("MondhainBar%dButton%d"):format(def.id, i)
    local b = CreateFrame("CheckButton", name, header, "SecureActionButtonTemplate")
    b:SetSize(BTN, BTN)
    b.def = def
    b.index = i
    b.key = def.id .. ":" .. i
    b.baseSlot = def.base + i - 1
    b.commandName = def.bind .. i

    b:SetAttribute("type", "action")
    b:SetAttribute("action", b.baseSlot)
    b:SetAttribute("_childupdate-form", [[
        local slot = self:GetAttribute("slot-" .. (message or "normal")) or self:GetAttribute("slot-normal")
        self:SetAttribute("action", slot)
    ]])

    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("useOnKeyDown", GetCVarBool("ActionButtonUseKeyDown"))
    b:SetAttribute("lockbar", GetCVarBool("lockActionBars"))

    -- Aussehen: dunkler Holzrahmen, Symbol, leerer Platz bleibt sichtbar
    local frame = b:CreateTexture(nil, "BACKGROUND", nil, -2)
    frame:SetAllPoints()
    frame:SetColorTexture(unpack(ns.colors.border))
    b.frameTex = frame -- Rahmen: Holz, bei Wandeltasten in Gestaltfarbe
    local slotBg = b:CreateTexture(nil, "BACKGROUND", nil, -1)
    slotBg:SetPoint("TOPLEFT", 1, -1)
    slotBg:SetPoint("BOTTOMRIGHT", -1, 1)
    slotBg:SetColorTexture(0.05, 0.06, 0.08, 0.85)

    b.icon = b:CreateTexture(name .. "Icon", "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 1, -1)
    b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    b.cooldown = CreateFrame("Cooldown", name .. "Cooldown", b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b.icon)
    b.cooldown:SetDrawEdge(false)

    b.chargeCooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.chargeCooldown:SetAllPoints(b.icon)
    b.chargeCooldown:SetDrawSwipe(false)
    b.chargeCooldown:SetDrawEdge(true)
    b.chargeCooldown:SetHideCountdownNumbers(true)

    local textLayer = CreateFrame("Frame", nil, b)
    textLayer:SetAllPoints()
    textLayer:SetFrameLevel(b.cooldown:GetFrameLevel() + 2)

    b.HotKey = textLayer:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmallGray")
    b.HotKey:SetPoint("TOPRIGHT", -2, -3)
    b.HotKey:SetWidth(BTN - 4)
    b.HotKey:SetJustifyH("RIGHT")
    b.HotKey:SetWordWrap(false)
    ns.StyleHotKey(b.HotKey)
    b.Count = textLayer:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    b.Count:SetPoint("BOTTOMRIGHT", -2, 2)
    b.Name = textLayer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    b.Name:SetPoint("BOTTOM", 0, 2)
    b.Name:SetWidth(BTN - 4)
    b.Name:SetWordWrap(false)

    b:SetHighlightTexture(WHITE)
    b:GetHighlightTexture():SetAllPoints(b.icon)
    b:GetHighlightTexture():SetVertexColor(1, 1, 1, 0.15)
    b:SetPushedTexture(WHITE)
    b:GetPushedTexture():SetAllPoints(b.icon)
    b:GetPushedTexture():SetVertexColor(1, 0.85, 0.4, 0.25)
    b:SetCheckedTexture(WHITE)
    b:GetCheckedTexture():SetAllPoints(b.icon)
    b:GetCheckedTexture():SetVertexColor(1, 0.49, 0.04, 0.35)

    -- Ziehen und Ablegen über die geschützte Spiellogik (funktioniert auch im Kampf)
    b:RegisterForDrag("LeftButton")
    header:WrapScript(b, "OnDragStart", [[
        if self:GetAttribute("lockbar") and not IsModifiedClick("PICKUPACTION") then return false end
        return "action", self:GetAttribute("action")
    ]])
    header:WrapScript(b, "OnReceiveDrag", [[
        if not kind then return false end
        return "action", self:GetAttribute("action")
    ]])

    -- Mouseover: Hat der Zauber auf diesem Platz den Aufkleber und liegt die Maus
    -- über etwas Freundlichem (z. B. einem Gruppenrahmen), geht er dorthin.
    -- Sonst wirkt er ganz normal.
    header:WrapScript(b, "OnClick", [[
        local slot = self:GetAttribute("action")
        if slot and self:GetAttribute("mo-" .. slot) then
            local u = SecureCmdOptionParse("[@mouseover,help,nodead] mouseover; none")
            if u == "mouseover" then
                self:SetAttribute("unit", "mouseover")
                return
            end
        end
        self:SetAttribute("unit", nil)
    ]])

    b:SetScript("OnEnter", buttonOnEnter)
    b:SetScript("OnLeave", GameTooltip_Hide)

    -- Eine Prüftaste schaltet sich beim Drücken selbst auf „aktiv“. Schlägt der
    -- Zauber fehl (zu wenig Wut/Energie), kommt kein Ereignis, das das zurücknimmt –
    -- die orange Tönung blieb hängen. Darum nach jedem Druck den echten Stand setzen.
    b:HookScript("OnClick", function(self)
        updateChecked(self)
        updateUsable(self)
    end)

    -- Nach jedem Seitenwechsel die Anzeige auffrischen
    b:HookScript("OnAttributeChanged", function(self, attr)
        if attr == "action" then updateAll(self) end
    end)

    -- Wandeltasten: kurzes Aufleuchten beim Gestaltwechsel (sonst unsichtbar)
    local flash = b:CreateTexture(nil, "OVERLAY", nil, 7)
    flash:SetPoint("TOPLEFT", b.icon, "TOPLEFT")
    flash:SetPoint("BOTTOMRIGHT", b.icon, "BOTTOMRIGHT")
    flash:SetTexture(WHITE)
    flash:SetBlendMode("ADD")
    flash:SetAlpha(0)
    local ag = flash:CreateAnimationGroup()
    local up = ag:CreateAnimation("Alpha")
    up:SetFromAlpha(0); up:SetToAlpha(0.85); up:SetDuration(0.15); up:SetOrder(1)
    local down = ag:CreateAnimation("Alpha")
    down:SetFromAlpha(0.85); down:SetToAlpha(0); down:SetDuration(0.7); down:SetOrder(2)
    ag:SetScript("OnFinished", function() flash:SetAlpha(0) end)
    b.flash, b.flashAnim, b.flashUp, b.flashDown = flash, ag, up, down

    -- Schicht für den Wandeltasten-Modus
    local o = CreateFrame("Button", nil, b)
    o:SetAllPoints()
    o:SetFrameLevel(b:GetFrameLevel() + 10)
    o.tex = o:CreateTexture(nil, "OVERLAY")
    o.tex:SetAllPoints()
    o.label = o:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    o.label:SetPoint("BOTTOM", 0, 3)
    o:SetScript("OnClick", function() mod:ToggleWandel(b) end)
    o:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        if b.def.allWandel then
            GameTooltip:AddLine("Leiste 1 – wechselt immer", 1, 0.49, 0.04)
        elseif db.wandel[b.key] then
            GameTooltip:AddLine("Wandeltaste", 0.30, 0.85, 0.35)
            GameTooltip:AddLine("Eigene Belegung für: Normal, Katze, Schleichen, Bär, Mondkin", 0.8, 0.8, 0.8, true)
            GameTooltip:AddLine("Klick: wieder fest machen", 0.6, 0.6, 0.6)
        else
            GameTooltip:AddLine("Feste Taste", 1, 1, 1)
            GameTooltip:AddLine("Klick: wechselt ab jetzt mit der Gestalt", 0.6, 0.6, 0.6)
        end
        GameTooltip:Show()
    end)
    o:SetScript("OnLeave", GameTooltip_Hide)
    o:Hide()
    b.wandelOverlay = o

    buttons[#buttons + 1] = b
    return b
end

local function createBar(def, parent)
    local h = CreateFrame("Frame", "MondhainBar" .. def.id, parent, "SecureHandlerStateTemplate")
    h:SetAttribute("_onstate-form", [[ control:ChildUpdate("form", newstate) ]])
    headers[def.id] = h

    h.buttons = {}
    for i = 1, MAX do
        local b = createButton(def, i, h)
        b:ClearAllPoints()
        b:SetPoint("LEFT", h, "LEFT", (i - 1) * (BTN + GAP), 0)
        h.buttons[i] = b
    end
    h:SetSize(MAX * (BTN + GAP) - GAP, BTN)
    h.buttonSize = BTN
    return h
end

-- Tasten je Leiste ein-/ausblenden und Leisten neu zentrieren (nur außerhalb des Kampfes)
local function layout()
    local centerW = 0
    for _, def in ipairs(BARS) do
        local h = headers[def.id]
        local n = countOf(def)
        for i, b in ipairs(h.buttons) do b:SetShown(i <= n) end
        h:SetSize(n * (BTN + GAP) - GAP, BTN)
        if def.group == "center" then
            centerW = math.max(centerW, h:GetWidth())
        else
            groups[def.group]:SetSize(h:GetWidth(), h:GetHeight())
        end
    end
    groups.center:SetSize(centerW, 3 * (BTN + GAP) - GAP)
end

-- Für den Belegungsmodus: alle sichtbaren Tasten mit Namen
function mod:GetBindButtons()
    local out = {}
    for _, b in ipairs(buttons) do
        if buttonActive(b) then
            local d = b.def
            b.bindLabel = (d.group == "park" and "Parkleiste" or ("Leiste " .. d.id)) .. ", Taste " .. b.index
            out[#out + 1] = b
        end
    end
    return out
end

function mod:GetCount(ckey) return db and db.counts[ckey] end

function mod:SetCount(ckey, n)
    if InCombatLockdown() then
        ns.Print("Die Tastenzahl lässt sich nur außerhalb des Kampfes ändern.")
        return false
    end
    if n < 1 then n = 1 elseif n > MAX then n = MAX end
    db.counts[ckey] = n
    if not db.enabled then return true end
    layout()
    applyBindings()
    return true
end

local function createGroup(key, label)
    local gdb = db[key]
    local g = CreateFrame("Frame", "MondhainBars_" .. key, UIParent)
    g:SetPoint(gdb.point[1], UIParent, gdb.point[3], gdb.point[4], gdb.point[5])
    g:SetSize(10, 10)
    groups[key] = g
    return g
end

---------------------------------------------------------------------------
-- Blizzard-Leisten ausblenden
---------------------------------------------------------------------------
local function hideBlizzardBars()
    local hider = CreateFrame("Frame")
    hider:Hide()
    for _, n in ipairs({ "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight",
        "MultiBarLeft", "MultiBar5", "MultiBar6", "MultiBar7" }) do
        local f = _G[n]
        if f then f:SetParent(hider) end
    end
    local main = _G.MainActionBar or _G.MainMenuBar
    if main then
        -- Was an der Hauptleiste hängt, aber bleiben soll, vorher retten
        for _, n in ipairs({ "MicroMenuContainer", "MicroButtonAndBagsBar", "BagsBar",
            "MainMenuBarBackpackButton", "StatusTrackingBarManager", "StanceBar",
            "PetActionBar", "PossessActionBar", "MainMenuBarVehicleLeaveButton" }) do
            local f = _G[n]
            if f and f:GetParent() == main then f:SetParent(UIParent) end
        end
        main:SetParent(hider)
    end
end

---------------------------------------------------------------------------
-- Parkleiste an/aus
---------------------------------------------------------------------------
function mod:SetBarEnabled(group, on)
    if InCombatLockdown() then
        ns.Print("Leisten lassen sich nur außerhalb des Kampfes ein- und ausschalten.")
        return false
    end
    db[group].enabled = on
    if groups[group] then groups[group]:SetShown(on) end
    applyBindings()
    return true
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.actionBars
    if not db.enabled then return end

    -- Gruppen: Mitte (Leisten 1–3) und die Parkleiste
    local center = createGroup("center", "Aktionsleisten")
    createGroup("park", "Parkleiste")

    for _, def in ipairs(BARS) do
        local g = groups[def.group]
        local h = createBar(def, g)
        if def.group == "center" then
            h:SetPoint("TOP", center, "TOP", 0, -(def.row - 1) * (BTN + GAP))
        else
            h:SetPoint("LEFT", g, "LEFT")
        end
    end
    layout()

    formKey = select(2, ns.GetForm()) or "caster"
    for _, b in ipairs(buttons) do configure(b) end
    ns.On("FORM_CHANGED", onFormChanged)
    for _, def in ipairs(BARS) do
        RegisterStateDriver(headers[def.id], "form", STATE_DRIVER)
    end

    groups.park:SetShown(db.park.enabled)

    ns.MakeMovable(center, db.center, "Aktionsleisten")
    ns.MakeMovable(groups.park, db.park, "Parkleiste")

    if db.hideBlizzard then hideBlizzardBars() end

    applyBindings()

    for _, e in ipairs(EVENT_LIST) do events:RegisterEvent(e) end
    for _, b in ipairs(buttons) do updateAll(b) end

    ns.RegisterEvent("UPDATE_BINDINGS", applyBindings)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
        if bindPending then applyBindings() end
    end)
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function()
        if wandelMode then mod:SetWandelMode(false) end
        if moMode then mod:SetMouseoverMode(false) end
    end)
    ns.RegisterEvent("CVAR_UPDATE", function()
        if InCombatLockdown() then return end
        local down = GetCVarBool("ActionButtonUseKeyDown")
        local lock = GetCVarBool("lockActionBars")
        for _, b in ipairs(buttons) do
            b:SetAttribute("useOnKeyDown", down)
            b:SetAttribute("lockbar", lock)
        end
    end)
end

-- Für /mh seite: welche Gestaltseite ist gerade aktiv?
function mod:CurrentPage()
    local h = headers[1]
    local s = h and h:GetAttribute("state-form") or "normal"
    return s, FORM_LABEL[s] or s
end
