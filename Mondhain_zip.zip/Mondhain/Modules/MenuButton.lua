-- Mondhain – Menüknopf (unten rechts, frei verschiebbar)
--   Linksklick          → Mondhain-Optionen
--   Rechtsklick         → Schnellmenü
--   Strg + Rechtsklick  → UI neu laden

local _, ns = ...
local mod = ns.NewModule("MenuButton")

local SIZE = 34
local ICON = ns.ICON
local FALLBACK_ICON = "Interface\\Icons\\Ability_Druid_Maul"

local function openMenu(owner)
    if not (MenuUtil and MenuUtil.CreateContextMenu) then
        ns.ToggleOptions()
        return
    end
    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle(ns.IconText(16) .. " Mondhain")
        root:CreateButton("Optionen", function() ns.ToggleOptions() end)
        root:CreateButton("Verschieben & Größe", function() ns.SetUnlocked(true) end)
        root:CreateButton("Wandeltasten festlegen", function()
            if ns.ActionBars then ns.ActionBars:SetWandelMode(true) end
        end)
        root:CreateButton("Mouseover-Zauber festlegen", function()
            if ns.ActionBars then ns.ActionBars:SetMouseoverMode(true) end
        end)
        root:CreateButton("Vorratsleiste bearbeiten", function()
            if ns.ItemBar then ns.ItemBar:SetEditMode(true) end
        end)
        root:CreateButton("Tasten belegen", function()
            if ns.KeyBind then ns.KeyBind:SetActive(true) end
        end)
        root:CreateDivider()
        root:CreateButton("UI neu laden", function() ReloadUI() end)
    end)
end

function mod:OnEnable()
    local db = ns.db.menuButton
    if not db.enabled then return end

    local b = CreateFrame("Button", "MondhainMenuButton", UIParent)
    ns.SkinButton(b, SIZE)
    b:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    b:SetFrameStrata("MEDIUM")
    b.icon:SetTexture(ICON)
    if not b.icon:GetTexture() then b.icon:SetTexture(FALLBACK_ICON) end
    b.border:SetColorTexture(1, 0.49, 0.04, 0.8) -- Druidenorange
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    b:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            if IsControlKeyDown() then
                ReloadUI()
            else
                openMenu(self)
            end
        else
            ns.ToggleOptions()
        end
    end)
    b:SetScript("OnEnter", function(self)
        ns.TooltipBeside(self)
        GameTooltip:AddLine("Mondhain", 1, 0.49, 0.04)
        GameTooltip:AddLine("Linksklick: Optionen", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Rechtsklick: Menü", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Strg + Rechtsklick: UI neu laden", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)

    ns.MakeMovable(b, db, "Menü")
end
