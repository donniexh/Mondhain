-- Mondhain – Optionen (/mh, Linksklick auf den Menüknopf)
--
-- Erster Blick: eine Bildübersicht („Wohin willst du?“). Jede Kachel ist ein
-- Bereich. Ein Klick öffnet nur die Einstellungen dieses Bereichs – mit einem
-- Satz Erklärung und einem Zurück-Knopf. Wie Türen im Hain: erst den Weg
-- wählen, dann eintreten.

local _, ns = ...
local mod = ns.NewModule("Options")

local WHITE = "Interface\\Buttons\\WHITE8x8"
local ORANGE = { 1, 0.49, 0.04 }
local W = 724           -- Breite des Fensters
local COL_W = 560       -- Breite der Einstellungen auf einer Seite
local PAGE_X = 70       -- linker Rand der Einstellungen
local RELOAD = " |cff888888(nach /reload)|r"

local panel, home, current
local pages = {}

---------------------------------------------------------------------------
-- Bausteine für die Seiten
---------------------------------------------------------------------------
local function newPage()
    local p = CreateFrame("Frame", nil, panel)
    p:SetAllPoints()
    p.refreshers = {}
    p:Hide()
    return p
end

-- xoff: für zweispaltige Listen (zweite Spalte = COL_W / 2)
local function checkbox(p, y, label, get, set, xoff)
    local c = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
    c:SetSize(26, 26)
    c:SetPoint("TOPLEFT", PAGE_X + (xoff or 0), y)
    local t = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    t:SetPoint("LEFT", c, "RIGHT", 6, 0)
    t:SetWidth(xoff and (COL_W / 2 - 40) or (COL_W - 40))
    t:SetJustifyH("LEFT")
    t:SetText(label)
    c:SetScript("OnClick", function(self)
        if set(self:GetChecked()) == false then self:SetChecked(get()) end
    end)
    p.refreshers[#p.refreshers + 1] = function() c:SetChecked(get()) end
    return y - 30
end

local function stepper(p, y, label, get, set, min, max, step)
    step = step or 1
    local t = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    t:SetPoint("TOPLEFT", PAGE_X + 6, y - 4)
    t:SetText(label)
    local plusB = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
    plusB:SetSize(26, 22)
    plusB:SetPoint("TOPLEFT", PAGE_X + COL_W - 60, y)
    plusB:SetText("+")
    local value = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    value:SetPoint("RIGHT", plusB, "LEFT", -8, 0)
    value:SetWidth(34)
    local minusB = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
    minusB:SetSize(26, 22)
    minusB:SetPoint("RIGHT", value, "LEFT", -8, 0)
    minusB:SetText("-")
    local function refresh() value:SetText(tostring(get() or "?")) end
    local function change(d)
        local n = (get() or min) + d
        if n < min or n > max then return end
        set(n)
        refresh()
    end
    minusB:SetScript("OnClick", function() change(-step) end)
    plusB:SetScript("OnClick", function() change(step) end)
    p.refreshers[#p.refreshers + 1] = refresh
    return y - 30
end

local function button(p, y, label, onClick)
    local b = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
    b:SetSize(260, 26)
    b:SetPoint("TOPLEFT", PAGE_X + 4, y)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return y - 34
end

local function heading(p, y, text)
    local t = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    t:SetPoint("TOPLEFT", PAGE_X, y)
    t:SetText(text)
    t:SetTextColor(unpack(ORANGE))
    return y - 22
end

-- Kopf einer Seite: Zurück, Bild, Titel, ein Satz Erklärung
local function pageHeader(p, icon, title, text)
    local back = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
    back:SetSize(90, 24)
    back:SetPoint("TOPLEFT", 14, -14)
    back:SetText("< Zurück")
    back:SetScript("OnClick", function() mod:ShowHome() end)

    local ic = p:CreateTexture(nil, "ARTWORK")
    ic:SetSize(44, 44)
    ic:SetPoint("TOPLEFT", PAGE_X - 4, -50)
    ic:SetTexture(icon)
    ic:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local t = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOPLEFT", ic, "TOPRIGHT", 12, -2)
    t:SetText(title)
    t:SetTextColor(unpack(ORANGE))

    local d = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -6)
    d:SetWidth(COL_W - 56)
    d:SetJustifyH("LEFT")
    d:SetText(text)
    d:SetTextColor(0.78, 0.76, 0.70)

    local line = p:CreateTexture(nil, "ARTWORK")
    line:SetTexture(WHITE)
    line:SetHeight(1)
    line:SetPoint("TOPLEFT", PAGE_X - 4, -110)
    line:SetWidth(COL_W)
    line:SetVertexColor(1, 0.49, 0.04, 0.35)
    return -124
end

---------------------------------------------------------------------------
-- Die Bereiche
---------------------------------------------------------------------------
local AREAS = {
    {
        key = "bars", title = "Aktionsleisten", icon = "Interface\\Icons\\Ability_Druid_Ravage",
        short = "Tasten in der Mitte, Parkleiste, Wandeltasten",
        build = function(p)
            local adb, bars = ns.db.actionBars, ns.ActionBars
            local y = pageHeader(p, "Interface\\Icons\\Ability_Druid_Ravage", "Aktionsleisten",
                "Wie viele Tasten jede Leiste hat. Leiste 1 wechselt immer mit der Gestalt, in den anderen kannst du einzelne Tasten zu Wandeltasten machen.")
            local function count(label, key)
                y = stepper(p, y, label, function() return adb.counts[key] end, function(n)
                    if adb.enabled and bars then bars:SetCount(key, n) else adb.counts[key] = n end
                end, 1, 12)
            end
            y = heading(p, y, "Tasten je Leiste")
            count("Leiste 1 (wechselt mit der Gestalt)", "bar1")
            count("Leiste 2", "bar2")
            count("Leiste 3", "bar3")
            count("Parkleiste (über dem Chat)", "park")
            y = y - 6
            y = heading(p, y, "Mehr")
            y = checkbox(p, y, "Parkleiste anzeigen", function() return adb.park.enabled end, function(v)
                if not adb.enabled then adb.park.enabled = v and true or false return end
                return bars:SetBarEnabled("park", v and true or false)
            end)
            y = checkbox(p, y, "Blizzards eigene Leisten ausblenden" .. RELOAD,
                function() return adb.hideBlizzard end, function(v) adb.hideBlizzard = v and true or false end)
            y = button(p, y, "Wandeltasten festlegen", function()
                panel:Hide()
                if bars then bars:SetWandelMode(true) end
            end)
            y = button(p, y, "Mouseover-Zauber festlegen", function()
                panel:Hide()
                if bars then bars:SetMouseoverMode(true) end
            end)

            -- Wie Wandeltasten aussehen
            local look = adb.wandelLook
            local function repaint() if bars and adb.enabled then bars:RepaintWandel() end end
            y = y - 4
            y = heading(p, y, "Wandeltasten kennzeichnen")
            local markBtn = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            markBtn:SetSize(260, 26)
            markBtn:SetPoint("TOPLEFT", PAGE_X + 4, y)
            local function markText()
                local label = "Rahmen"
                for _, m in ipairs(bars.MARKS) do if m.key == look.mark then label = m.label end end
                markBtn:SetText("Markierung: " .. label)
            end
            markBtn:SetScript("OnClick", function()
                local list, idx = bars.MARKS, 1
                for i, m in ipairs(list) do if m.key == look.mark then idx = i end end
                look.mark = list[idx % #list + 1].key
                markText()
                repaint()
            end)
            p.refreshers[#p.refreshers + 1] = markText
            y = y - 34
            y = stepper(p, y, "Dicke (Pixel)", function() return look.thickness end,
                function(n) look.thickness = n; repaint() end, 1, 4)
            y = checkbox(p, y, "Beim Gestaltwechsel aufleuchten", function() return look.flash end,
                function(v) look.flash = v and true or false end)
            y = stepper(p, y, "Aufleuchten: Helligkeit (%)", function() return look.flashAlpha end,
                function(n) look.flashAlpha = n end, 20, 100, 5)
            y = stepper(p, y, "Aufleuchten: Dauer (Zehntelsekunden)", function() return look.flashTime end,
                function(n) look.flashTime = n end, 3, 20)
            y = button(p, y, "Aufleuchten ausprobieren", function()
                if bars and adb.enabled then bars:PreviewFlash() end
            end)
            y = y - 4
            y = heading(p, y, "Tastenkürzel")
            y = checkbox(p, y, "Tastenkürzel auf den Tasten zeigen" .. RELOAD,
                function() return adb.hotkeys ~= false end, function(v) adb.hotkeys = v and true or false end)
            y = stepper(p, y, "Schriftgröße der Kürzel" .. RELOAD, function() return adb.hotkeySize or 9 end,
                function(n) adb.hotkeySize = n end, 7, 14)
            return y
        end,
    },
    {
        key = "center", title = "Mitte", icon = "Interface\\Icons\\Spell_Nature_ProtectionformNature",
        short = "Grund hinter den Leisten, Schwung und Zauber, EP",
        build = function(p)
            local c = ns.db.centerBlock
            local y = pageHeader(p, "Interface\\Icons\\Spell_Nature_ProtectionformNature", "Mitte",
                "Ein ruhiger, dunkler Grund fasst die drei Leisten zu einem Block zusammen. Schwung- und Zauberleiste sitzen direkt darüber.")
            y = checkbox(p, y, "Grund hinter den Leisten" .. RELOAD, function() return c.enabled end,
                function(v) c.enabled = v and true or false end)
            y = stepper(p, y, "Deckkraft des Grunds (%)", function() return c.alpha end,
                function(n) if ns.CenterBlock and ns.CenterBlock.SetAlpha and ns.db.centerBlock.enabled then
                    ns.CenterBlock:SetAlpha(n) else c.alpha = n end end, 0, 100, 5)
            y = checkbox(p, y, "Wurzel um den Block" .. RELOAD, function() return c.wrap end,
                function(v) c.wrap = v and true or false end)
            y = y - 6
            y = heading(p, y, "Schwung und Zauber")
            y = checkbox(p, y, "Direkt über den Leisten stapeln", function() return c.stack end,
                function(v) c.stack = v and true or false end)
            y = checkbox(p, y, "So breit wie die Leisten" .. RELOAD, function() return c.matchWidth end,
                function(v) c.matchWidth = v and true or false end)
            y = checkbox(p, y, "Schwungtimer nur im Kampf", function() return c.swingCombatOnly end,
                function(v) c.swingCombatOnly = v and true or false end)
            y = button(p, y, "Alle wieder an den Block hängen", function()
                for _, k in ipairs({ "swingMain", "cast", "swingOff", "swingRanged" }) do
                    if ns.db.blizz[k] then ns.db.blizz[k].free = nil end
                end
                c.stack = true
            end)
            y = y - 6
            y = heading(p, y, "Erfahrung")
            y = checkbox(p, y, "EP-Balken unten im Grund" .. RELOAD, function() return c.xp end,
                function(v) c.xp = v and true or false end)
            return y
        end,
    },
    {
        key = "forms", title = "Gestalten", icon = "Interface\\Icons\\Ability_Racial_BearForm",
        short = "Gestalten, Auren, Haltungen",
        build = function(p)
            local y = pageHeader(p, "Interface\\Icons\\Ability_Racial_BearForm", "Gestalten",
                "Die kleine Leiste mit deinen Gestalten (Druide), Auren (Paladin) oder Haltungen. Die aktive leuchtet. Sie sitzt unten mittig in der rechten Tafel; verschiebst du sie selbst, bleibt sie dort.")
            y = checkbox(p, y, "Gestaltleiste anzeigen" .. RELOAD,
                function() return ns.db.stanceBar.enabled end, function(v) ns.db.stanceBar.enabled = v and true or false end)
            y = checkbox(p, y, "Alten Gestalt-Balken zusätzlich zeigen" .. RELOAD,
                function() return ns.db.formIndicator.enabled end, function(v) ns.db.formIndicator.enabled = v and true or false end)
            y = button(p, y, "Zurück an ihren Platz (rechte Tafel, unten mittig)", function()
                if ns.StanceBar then ns.StanceBar:BackToBoard() end
            end)
            return y
        end,
    },
    {
        key = "items", title = "Vorratsleiste", icon = "Interface\\Icons\\INV_Potion_54",
        short = "Deine eigene Leiste mit Tränken, Steinen, Essen",
        build = function(p)
            local idb = ns.db.itemBar
            local IB = ns.ItemBar
            local function rebuild() if IB then IB:Rebuild() end end
            local y = pageHeader(p, "Interface\\Icons\\INV_Potion_54", "Vorratsleiste",
                "Du bestimmst, was hineinkommt. Ist etwas aufgebraucht, bleibt das Fach grau stehen, bis du wieder welche hast.")

            -- Eintragen: Item-ID, Name oder Shift-Klick auf einen Gegenstand
            y = heading(p, y, "Gegenstand hinzufügen")
            local box = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
            box:SetSize(250, 24)
            box:SetPoint("TOPLEFT", PAGE_X + 10, y)
            box:SetAutoFocus(false)
            local hint = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            hint:SetPoint("LEFT", box, "LEFT", 4, 0)
            hint:SetText("Item-ID, Name oder Shift-Klick")
            local add = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            add:SetSize(110, 24)
            add:SetPoint("LEFT", box, "RIGHT", 10, 0)
            add:SetText("Hinzufügen")
            local msg = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            msg:SetPoint("TOPLEFT", box, "BOTTOMLEFT", -4, -6)
            msg:SetWidth(COL_W - 20)
            msg:SetJustifyH("LEFT")

            local grid -- unten
            local function doAdd()
                local ok, res = IB:AddItem(box:GetText())
                if ok then
                    msg:SetText("|cff59e659Hinzugefügt:|r " .. (IB:ItemName(res) or ("Item " .. res)))
                    box:SetText("")
                else
                    msg:SetText("|cffff7777" .. res .. "|r")
                end
                box:ClearFocus()
                if grid then grid.refresh() end
            end
            add:SetScript("OnClick", doAdd)
            box:SetScript("OnEnterPressed", doAdd)
            box:SetScript("OnEscapePressed", box.ClearFocus)
            box:SetScript("OnTextChanged", function(self) hint:SetShown(self:GetText() == "") end)
            -- Shift-Klick auf einen Gegenstand, während das Feld aktiv ist
            local function takeLink(link)
                if box:HasFocus() and type(link) == "string" and link:find("item:") then box:SetText(link) end
            end
            if ChatEdit_InsertLink then hooksecurefunc("ChatEdit_InsertLink", takeLink) end
            if HandleModifiedItemClick then hooksecurefunc("HandleModifiedItemClick", takeLink) end
            y = y - 52

            -- Was schon drin ist (Klick = entfernen)
            y = heading(p, y, "In deiner Leiste  |cff888888(Klick auf ein Fach: entfernen)|r")
            local ICON, PER_ROW, ROWS = 36, 12, 2
            grid = CreateFrame("Frame", nil, p)
            grid:SetPoint("TOPLEFT", PAGE_X + 6, y)
            grid:SetSize(PER_ROW * (ICON + 6), ROWS * (ICON + 6))
            grid.cells = {}
            local empty = grid:CreateFontString(nil, "OVERLAY", "GameFontDisable")
            empty:SetPoint("TOPLEFT", 2, -10)
            empty:SetText("Noch leer – trag oben etwas ein.")
            grid.refresh = function()
                local list = IB:GetPinnedList()
                empty:SetShown(#list == 0)
                for i = 1, PER_ROW * ROWS do
                    local c = grid.cells[i]
                    local id = list[i]
                    if id and not c then
                        c = CreateFrame("Button", nil, grid)
                        ns.SkinButton(c, ICON)
                        c:SetPoint("TOPLEFT", ((i - 1) % PER_ROW) * (ICON + 6), -math.floor((i - 1) / PER_ROW) * (ICON + 6))
                        c:SetScript("OnClick", function(self) IB:RemoveItem(self.itemID); grid.refresh() end)
                        c:SetScript("OnEnter", function(self)
                            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                            GameTooltip:SetItemByID(self.itemID)
                            GameTooltip:AddLine("Klick: aus der Leiste nehmen", 1, 0.5, 0.5)
                            GameTooltip:Show()
                        end)
                        c:SetScript("OnLeave", GameTooltip_Hide)
                        grid.cells[i] = c
                    end
                    if c then
                        c.itemID = id
                        if id then
                            c.icon:SetTexture(C_Item.GetItemIconByID and C_Item.GetItemIconByID(id) or select(5, C_Item.GetItemInfoInstant(id)))
                            c:Show()
                        else
                            c:Hide()
                        end
                    end
                end
            end
            p.refreshers[#p.refreshers + 1] = grid.refresh
            y = y - ROWS * (ICON + 6) - 8

            -- Optional: automatisch aus den Taschen auffüllen (zweispaltig)
            y = heading(p, y, "Zusätzlich automatisch auffüllen  |cff888888(optional)|r")
            local half = COL_W / 2
            local i = 0
            local rowY = y
            for _, c in ipairs(IB.CATS) do
                if c.key ~= "pinned" then
                    local col = i % 2
                    if col == 0 and i > 0 then rowY = rowY - 28 end
                    checkbox(p, rowY, c.label, function() return idb.cats[c.key] end, function(v)
                        if InCombatLockdown() then return false end
                        idb.cats[c.key] = v and true or false
                        rebuild()
                    end, col * half)
                    i = i + 1
                end
            end
            y = rowY - 34

            y = heading(p, y, "Aussehen")
            y = checkbox(p, y, "Senkrecht (4 übereinander, dann nächste Spalte)", function() return idb.vertical end, function(v)
                if InCombatLockdown() then return false end
                idb.vertical = v and true or false
                rebuild()
            end)
            y = checkbox(p, y, "Item-ID im Tooltip zeigen", function() return idb.showID end,
                function(v) idb.showID = v and true or false end)
            y = stepper(p, y, "Höchstens so viele Fächer (4 je Reihe)", function() return math.min(idb.max or 8, 8) end, function(n)
                if InCombatLockdown() then return end
                idb.max = n
                rebuild()
            end, 1, 8)
            return y
        end,
    },
    {
        key = "map", title = "Karte", icon = "Interface\\Icons\\INV_Misc_Map_01",
        short = "Größe der Karte, Addon-Knöpfe daneben",
        build = function(p)
            local y = pageHeader(p, "Interface\\Icons\\INV_Misc_Map_01", "Karte",
                "Die eckige Minikarte unten links. Oben links die Lupe (Kräutersuche usw.), unten links der Beutel mit deinen Addons.")
            y = stepper(p, y, "Größe der Karte", function() return ns.db.minimapFrame.size end, function(n)
                if ns.Minimap then ns.Minimap:SetSize(n) else ns.db.minimapFrame.size = n end
            end, 120, 320, 10)
            y = checkbox(p, y, "Addon-Beutel unten links in der Karte" .. RELOAD,
                function() return ns.db.buttonBag.enabled end, function(v) ns.db.buttonBag.enabled = v and true or false end)
            y = checkbox(p, y, "Einzelne runde Addon-Knöpfe verstecken" .. RELOAD,
                function() return ns.db.buttonBag.hideButtons end, function(v) ns.db.buttonBag.hideButtons = v and true or false end)
            y = checkbox(p, y, "Tafeln links und rechts der Karte" .. RELOAD,
                function() return ns.db.minimapFrame.boards end, function(v) ns.db.minimapFrame.boards = v and true or false end)
            y = stepper(p, y, "Breite der Tafeln" .. RELOAD, function() return ns.db.minimapFrame.boardWidth end,
                function(n) ns.db.minimapFrame.boardWidth = n end, 80, 300, 10)
            y = button(p, y, "Tafeln zurück an ihren Platz", function()
                ns.db.minimapFrame.boardLeft = {}
                ns.db.minimapFrame.boardRight = {}
                ReloadUI()
            end)
            y = checkbox(p, y, "Eckige Mondhain-Karte benutzen" .. RELOAD,
                function() return ns.db.minimapFrame.enabled end, function(v) ns.db.minimapFrame.enabled = v and true or false end)
            return y
        end,
    },
    {
        key = "chat", title = "Chat", icon = "Interface\\Icons\\INV_Misc_Note_01",
        short = "Größe und Reiter",
        build = function(p)
            local cdb = ns.db.chat
            local y = pageHeader(p, "Interface\\Icons\\INV_Misc_Note_01", "Chat",
                "Der schlanke Chat ohne Kasten. Er wächst nach oben und nach rechts, die Ecke links unten bleibt stehen.")
            y = stepper(p, y, "Breite", function() return cdb.width end,
                function(n) if ns.Chat then ns.Chat:SetSize(n, nil) else cdb.width = n end end, 200, 800, 10)
            y = stepper(p, y, "Höhe", function() return cdb.height end,
                function(n) if ns.Chat then ns.Chat:SetSize(nil, n) else cdb.height = n end end, 80, 500, 10)
            y = stepper(p, y, "Hintergrund (Deckkraft in %)", function() return cdb.bgAlpha end,
                function(n)
                    cdb.bgAlpha = n
                    if ns.Chat then ns.Chat:UpdateBackground() end
                end, 0, 90, 5)
            local colorBtn = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            colorBtn:SetSize(260, 26)
            colorBtn:SetPoint("TOPLEFT", PAGE_X + 4, y)
            local function colorText() colorBtn:SetText("Farbe: " .. (ns.Chat and ns.Chat:ColorLabel() or "Schwarz")) end
            colorBtn:SetScript("OnClick", function()
                if ns.Chat then ns.Chat:NextColor() end
                colorText()
            end)
            p.refreshers[#p.refreshers + 1] = colorText
            y = y - 34
            y = button(p, y, "Reiter neu einrichten", function()
                if ns.Chat then ns.Chat:SetupTabs() end
            end)
            y = checkbox(p, y, "Schlanken Chat benutzen" .. RELOAD,
                function() return cdb.enabled end, function(v) cdb.enabled = v and true or false end)
            return y
        end,
    },
    {
        key = "quests", title = "Quests", icon = "Interface\\Icons\\INV_Misc_Book_09",
        short = "Questtracker unten rechts",
        build = function(p)
            local qdb = ns.db.questTracker
            local y = pageHeader(p, "Interface\\Icons\\INV_Misc_Book_09", "Quests",
                "Der Questtracker unten rechts. Größe änderst du an der Ecke unten rechts, Zone und Sortierung oben links im Tracker.")
            y = checkbox(p, y, "Blizzards Questtracker ausblenden" .. RELOAD,
                function() return qdb.hideBlizzard end, function(v) qdb.hideBlizzard = v and true or false end)
            return y
        end,
    },
    {
        key = "layout", title = "Anordnung", icon = "Interface\\Icons\\INV_Misc_Wrench_01",
        short = "Alles verschieben, Grundaufstellung",
        build = function(p)
            local y = pageHeader(p, "Interface\\Icons\\INV_Misc_Wrench_01", "Anordnung",
                "Alles an seinen Platz ziehen. Mausrad über einem Teil macht es größer oder kleiner.")
            y = button(p, y, "Verschieben & Größe", function()
                panel:Hide()
                ns.SetUnlocked(true)
            end)
            y = button(p, y, "Grundaufstellung (lädt neu)", function()
                if InCombatLockdown() then ns.Print("Im Kampf nicht möglich.") return end
                ns.ApplyDefaultLayout()
                ReloadUI()
            end)
            y = y - 6
            y = checkbox(p, y, "Mikromenü, Taschen, Erfahrung usw. mit verwalten" .. RELOAD,
                function() return ns.db.manageBlizz end, function(v) ns.db.manageBlizz = v and true or false end)
            y = checkbox(p, y, "Holzrahmen um die Fenster", function() return ns.db.woodFrames ~= false end,
                function(v) ns.db.woodFrames = v and true or false; ns.SetWoodShown(ns.db.woodFrames) end)
            y = checkbox(p, y, "IDs im Tooltip (Zauber, Stärkungen, Gegenstände)",
                function() return ns.db.tooltip.ids ~= false end, function(v) ns.db.tooltip.ids = v and true or false end)
            y = checkbox(p, y, "Menüknopf unten rechts" .. RELOAD,
                function() return ns.db.menuButton.enabled end, function(v) ns.db.menuButton.enabled = v and true or false end)
            y = checkbox(p, y, "Händlerliste mit Suche und Filter (statt Seiten)" .. RELOAD,
                function() return ns.db.merchant.enabled end, function(v) ns.db.merchant.enabled = v and true or false end)
            return y
        end,
    },
    {
        key = "units", title = "Einheiten", icon = "Interface\\Icons\\Ability_Hunter_SniperShot",
        short = "Spieler, Ziel, Ziel des Ziels, Fokus",
        build = function(p)
            local u = ns.db.unitFrames
            local y = pageHeader(p, "Interface\\Icons\\Ability_Hunter_SniperShot", "Einheiten",
                "Spieler links und Ziel rechts neben den Leisten. Verschieben geht wie bei allem anderen über „Verschieben & Größe“.")
            y = checkbox(p, y, "Ziel spiegelgleich zum Spieler (gleiche Höhe)",
                function() return u.mirror ~= false end, function(v)
                    u.mirror = v and true or false
                    if v and ns.UnitFrames then ns.UnitFrames:Mirror("player", "target") end
                end)
            y = y - 6
            y = heading(p, y, "Porträts")
            y = checkbox(p, y, "Porträt beim Spieler" .. RELOAD,
                function() return u.player.portrait end, function(v) u.player.portrait = v and true or false end)
            y = checkbox(p, y, "Porträt beim Ziel" .. RELOAD,
                function() return u.target.portrait end, function(v) u.target.portrait = v and true or false end)
            y = y - 6
            y = heading(p, y, "Aussehen  |cff888888(wirkt sofort)|r")
            local l = u.look
            local function apply() if ns.UnitFrames then ns.UnitFrames:ApplyLook() end end
            y = stepper(p, y, "Farbstärke der Balken (%)", function() return l.colorPct end,
                function(n) l.colorPct = n; apply() end, 20, 100, 5)
            y = stepper(p, y, "Hintergrund hinter den Balken (%)", function() return l.barBgAlpha end,
                function(n) l.barBgAlpha = n; apply() end, 0, 100, 5)
            y = stepper(p, y, "Hintergrund des Fensters (%)", function() return l.frameAlpha end,
                function(n) l.frameAlpha = n; apply() end, 0, 100, 5)
            y = stepper(p, y, "Schriftgröße", function() return l.fontSize end,
                function(n) l.fontSize = n; apply() end, 9, 18)
            y = checkbox(p, y, "Dunkle Kontur um die Schrift", function() return l.outline end,
                function(v) l.outline = v and true or false; apply() end)
            y = y - 6
            y = heading(p, y, "Auren am Ziel  |cff888888(wirkt sofort)|r")
            local ta = u.targetAuras
            local function applyA() if ns.UnitFrames and ns.UnitFrames.RefreshAuras then ns.UnitFrames:RefreshAuras() end end
            y = checkbox(p, y, "Blizzards Symbole übernehmen (aktualisieren sich auch im Kampf)",
                function() return ta.blizzard ~= false end, function(v) ta.blizzard = v and true or false; applyA() end)
            y = stepper(p, y, "Symbolgröße (Pixel)", function() return ta.size or 22 end,
                function(n) ta.size = n; applyA() end, 16, 44, 2)
            y = stepper(p, y, "Höchstens so viele Symbole", function() return ta.max or 16 end,
                function(n) ta.max = n; applyA() end, 4, 32, 1)
            y = checkbox(p, y, "Schwächungen zeigen", function() return ta.debuffs ~= false end,
                function(v) ta.debuffs = v and true or false; applyA() end)
            y = checkbox(p, y, "  nur meine eigenen (im Kampf entscheidet Blizzard)", function() return ta.onlyMine end,
                function(v) ta.onlyMine = v and true or false; applyA() end)
            y = checkbox(p, y, "Stärkungen zeigen", function() return ta.buffs ~= false end,
                function(v) ta.buffs = v and true or false; applyA() end)
            y = checkbox(p, y, "  bei Gegnern nur bannbare (Magie)", function() return ta.enemyDispel end,
                function(v) ta.enemyDispel = v and true or false; applyA() end)
            y = y - 6
            y = heading(p, y, "Weitere Fenster")
            y = checkbox(p, y, "Ziel des Ziels" .. RELOAD,
                function() return u.targettarget.enabled end, function(v) u.targettarget.enabled = v and true or false end)
            y = checkbox(p, y, "Fokus" .. RELOAD,
                function() return u.focus.enabled end, function(v) u.focus.enabled = v and true or false end)
            y = checkbox(p, y, "Begleiter" .. RELOAD,
                function() return u.pet.enabled end, function(v) u.pet.enabled = v and true or false end)
            y = y - 6
            y = heading(p, y, "Mehr")
            y = checkbox(p, y, "PvP-Wappen am Rahmen, wenn jemand PvP-markiert ist",
                function() return u.pvpIcon ~= false end,
                function(v) u.pvpIcon = v and true or false; if ns.UnitFrames and ns.UnitFrames.RefreshPvP then ns.UnitFrames:RefreshPvP() end end)
            y = checkbox(p, y, "Blizzards eigene Spieler-/Zielfenster ausblenden" .. RELOAD,
                function() return u.hideBlizzard end, function(v) u.hideBlizzard = v and true or false end)
            y = checkbox(p, y, "Mondhain-Einheitenfenster benutzen" .. RELOAD,
                function() return u.enabled end, function(v) u.enabled = v and true or false end)
            return y
        end,
    },
    {
        key = "group", title = "Gruppe", icon = "Interface\\Icons\\Spell_Nature_Rejuvenation",
        short = "Gruppen- und Schlachtzugsrahmen, Klickzauber",
        build = function(p)
            local g = ns.db.groupFrames
            local G = ns.GroupFrames
            local y = pageHeader(p, "Interface\\Icons\\Spell_Nature_Rejuvenation", "Gruppe",
                "Linksklick auf einen Rahmen visiert an. Was die anderen Maustasten wirken, legst du hier fest.")
            y = checkbox(p, y, "Auch allein anzeigen (zum Einrichten)", function() return g.showSolo end,
                function(v) if G then return G:SetShowSolo(v and true or false) end end)
            -- Testmodus: ausgedachte Mitglieder
            local function testBtn(kind, label, xoff)
                local b = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
                b:SetSize(200, 26)
                b:SetPoint("TOPLEFT", PAGE_X + 4 + xoff, y)
                local function txt() b:SetText((G:IsTest(kind) and "Test aus: " or "Test an: ") .. label) end
                b:SetScript("OnClick", function()
                    if InCombatLockdown() then return end
                    G:SetTest(kind, not G:IsTest(kind))
                    txt()
                end)
                p.refreshers[#p.refreshers + 1] = txt
            end
            testBtn("party", "Gruppe", 0)
            testBtn("raid", "Schlachtzug", 210)
            y = y - 34
            y = y - 4
            y = heading(p, y, "Klickzauber  |cff888888(Zauber aus dem Zauberbuch aufs Feld ziehen oder Namen tippen)|r")
            for _, row in ipairs(G.CLICK_ROWS) do
                local t = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
                t:SetPoint("TOPLEFT", PAGE_X + 6, y - 5)
                t:SetText(row.label)
                local box = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
                box:SetSize(250, 22)
                box:SetPoint("TOPLEFT", PAGE_X + 200, y)
                box:SetAutoFocus(false)
                local function save()
                    local txt = (box:GetText() or ""):gsub("^%s+", ""):gsub("%s+$", "")
                    g.clicks[row.key] = (txt ~= "") and txt or nil
                end
                local function takeSpell()
                    local kind, a, b, spellID = GetCursorInfo()
                    if kind ~= "spell" then return end
                    local name = spellID and C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(spellID)
                    if not name and a and C_SpellBook and C_SpellBook.GetSpellBookItemName then
                        name = C_SpellBook.GetSpellBookItemName(a, b)
                    end
                    if not name and a and GetSpellBookItemName then name = GetSpellBookItemName(a, b) end
                    ClearCursor()
                    if name then box:SetText(name); save() end
                end
                box:SetScript("OnReceiveDrag", takeSpell)
                box:HookScript("OnMouseDown", takeSpell)
                box:SetScript("OnEnterPressed", function(self) save(); self:ClearFocus() end)
                box:SetScript("OnEditFocusLost", save)
                box:SetScript("OnEscapePressed", box.ClearFocus)
                p.refreshers[#p.refreshers + 1] = function() box:SetText(g.clicks[row.key] or "") end
                y = y - 26
            end
            y = y - 4
            y = button(p, y, "Übernehmen (lädt neu)", function()
                if InCombatLockdown() then ns.Print("Im Kampf nicht möglich.") return end
                ReloadUI()
            end)
            y = heading(p, y, "Mehr")
            y = checkbox(p, y, "Blizzards Gruppen-/Schlachtzugsrahmen ausblenden" .. RELOAD,
                function() return g.hideBlizzard end, function(v) g.hideBlizzard = v and true or false end)
            y = checkbox(p, y, "Mondhain-Gruppenfenster benutzen" .. RELOAD,
                function() return g.enabled end, function(v) g.enabled = v and true or false end)
            return y
        end,
    },
    {
        key = "auras", title = "Stärkungen", icon = "Interface\\Icons\\Spell_Nature_Regeneration",
        short = "Deine Stärkungen und Schwächungen oben rechts",
        build = function(p)
            local a = ns.db.auras
            local function refresh() if ns.PlayerAuras then ns.PlayerAuras:Refresh() end end
            local y = pageHeader(p, "Interface\\Icons\\Spell_Nature_Regeneration", "Stärkungen",
                "Oben rechts: Stärkungen, darunter Schwächungen. Rechtsklick auf eine Stärkung entfernt sie (nur außerhalb des Kampfes).")
            y = stepper(p, y, "Größe der Symbole", function() return a.size end,
                function(n) a.size = n; refresh() end, 24, 64, 2)
            y = stepper(p, y, "Symbole pro Reihe", function() return a.perRow end,
                function(n) a.perRow = n; refresh() end, 4, 20)
            y = checkbox(p, y, "Restzeit unter dem Symbol", function() return a.showTime end,
                function(v) a.showTime = v and true or false; refresh() end)
            local tb = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            tb:SetSize(260, 26)
            tb:SetPoint("TOPLEFT", PAGE_X + 4, y)
            local PA = ns.PlayerAuras
            local function tbText() tb:SetText(PA:IsTest() and "Test aus" or "Test an: je zwei Reihen") end
            tb:SetScript("OnClick", function()
                if InCombatLockdown() then return end
                PA:SetTest(not PA:IsTest())
                tbText()
            end)
            p.refreshers[#p.refreshers + 1] = tbText
            y = y - 34
            y = checkbox(p, y, "Blizzards eigene Stärkungsleiste ausblenden" .. RELOAD,
                function() return a.hideBlizzard end, function(v) a.hideBlizzard = v and true or false end)
            y = checkbox(p, y, "Mondhain-Stärkungen benutzen" .. RELOAD,
                function() return a.enabled end, function(v) a.enabled = v and true or false end)
            return y
        end,
    },
    {
        key = "branch", title = "Ast", icon = "Interface\\Icons\\Ability_Druid_ManaTree",
        short = "Teldrassil-Ast über allem am unteren Rand",
        build = function(p)
            local b = ns.db.branch
            local function refresh() if ns.Branch and ns.Branch.Refresh then ns.Branch:Refresh() end end
            local y = pageHeader(p, "Interface\\Icons\\Ability_Druid_ManaTree", "Ast",
                "Ein durchgehender Ast von links nach rechts legt sich über Chat, Tafeln, Karte, Leisten und Quests. Darunter ist alles Stamm. Spieler und Ziel bleiben draußen.")
            y = checkbox(p, y, "Teldrassil-Ast (ersetzt die Wurzel)" .. RELOAD, function() return b.enabled end,
                function(v) b.enabled = v and true or false end)
            y = stepper(p, y, "Dicke des Asts", function() return b.thickness end,
                function(n) b.thickness = n; refresh() end, 16, 60, 2)
            y = stepper(p, y, "Höhen und Tiefen", function() return b.wave end,
                function(n) b.wave = n; refresh() end, 0, 14, 1)
            y = stepper(p, y, "Deckkraft des Stamms (%)", function() return b.fillAlpha end,
                function(n) b.fillAlpha = n; refresh() end, 0, 100, 5)
            y = stepper(p, y, "Helligkeit der Rinde (%)", function() return b.fillBright end,
                function(n) b.fillBright = n; refresh() end, 30, 130, 5)
            -- Farbstimmung durchschalten
            local palBtn = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            palBtn:SetSize(260, 26)
            palBtn:SetPoint("TOPLEFT", PAGE_X + 4, y)
            local function palText()
                local P = ns.Branch and ns.Branch.PALETTES
                local e = P and P[b.palette or "mahagoni"]
                palBtn:SetText("Farbstimmung: " .. (e and e.label or "Mahagoni"))
            end
            palBtn:SetScript("OnClick", function()
                local order = ns.Branch and ns.Branch.PALETTE_ORDER
                if not order then return end
                local idx = 1
                for i, k in ipairs(order) do if k == (b.palette or "mahagoni") then idx = i end end
                b.palette = order[idx % #order + 1]
                b.palettePicked = true
                palText()
                refresh()
            end)
            p.refreshers[#p.refreshers + 1] = palText
            y = y - 34
            -- Mittelstück des Gewands (z. B. Paladin: Silberne Hand, Hammer, Libram)
            local crestBtn = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            crestBtn:SetSize(260, 26)
            crestBtn:SetPoint("TOPLEFT", PAGE_X + 4, y)
            local function crestList()
                local P = ns.Branch and ns.Branch.PALETTES
                local e = P and P[b.palette or "mahagoni"]
                local a = e and type(e.arch) == "table" and e.arch
                return a and type(a.crests) == "table" and #a.crests > 0 and a.crests or nil
            end
            local function crestText()
                local list = crestList()
                if not list then
                    crestBtn:SetText("Mittelstück: – (nur mit Gewand)")
                    crestBtn:Disable()
                    return
                end
                crestBtn:Enable()
                local cur = list[1]
                for _, c in ipairs(list) do if c.key == b.crest then cur = c end end
                crestBtn:SetText("Mittelstück: " .. (cur.label or cur.key))
            end
            crestBtn:SetScript("OnClick", function()
                local list = crestList()
                if not list then return end
                local idx = 1
                for i, c in ipairs(list) do if c.key == b.crest then idx = i end end
                b.crest = list[idx % #list + 1].key
                crestText()
                refresh()
            end)
            palBtn:HookScript("OnClick", crestText)
            p.refreshers[#p.refreshers + 1] = crestText
            y = y - 34
            y = y - 6
            y = heading(p, y, "Schmuck")
            y = checkbox(p, y, "Schatten und Glanzkante (Tiefe)", function() return b.depth ~= false end,
                function(v) b.depth = v and true or false; refresh() end)
            y = checkbox(p, y, "Ranken mit Schnörkeln", function() return b.tendrils ~= false end,
                function(v) b.tendrils = v and true or false; refresh() end)
            y = checkbox(p, y, "Mondsichel / Mittelstück auf der Krone", function() return b.moon ~= false end,
                function(v) b.moon = v and true or false; refresh() end)
            y = checkbox(p, y, "Erfahrungs-Ast über den Quests (Liane wächst mit den EP)" .. RELOAD,
                function() return b.xpBranch ~= false end, function(v) b.xpBranch = v and true or false end)
            y = checkbox(p, y, "Ruf-Ast darüber (blaue Liane, verfolgte Fraktion)" .. RELOAD,
                function() return b.repBranch ~= false end, function(v) b.repBranch = v and true or false end)
            y = checkbox(p, y, "Zauber-Ast statt Zauberleiste (rechts der Karte)" .. RELOAD,
                function() return b.castBranch ~= false end, function(v) b.castBranch = v and true or false end)
            y = checkbox(p, y, "Efeu-Büschel am Ast", function() return b.leaves ~= false end,
                function(v) b.leaves = v and true or false; refresh() end)
            y = checkbox(p, y, "Irrlichter", function() return b.wisps ~= false end,
                function(v) b.wisps = v and true or false; refresh() end)
            return y
        end,
    },
    {
        key = "root", title = "Wurzel", icon = "Interface\\Icons\\Spell_Nature_StrangleVines",
        short = "Wurzel am Boden, EP-Ranke",
        build = function(p)
            local r = ns.db.root
            local y = pageHeader(p, "Interface\\Icons\\Spell_Nature_StrangleVines", "Wurzel",
                "Die alte Wurzel am unteren Rand. Wirkt nur, wenn der Ast (Seite „Ast“) aus ist.")
            y = stepper(p, y, "Dicke des Strangs" .. RELOAD, function() return r.thickness end,
                function(n) r.thickness = n end, 12, 48, 2)
            y = checkbox(p, y, "Wurzelbogen über die Leisten" .. RELOAD, function() return r.arch end,
                function(v) r.arch = v and true or false end)
            y = stepper(p, y, "Höhe des Bogens" .. RELOAD, function() return r.archHeight end,
                function(n) r.archHeight = n end, 80, 260, 5)
            y = checkbox(p, y, "Wurzelbett auch rechts" .. RELOAD, function() return r.bedRight end,
                function(v) r.bedRight = v and true or false end)
            y = stepper(p, y, "Höhe rechts" .. RELOAD, function() return r.bedHeightRight end,
                function(n) r.bedHeightRight = n end, 80, 400, 10)
            y = checkbox(p, y, "Wurzelbett links hinter Chat und Karte" .. RELOAD, function() return r.bed end,
                function(v) r.bed = v and true or false end)
            y = stepper(p, y, "Höhe des Wurzelbetts" .. RELOAD, function() return r.bedHeight end,
                function(n) r.bedHeight = n end, 100, 400, 10)
            y = checkbox(p, y, "Wurzel um den Questtracker" .. RELOAD, function() return r.questWrap end,
                function(v) r.questWrap = v and true or false end)
            y = checkbox(p, y, "Wurzel um die Tafeln" .. RELOAD, function() return r.wrapBoards end,
                function(v) r.wrapBoards = v and true or false end)
            y = stepper(p, y, "Dicke der Umrankung" .. RELOAD, function() return r.wrapThickness end,
                function(n) r.wrapThickness = n end, 12, 48, 2)
            y = checkbox(p, y, "Knoten um die Kartenecke" .. RELOAD, function() return r.knot end,
                function(v) r.knot = v and true or false end)
            y = checkbox(p, y, "Triebe hinter Spieler und Ziel" .. RELOAD, function() return r.shoots end,
                function(v) r.shoots = v and true or false end)
            y = checkbox(p, y, "EP-Ranke in der Mulde" .. RELOAD, function() return r.xp end,
                function(v) r.xp = v and true or false end)
            y = checkbox(p, y, "Blizzards EP-Balken ausblenden" .. RELOAD, function() return r.hideXPBar end,
                function(v) r.hideXPBar = v and true or false end)
            y = checkbox(p, y, "Wurzel anzeigen" .. RELOAD, function() return r.enabled end,
                function(v) r.enabled = v and true or false end)
            y = button(p, y, "Neu laden", function()
                if InCombatLockdown() then return end
                ReloadUI()
            end)
            return y
        end,
    },
    {
        key = "combat", title = "Kampf", icon = "Interface\\Icons\\Ability_Druid_Rake",
        short = "Anzeige bei Kampfbeginn und -ende",
        build = function(p)
            local c = ns.db.combatAlert
            local CA = ns.CombatAlert
            local y = pageHeader(p, "Interface\\Icons\\Ability_Druid_Rake", "Kampf",
                "Kurze Anzeige mitten im Bild, wenn ein Kampf beginnt oder endet – und gekreuzte Schwerter am Spielerfenster, solange du kämpfst.")
            y = checkbox(p, y, "Anzeige mitten im Bild" .. RELOAD, function() return c.enabled end,
                function(v) c.enabled = v and true or false end)
            y = checkbox(p, y, "Schwerter am Spielerfenster im Kampf", function() return ns.db.unitFrames.combatIcon ~= false end,
                function(v) ns.db.unitFrames.combatIcon = v and true or false end)
            y = checkbox(p, y, "Ton bei Kampfbeginn", function() return c.sound end,
                function(v) c.sound = v and true or false end)
            y = y - 4
            y = heading(p, y, "Texte")
            local function textRow(label, key)
                local t = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
                t:SetPoint("TOPLEFT", PAGE_X + 6, y - 5)
                t:SetText(label)
                local box = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
                box:SetSize(250, 22)
                box:SetPoint("TOPLEFT", PAGE_X + 150, y)
                box:SetAutoFocus(false)
                local function save() c[key] = box:GetText() end
                box:SetScript("OnEnterPressed", function(self) save(); self:ClearFocus() end)
                box:SetScript("OnEditFocusLost", save)
                box:SetScript("OnEscapePressed", box.ClearFocus)
                p.refreshers[#p.refreshers + 1] = function() box:SetText(c[key] or "") end
                y = y - 28
            end
            textRow("Kampfbeginn", "textIn")
            textRow("Kampfende", "textOut")
            y = y - 4
            y = heading(p, y, "Vorschau")
            local b1 = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            b1:SetSize(200, 26); b1:SetPoint("TOPLEFT", PAGE_X + 4, y); b1:SetText("Kampfbeginn zeigen")
            b1:SetScript("OnClick", function() if CA then CA:Play(true) end end)
            local b2 = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            b2:SetSize(200, 26); b2:SetPoint("TOPLEFT", PAGE_X + 214, y); b2:SetText("Kampfende zeigen")
            b2:SetScript("OnClick", function() if CA then CA:Play(false) end end)
            y = y - 34
            y = y - 6
            y = heading(p, y, "Stufenaufstieg")
            local lu = ns.db.levelUp
            y = checkbox(p, y, "Animation beim Stufenaufstieg (Blitz, Stufe, Zeichen der Spezialisierung)",
                function() return lu.enabled ~= false end, function(v) lu.enabled = v and true or false end)
            y = checkbox(p, y, "Blizzards eigenes Stufenbanner ausblenden",
                function() return lu.hideBlizzard ~= false end, function(v) lu.hideBlizzard = v and true or false end)
            y = button(p, y, "Vorschau", function() if ns.LevelUp then ns.LevelUp:Play(UnitLevel("player")) end end)
            return y
        end,
    },
    {
        key = "loot", title = "Beute", icon = "Interface\\Icons\\INV_Misc_Bag_10_Green",
        short = "Automatisch plündern, Hinweis bei guter Beute",
        build = function(p)
            local L = ns.db.loot
            local y = pageHeader(p, "Interface\\Icons\\INV_Misc_Bag_10_Green", "Beute",
                "Alles wird automatisch geplündert. Bei guter Beute kommt ein kleiner Hinweis, woher sie stammt – und der Gegenstand merkt sich das für später im Tooltip.")
            y = checkbox(p, y, "Beute-Teil an" .. RELOAD, function() return L.enabled end,
                function(v) L.enabled = v and true or false end)
            y = checkbox(p, y, "Automatisch plündern", function() return L.autoLoot end,
                function(v) if ns.Loot then ns.Loot:SetAutoLoot(v) else L.autoLoot = v and true or false end end)
            y = checkbox(p, y, "Hinweis bei guter Beute", function() return L.popups ~= false end,
                function(v) L.popups = v and true or false end)
            y = checkbox(p, y, "Herkunft im Gegenstands-Tooltip", function() return L.tooltip ~= false end,
                function(v) L.tooltip = v and true or false end)
            y = y - 4
            local q = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
            q:SetSize(260, 26)
            q:SetPoint("TOPLEFT", PAGE_X + 4, y)
            local function qText()
                local name = ns.Loot and ns.Loot:QualityName(L.minQuality or 2) or tostring(L.minQuality)
                q:SetText("Hinweis ab: " .. name .. " (klicken zum Wechseln)")
            end
            q:SetScript("OnClick", function()
                if ns.Loot then ns.Loot:CycleQuality() end
                qText()
            end)
            p.refreshers[#p.refreshers + 1] = qText
            y = y - 34
            y = heading(p, y, "Ausprobieren")
            y = button(p, y, "Probe-Hinweis zeigen", function() if ns.Loot then ns.Loot:Test() end end)
            y = button(p, y, "Letzte Beute im Chat auflisten", function() if ns.Loot then ns.Loot:List() end end)
            return y
        end,
    },
    {
        key = "quests", title = "Quests", icon = "Interface\\Icons\\INV_Misc_Book_08",
        short = "Automatisch annehmen/abgeben, Meldungen",
        build = function(p)
            local qh = ns.db.questHelp
            local y = pageHeader(p, "Interface\\Icons\\INV_Misc_Book_08", "Quests",
                "Alles rund um Quests an einem Ort: automatisch annehmen und abgeben, Fortschritt melden, Hilfen im Questlog. Shift beim Ansprechen eines NPCs schaltet die Automatik für dieses eine Mal ab.")
            y = heading(p, y, "Automatik")
            y = checkbox(p, y, "Quests automatisch annehmen",
                function() return qh.autoAccept ~= false end, function(v) qh.autoAccept = v and true or false end)
            y = checkbox(p, y, "Quests automatisch abgeben (gibt es Belohnungen zur Wahl, wählst du selbst)",
                function() return qh.autoTurnIn ~= false end, function(v) qh.autoTurnIn = v and true or false end)
            y = y - 4
            y = heading(p, y, "Quests melden")
            y = checkbox(p, y, "Meldungen an",
                function() return qh.announce ~= false end, function(v) qh.announce = v and true or false end)
            y = checkbox(p, y, "      Quest angenommen (nur der Titel)",
                function() return qh.announceAccept ~= false end, function(v) qh.announceAccept = v and true or false end)
            y = checkbox(p, y, "      Zwischenstände (z. B. 3/8 getötet)",
                function() return qh.announceProgress == true end, function(v) qh.announceProgress = v and true or false end)
            y = checkbox(p, y, "      Quest fertig (erst wenn alle Ziele erfüllt sind)",
                function() return qh.announceDone ~= false end, function(v) qh.announceDone = v and true or false end)
            y = y - 4
            y = checkbox(p, y, "      an mich (nur im eigenen Chat, z. B. allein unterwegs)",
                function() return qh.announceSelf == true end, function(v) qh.announceSelf = v and true or false end)
            y = checkbox(p, y, "      an die Gruppe",
                function() return qh.announceParty ~= false end, function(v) qh.announceParty = v and true or false end)
            y = checkbox(p, y, "      an den Schlachtzug",
                function() return qh.announceRaid == true end, function(v) qh.announceRaid = v and true or false end)
            y = y - 4
            y = heading(p, y, "Im Questlog")
            y = checkbox(p, y, "Beste Belohnung (Verkaufswert) mit Münze markieren",
                function() return qh.bestReward ~= false end, function(v) qh.bestReward = v and true or false end)
            y = checkbox(p, y, "Zeigen, wer aus der Gruppe die Quest auch hat",
                function() return qh.party ~= false end, function(v) qh.party = v and true or false end)
            return y
        end,
    },
    {
        key = "watch", title = "Wächter", icon = "Interface\\Icons\\Spell_Nature_Thorns",
        short = "Nachbuffen-Erinnerung, Zeiten am Gegner",
        build = function(p)
            local w = ns.db.watch
            local W = ns.Watch
            local y = pageHeader(p, "Interface\\Icons\\Spell_Nature_Thorns", "Wächter",
                "Fehlt eine deiner Stärkungen, springt ihr Symbol über der Bildmitte auf und blinkt, bis sie wieder drauf ist. Blutung und Feenfeuer laufen als Balken zwischen Spieler- und Zielrahmen. Im Kampf rechnet Mondhain mit, weil Forever Auren dann nicht verrät.")
            y = checkbox(p, y, "Wächter an" .. RELOAD, function() return w.enabled end,
                function(v) w.enabled = v and true or false end)
            y = y - 4
            y = heading(p, y, "Nachbuffen")
            for _, e in ipairs(W and W:Entries("remind") or {}) do
                local label = e.label or e.name or e.key
                if e.key == "food" then label = label .. "  |cff888888(Essen)|r" end
                y = checkbox(p, y, label, function()
                    if e.defaultOff then return w.remind[e.key] == true end
                    return w.remind[e.key] ~= false
                end, function(v) w.remind[e.key] = v and true or false end)
                y = checkbox(p, y, "      eigener Platz (einzeln verschiebbar)", function() return W:IsOwn(e.key) end,
                    function(v) W:SetOwn(e.key, v) end)
            end
            y = checkbox(p, y, "In Städten und Gasthäusern ausblenden",
                function() return w.hideResting ~= false end, function(v) w.hideResting = v and true or false end)
            y = checkbox(p, y, "Ruhige Vorwarnung 30 s vor dem Auslaufen (außerhalb des Kampfs)",
                function() return (w.warnBefore or 0) > 0 end, function(v) w.warnBefore = v and 30 or 0 end)
            y = y - 4
            y = heading(p, y, "Zeiten am Gegner")
            for _, e in ipairs(W and W:Entries("dots") or {}) do
                y = checkbox(p, y, e.name or e.key, function() return w.dots[e.key] ~= false end,
                    function(v) w.dots[e.key] = v and true or false end)
            end
            y = y - 4
            y = heading(p, y, "Ausprobieren")
            y = button(p, y, "Probe zeigen (8 Sekunden)", function() if W then W:Test() end end)
            return y
        end,
    },
    {
        key = "keys", title = "Tasten belegen", icon = "Interface\\Icons\\INV_Misc_Key_03",
        short = "Maus auf eine Taste, Taste drücken",
        action = function()
            panel:Hide()
            if ns.KeyBind then ns.KeyBind:SetActive(true) end
        end,
    },
}

---------------------------------------------------------------------------
-- Übersicht mit Kacheln
---------------------------------------------------------------------------
local TILE_W, TILE_H, GAP, COLS = 126, 128, 12, 5

local function makeTile(parent, area, i)
    local col = (i - 1) % COLS
    local row = math.floor((i - 1) / COLS)
    local t = CreateFrame("Button", nil, parent, "BackdropTemplate")
    t:SetSize(TILE_W, TILE_H)
    t:SetPoint("TOPLEFT", 26 + col * (TILE_W + GAP), -92 - row * (TILE_H + GAP))
    t:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    t:SetBackdropColor(0.09, 0.08, 0.06, 0.9)
    t:SetBackdropBorderColor(unpack(ns.colors.border))

    local ic = t:CreateTexture(nil, "ARTWORK")
    ic:SetSize(52, 52)
    ic:SetPoint("TOP", 0, -14)
    ic:SetTexture(area.icon)
    ic:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local title = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", ic, "BOTTOM", 0, -8)
    title:SetText(area.title)
    title:SetTextColor(unpack(ORANGE))

    local d = t:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    d:SetPoint("TOP", title, "BOTTOM", 0, -4)
    d:SetWidth(TILE_W - 16)
    d:SetText(area.short)
    d:SetTextColor(0.7, 0.68, 0.62)

    t:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(1, 0.49, 0.04, 1)
        self:SetBackdropColor(0.16, 0.11, 0.06, 0.95)
    end)
    t:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(unpack(ns.colors.border))
        self:SetBackdropColor(0.09, 0.08, 0.06, 0.9)
    end)
    t:SetScript("OnClick", function()
        if area.action then area.action() else mod:ShowPage(area) end
    end)
end

local function buildHome()
    home = CreateFrame("Frame", nil, panel)
    home:SetAllPoints()
    local t = home:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    t:SetPoint("TOP", 0, -22)
    t:SetText("Mondhain")
    t:SetTextColor(unpack(ORANGE))
    local s = home:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    s:SetPoint("TOP", t, "BOTTOM", 0, -8)
    s:SetText("Wohin willst du?")
    s:SetTextColor(0.78, 0.76, 0.70)
    for i, area in ipairs(AREAS) do makeTile(home, area, i) end
    local tilesBottom = 92 + math.ceil(#AREAS / COLS) * (TILE_H + GAP)

    -- Großer Knopf unten mittig: alles verschieben und skalieren
    local move = CreateFrame("Button", nil, home, "UIPanelButtonTemplate")
    move:SetSize(280, 34)
    move:SetPoint("TOP", home, "TOP", 0, -tilesBottom - 4)
    move:SetText(ns.IconText(18) .. "  Verschieben & Größe")
    move:SetScript("OnClick", function()
        panel:Hide()
        ns.SetUnlocked(true)
    end)
    move:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Alles neu anordnen", 1, 0.82, 0)
        GameTooltip:AddLine("Ziehen: verschieben · Mausrad: Größe · Rechtsklick: 100 %", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    move:SetScript("OnLeave", GameTooltip_Hide)
    home.height = tilesBottom + 4 + 34 + 18
end

---------------------------------------------------------------------------
-- Umschalten
---------------------------------------------------------------------------
function mod:ShowHome()
    if current then current:Hide() end
    current = nil
    home:Show()
    panel:SetHeight(home.height)
end

function mod:ShowPage(area)
    local p = pages[area.key]
    if not p then
        p = newPage()
        p.height = -area.build(p) + 16
        pages[area.key] = p
    end
    home:Hide()
    if current then current:Hide() end
    current = p
    for _, r in ipairs(p.refreshers) do r() end
    p:Show()
    panel:SetHeight(math.max(p.height, 260))
end

local function build()
    panel = CreateFrame("Frame", "MondhainOptions", UIParent, "BackdropTemplate")
    panel:SetFrameStrata("FULLSCREEN_DIALOG") -- über den Verschiebe-Schablonen
    panel:SetToplevel(true)
    panel:HookScript("OnShow", function(self) self:Raise() end)
    panel:SetPoint("CENTER")
    panel:SetWidth(W)
    panel:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 2 })
    panel:SetBackdropColor(0.04, 0.05, 0.05, 0.96)
    panel:SetBackdropBorderColor(0, 0, 0, 0)
    ns.WoodFrame(panel, 30)
    panel:EnableMouse(true)
    panel:SetMovable(true)
    panel:SetClampedToScreen(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", panel.StartMoving)
    panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
    tinsert(UISpecialFrames, "MondhainOptions")

    local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 2, 2)
    close:SetFrameLevel(panel:GetFrameLevel() + 20)

    buildHome()
    panel:Hide()
end

-- Optionen direkt auf einer Seite öffnen, z. B. ns.OpenOptions("chat")
function ns.OpenOptions(key)
    if not panel then build() end
    panel:SetFrameStrata("FULLSCREEN_DIALOG")
    panel:Raise()
    for _, area in ipairs(AREAS) do
        if area.key == key and area.build then
            mod:ShowPage(area)
            panel:Show()
            return
        end
    end
    mod:ShowHome()
    panel:Show()
end

function ns.ToggleOptions()
    if not panel then build() end
    if panel:IsShown() then
        panel:Hide()
    else
        mod:ShowHome() -- immer mit der Übersicht beginnen
        panel:Show()
    end
end
