-- Mondhain – Beute
-- · Automatisch plündern (Blizzards eigene Einstellung, hier an/aus).
-- · Bei guter Beute (ab Grün, einstellbar Blau/Lila) ein kleiner Hinweis im
--   Mondhain-Look: Symbol, Name in Qualitätsfarbe, woher (Gegner bzw. Sammeln,
--   Gebiet). Grau und Weiß bleiben still.
-- · „Wo hab ich das her?“: Der Gegenstands-Tooltip zeigt später die Herkunft
--   (Beute: Wildschrammyeti · Feralas · 24.11. 18:31). /mh beute listet die
--   letzten Funde im Chat.

local _, ns = ...
local mod = ns.NewModule("Loot")
ns.Loot = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local QUALITY_NAMES = { [2] = "Grün", [3] = "Blau", [4] = "Lila" }
local MAX_TOASTS, LIFE = 5, 7

local db
local anchor
local toasts, pool = {}, {}
local pending = {}               -- [itemID] = { source, zone, t }
local lastSpell, lastSpellT
local lastQuestT

local function safe(v)
    if v == nil or ns.isSecret(v) then return nil end
    return v
end

local function zoneName()
    local z = safe(GetZoneText and GetZoneText())
    if z == "" then z = nil end
    return z
end

local function itemID(link)
    if type(link) ~= "string" then return end
    return tonumber(link:match("item:(%d+)"))
end

-- Qualität aus der Farbe des Links (falls das Spiel den Gegenstand noch nicht kennt)
local function qualityFromLink(link)
    local hex = link:match("|c(%x%x%x%x%x%x%x%x)")
    if not hex or not ITEM_QUALITY_COLORS then return end
    hex = hex:lower()
    for q = 0, 7 do
        local c = ITEM_QUALITY_COLORS[q]
        if c and c.hex and c.hex:lower():find(hex, 1, true) then return q end
    end
end

local function qualityOf(link, id)
    local q
    if id and C_Item and C_Item.GetItemQualityByID then
        local ok, v = pcall(C_Item.GetItemQualityByID, id)
        if ok then q = safe(v) end
    end
    if not q then
        local getInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
        if getInfo then
            local ok, _, _, v = pcall(getInfo, link)
            if ok then q = safe(v) end
        end
    end
    return q or qualityFromLink(link)
end

---------------------------------------------------------------------------
-- Herkunft merken: beim Öffnen der Beute steht fest, von wem sie kommt
---------------------------------------------------------------------------
local GATHER = { "Kräuter", "Bergbau", "Kürschn", "Angeln", "Öffnen", "Schlossknacken",
    "Herb", "Mining", "Skinning", "Fishing", "Opening", "Pick Lock" }

local function lootSource()
    local src
    local ok, name = pcall(function()
        if UnitExists("target") and UnitIsDead("target") then return UnitName("target") end
    end)
    if ok then src = safe(name) end
    if lastSpell and lastSpellT and GetTime() - lastSpellT < 8 then
        for _, w in ipairs(GATHER) do
            if lastSpell:find(w, 1, true) then
                src = src and (lastSpell .. ": " .. src) or lastSpell
                break
            end
        end
    end
    return src
end

local function onLootReady()
    local src, zone, now = lootSource(), zoneName(), GetTime()
    for k, v in pairs(pending) do
        if now - v.t > 300 then pending[k] = nil end
    end
    local n = GetNumLootItems and GetNumLootItems() or 0
    for i = 1, n do
        local ok, link = pcall(GetLootSlotLink, i)
        local id = ok and itemID(safe(link))
        if id then pending[id] = { source = src, zone = zone, t = now } end
    end
end

---------------------------------------------------------------------------
-- Gedächtnis: letzte Funde + Herkunft je Gegenstand (für den Tooltip)
---------------------------------------------------------------------------
local function record(link, id, count, source, zone)
    local now = time()
    table.insert(db.history, 1, { link = link, count = count, source = source, zone = zone, t = now })
    while #db.history > 100 do table.remove(db.history) end
    db.origin[id] = { s = source, z = zone, t = now }
    -- nicht endlos wachsen lassen: ab 800 Einträgen die ältesten 200 weg
    local n = 0
    for _ in pairs(db.origin) do n = n + 1 end
    if n > 800 then
        local list = {}
        for k, v in pairs(db.origin) do list[#list + 1] = { k, v.t or 0 } end
        table.sort(list, function(a, b) return a[2] < b[2] end)
        for i = 1, 200 do db.origin[list[i][1]] = nil end
    end
end

local function originText(o)
    local parts = {}
    if o.s then parts[#parts + 1] = o.s end
    if o.z then parts[#parts + 1] = o.z end
    if o.t then parts[#parts + 1] = date("%d.%m. %H:%M", o.t) end
    return table.concat(parts, " · ")
end

---------------------------------------------------------------------------
-- Hinweis-Kärtchen
---------------------------------------------------------------------------
local function layout()
    for i, t in ipairs(toasts) do
        t:ClearAllPoints()
        if i == 1 then
            t:SetPoint("BOTTOM", anchor, "BOTTOM", 0, 0)
        else
            t:SetPoint("BOTTOM", toasts[i - 1], "TOP", 0, 8)
        end
    end
end

local function release(t)
    t:Hide()
    for i, x in ipairs(toasts) do
        if x == t then table.remove(toasts, i) break end
    end
    pool[#pool + 1] = t
    layout()
end

local function makeToast()
    local t = CreateFrame("Button", nil, UIParent)
    t:SetSize(270, 48)
    t:SetFrameStrata("HIGH")
    t:RegisterForClicks("AnyUp")
    local bg = t:CreateTexture(nil, "BACKGROUND", nil, -8)
    bg:SetAllPoints()
    bg:SetColorTexture(0.04, 0.05, 0.05, 0.92)
    ns.WoodFrame(t, 12)
    t.edge = t:CreateTexture(nil, "BORDER")
    t.edge:SetSize(36, 36)
    t.edge:SetPoint("LEFT", 8, 0)
    t.icon = t:CreateTexture(nil, "ARTWORK")
    t.icon:SetPoint("TOPLEFT", t.edge, "TOPLEFT", 1, -1)
    t.icon:SetPoint("BOTTOMRIGHT", t.edge, "BOTTOMRIGHT", -1, 1)
    t.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    t.count = t:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    t.count:SetPoint("BOTTOMRIGHT", t.icon, "BOTTOMRIGHT", 1, 0)
    t.name = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    t.name:SetPoint("TOPLEFT", t.edge, "TOPRIGHT", 8, -2)
    t.name:SetPoint("RIGHT", -10, 0)
    t.name:SetJustifyH("LEFT")
    t.name:SetWordWrap(false)
    t.sub = t:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    t.sub:SetPoint("BOTTOMLEFT", t.edge, "BOTTOMRIGHT", 8, 2)
    t.sub:SetPoint("RIGHT", -10, 0)
    t.sub:SetJustifyH("LEFT")
    t.sub:SetWordWrap(false)
    t.sub:SetTextColor(0.72, 0.70, 0.64)
    t:SetScript("OnEnter", function(self)
        self.hover = true
        self:SetAlpha(1)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        pcall(GameTooltip.SetHyperlink, GameTooltip, self.link)
        GameTooltip:Show()
    end)
    t:SetScript("OnLeave", function(self)
        self.hover = false
        GameTooltip:Hide()
    end)
    t:SetScript("OnClick", function(self)
        -- Umschalt-Klick: in den Chat verlinken, sonst schließen
        if IsModifiedClick("CHATLINK") and ChatEdit_InsertLink then
            ChatEdit_InsertLink(self.link)
        else
            release(self)
        end
    end)
    t:SetScript("OnUpdate", function(self, el)
        self.age = self.age + el
        if self.hover then return end
        if self.age < 0.2 then
            self:SetAlpha(self.age / 0.2)
        elseif self.age > LIFE then
            local a = 1 - (self.age - LIFE) / 0.6
            if a <= 0 then release(self) else self:SetAlpha(a) end
        else
            self:SetAlpha(1)
        end
    end)
    return t
end

function mod:Show(link, count, source, zone, q)
    if not anchor then return end
    local t = table.remove(pool) or makeToast()
    local id = itemID(link)
    t.link = link
    t.age = 0
    t.hover = false
    local tex = id and ((C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id)) or (GetItemIcon and GetItemIcon(id)))
    t.icon:SetTexture(tex or 134400)
    local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q or 1]
    if c then t.edge:SetColorTexture(c.r, c.g, c.b, 1) else t.edge:SetColorTexture(0.5, 0.5, 0.5, 1) end
    t.name:SetText(link)
    t.count:SetText((count and count > 1) and count or "")
    local where = originText({ s = source, z = zone })
    t.sub:SetText(where ~= "" and ("aus " .. where) or "erbeutet")
    t:SetAlpha(0)
    t:Show()
    table.insert(toasts, 1, t)
    while #toasts > MAX_TOASTS do release(toasts[#toasts]) end
    layout()
end

---------------------------------------------------------------------------
-- Beute-Meldungen im Chat auswerten (deckt Leichen, Sammeln, Würfeln, Quests ab)
---------------------------------------------------------------------------
local SELF = {}
for _, g in ipairs({ "LOOT_ITEM_SELF", "LOOT_ITEM_SELF_MULTIPLE", "LOOT_ITEM_PUSHED_SELF",
    "LOOT_ITEM_PUSHED_SELF_MULTIPLE" }) do
    local fmt = _G[g]
    local p = type(fmt) == "string" and fmt:match("^(.-)%%s")
    if p and p ~= "" then SELF[#SELF + 1] = p end
end

local function onLootMsg(msg)
    if not db.enabled then return end
    local ok, link, count = pcall(function()
        local mine = false
        for _, p in ipairs(SELF) do
            if msg:sub(1, #p) == p then mine = true break end
        end
        if not mine then return end
        local l = msg:match("(|c%x+|Hitem:.-|h.-|h|r)")
        local c = tonumber(msg:match("|rx(%d+)") or "") or 1
        return l, c
    end)
    if not ok or not link then return end
    local id = itemID(link)
    if not id then return end
    local q = qualityOf(link, id)
    if not q or q < (db.minQuality or 2) then return end
    local src, zone
    local p = pending[id]
    if p and GetTime() - p.t < 120 then src, zone = p.source, p.zone end
    if not src and lastQuestT and GetTime() - lastQuestT < 5 then src = "Quest-Belohnung" end
    zone = zone or zoneName()
    record(link, id, count, src, zone)
    if db.popups ~= false then mod:Show(link, count, src, zone, q) end
end

---------------------------------------------------------------------------
-- Herkunft im Gegenstands-Tooltip
---------------------------------------------------------------------------
local function addOrigin(tt, id)
    if not db.enabled or db.tooltip == false or not id then return end
    local o = db.origin[id]
    if not o then return end
    tt:AddLine("Beute: " .. originText(o), 0.55, 0.85, 0.55)
end

local function hookTooltips()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
            if tt ~= GameTooltip and tt ~= ItemRefTooltip then return end
            pcall(addOrigin, tt, data and safe(data.id))
        end)
    else
        for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
            if tt and tt.HookScript then
                tt:HookScript("OnTooltipSetItem", function(self)
                    local _, link = self:GetItem()
                    pcall(addOrigin, self, itemID(safe(link)))
                end)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Einstellungen, Befehl
---------------------------------------------------------------------------
function mod:SetAutoLoot(on)
    db.autoLoot = on and true or false
    if SetCVar then pcall(SetCVar, "autoLootDefault", on and "1" or "0") end
end

function mod:QualityName(q) return QUALITY_NAMES[q] or tostring(q) end

function mod:CycleQuality()
    local q = (db.minQuality or 2) + 1
    if q > 4 then q = 2 end
    db.minQuality = q
    return q
end

function mod:Test()
    local id = 6256 -- Angelrute: kennt jeder Client
    local link = select(2, ((C_Item and C_Item.GetItemInfo) or GetItemInfo)(id))
        or "|cff1eff00|Hitem:6256::::::::1:::::::|h[Probe-Beute]|h|r"
    mod:Show(link, 1, "Wildschrammyeti", zoneName() or "Feralas", 2)
end

function mod:List()
    ns.Print("Letzte gute Beute:")
    if #db.history == 0 then print("  noch nichts") return end
    for i, e in ipairs(db.history) do
        if i > 15 then break end
        print(("  %s  %s%s – %s"):format(date("%d.%m. %H:%M", e.t), e.link,
            (e.count and e.count > 1) and ("x" .. e.count) or "", originText({ s = e.source, z = e.zone })))
    end
end

function mod:OnEnable()
    ns.db.loot = ns.db.loot or {}
    db = ns.db.loot
    db.history = db.history or {}
    db.origin = db.origin or {}
    if not db.enabled then return end

    anchor = CreateFrame("Frame", "MondhainLootAnchor", UIParent)
    anchor:SetSize(270, 48)
    local p = db.point or { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -300, 460 }
    anchor:SetPoint(p[1], UIParent, p[3], p[4], p[5])
    ns.MakeMovable(anchor, db, "Beute-Hinweise", nil, true)

    if db.autoLoot then mod:SetAutoLoot(true) end
    hookTooltips()

    local ev = CreateFrame("Frame")
    ev:RegisterEvent("LOOT_READY")
    ev:RegisterEvent("LOOT_OPENED")
    ev:RegisterEvent("CHAT_MSG_LOOT")
    ev:RegisterEvent("QUEST_TURNED_IN")
    ev:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")
    ev:RegisterUnitEvent("UNIT_SPELLCAST_START", "player")
    ev:SetScript("OnEvent", function(_, event, a1, _, a3)
        if event == "LOOT_READY" or event == "LOOT_OPENED" then
            pcall(onLootReady)
        elseif event == "CHAT_MSG_LOOT" then
            pcall(onLootMsg, a1)
        elseif event == "QUEST_TURNED_IN" then
            lastQuestT = GetTime()
        else
            -- Sammelzauber merken (Kräuter, Bergbau, Kürschnern, Angeln …)
            local spellID = a3
            local name
            if spellID and C_Spell and C_Spell.GetSpellName then
                local ok, n = pcall(C_Spell.GetSpellName, spellID)
                if ok then name = safe(n) end
            elseif spellID and GetSpellInfo then
                local ok, n = pcall(GetSpellInfo, spellID)
                if ok then name = safe(n) end
            end
            if type(name) == "string" then lastSpell, lastSpellT = name, GetTime() end
        end
    end)
end
