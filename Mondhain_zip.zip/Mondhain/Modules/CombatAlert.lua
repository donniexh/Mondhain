-- Mondhain – Kampfanzeige
-- Kampfbeginn:  „Kampf“ in Blizzards Fantasy-Schrift, Ranken wachsen von der
--               Mitte nach außen über und unter dem Wort, an den Enden öffnen
--               sich Blätter.
-- Kampfende:    „Kampf verlassen“ – die Ranken ziehen sich zur Mitte zurück,
--               dann verblasst das Wort.
-- Texte, Ton und Platz sind einstellbar (Optionen → Kampf).

local _, ns = ...
local mod = ns.NewModule("CombatAlert")
ns.CombatAlert = mod

local MEDIA = "Interface\\AddOns\\Mondhain\\media\\"
local FONT = "Fonts\\MORPHEUS.TTF"
local VINE_H = 30      -- Höhe einer Rankenbahn
local LEAF = 40        -- Größe der Blätterbüschel

local db, frame

---------------------------------------------------------------------------
-- Hilfen für den Ablauf
---------------------------------------------------------------------------
local function clamp(x) return x < 0 and 0 or (x > 1 and 1 or x) end
local function ease(x) x = clamp(x); return 1 - (1 - x) * (1 - x) end -- sanft auslaufend
local function phase(t, a, b) return clamp((t - a) / (b - a)) end

---------------------------------------------------------------------------
-- Aufbau
---------------------------------------------------------------------------
local function vine(parent, flipY)
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetTexture(MEDIA .. "ranke")
    t:SetHeight(VINE_H)
    t.flipY = flipY
    return t
end

local function leaf(parent, flipX, flipY)
    local t = parent:CreateTexture(nil, "OVERLAY")
    t:SetTexture(MEDIA .. "blaetter")
    t:SetSize(LEAF, LEAF)
    t.flipX, t.flipY = flipX, flipY
    local l, r = 0, 1
    local top, bot = 0, 1
    if flipX then l, r = 1, 0 end
    if flipY then top, bot = 1, 0 end
    t:SetTexCoord(l, r, top, bot)
    return t
end

-- Gewand (Ben 26.11. 08:15): Paladin bekommt Goldleisten statt Ranken, an den
-- Enden das gewählte Wappen, Gold beim Eintritt, Silberblau beim Verlassen.
-- Farbstimmung: combat = { rail, railV = {oben, unten}, railH, ends ("crest"
-- oder Bild), endSize, noFlip, colorIn, colorOut }
local skin = { vT = 0.25, vB = 0.75, leaf = LEAF, colIn = { 0.95, 0.80, 0.42 }, colOut = { 0.72, 0.86, 0.72 } }
local function applySkin()
    local pal = ns.ActivePalette and ns.ActivePalette()
    local c = pal and type(pal.combat) == "table" and pal.combat or nil
    local railTex = c and c.rail or (MEDIA .. "ranke")
    local endTex = c and c.ends or (MEDIA .. "blaetter")
    if endTex == "crest" then endTex = ns.CurrentCrest and ns.CurrentCrest() or (MEDIA .. "blaetter") end
    skin.vT = c and c.railV and c.railV[1] or 0.25
    skin.vB = c and c.railV and c.railV[2] or 0.75
    skin.leaf = c and c.endSize or LEAF
    skin.colIn = c and c.colorIn or { 0.95, 0.80, 0.42 }
    skin.colOut = c and c.colorOut or { 0.72, 0.86, 0.72 }
    local noFlip = c and c.noFlip
    for _, t in pairs(frame.vines) do
        t:SetTexture(railTex)
        t:SetHeight(c and c.railH or VINE_H)
    end
    for _, t in pairs(frame.leaves) do
        t:SetTexture(endTex)
        local l, r, top, bot = 0, 1, 0, 1
        if not noFlip then
            if t.flipX then l, r = 1, 0 end
            if t.flipY then top, bot = 1, 0 end
        end
        t:SetTexCoord(l, r, top, bot)
    end
end

local function build()
    frame = CreateFrame("Frame", "MondhainCombatAlert", UIParent)
    frame:SetSize(420, 110)
    frame:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    frame:SetFrameStrata("HIGH")

    local text = frame:CreateFontString(nil, "OVERLAY")
    if not text:SetFont(FONT, 46, "OUTLINE") then text:SetFont(STANDARD_TEXT_FONT, 40, "OUTLINE") end
    text:SetPoint("CENTER")
    text:SetShadowOffset(2, -2)
    text:SetShadowColor(0, 0, 0, 1)
    frame.text = text

    -- vier Rankenhälften: oben/unten, jeweils links/rechts von der Mitte
    frame.vines = {
        tl = vine(frame, false), tr = vine(frame, false),
        bl = vine(frame, true),  br = vine(frame, true),
    }
    frame.leaves = {
        tl = leaf(frame, false, true), tr = leaf(frame, true, true),
        bl = leaf(frame, false, false), br = leaf(frame, true, false),
    }
    for _, t in pairs(frame.vines) do t:Hide() end
    for _, t in pairs(frame.leaves) do t:Hide() end
    frame:SetAlpha(0)
    ns.MakeMovable(frame, db, "Kampfanzeige")
end

-- Ranken auf Wachstum p (0 = nichts, 1 = ganz) stellen; zeigt nur den
-- gewachsenen Teil der Rankenbahn, statt sie zu stauchen
local function setGrowth(p, half)
    local v, w = frame.vines, half * p
    local tH = frame.text:GetStringHeight()
    local yTop, yBot = tH / 2 + 6, -(tH / 2 + 4)
    local function place(t, side, y)
        if w < 1 then t:Hide() return end
        t:ClearAllPoints()
        t:SetWidth(w)
        if side == "l" then
            t:SetPoint("RIGHT", frame, "CENTER", 0, y)
        else
            t:SetPoint("LEFT", frame, "CENTER", 0, y)
        end
        -- Texturausschnitt: von der Mitte der Bahn aus nach außen aufdecken
        local u1, u2
        if side == "l" then u1, u2 = 0.5 - 0.5 * p, 0.5 else u1, u2 = 0.5, 0.5 + 0.5 * p end
        local vT, vB = skin.vT, skin.vB
        if t.flipY then vT, vB = vB, vT end
        t:SetTexCoord(u1, u2, vT, vB)
        t:Show()
    end
    place(v.tl, "l", yTop); place(v.tr, "r", yTop)
    place(v.bl, "l", yBot); place(v.br, "r", yBot)
    -- Blätter an den Enden
    local L = frame.leaves
    L.tl:ClearAllPoints(); L.tl:SetPoint("CENTER", frame, "CENTER", -w - 4, yTop + 4)
    L.tr:ClearAllPoints(); L.tr:SetPoint("CENTER", frame, "CENTER", w + 4, yTop + 4)
    L.bl:ClearAllPoints(); L.bl:SetPoint("CENTER", frame, "CENTER", -w - 4, yBot - 4)
    L.br:ClearAllPoints(); L.br:SetPoint("CENTER", frame, "CENTER", w + 4, yBot - 4)
end

local function setLeaves(a)
    for _, t in pairs(frame.leaves) do
        t:SetAlpha(a)
        local s = skin.leaf * (0.5 + 0.5 * a)
        t:SetSize(s, s)
        t:SetShown(a > 0.01)
    end
end

---------------------------------------------------------------------------
-- Abläufe
---------------------------------------------------------------------------
local function run(entering)
    local t0 = GetTime()
    local text = frame.text
    applySkin()
    if entering then
        text:SetText(db.textIn or "Kampf")
        text:SetTextColor(unpack(skin.colIn)) -- Bernstein / Gold
    else
        text:SetText(db.textOut or "Kampf verlassen")
        text:SetTextColor(unpack(skin.colOut)) -- Moosgrün / Silberblau
    end
    local half = text:GetStringWidth() / 2 + 34
    frame:SetAlpha(1)

    frame:SetScript("OnUpdate", function()
        local t = GetTime() - t0
        if entering then
            -- Wort taucht auf, Ranken wachsen, Blätter öffnen sich, dann ausblenden
            text:SetAlpha(ease(phase(t, 0, 0.25)))
            setGrowth(ease(phase(t, 0.15, 0.85)), half)
            setLeaves(ease(phase(t, 0.75, 1.05)))
            frame:SetAlpha(1 - phase(t, 2.0, 2.5))
            if t > 2.5 then frame:SetScript("OnUpdate", nil); frame:SetAlpha(0) end
        else
            -- Ranken sind da, ziehen sich zurück, dann verblasst das Wort
            text:SetAlpha(ease(phase(t, 0, 0.2)) * (1 - phase(t, 1.4, 1.9)))
            setLeaves(1 - phase(t, 0.5, 0.75))
            setGrowth(1 - ease(phase(t, 0.6, 1.35)), half)
            if t > 1.9 then frame:SetScript("OnUpdate", nil); frame:SetAlpha(0) end
        end
    end)
end

function mod:Play(entering)
    if not frame then return end
    run(entering)
    if entering and db.sound and PlaySound and SOUNDKIT and SOUNDKIT.RAID_WARNING then
        PlaySound(SOUNDKIT.RAID_WARNING, "Master")
    end
end

function mod:OnEnable()
    db = ns.db.combatAlert
    -- alte Standardtexte auf die neuen umstellen (eigene Texte bleiben)
    if db.textIn == "Ins Gefecht!" then db.textIn = "Kampf" end
    if db.textOut == "Ruhe im Hain" then db.textOut = "Kampf verlassen" end
    if not db.enabled then return end
    build()
    -- Im Verschiebe-Modus sichtbar stehen lassen, damit man sie greifen kann
    ns.On("LOCK_CHANGED", function(locked)
        frame:SetScript("OnUpdate", nil)
        if locked then
            frame:SetAlpha(0)
        else
            applySkin()
            frame.text:SetText(db.textIn or "Kampf")
            frame.text:SetTextColor(unpack(skin.colIn))
            frame.text:SetAlpha(1)
            setGrowth(1, frame.text:GetStringWidth() / 2 + 34)
            setLeaves(1)
            frame:SetAlpha(1)
        end
    end)
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function() mod:Play(true) end)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function() mod:Play(false) end)
end
