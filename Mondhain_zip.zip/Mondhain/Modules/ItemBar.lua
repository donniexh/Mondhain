-- Mondhain – Vorratsleiste
-- Füllt sich selbst aus den Taschen: Heiltränke, Gesundheitssteine, Essen und
-- Trinken (auch herbeigezaubertes), Verbände, benutzbare Quest-Gegenstände …
-- Wie eine Speisekammer: Ein Fach erscheint, sobald etwas drinsteht.
--
-- Spielregel: Im Kampf darf kein Addon Tasten hinzufügen oder entfernen.
-- Neue Sachen tauchen deshalb erst nach dem Kampf auf; leere Fächer werden
-- im Kampf grau und verschwinden danach.
--
-- /mh vorrat: Bearbeiten
--   Klick auf ein Fach           → Gegenstand ausblenden (bzw. Anheften lösen)
--   Gegenstand aufs [+] ziehen   → hinten anheften
--   Gegenstand auf ein Fach ziehen → davor bzw. dahinter einfügen (grüne Linie
--                                  zeigt, wo); schon angeheftet → wird verschoben
-- Höchstens 8 Fächer, 4 je Reihe; das fünfte beginnt unter dem ersten.

local _, ns = ...
local mod = ns.NewModule("ItemBar")
ns.ItemBar = mod

local SIZE, GAP = 32, 4
local PER_ROW, MAX_SLOTS = 4, 8
local WHITE = "Interface\\Buttons\\WHITE8x8"
local db, bar, plus, banner
local buttons = {}
local items = {}          -- aktuell angezeigte Liste { id, cat }
local pending = false
local editMode = false

-- Reihenfolge und Namen der Fächer
local CATS = {
    { key = "pinned",  label = "Angeheftet" },
    { key = "potion",  label = "Tränke" },
    { key = "stone",   label = "Gesundheitssteine" },
    { key = "food",    label = "Essen und Trinken" },
    { key = "bandage", label = "Verbände" },
    { key = "quest",   label = "Quest-Gegenstände" },
    { key = "elixir",  label = "Elixiere und Fläschchen" },
    { key = "other",   label = "Sonstige Verbrauchsgüter" },
}
mod.CATS = CATS
local ORDER = {}
for i, c in ipairs(CATS) do ORDER[c.key] = i end

---------------------------------------------------------------------------
-- Gegenstände einordnen
---------------------------------------------------------------------------
local function itemName(id)
    if C_Item and C_Item.GetItemNameByID then
        local n = C_Item.GetItemNameByID(id)
        if n then return n end
    end
    local gi = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    return gi and (gi(id)) or nil
end

local function itemSpell(id)
    if C_Item and C_Item.GetItemSpell then return C_Item.GetItemSpell(id) end
    if GetItemSpell then return GetItemSpell(id) end
end

local function itemCount(id)
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(id, false, true) or 0 end
    return GetItemCount(id, false, true) or 0
end

local function classify(id)
    if not itemSpell(id) then return nil end -- nicht benutzbar
    local _, _, _, _, _, classID, subID = C_Item.GetItemInfoInstant(id)
    local name = (itemName(id) or ""):lower()
    if name:find("gesundheitsstein", 1, true) or name:find("healthstone", 1, true) then
        return "stone"
    end
    if classID == 12 then return "quest" end
    if classID == 0 then
        if subID == 1 then return "potion" end
        if subID == 5 then return "food" end
        if subID == 7 then return "bandage" end
        if subID == 2 or subID == 3 then return "elixir" end
        return "other"
    end
end

local function lastBag()
    return NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4
end

local function scan()
    local list, seen = {}, {}
    for id, ord in pairs(db.pinned) do
        seen[id] = true
        -- Ben 25.11. 13:49: nicht im Inventar → nicht zeigen (nur im Bearbeiten-
        -- Modus, damit man die Liste pflegen kann); kommt er zurück, ist er wieder da
        if editMode or itemCount(id) > 0 then
            list[#list + 1] = { id = id, cat = "pinned", ord = type(ord) == "number" and ord or 0 }
        end
    end
    for bag = 0, lastBag() do
        local slots = C_Container.GetContainerNumSlots(bag) or 0
        for slot = 1, slots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            local id = info and info.itemID
            if id and not seen[id] then
                seen[id] = true
                if not db.hidden[id] then
                    local cat = classify(id)
                    if cat and db.cats[cat] then
                        list[#list + 1] = { id = id, cat = cat }
                    end
                end
            end
        end
    end
    table.sort(list, function(a, b)
        if a.cat ~= b.cat then return ORDER[a.cat] < ORDER[b.cat] end
        if a.ord and b.ord and a.ord ~= b.ord then return a.ord < b.ord end
        return a.id < b.id
    end)
    return list
end

---------------------------------------------------------------------------
-- Anzeige
---------------------------------------------------------------------------
local function updateButton(b)
    local id = b.itemID
    if not id then return end
    local n = itemCount(id)
    if n > 1 then b.Count:SetText(n) else b.Count:SetText("") end
    local empty = (n == 0)
    b.icon:SetDesaturated(empty)
    if empty and not editMode then
        -- im Kampf lässt sich die Taste nicht wegnehmen: unsichtbar, nach dem Kampf neu ordnen
        b:SetAlpha(0)
        if InCombatLockdown() then pending = true else C_Timer.After(0, function() mod:Rebuild() end) end
    else
        b:SetAlpha(empty and 0.45 or 1)
    end

    local ok, start, dur = pcall(C_Container.GetItemCooldown, id)
    if ok and start then
        pcall(b.cooldown.SetCooldown, b.cooldown, start, dur)
    else
        b.cooldown:Clear()
    end
end

local function updateAll()
    for _, b in ipairs(buttons) do
        if b:IsShown() then updateButton(b) end
    end
end

-- 4 je Reihe; waagerecht: zweite Reihe unter der ersten,
-- senkrecht: 4 übereinander, zweite Spalte rechts daneben
local function placeButton(b, i)
    b:ClearAllPoints()
    local a, c = (i - 1) % PER_ROW, math.floor((i - 1) / PER_ROW)
    if db.vertical then
        b:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", c * (SIZE + GAP), a * (SIZE + GAP))
    else
        b:SetPoint("TOPLEFT", bar, "TOPLEFT", a * (SIZE + GAP), -c * (SIZE + GAP))
    end
end

local function createButton(i)
    local b = CreateFrame("Button", "MondhainItemButton" .. i, bar, "SecureActionButtonTemplate")
    ns.SkinButton(b, SIZE)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("useOnKeyDown", false)
    b:SetAttribute("type", "item")
    b:SetScript("OnEnter", function(self)
        if not self.itemID then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetItemByID(self.itemID)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)

    -- Schicht für den Bearbeiten-Modus (klickbar, liegt über der Taste)
    local o = CreateFrame("Button", nil, b)
    o:SetAllPoints()
    o:SetFrameLevel(b:GetFrameLevel() + 10)
    o.tex = o:CreateTexture(nil, "OVERLAY")
    o.tex:SetAllPoints()
    o.label = o:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    o.label:SetPoint("CENTER")
    -- grüne Einfügemarke (links = davor, rechts = dahinter)
    o.mark = o:CreateTexture(nil, "OVERLAY", nil, 7)
    o.mark:SetColorTexture(0.30, 0.95, 0.40, 1)
    o.mark:Hide()
    o:SetScript("OnClick", function(self)
        if mod:CursorItem() then mod:DropOn(self, b) return end
        mod:ToggleItem(b.itemID)
    end)
    o:SetScript("OnReceiveDrag", function(self) mod:DropOn(self, b) end)
    o:SetScript("OnUpdate", function(self)
        if not self:IsMouseOver() or not mod:CursorItem() then
            self.mark:Hide()
            return
        end
        local after = mod:DropSide(self)
        self.mark:ClearAllPoints()
        if db.vertical then
            self.mark:SetPoint(after and "TOPLEFT" or "BOTTOMLEFT", self, after and "TOPLEFT" or "BOTTOMLEFT", -2, after and 2 or -2)
            self.mark:SetSize(SIZE + 4, 3)
        else
            self.mark:SetPoint(after and "TOPRIGHT" or "TOPLEFT", self, after and "TOPRIGHT" or "TOPLEFT", after and 3 or -3, 2)
            self.mark:SetSize(3, SIZE + 4)
        end
        self.mark:Show()
    end)
    o:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if mod:CursorItem() then
            GameTooltip:AddLine("Hier einfügen", 0.30, 0.95, 0.40)
            GameTooltip:AddLine("Linke Hälfte: davor · rechte Hälfte: dahinter", 0.8, 0.8, 0.8, true)
            GameTooltip:Show()
            return
        end
        GameTooltip:AddLine(itemName(b.itemID) or "Gegenstand", 1, 0.82, 0)
        if db.pinned[b.itemID] then
            GameTooltip:AddLine("Angeheftet – Klick: lösen", 0.8, 0.8, 0.8)
        else
            GameTooltip:AddLine("Klick: nicht mehr zeigen", 0.8, 0.8, 0.8)
        end
        GameTooltip:Show()
    end)
    o:SetScript("OnLeave", GameTooltip_Hide)
    o:Hide()
    b.edit = o

    buttons[i] = b
    return b
end

local function updateEditOverlays()
    for _, b in ipairs(buttons) do
        local show = editMode and b:IsShown()
        b.edit:SetShown(show)
        if show then
            if db.pinned[b.itemID] then
                b.edit.tex:SetColorTexture(1, 0.49, 0.04, 0.35)
                b.edit.label:SetText("fest")
            else
                b.edit.tex:SetColorTexture(0, 0, 0, 0.45)
                b.edit.label:SetText("")
            end
        end
    end
    if plus then
        local n = math.min(#items, MAX_SLOTS)
        plus:SetShown(editMode and n < MAX_SLOTS)
        if editMode then placeButton(plus, n + 1) end
    end
end

-- Leiste neu aufbauen (nur außerhalb des Kampfes)
function mod:Rebuild()
    if not bar then return end
    if InCombatLockdown() then
        pending = true
        updateAll()
        return
    end
    pending = false
    items = scan()
    local maxN = math.max(1, math.min(tonumber(db.max) or MAX_SLOTS, MAX_SLOTS))
    local n = math.min(#items, maxN)
    for i = 1, n do
        local b = buttons[i] or createButton(i)
        local id = items[i].id
        b.itemID = id
        b:SetAttribute("item", "item:" .. id)
        local icon = C_Item.GetItemIconByID and C_Item.GetItemIconByID(id) or select(5, C_Item.GetItemInfoInstant(id))
        b.icon:SetTexture(icon)
        placeButton(b, i)
        b:Show()
    end
    for i = n + 1, #buttons do
        buttons[i]:Hide()
        buttons[i].itemID = nil
    end
    -- Rahmen = erste Reihe (bzw. Spalte); weitere hängen darunter (daneben),
    -- so bleibt die erste Reihe an ihrem Platz, wenn eine zweite dazukommt
    local slots = math.min(PER_ROW, math.max(n, 1) + ((editMode and n < MAX_SLOTS) and 1 or 0))
    if db.vertical then
        bar:SetSize(SIZE, slots * (SIZE + GAP) - GAP)
    else
        bar:SetSize(slots * (SIZE + GAP) - GAP, SIZE)
    end
    updateAll()
    updateEditOverlays()
end

local function requestRebuild()
    if pending then return end
    pending = true
    C_Timer.After(0.2, function()
        pending = false
        mod:Rebuild()
    end)
end

---------------------------------------------------------------------------
-- Bearbeiten
---------------------------------------------------------------------------
function mod:ToggleItem(id)
    if not id or InCombatLockdown() then return end
    if db.pinned[id] then
        db.pinned[id] = nil
    else
        db.hidden[id] = true
    end
    self:Rebuild()
end

---------------------------------------------------------------------------
-- Eigene Leiste: Gegenstände per ID, Name oder Link eintragen
---------------------------------------------------------------------------
local function resolve(text)
    text = (text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if text == "" then return nil end
    local id = tonumber(text:match("item:(%d+)") or text:match("^(%d+)$"))
    if id then return id end
    local inst = C_Item.GetItemInfoInstant(text)
    if inst then return inst end
    -- Name in den Taschen suchen
    local want = text:lower()
    for bag = 0, lastBag() do
        for slot = 1, (C_Container.GetContainerNumSlots(bag) or 0) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            local bid = info and info.itemID
            local n = bid and itemName(bid)
            if n and n:lower() == want then return bid end
        end
    end
end

function mod:AddItem(text)
    if InCombatLockdown() then return false, "Im Kampf nicht möglich." end
    local id = resolve(text)
    if not id then return false, "Nicht gefunden – probier die Item-ID (steht im Tooltip)." end
    db.pinOrder = (db.pinOrder or 0) + 1
    db.pinned[id] = db.pinOrder
    db.hidden[id] = nil
    if C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
    self:Rebuild()
    return true, id
end

function mod:RemoveItem(id)
    if InCombatLockdown() or not id then return end
    db.pinned[id] = nil
    self:Rebuild()
end

-- Eingetragene Gegenstände in ihrer Reihenfolge
function mod:GetPinnedList()
    local list = {}
    for id, ord in pairs(db.pinned) do list[#list + 1] = { id = id, ord = type(ord) == "number" and ord or 0 } end
    table.sort(list, function(a, b) return a.ord < b.ord end)
    local out = {}
    for i, e in ipairs(list) do out[i] = e.id end
    return out
end

function mod:ItemName(id) return itemName(id) end

-- Gegenstand am Mauszeiger (aus der Tasche gezogen)?
function mod:CursorItem()
    local kind, id = GetCursorInfo()
    if kind == "item" and id then return id end
end

-- Mauszeiger in der hinteren Hälfte des Fachs → dahinter einfügen
function mod:DropSide(o)
    local x, y = GetCursorPosition()
    local sc = o:GetEffectiveScale()
    x, y = x / sc, y / sc
    if db.vertical then
        local b, h = o:GetBottom(), o:GetHeight()
        return b and h and (y - b) > h / 2
    end
    local l, w = o:GetLeft(), o:GetWidth()
    return l and w and (x - l) > w / 2
end

-- an Stelle pos (1 = ganz vorne) in die angeheftete Reihenfolge setzen
function mod:InsertItem(id, pos)
    if InCombatLockdown() or not id then return end
    local list = self:GetPinnedList()
    for i = #list, 1, -1 do
        if list[i] == id then table.remove(list, i) end
    end
    if #list >= MAX_SLOTS then
        ns.Print("Die Vorratsleiste ist voll (höchstens " .. MAX_SLOTS .. " Fächer).")
        return
    end
    pos = math.max(1, math.min(pos, #list + 1))
    table.insert(list, pos, id)
    wipe(db.pinned)
    for i, pid in ipairs(list) do db.pinned[pid] = i end
    db.pinOrder = #list
    db.hidden[id] = nil
    if C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
    self:Rebuild()
end

-- Ablegen auf einem Fach: davor oder dahinter einfügen
function mod:DropOn(o, b)
    local id = self:CursorItem()
    if not id then return end
    ClearCursor()
    local idx
    for i, e in ipairs(items) do
        if e.id == b.itemID then idx = i break end
    end
    if not idx then self:InsertItem(id, math.huge) return end
    local pos = idx + (self:DropSide(o) and 1 or 0)
    -- Angeheftete stehen immer vorne; hinter den letzten Angehefteten geht's nicht weiter
    local pinnedN = #self:GetPinnedList()
    if db.pinned[id] then
        -- Verschieben: eigene alte Stelle davor zählt nicht mit
        for i, e in ipairs(items) do
            if e.id == id and i < pos then pos = pos - 1 break end
        end
        pinnedN = pinnedN - 1
    end
    self:InsertItem(id, math.min(pos, pinnedN + 1))
end

local function pinFromCursor()
    local id = mod:CursorItem()
    if not id then return end
    ClearCursor()
    mod:InsertItem(id, math.huge)
end

local function buildEditParts()
    plus = CreateFrame("Button", nil, bar, "BackdropTemplate")
    plus:SetSize(SIZE, SIZE)
    plus:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    plus:SetBackdropColor(0.05, 0.06, 0.08, 0.6)
    plus:SetBackdropBorderColor(0.30, 0.85, 0.35, 0.8)
    local t = plus:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("CENTER", 0, 1)
    t:SetText("+")
    t:SetTextColor(0.30, 0.85, 0.35)
    plus:SetScript("OnReceiveDrag", pinFromCursor)
    plus:SetScript("OnClick", pinFromCursor)
    plus:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Gegenstand anheften", 0.30, 0.85, 0.35)
        GameTooltip:AddLine("Aus der Tasche hierher ziehen – wird dann immer gezeigt.", 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    plus:SetScript("OnLeave", GameTooltip_Hide)
    plus:Hide()

    banner = ns.MakeBanner("Vorratsleiste",
        "Klick auf ein Fach: ausblenden · Gegenstand auf ein Fach ziehen: davor/dahinter einfügen · aufs [+]: hinten anheften",
        0.30, 0.85, 0.35, function() mod:SetEditMode(false) end)
    local reset = CreateFrame("Button", nil, banner, "UIPanelButtonTemplate")
    reset:SetSize(86, 22)
    reset:SetPoint("RIGHT", banner.done, "LEFT", -6, 0)
    reset:SetText("Alle zeigen")
    reset:SetScript("OnClick", function()
        wipe(db.hidden)
        mod:Rebuild()
        ns.Print("Ausgeblendete Gegenstände sind wieder da.")
    end)
end

function mod:SetEditMode(on)
    if not bar then
        ns.Print("Die Vorratsleiste ist abgeschaltet.")
        return
    end
    if on and InCombatLockdown() then
        ns.Print("Die Vorratsleiste lässt sich nur außerhalb des Kampfes bearbeiten.")
        return
    end
    editMode = on
    if not plus then buildEditParts() end
    banner:SetShown(on)
    self:Rebuild()
end

function mod:IsEditMode() return editMode end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
-- Item-ID im Tooltip (hilft beim Eintragen)
local function hookTooltipID()
    local function add(tt, id)
        if not db.showID or not id or ns.isSecret(id) then return end
        if ns.db.tooltip and ns.db.tooltip.ids then return end   -- macht jetzt der Tooltip für alles
        tt:AddLine("Item-ID: " .. id, 0.55, 0.75, 1)
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
            pcall(add, tt, data and data.id)
        end)
    elseif GameTooltip.HookScript then
        GameTooltip:HookScript("OnTooltipSetItem", function(tt)
            local _, link = tt:GetItem()
            pcall(add, tt, link and tonumber(link:match("item:(%d+)")))
        end)
    end
end

function mod:OnEnable()
    db = ns.db.itemBar
    hookTooltipID()
    if not db.enabled then return end

    bar = CreateFrame("Frame", "MondhainItemBar", UIParent)
    bar:SetSize(SIZE, SIZE)
    -- rechts neben der Karte – oder neben der rechten Tafel, falls vorhanden
    local holder = _G.MondhainMinimapHolder
    if db.followMap and holder then
        -- rechts an der Karte festgewachsen; wird sie größer, rückt die Leiste mit.
        -- Sitzt die linke Tafel rechts an der Karte (schmales Bild), dann rechts an der Tafel
        bar:SetPoint("BOTTOMLEFT", holder, "BOTTOMRIGHT", 6, 0)
        C_Timer.After(1, function()
            local lb = ns.Boards and ns.Boards.left
            if ns.db.minimapFrame.boardLeftSide == "right" and lb and db.followMap and not InCombatLockdown() then
                bar:ClearAllPoints()
                bar:SetPoint("BOTTOMLEFT", lb, "BOTTOMRIGHT", 6, 0)
            end
        end)
    else
        bar:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    end
    -- Wer die Leiste von Hand verschiebt, löst sie von der Karte
    ns.MakeMovable(bar, db, "Vorratsleiste", function() db.followMap = false end)

    self:Rebuild()

    ns.RegisterEvent("BAG_UPDATE_DELAYED", requestRebuild)
    ns.RegisterEvent("PLAYER_ENTERING_WORLD", requestRebuild)
    ns.RegisterEvent("QUEST_ACCEPTED", requestRebuild)
    ns.RegisterEvent("GET_ITEM_INFO_RECEIVED", requestRebuild)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
        if pending then mod:Rebuild() end
    end)
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function()
        if editMode then mod:SetEditMode(false) end
    end)
    ns.RegisterEvent("BAG_UPDATE_COOLDOWN", updateAll)
    ns.RegisterEvent("SPELL_UPDATE_COOLDOWN", updateAll)
end
