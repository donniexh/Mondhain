-- Mondhain – eigene Stärkungen und Schwächungen
-- Oben rechts in der Ecke zwei Blöcke untereinander: Stärkungen, darunter
-- Schwächungen. Größer als bei Blizzard, Restzeit unter dem Symbol.
-- Rechtsklick auf eine Stärkung entfernt sie (außerhalb des Kampfes).

local _, ns = ...
local mod = ns.NewModule("PlayerAuras")
ns.PlayerAuras = mod

local FONT = STANDARD_TEXT_FONT
local db
local blocks = {}

local DEBUFF_COLORS = {
    Curse = { 0.6, 0.0, 1.0 }, Poison = { 0.0, 0.6, 0.1 },
    Magic = { 0.2, 0.6, 1.0 }, Disease = { 0.6, 0.4, 0.0 },
}

local function isSecret(v) return ns.isSecret(v) end

-- 45s · 8m · 2h · 3T
local function shortTime(sec)
    if sec >= 86400 then return math.floor(sec / 86400 + 0.5) .. "T" end
    if sec >= 3600 then return math.floor(sec / 3600 + 0.5) .. "h" end
    if sec >= 60 then return math.floor(sec / 60 + 0.5) .. "m" end
    return math.floor(sec) .. "s"
end

---------------------------------------------------------------------------
-- Ein Symbol
---------------------------------------------------------------------------
local function makeIcon(block, i)
    local size = db.size
    local b = CreateFrame("Button", nil, block)
    b:SetSize(size, size)
    b:RegisterForClicks("RightButtonUp")
    b.edge = b:CreateTexture(nil, "BACKGROUND")
    b.edge:SetAllPoints()
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 1, -1)
    b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cd:SetAllPoints(b.icon)
    b.cd:SetDrawEdge(false)
    b.cd:SetReverse(true)
    b.cd:SetHideCountdownNumbers(true)
    local textLayer = CreateFrame("Frame", nil, b)
    textLayer:SetAllPoints()
    textLayer:SetFrameLevel(b.cd:GetFrameLevel() + 2)
    b.count = textLayer:CreateFontString(nil, "OVERLAY")
    b.count:SetFont(FONT, math.max(10, size * 0.32), "OUTLINE")
    b.count:SetPoint("BOTTOMRIGHT", -1, 2)
    b.time = b:CreateFontString(nil, "OVERLAY")
    b.time:SetFont(FONT, math.max(9, size * 0.28), "OUTLINE")
    b.time:SetPoint("TOP", b, "BOTTOM", 0, -2)

    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        pcall(GameTooltip.SetUnitAura, GameTooltip, "player", self.index, self.filter)
        if self.filter == "HELPFUL" then
            GameTooltip:AddLine(InCombatLockdown() and "Im Kampf nicht entfernbar" or "Rechtsklick: entfernen", 0.6, 0.6, 0.6)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    b:SetScript("OnClick", function(self)
        if self.filter == "HELPFUL" and not InCombatLockdown() and self.index then
            pcall(CancelUnitBuff, "player", self.index, self.filter)
        end
    end)
    block.icons[i] = b
    return b
end

---------------------------------------------------------------------------
-- Block füllen
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- Stärkungen lesen
-- Forever gibt die Stärkungen im Kampf über den üblichen Weg (nach Nummer)
-- teils gar nicht heraus. Darum mehrere Wege nacheinander – und ein eigenes
-- Gedächtnis, das aus Blizzards UNIT_AURA-Meldungen gepflegt wird (die
-- liefern neue Auren mit, auch im Kampf).
---------------------------------------------------------------------------
local cache = {}        -- [auraInstanceID] = Aura-Daten
local lastWay = {}      -- [filter] = Name des Wegs, der zuletzt geliefert hat

local function isHarmful(d)
    local ok, v = pcall(function()
        if d.isHarmful ~= nil then return d.isHarmful and true or false end
        if d.isHelpful ~= nil then return not d.isHelpful end
        return nil
    end)
    if ok then return v end
end

local function wayIndex(filter)
    local list = {}
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return list end
    for i = 1, 40 do
        local ok, data = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, filter)
        if not ok or not data then break end
        list[#list + 1] = { index = i, data = data }
    end
    return list
end

local function wayForEach(filter)
    local list = {}
    if not (AuraUtil and AuraUtil.ForEachAura) then return list end
    pcall(AuraUtil.ForEachAura, "player", filter, nil, function(data)
        if data then list[#list + 1] = { data = data } end
    end, true)
    return list
end

local function waySlots(filter)
    local list = {}
    if not (C_UnitAuras and C_UnitAuras.GetAuraSlots and C_UnitAuras.GetAuraDataBySlot) then return list end
    local ok, res = pcall(function() return { C_UnitAuras.GetAuraSlots("player", filter) } end)
    if not ok or not res then return list end
    for i = 2, #res do
        local ok2, d = pcall(C_UnitAuras.GetAuraDataBySlot, "player", res[i])
        if ok2 and d then list[#list + 1] = { data = d } end
    end
    return list
end

local function wayClassic(filter)
    local list = {}
    if not UnitAura then return list end
    for i = 1, 40 do
        local ok, name, icon, count, dtype, duration, expires, _, _, _, spellId =
            pcall(UnitAura, "player", i, filter)
        if not ok or not name then break end
        list[#list + 1] = { index = i, data = { name = name, icon = icon, applications = count,
            dispelName = dtype, duration = duration, expirationTime = expires, spellId = spellId } }
    end
    return list
end

local function wayCache(filter)
    local list, now = {}, GetTime()
    local wantHarm = (filter == "HARMFUL")
    for id, d in pairs(cache) do
        local harm = isHarmful(d)
        if harm == nil then harm = false end
        if harm == wantHarm then
            -- abgelaufen, aber nicht abgemeldet → raus
            local ok, gone = pcall(function()
                return d.expirationTime and d.expirationTime > 0 and d.expirationTime < now - 0.5
            end)
            if ok and gone then cache[id] = nil else list[#list + 1] = { data = d } end
        end
    end
    return list
end

local WAYS = {
    { "Nummer", wayIndex }, { "ForEachAura", wayForEach }, { "Plätze", waySlots }, { "UnitAura", wayClassic },
}

-- Gedächtnis aus einer vollständigen Liste neu aufbauen (nur wenn lesbar)
local function refill(list)
    for _, e in ipairs(list) do
        pcall(function()
            local id = e.data.auraInstanceID
            if id then cache[id] = e.data end
        end)
    end
end

-- liefert die Liste und ob die Antwort verlässlich ist
local function collect(filter)
    if InCombatLockdown() then
        -- im Kampf: erst die normalen Wege, sonst das Gedächtnis
        for _, w in ipairs(WAYS) do
            local list = w[2](filter)
            if #list > 0 then lastWay[filter] = w[1]; return list, true end
        end
        local list = wayCache(filter)
        lastWay[filter] = (#list > 0) and "Gedächtnis" or "nichts lesbar"
        -- gar nichts lesbar → „unsicher“: die Anzeige bleibt dann stehen
        return list, #list > 0
    end
    for _, w in ipairs(WAYS) do
        local list = w[2](filter)
        if #list > 0 then
            lastWay[filter] = w[1]
            return list, true
        end
    end
    lastWay[filter] = "leer"
    return {}, true
end

local function sortList(list)
    -- Sortieren: ohne Ablauf zuerst, dann längste Restzeit zuerst (wenn lesbar)
    pcall(table.sort, list, function(a, b)
        local ea, eb = a.data.expirationTime or 0, b.data.expirationTime or 0
        if ea == 0 and eb ~= 0 then return true end
        if eb == 0 and ea ~= 0 then return false end
        if ea ~= eb then return ea > eb end
        return (a.index or 0) < (b.index or 0)
    end)
end

-- UNIT_AURA: Gedächtnis pflegen
local function onAura(info)
    if not info or info.isFullUpdate then
        if not InCombatLockdown() then
            wipe(cache)
            refill(wayIndex("HELPFUL")); refill(wayIndex("HARMFUL"))
        end
        return
    end
    if info.addedAuras then
        for _, d in ipairs(info.addedAuras) do
            pcall(function() local id = d.auraInstanceID; if id then cache[id] = d end end)
        end
    end
    if info.updatedAuraInstanceIDs and C_UnitAuras and C_UnitAuras.GetAuraDataByAuraInstanceID then
        for _, id in ipairs(info.updatedAuraInstanceIDs) do
            pcall(function()
                local d = C_UnitAuras.GetAuraDataByAuraInstanceID("player", id)
                if d then cache[id] = d end
            end)
        end
    end
    if info.removedAuraInstanceIDs then
        for _, id in ipairs(info.removedAuraInstanceIDs) do
            pcall(function() cache[id] = nil end)
        end
    end
end

-- /mh buffs: welcher Weg liefert gerade was?
function mod:Diagnose()
    local inC = InCombatLockdown() and "im Kampf" or "außerhalb des Kampfes"
    ns.Print("Stärkungen lesen (" .. inC .. "):")
    for _, w in ipairs(WAYS) do
        print(("  %s: %d Stärkungen, %d Schwächungen"):format(w[1], #w[2]("HELPFUL"), #w[2]("HARMFUL")))
    end
    local n = 0
    for _ in pairs(cache) do n = n + 1 end
    print(("  Gedächtnis: %d Auren · zuletzt genutzt: %s / %s"):format(n, lastWay.HELPFUL or "–", lastWay.HARMFUL or "–"))
    local st = mod.SwipeStats and mod:SwipeStats() or {}
    print(("  Uhr: %s Symbole gefunden, %s sichtbar, %s mit Uhr (%s vom Symbol selbst, %s gemerkt) · lesbar: %s"):format(
        tostring(st.buttons or "–"), tostring(st.shown or "–"), tostring(st.set or "–"),
        tostring(st.info or "–"), tostring(st.cache or "–"), tostring(st.readable)))
    if st.sample then print("  erstes Symbol: " .. st.sample) end
    if st.err then print("  |cffff6060Fehler:|r " .. st.err) end
end

local function layoutBlock(block, n)
    local size, per = db.size, db.perRow
    local gapX, gapY = 4, db.showTime and (size * 0.28 + 8) or 4
    for i = 1, n do
        local b = block.icons[i]
        local col = (i - 1) % per
        local row = math.floor((i - 1) / per)
        b:ClearAllPoints()
        -- wächst von rechts nach links, Reihen nach unten
        b:SetPoint("TOPRIGHT", block, "TOPRIGHT", -col * (size + gapX), -row * (size + gapY))
    end
    local rows = math.max(1, math.ceil(n / per))
    block:SetSize(per * (size + gapX) - gapX, rows * (size + gapY))
end

---------------------------------------------------------------------------
-- Testmodus: zwei Reihen ausgedachter Stärkungen und Schwächungen
---------------------------------------------------------------------------
local testMode = false
local TEST_BUFFS = {
    "Spell_Nature_Regeneration", "Spell_Nature_Thorns", "Spell_Nature_Rejuvenation", "Spell_Nature_ResistNature",
    "Spell_Holy_WordFortitude", "Spell_Holy_MagicalSentry", "Spell_Holy_GreaterBlessingofKings", "INV_Misc_Food_15",
    "Spell_Nature_Lightning", "Spell_Holy_PowerWordShield", "Spell_Nature_StarFall", "Ability_Druid_TravelForm",
}
local TEST_DEBUFFS = {
    { "Spell_Shadow_CurseOfTounges", "Curse" }, { "Spell_Nature_CorrosiveBreath", "Poison" },
    { "Spell_Frost_FrostNova", "Magic" }, { "Spell_Shadow_AbominationExplosion", "Disease" },
    { "Ability_Gouge", nil }, { "Spell_Shadow_ShadowWordPain", "Magic" },
}

local function fakeList(filter)
    local list, now = {}, GetTime()
    local n = db.perRow * 2
    for i = 1, n do
        local d = { applications = (i % 5 == 0) and 3 or 0 }
        if filter == "HELPFUL" then
            d.icon = "Interface\\Icons\\" .. TEST_BUFFS[(i - 1) % #TEST_BUFFS + 1]
            d.duration = (i <= 3) and 0 or (60 * i)
        else
            local e = TEST_DEBUFFS[(i - 1) % #TEST_DEBUFFS + 1]
            d.icon = "Interface\\Icons\\" .. e[1]
            d.dispelName = e[2]
            d.duration = 8 + i * 3
        end
        d.expirationTime = (d.duration > 0) and (now + d.duration * 0.7) or 0
        list[i] = { index = nil, data = d }
    end
    return list
end

function mod:SetTest(on)
    testMode = on
    for _, block in pairs(blocks) do
        for _, b in ipairs(block.icons) do b:Hide() end
    end
    if blocks.buffs then
        for _, block in pairs(blocks) do
            block.updateNow()
        end
    end
    if on then ns.Print("Test: Stärkungen und Schwächungen – je zwei Reihen.") end
end
function mod:IsTest() return testMode end

local function updateBlock(block)
    -- Blizzard-Modus: Blizzards Leiste zeigt die Stärkungen, eigene Symbole nur im Test
    if db.blizzardMode and not testMode then
        for _, b in ipairs(block.icons) do b:Hide() end
        block.lastCount = 0
        return
    end
    local list, readable
    if testMode then list, readable = fakeList(block.filter), true else list, readable = collect(block.filter) end
    sortList(list)
    -- Nur wenn das Spiel die Stärkungen im Kampf gar nicht herausgibt (Fehler
    -- statt Antwort), das Bisherige stehen lassen. Eine lesbare leere Liste
    -- heißt: wirklich ausgelaufen → weg damit.
    if not testMode and not readable and (block.lastCount or 0) > 0 then
        -- stehen lassen, aber was nachweislich abgelaufen ist, ausblenden
        block.stale = true
        local now = GetTime()
        for _, b in ipairs(block.icons) do
            if b:IsShown() and b.expires and b.expires < now - 0.3 then
                b:Hide()
                b.expires = nil
            end
        end
        return
    end
    block.stale = nil
    block.lastCount = #list
    for i, e in ipairs(list) do
        local b = block.icons[i] or makeIcon(block, i)
        local d = e.data
        b.index, b.filter = e.index, block.filter
        pcall(b.icon.SetTexture, b.icon, d.icon)
        if block.filter == "HARMFUL" then
            local c = { 0.8, 0.1, 0.1 }
            pcall(function() c = DEBUFF_COLORS[d.dispelName] or c end)
            b.edge:SetColorTexture(c[1], c[2], c[3], 1)
        else
            b.edge:SetColorTexture(unpack(ns.colors.border))
        end
        if not pcall(function()
            b.count:SetText((d.applications and d.applications > 1) and d.applications or "")
        end) then b.count:SetText("") end
        b.expires = nil
        if not pcall(function()
            if d.duration and d.duration > 0 then
                b.cd:SetCooldown(d.expirationTime - d.duration, d.duration)
                b.expires = d.expirationTime
            else
                b.cd:Clear()
            end
        end) then b.cd:Clear() end
        -- Zeit gleich setzen (sonst flackert sie beim häufigen Neulesen kurz weg)
        local left = b.expires and (b.expires - GetTime())
        b.time:SetText((db.showTime and left and left > 0) and shortTime(left) or "")
        b:Show()
    end
    for i = #list + 1, #block.icons do block.icons[i]:Hide() end
    layoutBlock(block, #list)
end

local function updateTimes()
    local now = GetTime()
    for _, block in pairs(blocks) do
        local expired = false
        for _, b in ipairs(block.icons) do
            if b:IsShown() and b.expires then
                local left = b.expires - now
                if db.showTime then b.time:SetText(left > 0 and shortTime(left) or "") end
                if left < -0.3 then expired = true end
            end
        end
        -- abgelaufen, aber noch angezeigt → neu lesen (das Spiel meldet das
        -- Auslaufen im Kampf nicht immer)
        if expired and not testMode then updateBlock(block) end
    end
end

function mod:Refresh()
    for _, block in pairs(blocks) do
        -- Größe geändert: Symbole neu anlegen
        for _, b in ipairs(block.icons) do b:Hide(); b:SetParent(nil) end
        wipe(block.icons)
        updateBlock(block)
    end
end

---------------------------------------------------------------------------
-- Blizzards Stärkungsleiste wegstecken
---------------------------------------------------------------------------
local hider
local function hideBlizzard()
    if InCombatLockdown() then return end
    hider = hider or CreateFrame("Frame")
    hider:Hide()
    for _, n in ipairs({ "BuffFrame", "DebuffFrame", "TemporaryEnchantFrame" }) do
        local f = _G[n]
        if f and f.SetParent and f:GetParent() ~= hider then
            f:SetParent(hider)
            if not f.mondhainHooked then
                f.mondhainHooked = true
                hooksecurefunc(f, "SetParent", function(self, parent)
                    if parent ~= hider and not self.mondhainBusy and not InCombatLockdown() then
                        self.mondhainBusy = true
                        self:SetParent(hider)
                        self.mondhainBusy = false
                    end
                end)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Blizzard-Modus: Blizzards eigene Stärkungsleiste an Mondhains Platz, größer
-- und im Mondhain-Look. Blizzard liest die Auren selbst – das klappt im Kampf,
-- wo Forever sie Addons nicht herausgibt.
---------------------------------------------------------------------------
local BLIZZ_ICON = 30          -- Grundgröße eines Blizzard-Symbols
local placing = false

local function editing()
    local em = _G.EditModeManagerFrame
    return em and em:IsShown()
end

-- Abstand von der Oberkante von f bis unter das tiefste sichtbare Symbol
-- (in f-Einheiten, negativ), samt Platz für die Zeit darunter
local function belowContent(f)
    local top, fs = f:GetTop(), f:GetEffectiveScale()
    if not top then return end
    local low
    local function scan(p, d)
        for _, c in ipairs({ p:GetChildren() }) do
            if c:IsVisible() then
                local b, h = c:GetBottom(), c:GetHeight()
                if b and h and h > 4 and h < 80 then
                    b = b * c:GetEffectiveScale() / fs
                    if not low or b < low then low = b end
                end
                if d > 0 then scan(c, d - 1) end
            end
        end
    end
    scan(f, 3)
    if low and low < top then return (low - top) - 18 end
end

local function placeBlizzard()
    if placing or not db.blizzardMode then return end
    if InCombatLockdown() then
        for _, n in ipairs({ "BuffFrame", "DebuffFrame", "TemporaryEnchantFrame" }) do
            local f = _G[n]
            if f and f:IsProtected() then return end
        end
    end
    placing = true
    local scale = (db.size or 40) / BLIZZ_ICON
    local bf, df, te = _G.BuffFrame, _G.DebuffFrame, _G.TemporaryEnchantFrame
    -- klassisch hängen die Symbole an der Waffenverzauberungs-Leiste → beide
    -- an dieselbe Stelle und gleich groß
    for _, f in ipairs({ bf, te }) do
        if f and f.SetPoint and blocks.buffs then
            if f:GetParent() ~= UIParent then f:SetParent(UIParent) end
            f:SetScale(scale)
            f:ClearAllPoints()
            f:SetPoint("TOPRIGHT", blocks.buffs, "TOPRIGHT", 0, 0)
        end
    end
    if df and df.SetPoint and blocks.debuffs then
        if df:GetParent() ~= UIParent then df:SetParent(UIParent) end
        df:SetScale(scale)
        df:ClearAllPoints()
        -- Im HUD-Bearbeitungsmodus zeigt Blizzard viel mehr Beispiel-Stärkungen
        -- als man je hat → Schwächungen dann direkt unter deren letzte Reihe,
        -- sonst liegen beide Raster übereinander
        local y = bf and editing() and belowContent(bf)
        if y then
            df:SetPoint("TOPRIGHT", bf, "TOPRIGHT", 0, y)
        else
            df:SetPoint("TOPRIGHT", blocks.debuffs, "TOPRIGHT", 0, 0)
        end
    end
    placing = false
end

local function styleButton(btn)
    if not btn or btn.mhStyled or not btn.GetObjectType then return end
    btn.mhStyled = true
    local name = btn.GetName and btn:GetName()
    local icon = btn.Icon or btn.icon or (name and _G[name .. "Icon"])
    if icon and icon.SetTexCoord then
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        local edge = btn:CreateTexture(nil, "BACKGROUND", nil, -1)
        edge:SetPoint("TOPLEFT", icon, "TOPLEFT", -1, 1)
        edge:SetPoint("BOTTOMRIGHT", icon, "BOTTOMRIGHT", 1, -1)
        edge:SetColorTexture(unpack(ns.colors.border))
    end
    for _, k in ipairs({ "Duration", "duration", "Count", "count" }) do
        local fs = btn[k] or (name and _G[name .. k:gsub("^%l", string.upper)])
        if fs and fs.SetFont then
            fs:SetFont(FONT, (k:lower() == "duration") and 9 or 10, "OUTLINE")
            fs:SetShadowOffset(0, 0)
        end
    end
    -- Uhr: der abgelaufene Teil wird dunkel (wie ein Tortenstück, das wächst)
    if icon and not btn.mhCd then
        local cd = CreateFrame("Cooldown", nil, btn, "CooldownFrameTemplate")
        cd:SetAllPoints(icon)
        cd:SetReverse(true)
        cd:SetDrawEdge(false)
        if cd.SetDrawBling then cd:SetDrawBling(false) end
        cd:SetHideCountdownNumbers(true)
        if cd.SetSwipeColor then cd:SetSwipeColor(0, 0, 0, 0.65) end
        cd.noCooldownCount = true          -- fremde Zahlen-Addons fernhalten
        btn.mhCd = cd
    end
end

---------------------------------------------------------------------------
-- Uhr auf Blizzards Symbolen. Forever verrät die Restzeit im Kampf nicht –
-- darum: außerhalb des Kampfs genau lesen und je Symbolbild merken (Start,
-- Dauer). Eine einmal gestellte Uhr läuft im Kampf von selbst weiter. Neue
-- Stärkungen im Kampf starten mit der zuletzt gemessenen Dauer; eigenes
-- Nachwirken auf dich setzt die Uhr neu.
---------------------------------------------------------------------------
local swipeCache, durByTex, lastShown = {}, {}, {}
local enchantMax = {}

local function texOf(btn)
    local name = btn.GetName and btn:GetName()
    local icon = btn.Icon or btn.icon or (name and _G[name .. "Icon"])
    if not (icon and icon.GetTexture) then return nil end
    local ok, t = pcall(icon.GetTexture, icon)
    if not ok or t == nil or isSecret(t) then return nil end
    return tostring(t)
end

-- baut das Gedächtnis neu, wenn lesbar; sonst false
local function readSwipes()
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return false end
    local fresh, any = {}, false
    for _, filter in ipairs({ "HELPFUL", "HARMFUL" }) do
        for i = 1, 40 do
            local ok, d = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, filter)
            if not ok or not d then break end
            local ok2, tex, exp, dur = pcall(function()
                local t, e, du = d.icon, d.expirationTime, d.duration
                if t == nil or isSecret(t) or isSecret(e) or isSecret(du) then error("geheim") end
                return tostring(t), e, du
            end)
            if ok2 then                      -- einzelne geheime Auren überspringen
                any = true
                if dur and dur > 0 and exp and exp > 0 then
                    fresh[tex] = { exp - dur, dur }
                    durByTex[tex] = dur
                else
                    fresh[tex] = false       -- ohne Ablauf: keine Uhr
                end
            end
        end
    end
    if not any and InCombatLockdown() then return false end
    swipeCache = fresh
    return true
end

local function setSwipe(cd, start, dur)
    if cd.mhS == start and cd.mhD == dur then return end
    cd.mhS, cd.mhD = start, dur
    cd:SetCooldown(start, dur)
end

local function clearSwipe(cd)
    if cd.mhS == nil then return end
    cd.mhS, cd.mhD = nil, nil
    cd:Clear()
end

-- Alle Symbole, egal in welcher Bauart Forever sie anlegt:
-- klassisch (BuffButton1 …) oder neu (BuffFrame.auraFrames / AuraContainer)
local function auraButtons()
    local list, seen = {}, {}
    local function add(b, kind)
        if type(b) == "table" and b.GetObjectType and not seen[b] then
            seen[b] = true
            list[#list + 1] = { b = b, kind = kind }
        end
    end
    for _, pre in ipairs({ { "BuffButton", "buff" }, { "DebuffButton", "debuff" } }) do
        for i = 1, 40 do
            local b = _G[pre[1] .. i]
            if not b then if i > 3 then break end else add(b, pre[2]) end
        end
    end
    for _, n in ipairs({ "BuffFrame", "DebuffFrame" }) do
        local f = _G[n]
        local kind = (n == "DebuffFrame") and "debuff" or "buff"
        if f and type(f.auraFrames) == "table" then
            for _, b in pairs(f.auraFrames) do add(b, kind) end
        end
        if f and f.AuraContainer and f.AuraContainer.GetChildren then
            for _, b in ipairs({ f.AuraContainer:GetChildren() }) do add(b, kind) end
        end
    end
    return list
end

-- neue Bauart: das Symbol kennt Ablauf und Dauer selbst (wenn nicht geheim)
local function infoTimes(b)
    local info = b.buttonInfo
    if type(info) ~= "table" then return nil end
    local ok, e, d, temp = pcall(function()
        local e, d = info.expirationTime, info.duration
        if e == nil or isSecret(e) or isSecret(d) then error("geheim") end
        return e, d or 0, info.auraType == "TempEnchant"
    end)
    if ok then return e, d, temp end
end

local swipeStats = {}
local function applySwipes()
    local readable = readSwipes()
    local now = GetTime()
    local list = auraButtons()
    local shownBy = { buff = 0, debuff = 0 }
    for _, it in ipairs(list) do
        if it.b:IsShown() then shownBy[it.kind] = shownBy[it.kind] + 1 end
    end
    local shifted = {}
    for k, v in pairs(shownBy) do
        shifted[k] = lastShown[k] ~= nil and lastShown[k] ~= v
        if readable then lastShown[k] = v end
    end
    local st = { buttons = #list, shown = 0, set = 0, info = 0, cache = 0 }
    for _, it in ipairs(list) do
        local b = it.b
        if not b.mhCd then styleButton(b) end
        local cd = b.mhCd
        if cd then
            if not b:IsShown() then
                clearSwipe(cd)
            else
                st.shown = st.shown + 1
                local tex = texOf(b)
                local e, d, temp = infoTimes(b)
                if e then
                    st.info = st.info + 1
                    if temp and e > 0 then
                        -- Waffen-Symbol neuer Bauart: Gesamtdauer = größte gesehene Restzeit
                        local key = "te:" .. tostring(tex)
                        local rem = e - now
                        if not enchantMax[key] or rem > enchantMax[key] + 1 then enchantMax[key] = rem end
                        setSwipe(cd, math.floor(e - enchantMax[key] + 0.5), enchantMax[key])
                    elseif d > 0 and e > 0 then
                        setSwipe(cd, e - d, d)
                        if tex then durByTex[tex] = d end
                    else
                        clearSwipe(cd)
                    end
                else
                    local c = tex and swipeCache[tex]
                    if tex and c == nil and not readable and durByTex[tex] then
                        -- neu im Kampf: mit der gemessenen Dauer ab jetzt
                        c = { now, durByTex[tex] }
                        swipeCache[tex] = c
                    end
                    if c and c[1] + c[2] > now then
                        setSwipe(cd, c[1], c[2])
                        st.cache = st.cache + 1
                    elseif tex or readable or shifted[it.kind] then
                        clearSwipe(cd)      -- ohne Ablauf, abgelaufen oder Zuordnung unklar
                    end
                end
                if cd.mhS then st.set = st.set + 1 end
                if not st.sample then
                    st.sample = ("%s · Bild %s · Ablauf vom Symbol %s · gemerkt %s"):format(
                        b.GetName and b:GetName() or "(ohne Namen)", tostring(tex),
                        e and "ja" or "nein", (tex and swipeCache[tex] ~= nil) and "ja" or "nein")
                end
            end
        end
    end
    st.readable = readable
    swipeStats = st
    -- Waffen-Symbole klassischer Bauart: Restzeit kommt direkt
    if GetWeaponEnchantInfo then
        local ok, hasM, mExp, _, mID, hasO, oExp, _, oID = pcall(GetWeaponEnchantInfo)
        for i = 1, 3 do
            local b = _G["TempEnchant" .. i]
            local cd = b and b.mhCd
            if cd and not infoTimes(b) then
                local slot = b:GetID()
                local rem, eid
                if ok and slot == 16 and hasM then rem, eid = mExp, mID
                elseif ok and slot == 17 and hasO then rem, eid = oExp, oID end
                if b:IsShown() and rem and not isSecret(rem) and rem > 0 then
                    local key = slot .. ":" .. tostring(eid)
                    rem = rem / 1000
                    if not enchantMax[key] or rem > enchantMax[key] + 1 then enchantMax[key] = rem end
                    local dur = enchantMax[key]
                    setSwipe(cd, math.floor(now - (dur - rem) + 0.5), dur)
                else
                    clearSwipe(cd)
                end
            end
        end
    end
end

function mod:SwipeStats() return swipeStats end

-- gebündelt: höchstens einmal pro Bild, dazu jede Sekunde
local swipeDirty = false
local function requestSwipes() swipeDirty = true end
local swipeDriver = CreateFrame("Frame")
local swipeAcc = 0
swipeDriver:SetScript("OnUpdate", function(_, el)
    swipeAcc = swipeAcc + el
    if not swipeDirty and swipeAcc < 1 then return end
    if not (db and db.blizzardMode) then return end
    swipeDirty, swipeAcc = false, 0
    local ok, err = pcall(applySwipes)
    if not ok then swipeStats.err = tostring(err) end
end)

-- eigenes Nachwirken auf dich: Uhr dieses Symbols neu starten
local function onOwnCast(spellID)
    if not spellID or isSecret(spellID) then return end
    if UnitExists("target") and not UnitIsUnit("target", "player") then
        local ok, friend = pcall(UnitIsFriend, "player", "target")
        if not ok or isSecret(friend) or friend then return end   -- ging an jemand anderen
    end
    local t = (C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(spellID))
        or (GetSpellTexture and GetSpellTexture(spellID))
    if t == nil or isSecret(t) then return end
    local tex = tostring(t)
    if durByTex[tex] then
        swipeCache[tex] = { GetTime(), durByTex[tex] }
        requestSwipes()
    end
end

local function styleAll()
    for _, pre in ipairs({ "BuffButton", "DebuffButton", "TempEnchant" }) do
        for i = 1, 40 do
            local b = _G[pre .. i]
            if not b then if i > 3 then break end else styleButton(b) end
        end
    end
    for _, n in ipairs({ "BuffFrame", "DebuffFrame" }) do
        local f = _G[n]
        local list = f and (f.auraFrames or (f.AuraContainer and { f.AuraContainer:GetChildren() }))
        if type(list) == "table" then
            for _, b in pairs(list) do styleButton(b) end
        end
    end
end

---------------------------------------------------------------------------
-- Sortierung: Kurzes (Heilung, HoTs, alles bis 60 s) ganz links, lange
-- Stärkungen rechts. Blizzards Plätze bleiben, nur die Symbole werden darauf
-- neu verteilt. Plätze werden aus der Lage bestimmt (oberste Reihe zuerst,
-- rechts nach links) – so liefert jedes erneute Sortieren dasselbe Bild.
---------------------------------------------------------------------------
local function remaining(btn)
    local ok, v = pcall(function()
        -- klassisch: timeLeft gibt es nur bei Stärkungen mit Ablauf (expirationTime
        -- bleibt am wiederverwendeten Symbol stehen – darum nicht darauf verlassen)
        if btn.timeLeft then return btn.timeLeft + 0 end
        local e = btn.buttonInfo and btn.buttonInfo.expirationTime
        if e and e > 0 then return e - GetTime() end
    end)
    if ok and v and v >= 0 then return v end
end

local function isShort(btn)
    local t = remaining(btn)
    if t then return t <= 60 end
    -- Notweg: Zeittext ablesen („12 Sek.“, „12 s“ = kurz; „3 Min.“, „1 Std.“ = lang)
    local name = btn.GetName and btn:GetName()
    local fs = btn.Duration or btn.duration or (name and _G[name .. "Duration"])
    local ok, short = pcall(function()
        if not (fs and fs:IsShown()) then return false end
        local txt = fs:GetText()
        return type(txt) == "string" and txt:find("%d") ~= nil and not txt:find("[mhMHTdD]")
    end)
    return ok and short or false
end

local function shownButtons(prefix)
    local list = {}
    for i = 1, 40 do
        local b = _G[prefix .. i]
        if not b then break end
        if b:IsShown() then list[#list + 1] = b end
    end
    return list
end

-- Mondhain ordnet Blizzards Symbole selbst in einem festen Raster an
-- (rechts oben beginnend, nach links, dann nächste Reihe): Waffen-Symbole,
-- lange Stärkungen, dann Kurzes/HoTs ganz links. Läuft bei jeder Änderung
-- sofort (keine Lücken, kein Springen), Schwächungen darunter.
local laying = false
local function layoutBuffs()
    if laying or not db.blizzardMode or db.healFirst == false then return end
    local bf = _G.BuffFrame
    if not bf then return end
    local buffs = shownButtons("BuffButton")
    if #buffs == 0 or (InCombatLockdown() and buffs[1]:IsProtected()) then return end
    local w, h = buffs[1]:GetWidth(), buffs[1]:GetHeight()
    if not w or w <= 0 then return end
    local gapX = math.abs(tonumber(BUFF_HORIZ_SPACING) or 5)
    if gapX < 2 then gapX = 5 end
    local rowH = h + 14                     -- Platz für die Zeit unter dem Symbol
    local per = tonumber(BUFFS_PER_ROW) or 10
    local long, short = {}, {}
    for _, b in ipairs(buffs) do
        if isShort(b) then short[#short + 1] = b else long[#long + 1] = b end
    end
    local order = shownButtons("TempEnchant")
    for _, b in ipairs(long) do order[#order + 1] = b end
    for _, b in ipairs(short) do order[#order + 1] = b end
    laying = true
    for i, b in ipairs(order) do
        local col, row = (i - 1) % per, math.floor((i - 1) / per)
        b:ClearAllPoints()
        b:SetPoint("TOPRIGHT", bf, "TOPRIGHT", -col * (w + gapX), -row * rowH)
    end
    local top = -math.ceil(#order / per) * rowH - 10
    for i, b in ipairs(shownButtons("DebuffButton")) do
        local col, row = (i - 1) % per, math.floor((i - 1) / per)
        b:ClearAllPoints()
        b:SetPoint("TOPRIGHT", bf, "TOPRIGHT", -col * (w + gapX), top - row * rowH)
    end
    laying = false
    requestSwipes()
end

-- jedes Symbol meldet sich, wenn Blizzard es setzt, zeigt oder versteckt
local function watchButton(b)
    if not b or b.mhWatched then return end
    b.mhWatched = true
    hooksecurefunc(b, "SetPoint", function() if not laying then layoutBuffs() end end)
    b:HookScript("OnShow", function() layoutBuffs() end)
    b:HookScript("OnHide", function() layoutBuffs() end)
end

local function watchAll()
    for _, pre in ipairs({ "BuffButton", "DebuffButton", "TempEnchant" }) do
        for i = 1, 40 do
            local b = _G[pre .. i]
            if not b then if i > 3 then break end else watchButton(b) end
        end
    end
end

local function useBlizzard()
    for _, n in ipairs({ "BuffFrame", "DebuffFrame", "TemporaryEnchantFrame" }) do
        local f = _G[n]
        if f and f.SetPoint and not f.mhPlaced then
            f.mhPlaced = true
            hooksecurefunc(f, "SetPoint", function() if not placing then placeBlizzard() end end)
            hooksecurefunc(f, "SetParent", function() if not placing then placeBlizzard() end end)
            if f.Show then f:Show() end
        end
    end
    placeBlizzard()
    styleAll()
    -- HUD-Bearbeitungsmodus auf/zu: Schwächungen umsetzen (siehe placeBlizzard)
    ns.OnEditMode(function(em)
        if em.mhAuras then return end
        em.mhAuras = true
        local function later()
            C_Timer.After(0.1, placeBlizzard)
            C_Timer.After(0.6, placeBlizzard)
        end
        em:HookScript("OnShow", later)
        em:HookScript("OnHide", later)
        local bf = _G.BuffFrame
        if bf then bf:HookScript("OnSizeChanged", function() if editing() then later() end end) end
        if em:IsShown() then later() end
    end)
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
local function makeBlock(key, filter, label)
    local cfg = db[key]
    local block = CreateFrame("Frame", "MondhainAuras_" .. key, UIParent)
    block:SetPoint(cfg.point[1], UIParent, cfg.point[3], cfg.point[4], cfg.point[5])
    -- Schablone gut greifbar: eine Reihe breit
    if db.blizzardMode then
        block:SetSize(db.size * math.min(db.perRow or 12, 10), db.size)
    else
        block:SetSize(db.size, db.size)
    end
    block.filter = filter
    block.icons = {}
    block.updateNow = function() updateBlock(block) end
    blocks[key] = block
    ns.MakeMovable(block, cfg, label)
    return block
end

function mod:OnEnable()
    db = ns.db.auras
    if not db.enabled then return end
    makeBlock("buffs", "HELPFUL", "Stärkungen")
    makeBlock("debuffs", "HARMFUL", "Schwächungen")
    for _, block in pairs(blocks) do updateBlock(block) end

    local ev = CreateFrame("Frame")
    ev:RegisterUnitEvent("UNIT_AURA", "player")
    ev:SetScript("OnEvent", function(_, _, _, info)
        pcall(onAura, info)
        for _, block in pairs(blocks) do updateBlock(block) end
    end)
    onAura(nil)
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function()
        if testMode then mod:SetTest(false) end
    end)
    -- nach dem Kampf sofort und kurz danach noch einmal neu lesen
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
        for _, block in pairs(blocks) do updateBlock(block) end
        C_Timer.After(0.5, function() for _, block in pairs(blocks) do updateBlock(block) end end)
    end)
    ns.RegisterEvent("PLAYER_ENTERING_WORLD", function()
        for _, block in pairs(blocks) do updateBlock(block) end
    end)
    C_Timer.NewTicker(0.25, updateTimes)
    -- Sicherheitsnetz: im Kampf zweimal pro Sekunde, sonst jede Sekunde neu lesen,
    -- falls ein Auslaufen ohne Meldung passiert (Restzeit im Kampf oft geheim)
    local tick = 0
    C_Timer.NewTicker(0.5, function()
        if testMode then return end
        tick = tick + 1
        if InCombatLockdown() or tick % 2 == 0 then
            for _, block in pairs(blocks) do updateBlock(block) end
        end
    end)

    if db.blizzardMode then
        useBlizzard()
        C_Timer.After(1, useBlizzard)
        C_Timer.NewTicker(1, styleAll)       -- neue Symbole gestalten
        -- eigenes Raster: Kurzes/HoTs links, sofort bei jeder Änderung
        if BuffFrame_UpdateAllBuffAnchors then hooksecurefunc("BuffFrame_UpdateAllBuffAnchors", layoutBuffs) end
        if AuraButton_Update then
            hooksecurefunc("AuraButton_Update", function(name, index)
                local b = _G[(name or "") .. (index or "")]
                if b then styleButton(b); watchButton(b) end
                layoutBuffs()
            end)
        end
        watchAll()
        C_Timer.NewTicker(1, function() watchAll(); pcall(layoutBuffs) end)
        local sev = CreateFrame("Frame")
        sev:RegisterUnitEvent("UNIT_AURA", "player")
        sev:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")
        sev:RegisterEvent("PLAYER_REGEN_ENABLED")
        sev:RegisterEvent("UNIT_INVENTORY_CHANGED")
        sev:SetScript("OnEvent", function(_, e, _, _, spellID)
            if e == "UNIT_SPELLCAST_SUCCEEDED" then
                C_Timer.After(0.2, function() onOwnCast(spellID) end)
            else
                requestSwipes()
            end
        end)
        ns.RegisterEvent("PLAYER_REGEN_ENABLED", placeBlizzard)
        -- (Schablone verschoben → die Leiste hängt an ihr und folgt von selbst)
    elseif db.hideBlizzard then
        hideBlizzard()
        C_Timer.After(1, hideBlizzard)
    end
end
