-- Mondhain – Blizzard-Teile verschieb- und skalierbar machen
-- Mikromenü, Taschen, Erfahrung, Ruf, Gestaltleiste, Begleiterleiste …
--
-- Jedes Teil bekommt einen eigenen Halter (wie ein Bilderrahmen). Das Blizzard-Teil
-- wird in den Rahmen gesteckt; verschoben und skaliert wird der Rahmen.
-- Versucht Blizzard das Teil woanders hinzusetzen, steckt Mondhain es zurück.
--
-- Pro Teil sind mehrere mögliche Namen hinterlegt, weil Forever teils andere
-- Rahmennamen nutzt als Retail. Gefunden wird der erste, der existiert.

local _, ns = ...
local mod = ns.NewModule("BlizzardFrames")
ns.BlizzardFrames = mod

local PARTS = {
    { key = "micro",   label = "Mikromenü",       names = { "MicroMenuContainer", "MicroMenu", "MicroButtonAndBagsBar" } },
    { key = "bags",    label = "Taschen",         names = { "BagsBar", "MainMenuBarBackpackButton" } },
    { key = "xp",      label = "Erfahrung",       names = { "MainStatusTrackingBarContainer", "MainMenuExpBar", "MainMenuBarExpBar", "ExpBar", "StatusTrackingBarManager" } },
    { key = "rep",     label = "Ruf",             names = { "SecondaryStatusTrackingBarContainer", "ReputationWatchBar" } },
    { key = "stance",  label = "Gestaltleiste",   names = { "StanceBar", "StanceBarFrame" } },
    { key = "pet",     label = "Begleiterleiste", names = { "PetActionBar", "PetActionBarFrame" } },
    { key = "leave",   label = "Absteigen",       names = { "MainMenuBarVehicleLeaveButton" } },
    { key = "cast",    label = "Zauberleiste",    names = { "PlayerCastingBarFrame", "CastingBarFrame" } },
    -- Forevers Schwungtimer (drei Balken, in Blizzards HUD-Bearbeitung einstellbar)
    { key = "swingMain",   label = "Schwung Waffenhand", names = { "SwingTimerMainHandFrame", "SwingTimerMainhandFrame", "SwingTimerMeleeFrame" },
      pattern = "^SwingTimer.*[Mm]ain.*Frame$" },
    { key = "swingOff",    label = "Schwung Schildhand", names = { "SwingTimerOffHandFrame", "SwingTimerOffhandFrame" },
      pattern = "^SwingTimer.*[Oo]ff.*Frame$" },
    { key = "swingRanged", label = "Schwung Distanz",    names = { "SwingTimerRangedFrame" },
      pattern = "^SwingTimer.*[Rr]anged.*Frame$" },
    -- Blizzards Abklingzeitmanager (z. B. die „Dornen“-Leiste). Standard: bleibt bei
    -- Blizzard und wird im HUD-Bearbeitungsmodus verschoben (dort klappt es zuverlässig);
    -- nur mit ns.db.manageCooldowns = true übernimmt Mondhain ihn.
    { key = "cdBars", cooldown = true,      label = "Abklingzeiten: Leisten (z. B. Dornen)", names = { "BuffBarCooldownViewer" },
      pattern = "^BuffBar.*CooldownViewer$", default = { "BOTTOM", "UIParent", "BOTTOM", 0, 360 } },
    { key = "cdBuffs", cooldown = true, label = "Abklingzeiten: Stärkungen", names = { "BuffIconCooldownViewer" },
      pattern = "^BuffIcon.*CooldownViewer$", default = { "BOTTOM", "UIParent", "BOTTOM", 0, 410 } },
    { key = "cdEssential", cooldown = true, label = "Abklingzeiten: Wichtig",    names = { "EssentialCooldownViewer" },
      pattern = "^Essential.*CooldownViewer$" },
    { key = "cdUtility", cooldown = true, label = "Abklingzeiten: Nützlich",   names = { "UtilityCooldownViewer" },
      pattern = "^Utility.*CooldownViewer$" },
}

local found = {}

local function isFrame(f) return type(f) == "table" and f.GetObjectType ~= nil end

local function findTarget(part)
    for _, n in ipairs(part.names) do
        local f = _G[n]
        if isFrame(f) then return f, n end
    end
    -- Notweg: nach Namensmuster suchen (Forever benennt manches anders)
    if part.pattern then
        for k, v in pairs(_G) do
            if type(k) == "string" and k:find(part.pattern) and isFrame(v) then return v, k end
        end
    end
end

local function wrap(part)
    -- Blizzards Gestaltleiste wird durch Mondhains eigene ersetzt
    if part.key == "stance" and ns.db.stanceBar.enabled then return end
    -- Abklingzeitmanager nur auf Wunsch (sonst zwei Systeme, die sich streiten)
    if (part.cooldown or part.key:find("^cdx_")) and not ns.db.manageCooldowns then return end
    if found[part.key] then return end -- schon im Rahmen
    local target, name = findTarget(part)
    if not target then return end

    local db = ns.db.blizz[part.key] or {}
    ns.db.blizz[part.key] = db

    local holder = CreateFrame("Frame", "MondhainHolder_" .. part.key, UIParent)
    -- Abklingzeit-Leisten sind leer oft winzig → Schablone trotzdem gut greifbar
    local minW, minH = 30, 12
    if part.key:find("^cd") then minW, minH = 160, 28 end
    local w, h = target:GetWidth(), target:GetHeight()
    holder:SetSize(math.max(w or 0, minW), math.max(h or 0, minH))

    if not db.point and part.default then db.point = part.default end
    if db.point then
        holder:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    else
        -- Startposition: dort, wo Blizzard das Teil gerade hat
        local x, y = target:GetCenter()
        if x and y then
            local s = target:GetEffectiveScale() / UIParent:GetEffectiveScale()
            holder:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x * s, y * s)
        else
            holder:SetPoint("CENTER")
        end
    end

    local busy = false
    local function anchor()
        if busy then return end
        if InCombatLockdown() and target:IsProtected() then return end
        busy = true
        if target:GetParent() ~= holder then target:SetParent(holder) end
        target:ClearAllPoints()
        target:SetPoint("CENTER", holder, "CENTER")
        busy = false
    end

    -- Wird das Teil in Blizzards eigenem Bearbeitungsmodus gezogen, übernimmt
    -- der Rahmen die neue Stelle (statt das Teil zurückzuschnappen)
    local function adoptPosition()
        local cx, cy = target:GetCenter()
        if not cx then return end
        local k = target:GetEffectiveScale() / holder:GetEffectiveScale()
        local x, y = cx * k, cy * k
        holder:ClearAllPoints()
        holder:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y)
        db.point = { "CENTER", "UIParent", "BOTTOMLEFT", x, y }
    end
    hooksecurefunc(target, "StopMovingOrSizing", function()
        if busy then return end
        if InCombatLockdown() and holder:IsProtected() then return end
        adoptPosition()
        anchor()
    end)

    hooksecurefunc(target, "SetPoint", function() if not busy then anchor() end end)
    hooksecurefunc(target, "SetParent", function() if not busy then anchor() end end)
    target:HookScript("OnSizeChanged", function(_, nw, nh)
        if not (InCombatLockdown() and holder:IsProtected()) then
            holder:SetSize(math.max(nw or 0, minW), math.max(nh or 0, minH))
        end
    end)

    anchor()
    -- selbst verschoben → hängt nicht mehr am Mittelblock
    ns.MakeMovable(holder, db, part.label, function() db.free = true end)
    found[part.key] = name
end

-- Jede weitere „…CooldownViewer“-Leiste bekommt ebenfalls einen Rahmen
local function wrapOtherViewers()
    if not ns.db.manageCooldowns then return end
    local known = {}
    for _, n in pairs(found) do known[n] = true end
    for k, v in pairs(_G) do
        if type(k) == "string" and k:find("CooldownViewer$") and isFrame(v) and not known[k]
            and v.GetParent and v:GetParent() ~= nil then
            local key = "cdx_" .. k
            if not found[key] then
                wrap({ key = key, label = "Abklingzeiten: " .. k:gsub("CooldownViewer$", ""), names = { k } })
            end
        end
    end
end

---------------------------------------------------------------------------
-- Dornen-Leiste (BuffBarCooldownViewer): Mondhain übernimmt sie wieder, aber
-- ohne sie umzuhängen – sie wird nur an eine eigene Schablone geheftet. Setzt
-- Blizzard sie woanders hin, heftet Mondhain sie zurück. Verschoben wird im
-- Mondhain-Bearbeitungsmodus („Dornen-Leiste“).
---------------------------------------------------------------------------
-- Ben 26.11. 07:09: auch die übrigen Leisten des Abklingzeitmanagers (bei Steve
-- über den Aktionsleisten, im Blizzard-Bearbeitungsmodus nicht greifbar) bekommen
-- so eine Schablone. Start: dort, wo Blizzard sie gerade hat.
local OWNED = {
    { key = "cdBarsOwn", name = "BuffBarCooldownViewer", label = "Dornen-Leiste (Abklingzeiten)",
      default = { "BOTTOM", "UIParent", "BOTTOM", 0, 360 } },
    { key = "cdIconsOwn", name = "BuffIconCooldownViewer", label = "Abklingzeiten: Stärkungen" },
    { key = "cdEssOwn",   name = "EssentialCooldownViewer", label = "Abklingzeiten: Wichtig" },
    { key = "cdUtilOwn",  name = "UtilityCooldownViewer",  label = "Abklingzeiten: Nützlich" },
}

local function ownViewer(o)
    local v = _G[o.name]
    if not isFrame(v) or v.mhOwned then return end
    if InCombatLockdown() and v:IsProtected() then return end
    v.mhOwned = true
    local db = ns.db.blizz[o.key] or {}
    ns.db.blizz[o.key] = db
    if not db.point and o.default then db.point = o.default end
    if not db.point then
        local t = v:GetTop()
        local cx = v:GetCenter()
        if cx and t then
            local k = v:GetEffectiveScale() / UIParent:GetEffectiveScale()
            db.point = { "TOP", "UIParent", "BOTTOMLEFT", cx * k, t * k }
        else
            db.point = { "BOTTOM", "UIParent", "BOTTOM", 0, 420 }
        end
    end
    local m = CreateFrame("Frame", "MondhainHolder_" .. o.key, UIParent)
    local vw, vh = v:GetWidth() or 0, v:GetHeight() or 0
    m:SetSize(math.max(vw, 160), math.max(vh, 30))
    m:SetPoint(db.point[1], UIParent, db.point[3], db.point[4], db.point[5])
    local busy = false
    local function apply()
        if busy or (InCombatLockdown() and v:IsProtected()) then return end
        busy = true
        pcall(function()          -- busy wird in jedem Fall wieder frei
            v:ClearAllPoints()
            v:SetPoint("TOP", m, "TOP", 0, 0)
        end)
        busy = false
    end
    hooksecurefunc(v, "SetPoint", function() if not busy then apply() end end)
    ns.MakeMovable(m, db, o.label, apply, true)
    apply()
end

local function ownViewers()
    for _, o in ipairs(OWNED) do ownViewer(o) end
end

function mod:GetTarget(key)
    local n = found[key]
    return n and _G[n]
end

function ns.DebugFrames()
    ns.Print("Gefundene Blizzard-Teile:")
    for _, part in ipairs(PARTS) do
        local n = found[part.key]
        if n then
            print(("  |cff33ff33%s|r → %s"):format(part.label, n))
        else
            print(("  |cff888888%s|r → nicht gefunden"):format(part.label))
        end
    end
    -- Abklingzeitmanager: alles, was es im Spiel gibt
    local cds = {}
    for k, v in pairs(_G) do
        if type(k) == "string" and k:find("CooldownViewer") and isFrame(v) then
            cds[#cds + 1] = ("%s%s"):format(k, v:IsShown() and "" or " (versteckt)")
        end
    end
    if #cds > 0 then
        table.sort(cds)
        print("  Abklingzeit-Rahmen im Spiel: " .. table.concat(cds, ", "))
    end
    -- Alles, was nach Schwungtimer klingt (falls Namen anders lauten)
    local extra = {}
    for k, v in pairs(_G) do
        if type(k) == "string" and k:find("^SwingTimer") and isFrame(v) then extra[#extra + 1] = k end
    end
    if #extra > 0 then
        table.sort(extra)
        print("  Schwungtimer-Rahmen im Spiel: " .. table.concat(extra, ", "))
    end
end

---------------------------------------------------------------------------
-- Blizzards HUD-Bearbeitungsmodus: mit „Erweiterte Optionen“ ragt der Inhalt
-- unten aus dem Fenster (Rahmen bleibt so hoch wie zugeklappt, die Knöpfe
-- stehen mitten in den Häkchen). Fensterhöhe an den Inhalt anpassen.
-- Nur SetHeight – keine Blizzard-Funktion aus Mondhain-Code aufrufen.
--
-- Gemessen wird wie mit einem Zollstock von der Oberkante aus: nur Kanten,
-- die beim Wachsen des Fensters stehen bleiben (von oben her aufgehängt).
-- Was unten am Fenster festgemacht ist (Rand, Hintergrund, Knöpfe), wandert
-- mit und wird nicht gemessen – sonst schaukelt es sich auf (Fehler 0.34.1).
-- Kästen, die bis zum unteren Rand gespannt sind, zählen selbst nicht, ihr
-- Inhalt aber schon (0.35.1 hat solche Kästen samt Inhalt übersprungen).
---------------------------------------------------------------------------
local emBase, emSetting, emChanged, emGiveUp
local emResets = {}
local emLastWant, emLastSet
local emInfo = {}

local function vpart(p)
    if type(p) ~= "string" then return "mid" end
    if p:find("^TOP") then return "top" end
    if p:find("^BOTTOM") then return "bottom" end
    return "mid"
end

-- Wandert diese Kante („top“/„bottom“) von r mit, wenn das Fenster unten wächst?
local depCache
local function edgeMoves(r, edge, em, d)
    if r == em then return edge ~= "top" end
    if type(r) ~= "table" or not r.GetNumPoints or r == UIParent or r == WorldFrame or d > 14 then
        return false
    end
    local c = depCache[r]
    if c and c[edge] ~= nil then return c[edge] end
    c = c or {}
    depCache[r] = c
    c[edge] = false                              -- Schutz gegen Kreise
    local same, mid, other
    local ok = pcall(function()
        for i = 1, (r:GetNumPoints() or 0) do
            local p, rel, rp = r:GetPoint(i)
            local a = { rel = rel or r:GetParent(), rp = rp }
            local v = vpart(p)
            if v == edge then same = same or {}; same[#same + 1] = a
            elseif v == "mid" then mid = mid or {}; mid[#mid + 1] = a
            else other = other or {}; other[#other + 1] = a end
        end
    end)
    if not ok then return false end
    local res = false
    for _, a in ipairs(same or mid or other or {}) do
        local rv = vpart(a.rp)
        local m
        if rv == "mid" then
            m = edgeMoves(a.rel, "top", em, d + 1) or edgeMoves(a.rel, "bottom", em, d + 1)
        else
            m = edgeMoves(a.rel, rv, em, d + 1)
        end
        if m then res = true break end
    end
    c[edge] = res
    return res
end

local function frameLabel(f)
    local n = f.GetName and f:GetName()
    if n then return n end
    local p = f.GetParent and f:GetParent()
    if p then
        for k, v in pairs(p) do
            if v == f and type(k) == "string" then return frameLabel(p) .. "." .. k end
        end
    end
    return tostring(f.GetObjectType and f:GetObjectType() or "?")
end

local function setEmHeight(em, h)
    emSetting = true
    em:SetHeight(h)
    emSetting = false
end

local function fitEditMode(report)
    local em = _G.EditModeManagerFrame
    if not (em and em:IsShown()) or (InCombatLockdown() and em:IsProtected()) then return end
    -- nach einer Pause neu versuchen (Blizzard ordnet beim Öffnen mehrmals um)
    if emGiveUp and GetTime() - emGiveUp > 3 then emGiveUp, emResets = nil, {} end
    if not report and ((ns.db and ns.db.editModeFit == false) or emGiveUp) then return end
    local top, bottom = em:GetTop(), em:GetBottom()
    local l, r = em:GetLeft(), em:GetRight()
    if not (top and bottom and l and r) then return end
    emBase = emBase or em:GetHeight()
    depCache = {}

    local skip = { [em.Grid or 0] = true }
    local lowest, lowestF, footer, footerF = nil, nil, 0, nil
    local function scan(parent, depth)
        for _, c in ipairs({ parent:GetChildren() }) do
            local forbidden = c.IsForbidden and c:IsForbidden()
            if not forbidden and not skip[c] and c:IsVisible() then
                local cl, cr, ct, cb = c:GetLeft(), c:GetRight(), c:GetTop(), c:GetBottom()
                if cl and cr and ct and cb and cr > l + 4 and cl < r - 4 and cl >= l - 8 and cr <= r + 8 then
                    if edgeMoves(c, "top", em, 0) then
                        -- unten festgemacht: kleine Teile sind die Knöpfe → Platz unten
                        if ct - cb < 80 and ct - bottom > footer then footer, footerF = ct - bottom, c end
                    elseif not edgeMoves(c, "bottom", em, 0) and ct <= top + 4 and ct - cb < 700 then
                        if not lowest or cb < lowest then lowest, lowestF = cb, c end
                    end
                    if depth > 0 then scan(c, depth - 1) end
                end
            end
        end
    end
    scan(em, 8)
    footer = (footer > 0 and footer or 40) + 10

    local want
    if lowest and lowest < top then
        want = math.max(emBase, top - lowest + footer)
        want = math.min(want, top - 10)  -- nie unter den Bildschirmrand
    end
    emInfo = { h = em:GetHeight(), base = emBase, lowestF = lowestF,
        content = lowest and (top - lowest), footer = footer, footerF = footerF, want = want,
        giveUp = emGiveUp }
    if report or not want then return end
    if math.abs(want - em:GetHeight()) > 2 then
        setEmHeight(em, want)
        emChanged = true
        emLastWant, emLastSet = want, GetTime()
        emInfo.after = em:GetHeight()
    end
end

local function hookEditMode()
    local em = _G.EditModeManagerFrame
    if not em or em.mhFit then return end
    em.mhFit = true
    -- Blizzards eigene Höhe merken (Untergrenze und Wert beim Schließen);
    -- setzt Blizzard neu, gleich danach wieder anpassen. Setzt Blizzard
    -- ständig zurück (Tauziehen), gibt Mondhain für dieses Öffnen nach.
    local function blizzSet()
        if emSetting then return end
        local h = em:GetHeight()
        emBase = h
        if not em:IsShown() then return end
        -- als Tauziehen zählt nur, wenn Blizzard unsere Höhe gleich wieder kürzt
        -- (beim Öffnen ordnet Blizzard selbst mehrmals um – das ist kein Streit)
        local now = GetTime()
        if emLastWant and h < emLastWant - 2 and now - (emLastSet or 0) < 0.5 then
            emResets[#emResets + 1] = now
            while emResets[1] and now - emResets[1] > 2 do table.remove(emResets, 1) end
            if #emResets > 12 then emGiveUp = now return end
        end
        C_Timer.After(0, function() fitEditMode() end)
    end
    hooksecurefunc(em, "SetHeight", blizzSet)
    hooksecurefunc(em, "SetSize", blizzSet)
    em:HookScript("OnShow", function()
        emGiveUp, emResets = nil, {}
        -- Blizzard baut das Fenster beim Öffnen in mehreren Schritten → mehrmals nachziehen
        for _, d in ipairs({ 0, 0.1, 0.4, 1, 2 }) do
            C_Timer.After(d, function() fitEditMode() end)
        end
    end)
    em:HookScript("OnHide", function()
        if emChanged and emBase and not (InCombatLockdown() and em:IsProtected()) then
            setEmHeight(em, emBase)
            emChanged = false
        end
    end)
    -- Auf-/Zuklappen der Optionen ändert nicht immer eine Größe → solange das
    -- Fenster offen ist, alle 0,3 s nachsehen
    local acc = 0
    em:HookScript("OnUpdate", function(_, el)
        acc = acc + el
        if acc < 0.3 then return end
        acc = 0
        fitEditMode()
    end)
    if em:IsShown() then C_Timer.After(0, function() fitEditMode() end) end
end

-- /mh hud: Anpassung an/aus (zum Vergleichen mit Blizzards Original)
function ns.ToggleEditModeFit(on)
    if on == nil then on = ns.db.editModeFit == false end
    ns.db.editModeFit = on and true or false
    local em = _G.EditModeManagerFrame
    if ns.db.editModeFit == false and em and emChanged and emBase then
        setEmHeight(em, emBase)
        emChanged = false
    end
    hookEditMode()
    emGiveUp = nil
    if ns.db.editModeFit ~= false then fitEditMode() end
    ns.Print("HUD-Bearbeitungsmodus: Fensterhöhe anpassen " ..
        (ns.db.editModeFit == false and "|cffff6060aus|r (Blizzard-Original)" or "|cff33ff33an|r"))
end

-- /mh hud info: was die Messung sieht (bei offenem HUD-Bearbeitungsmodus)
function ns.EditModeFitInfo()
    local em = _G.EditModeManagerFrame
    if not (em and em:IsShown()) then
        ns.Print("Erst den HUD-Bearbeitungsmodus öffnen (Erweiterte Optionen an), dann /mh hud info.")
        return
    end
    fitEditMode(true)
    local i = emInfo
    local function n(v) return v and ("%.0f"):format(v) or "–" end
    ns.Print(("HUD-Fenster: Höhe %s, Blizzard %s, Inhalt %s, unten %s → Soll %s"):format(
        n(i.h), n(i.base), n(i.content), n(i.footer), n(i.want)))
    print("  unterstes Teil: " .. (i.lowestF and frameLabel(i.lowestF) or "–"))
    print("  Knopfleiste: " .. (i.footerF and frameLabel(i.footerF) or "–"))
    local pts = {}
    for k = 1, em:GetNumPoints() do
        local p, rel, rp, x, y = em:GetPoint(k)
        pts[#pts + 1] = ("%s→%s %s (%.0f,%.0f)"):format(p, rel and frameLabel(rel) or "nil", rp, x or 0, y or 0)
    end
    print("  Anker: " .. table.concat(pts, ", "))
    print("  Anpassung: " .. (ns.db.editModeFit == false and "aus" or "an")
        .. (em.mhFit and "" or " · |cffff6060nicht eingehängt|r")
        .. (i.giveUp and " · |cffff6060Blizzard setzt ständig zurück (neuer Versuch in 3 s)|r" or ""))
end

function mod:OnEnable()
    ns.OnEditMode(hookEditMode)
    if not ns.db.manageBlizz then return end
    -- Einen Moment warten, bis Blizzard sein eigenes Layout gesetzt hat
    C_Timer.After(0.5, function()
        if InCombatLockdown() then
            ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
                if not next(found) then for _, p in ipairs(PARTS) do wrap(p) end end
            end)
            return
        end
        for _, p in ipairs(PARTS) do wrap(p) end
    end)
    -- Manche Teile (Abklingzeitmanager) lädt Blizzard erst später nach
    local function retry()
        if InCombatLockdown() then return end
        for _, p in ipairs(PARTS) do wrap(p) end
        wrapOtherViewers()
        ownViewers()
    end
    C_Timer.After(3, retry)
    C_Timer.After(8, retry)
    ns.RegisterEvent("ADDON_LOADED", function(_, name)
        if type(name) == "string" and name:find("CooldownViewer") then C_Timer.After(0.5, retry) end
    end)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", retry)
end
