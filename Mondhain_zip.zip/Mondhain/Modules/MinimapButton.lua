-- Mondhain – Knopf am Rand der Minikarte
-- Linksklick: Optionen · Rechtsklick: Verschieben & Größe · Ziehen: Knopf um die Karte schieben

local _, ns = ...
local mod = ns.NewModule("MinimapButton")

local ICON = "Interface\\Icons\\Ability_Druid_Maul"

local function placeButton(b, angle)
    local rad = math.rad(angle)
    local r = (Minimap:GetWidth() / 2) + 6
    b:ClearAllPoints()
    b:SetPoint("CENTER", Minimap, "CENTER", math.cos(rad) * r, math.sin(rad) * r)
end

function mod:OnEnable()
    local db = ns.db.minimap
    if db.hide or not Minimap then return end

    local b = CreateFrame("Button", "MondhainMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(Minimap:GetFrameLevel() + 8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")

    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetSize(20, 20)
    bg:SetPoint("CENTER")

    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(ICON)
    icon:SetSize(18, 18)
    icon:SetPoint("CENTER")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    placeButton(b, db.angle)

    -- Ziehen: nur während des Ziehens wird die Mausposition verfolgt
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            db.angle = math.deg(math.atan2(cy / s - my, cx / s - mx))
            placeButton(self, db.angle)
        end)
    end)
    b:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)

    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            ns.SetUnlocked(ns.db.locked) -- an/aus
        elseif ns.ToggleOptions then
            ns.ToggleOptions()
        end
    end)

    b:SetScript("OnEnter", function(self)
        ns.TooltipBeside(self)
        GameTooltip:AddLine("Mondhain", 1, 0.49, 0.04)
        GameTooltip:AddLine("Linksklick: Optionen", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Rechtsklick: Verschieben & Größe", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Ziehen: Knopf verschieben", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
end
