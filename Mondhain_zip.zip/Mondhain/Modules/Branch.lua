-- Mondhain – der Ast (Teldrassil)
-- Ein einziger Ast läuft vom linken bis zum rechten Bildschirmrand. Er legt sich
-- über die Oberkanten der Elemente am unteren Rand (Chat, Tafeln, Karte, Leisten
-- samt Schwung/Zauber, Questtracker) – flach, wo sie flach sind, mit einer Krone
-- über der Mitte, mit Senken dazwischen. Darunter ist alles Stamm: eine durch-
-- gehende Rindenfläche, in der die Elemente eingelassen sitzen.
-- Spieler, Ziel und andere schwebende Fenster bleiben draußen; der Ast taucht
-- unter ihnen durch. Verschiebt man etwas, wächst der Ast neu.
-- Ersetzt die alte Wurzel (Root.lua), solange er eingeschaltet ist.

local _, ns = ...
local mod = ns.NewModule("Branch")
ns.Branch = mod

local MEDIA = "Interface\\AddOns\\Mondhain\\media\\"
local STEP = 8                    -- Abstand der Stützpunkte (UI-Einheiten)
local STRANG_V = { 16 / 128, 111 / 128 } -- Holzband im Ast-Bild (1024 x 128)
local TILE = 1024 / 95            -- Kachellänge im Verhältnis zur Dicke
local BARK_TILE = 300             -- Kantenlänge einer Rindenkachel (UI-Einheiten)
local LEAVES = { "efeu_blatt", "efeu_blatt2", "efeu_blatt3" }
local SHOULDER = 170              -- wie weit ein Buckel seitlich ausläuft (sanfte Hänge)
local TAB_H = 22                  -- Chat-Reiter über dem Chat

-- Farbstimmungen: welche Bilder, dazu Multiplikatoren für Ast, Stamm, Schmuck, Ranken
local M_STRAND, M_BARK = "ast_strang_mahagoni", "stamm_mahagoni"
local V_STRAND, V_BARK = "ast_strang", "stamm"
local PALETTES = {
    mahagoni   = { label = "Mahagoni", strand = M_STRAND, bark = M_BARK,
        branch = { 1, 1, 1 }, trunk = { 0.92, 0.92, 0.92 }, orn = { 1, 1, 1 }, vine = { 0.95, 0.86, 0.80 } },
    mahagoniD  = { label = "Mahagoni dunkel", strand = M_STRAND, bark = M_BARK,
        branch = { 0.80, 0.76, 0.74 }, trunk = { 0.62, 0.60, 0.58 }, orn = { 0.90, 0.90, 0.90 }, vine = { 0.76, 0.70, 0.66 } },
    nachtelf   = { label = "Nachtelf (violett)", strand = V_STRAND, bark = V_BARK,
        branch = { 1, 1, 1 }, trunk = { 0.85, 0.85, 0.85 }, orn = { 1, 1, 1 }, vine = { 0.92, 0.90, 0.96 } },
    mondsilber = { label = "Mondsilber", strand = V_STRAND, bark = V_BARK,
        branch = { 0.84, 0.92, 1 }, trunk = { 0.60, 0.67, 0.80 }, orn = { 0.92, 0.96, 1 }, vine = { 0.85, 0.92, 1 } },
    waldgruen  = { label = "Waldgrün", strand = V_STRAND, bark = V_BARK,
        branch = { 0.80, 0.94, 0.80 }, trunk = { 0.52, 0.68, 0.56 }, orn = { 0.88, 1, 0.90 }, vine = { 0.80, 0.95, 0.80 } },
    -- Ben 25.11. 16:22: Übergangslook für Paladine (bis das echte Gewand kommt):
    -- vergoldetes Holz, Kalkstein, goldenes Licht statt grüner Liane, Goldlaub
    licht      = { label = "Licht (Paladin)", strand = "ast_strang_licht", bark = "stamm_licht",
        fill = "zweig_fuell_licht", knot = "ast_knoten_licht",
        liane = "liane_licht", lianeStrip = "liane_strang_licht",
        leaves = { "efeu_blatt_licht", "efeu_blatt2_licht", "efeu_blatt3_licht" },
        cast = { 0.520, 0.400, 0.140, bot = { 0.200, 0.140, 0.050 } },
        branch = { 1, 1, 1 }, trunk = { 1, 1, 1 }, orn = { 1, 1, 1 }, vine = { 1, 1, 1 } },
}
local PALETTE_ORDER = { "mahagoni", "mahagoniD", "nachtelf", "mondsilber", "waldgruen", "licht" }
mod.PALETTES, mod.PALETTE_ORDER = PALETTES, PALETTE_ORDER
-- Gewänder als Zusatz-Addon (Konzept 11/2026): MondhainAPI.RegisterPalette(key, def)
-- def wie oben, Bildnamen als volle Pfade; def.class = "PALADIN" → Voreinstellung der Klasse
mod.classPalette = {}
MondhainAPI = MondhainAPI or {}
function MondhainAPI.RegisterPalette(key, def)
    if type(key) ~= "string" or type(def) ~= "table" then return end
    def.branch = def.branch or { 1, 1, 1 }; def.trunk = def.trunk or { 1, 1, 1 }
    def.orn = def.orn or { 1, 1, 1 }; def.vine = def.vine or { 1, 1, 1 }
    if not PALETTES[key] then PALETTE_ORDER[#PALETTE_ORDER + 1] = key end
    PALETTES[key] = def
    if def.class then mod.classPalette[def.class] = key end
end
local function palette()
    local b = ns.db.branch
    return PALETTES[b and b.palette or "mahagoni"] or PALETTES.mahagoni
end
-- Bildpfad: Gewänder (Zusatz-Addons) geben volle Pfade, sonst Mondhains media
local function TX(name) if name:find("\\", 1, true) then return name end return MEDIA .. name end
-- Bildnamen je Farbstimmung (Licht hat eigene, sonst Mahagoni/Normal)
local function palFill(pal) return pal.fill or ((pal.strand == M_STRAND) and "zweig_fuell_mahagoni" or "zweig_fuell") end
local function palKnot(pal) return pal.knot or ((pal.strand == M_STRAND) and "ast_knoten_mahagoni" or "ast_knoten") end
local function palLeaves(pal) return pal.leaves or LEAVES end
local function palStrip(pal) return pal.lianeStrip or "liane_strang" end
-- Bauweise (Ben 25.11.: jede Klasse ihre eigene Baseline). pal.arch = { … } macht
-- aus dem gewachsenen Ast einen gemauerten Sockel: gerade Stufen mit Schrägen,
-- Säulen an den Stufen, Goldleiste, Zinnen über der Mitte, Banner, Lichtscheibe.
-- Felder: pillar, cap, merlon, banner, disc, rail (Bilder), slope, mapSlope,
-- bridge, thick, pillarW, merlonW/H/Gap, bannerW/L, discSize, railTh (Maße, optional)
local function palArch(pal) return type(pal.arch) == "table" and pal.arch or nil end
-- Mittelstück: ein Bild (arch.crest) oder eine Auswahl (arch.crests, db.crest)
local function archCrestPick(arch)
    if type(arch.crests) == "table" and #arch.crests > 0 then
        local pick = arch.crests[1]
        local want = ns.db and ns.db.branch and ns.db.branch.crest   -- db ist hier noch nicht da
        for _, c in ipairs(arch.crests) do if c.key == want then pick = c end end
        return pick.tex, pick.aspect or 1, pick.size
    end
    return arch.crest, arch.crestAspect or 1, arch.crestSize
end
-- für andere Module (Kampfanzeige …): aktive Farbstimmung und gewähltes Mittelstück
function ns.ActivePalette() return palette() end
function ns.CurrentCrest()
    local arch = palArch(palette())
    if not arch then return nil end
    return (archCrestPick(arch))
end
MondhainAPI.version = 40
-- Akzentfarbe (Überschriften wie die Questzone): Gewand darf eigene haben,
-- sonst Mondhain-Orange
function ns.Accent(a)
    local pal = ns.db and ns.db.branch and PALETTES and PALETTES[ns.db.branch.palette or "mahagoni"]
    local c = pal and pal.accent
    if c then return c[1], c[2], c[3], a or 1 end
    return 1, 0.49, 0.04, a or 1
end
-- für Zusatz-Addons (z. B. Mondhain_Multibox): Mondhain-Knöpfe und Bearbeiten-Modus
MondhainAPI.SkinButton = function(b, size) return ns.SkinButton(b, size) end
MondhainAPI.MakeMovable = function(frame, db, label, onMoved) return ns.MakeMovable(frame, db, label, onMoved) end
MondhainAPI.Print = function(msg) return ns.Print(msg) end
local STACK = { "swingMain", "cast", "swingOff", "swingRanged" }

-- Elemente, die unten am Rand stehen (der Ast legt sich darüber)
local GROUNDED = {
    { name = "MondhainChatHolder", tabs = true },
    { name = "MondhainBoardLeft" },
    { name = "MondhainMinimapHolder" },
    { name = "MondhainCenterPlate", crown = true },
    { name = "MondhainBoardRight" },
    { name = "MondhainQuestTracker" },
}
-- schwebende Fenster: der Ast bleibt darunter
local FLOATING = {
    "MondhainUnit_player", "MondhainUnit_target", "MondhainUnit_targettarget",
    "MondhainUnit_pet", "MondhainUnit_focus", "MondhainMenuButton",
}
-- Leisten, die unten stehen ODER auf einem unteren Element aufsitzen (z. B. die
-- Parkleiste über dem Chat): dann klammert der Ast sie mit ein, sonst schweben sie
local STACKABLE = { "MondhainBars_park", "MondhainItemBar" }

local db, branchFrame, fillFrame, ornFrame
local lines, strips = {}, {}

---------------------------------------------------------------------------
-- Linien-Vorrat für Schatten, Glanz, Ranken (werden wiederverwendet)
---------------------------------------------------------------------------
local pools = {}
local function pool(name, layer, sub, blend)
    local p = pools[name]
    if not p then
        p = { list = {}, used = 0, layer = layer, sub = sub or 0, blend = blend }
        pools[name] = p
    end
    p.used = 0
    return p
end
local function take(p, tex)
    p.used = p.used + 1
    local ln = p.list[p.used]
    if not ln then
        ln = branchFrame:CreateLine(nil, p.layer, nil, p.sub)
        if p.blend then ln:SetBlendMode(p.blend) end
        p.list[p.used] = ln
    end
    ln:SetTexture(tex, "REPEAT", "CLAMP")
    ln:Show()
    return ln
end
local function finish(p)
    for i = p.used + 1, #p.list do p.list[i]:Hide() end
end
local function seg(ln, x0, y0, x1, y1, th, ext)
    local dx, dy = x1 - x0, y1 - y0
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 0.01 then ln:Hide() return 0 end
    local e = ext or 0
    local ex, ey = dx / len * e, dy / len * e
    ln:SetThickness(math.max(0.5, th))
    ln:SetStartPoint("BOTTOMLEFT", UIParent, x0 - ex, y0 - ey)
    ln:SetEndPoint("BOTTOMLEFT", UIParent, x1 + ex, y1 + ey)
    return len
end
local leaves, wisps = {}, {}
local moon
local lastSig

-- verfolgte Fraktion (für den Ruf-Ast)
local function watchedFaction()
    if C_Reputation and C_Reputation.GetWatchedFactionData then
        local ok, d = pcall(C_Reputation.GetWatchedFactionData)
        if ok and d and d.name then
            return d.name, d.reaction, d.currentReactionThreshold or 0, d.nextReactionThreshold or 0, d.currentStanding or 0
        end
    end
    if GetWatchedFactionInfo then
        local name, standing, min, max, value = GetWatchedFactionInfo()
        if name then return name, standing, min or 0, max or 0, value or 0 end
    end
end
local function repActive()
    return db.repBranch ~= false and db.xpBranch ~= false and watchedFaction() ~= nil
end
mod.RepActive = repActive

local function uiRect(f)
    local l, r, t, b = f:GetLeft(), f:GetRight(), f:GetTop(), f:GetBottom()
    if not (l and r and t and b) then return end
    local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return l * s, r * s, t * s, b * s
end

local function smoothstep(t)
    if t <= 0 then return 0 elseif t >= 1 then return 1 end
    return t * t * (3 - 2 * t)
end

---------------------------------------------------------------------------
-- Was steht wo?
---------------------------------------------------------------------------
local function stackTop(t)
    local mirrored = ns.CenterBlock and ns.CenterBlock.SwingMirrored and ns.CenterBlock.SwingMirrored()
    for _, k in ipairs(STACK) do
        local h = _G["MondhainHolder_" .. k]
        local bdb = ns.db.blizz[k]
        -- Schwung unter dem Spielerrahmen (Spiegel): Blizzards unsichtbarer Balken zählt nicht
        if h and not (bdb and bdb.free) and not (mirrored and k ~= "cast") then
            local tgt = ns.BlizzardFrames and ns.BlizzardFrames:GetTarget(k)
            -- Waffenhand und Zauber haben immer ihren Platz, Schild/Distanz nur wenn da
            if k == "swingMain" or k == "cast" or (tgt and tgt:IsShown()) then
                local _, _, ht = uiRect(h)
                if ht and ht > t and ht - t < 140 then t = ht end
            end
        end
    end
    return t
end

local function collect()
    local plats, ceils, sig = {}, {}, {}
    for _, e in ipairs(GROUNDED) do
        local f = _G[e.name]
        if f and f:IsShown() then
            local l, r, t, b = uiRect(f)
            if l and b < 90 then
                if e.tabs and _G.ChatFrame1Tab then t = t + TAB_H end
                if e.stack then t = stackTop(t) end
                plats[#plats + 1] = { l = l - 6, r = r + 6, top = t, crown = e.crown, name = e.name }
                sig[#sig + 1] = ("%d,%d,%d"):format(l, r, t)
            end
        end
    end
    -- Krone: die Leisten selbst (alle sichtbaren Tasten) zählen mit – ragt eine
    -- Reihe über die Platte hinaus, steigt der Ast mit (Ben 26.11. 06:33)
    for _, p in ipairs(plats) do
        if p.crown then
            local bars = _G.MondhainBars_center
            if bars and bars:IsShown() then
                local top = p.top
                local _, _, bt = uiRect(bars)
                if bt and bt > top then top = bt end
                for _, c in ipairs({ bars:GetChildren() }) do
                    if c:IsShown() and (c:GetAlpha() or 0) > 0.05 then
                        local cl, cr, ct = uiRect(c)
                        if ct and cr > p.l and cl < p.r and ct > top and ct < top + 120 then top = ct end
                    end
                end
                if top > p.top then
                    p.top = top + 2
                    sig[#sig + 1] = ("k%d"):format(top)
                end
            end
        end
    end
    -- aufsitzende Leisten: zweimal prüfen, falls eine auf der anderen sitzt
    local done = {}
    for _ = 1, 2 do
        for _, n in ipairs(STACKABLE) do
            local f = _G[n]
            if not done[n] and f and f:IsShown() then
                local l, r, t, b = uiRect(f)
                if l then
                    local onTop = b < 90
                    for _, p in ipairs(plats) do
                        if r > p.l and l < p.r and b <= p.top + 50 and b >= p.top - 60 then onTop = true end
                    end
                    if onTop then
                        done[n] = true
                        plats[#plats + 1] = { l = l - 6, r = r + 6, top = t, name = n }
                        sig[#sig + 1] = ("s%d,%d,%d"):format(l, r, t)
                    end
                end
            end
        end
    end
    for _, n in ipairs(STACKABLE) do
        local f = _G[n]
        if not done[n] and f and f:IsShown() then
            local l, r, _, b = uiRect(f)
            if l and b >= 90 and b < 420 then
                ceils[#ceils + 1] = { l = l - 4, r = r + 4, bottom = b, name = n }
                sig[#sig + 1] = ("c%d,%d,%d"):format(l, r, b)
            end
        end
    end
    for _, n in ipairs(FLOATING) do
        local f = _G[n]
        if f then
            local l, r, _, b = uiRect(f)
            if l and b >= 90 and b < 420 then
                ceils[#ceils + 1] = { l = l - 4, r = r + 4, bottom = b, name = n }
                sig[#sig + 1] = ("c%d,%d,%d"):format(l, r, b)
            end
        end
    end
    sig[#sig + 1] = ("%d|%d|%d|%d|%d|%s%s%s%s%s%s"):format(UIParent:GetWidth(), db.thickness, db.wave, db.fillAlpha,
        db.fillBright or 100, tostring(db.moon), tostring(db.leaves), tostring(db.wisps), tostring(db.palette),
        tostring(db.depth), tostring(db.tendrils)) .. tostring(db.xpBranch) .. tostring(repActive())
        .. tostring(db.castBranch)
    return plats, ceils, table.concat(sig, ";")
end

---------------------------------------------------------------------------
-- Verlauf berechnen
---------------------------------------------------------------------------
local function blur(ys, radius)
    local n = #ys
    local out = {}
    for i = 1, n do
        local sum, cnt = 0, 0
        for j = math.max(1, i - radius), math.min(n, i + radius) do
            sum, cnt = sum + ys[j], cnt + 1
        end
        out[i] = sum / cnt
    end
    return out
end

-- gleitendes Maximum/Minimum (zum Zumauern schmaler Kerben)
local function slide(ys, r, useMax)
    local n, out = #ys, {}
    for i = 1, n do
        local v = ys[i]
        for j = math.max(1, i - r), math.min(n, i + r) do
            local w = ys[j]
            if useMax then if w > v then v = w end elseif w < v then v = w end
        end
        out[i] = v
    end
    return out
end

-- Gemauerter Sockel: flach über den Elementen, dazwischen gerade Schrägen (45°),
-- keine Wellen, gleich dick. Rechts der Karte steiler (Zaubersymbol liegt frei).
local function computeArch(plats, ceils, arch)
    local W = UIParent:GetWidth()
    local th = db.thickness * (arch.thick or 1)
    local xs, ths, req, cap, ys = {}, {}, {}, {}, {}
    local mapPl
    if db.castBranch ~= false then
        local crown
        for _, pl in ipairs(plats) do
            if pl.name == "MondhainMinimapHolder" then mapPl = pl end
            if pl.crown then crown = pl end
        end
        if not crown then mapPl = nil end
    end
    local k, kMap = arch.slope or 1, arch.mapSlope or 2.4
    -- gerader (Ben 17:06 „nicht so eingeknickt“): Höhen, die nah beieinander
    -- liegen, bekommen eine gemeinsame Ebene (die höhere) – weniger Stufen
    local snap = th * (arch.snap or 0.9)
    -- Luft zwischen Leisten und Balken (Ben 26.11. 06:28: sonst sitzt die Linie zu knapp)
    local crownGap = th * (arch.crownGap or 0.45)
    local function topOf(pl) return pl.top + (pl.crown and crownGap or 0) end
    local tops, level, head = {}, {}, nil
    for _, pl in ipairs(plats) do tops[#tops + 1] = topOf(pl) end
    table.sort(tops, function(a, b) return a > b end)
    for _, t in ipairs(tops) do
        if not head or head - t >= snap then head = t end
        level[t] = head
    end
    local clear = th * 0.5 - 3
    local ground = th * 0.5 + 4
    local x = -STEP * 3
    while x <= W + STEP * 3 do
        local i = #xs + 1
        xs[i], ths[i] = x, th
        local hard, v = ground, ground
        for _, pl in ipairs(plats) do
            local h = (level[topOf(pl)] or topOf(pl)) + clear
            local s
            if x >= pl.l and x <= pl.r then
                s = h
                if h > hard then hard = h end
            elseif x < pl.l then
                s = h - (pl.l - x) * k
            else
                s = h - (x - pl.r) * ((pl == mapPl) and kMap or k)
            end
            if s > v then v = s end
        end
        req[i], ys[i] = hard, v
        local c = math.huge
        for _, cl in ipairs(ceils) do
            if x >= cl.l and x <= cl.r then c = math.min(c, cl.bottom - clear) end
        end
        cap[i] = c
        x = x + STEP
    end
    -- Senken zwischen zwei höheren Stufen zumauern (erst weiten, dann schrumpfen):
    -- der Balken läuft gerade darüber; Stufen und Schrägen bleiben, wie sie sind
    local r = math.max(1, math.floor((arch.bridge or 6) * th / STEP + 0.5))
    ys = slide(slide(ys, r, true), r, false)
    for i = 1, #ys do
        if ys[i] < req[i] then ys[i] = req[i] end
        if ys[i] > cap[i] and cap[i] >= req[i] then ys[i] = cap[i] end
    end
    return xs, ys, ths
end

local function compute(plats, ceils)
    local arch = palArch(palette())
    if arch then return computeArch(plats, ceils, arch) end
    local W = UIParent:GetWidth()
    local base = db.thickness
    local xs, ths, req, cap, ys = {}, {}, {}, {}, {}
    -- Ben 25.11. 08:38 (grüne Linie): rechts neben der Karte fällt der Ast steil
    -- ab, damit das Zaubersymbol frei in der Ecke liegt (nur mit Zauber-Zweig)
    local mapPl
    if db.castBranch ~= false then
        local crown
        for _, pl in ipairs(plats) do
            if pl.name == "MondhainMinimapHolder" then mapPl = pl end
            if pl.crown then crown = pl end
        end
        if not crown then mapPl = nil end
    end
    local other, steep = {}, {}
    local x = -STEP * 3
    while x <= W + STEP * 3 do
        local i = #xs + 1
        xs[i] = x
        -- dicker am linken Ende (zum Stamm hin), dünn auslaufend nach rechts
        local p = math.max(0, math.min(1, x / W))
        local th = base * (1.25 - 0.45 * p)
        th = th * (0.35 + 0.65 * smoothstep((W + STEP * 3 - x) / 90))
        ths[i] = th
        local clear = th * 0.5 - 3

        local hard, soft, oth, stp = 0, 0, 0, 0
        local ground = th * 0.5 + 4
        local steepW = math.max(26, th * 0.9)
        for _, pl in ipairs(plats) do
            local h = pl.top + clear
            local v
            if x >= pl.l and x <= pl.r then
                if h > hard then hard = h end
                v = h
            else
                local d = (x < pl.l) and (pl.l - x) or (x - pl.r)
                if pl == mapPl and x > pl.r then
                    v = ground + (h - ground) * (1 - smoothstep(d / steepW))
                    if v > stp then stp = v end
                else
                    v = ground + (h - ground) * (1 - smoothstep(d / SHOULDER))
                end
            end
            if v > soft then soft = v end
            if pl ~= mapPl and v > oth then oth = v end
        end
        req[i] = math.max(hard, ground)
        ys[i] = math.max(soft, ground)
        other[i] = math.max(oth, ground)
        steep[i] = stp

        local c = math.huge
        for _, cl in ipairs(ceils) do
            if x >= cl.l and x <= cl.r then c = math.min(c, cl.bottom - clear) end
        end
        cap[i] = c
        x = x + STEP
    end

    -- weich machen, Höhen und Tiefen wie bei einem gewachsenen Ast
    ys = blur(blur(ys, 3), 3)
    if mapPl then other = blur(blur(other, 3), 3) end
    local amp = db.wave or 4
    for i = 1, #ys do
        local xx = xs[i]
        local w = amp * (0.5 + 0.5 * math.sin(xx / 61 + 1.3)) * (0.6 + 0.4 * math.sin(xx / 23))
        ys[i] = ys[i] + w
        -- rechts der Karte: der steile Hang wird nicht weichgezeichnet
        if mapPl and xx > mapPl.r then ys[i] = math.max(other[i] + w, steep[i]) end
        ys[i] = math.max(ys[i], req[i])
        if ys[i] > cap[i] and cap[i] >= req[i] then ys[i] = cap[i] end
    end
    ys = blur(ys, 1)
    for i = 1, #ys do
        if ys[i] < req[i] then ys[i] = req[i] end
    end
    return xs, ys, ths
end

---------------------------------------------------------------------------
-- Zeichnen
---------------------------------------------------------------------------
local function draw(xs, ys, ths)
    local L = db.thickness * TILE
    local acc = 0
    local pal = palette()
    local c = pal.branch
    local fa = (db.fillAlpha or 94) / 100
    local fb = (db.fillBright or 100) / 100
    local tc = pal.trunk
    local n = #xs - 1
    -- Richtung jedes Stücks; an Knicken klafft außen ein Keil, wenn die Stücke
    -- nur stumpf aneinanderstoßen (sah aus wie Risse). Darum jedes Ende genau
    -- so weit verlängern, wie der Knick dort braucht.
    local ang = {}
    for i = 1, n do ang[i] = math.atan2(ys[i + 1] - ys[i], xs[i + 1] - xs[i]) end
    local function need(j, th)
        if j <= 1 or j > n then return 0.4 end
        local d = math.abs(ang[j] - ang[j - 1])
        if d > math.pi then d = 2 * math.pi - d end
        return 0.4 + th * 0.5 * math.tan(math.min(d, 1.2) * 0.5)
    end
    for i = 1, n do
        local x0, y0, x1, y1 = xs[i], ys[i], xs[i + 1], ys[i + 1]
        local dx, dy = x1 - x0, y1 - y0
        local len = math.sqrt(dx * dx + dy * dy)

        -- Rinde
        local ln = lines[i]
        if not ln then
            ln = branchFrame:CreateLine(nil, "ARTWORK")
            lines[i] = ln
        end
        ln:SetTexture(TX(pal.strand), "REPEAT", "CLAMP")
        local th = (ths[i] + ths[i + 1]) * 0.5
        local e0, e1 = need(i, th), need(i + 1, th)
        local ux, uy = dx / len, dy / len
        ln:SetThickness(th)
        ln:SetStartPoint("BOTTOMLEFT", UIParent, x0 - ux * e0, y0 - uy * e0)
        ln:SetEndPoint("BOTTOMLEFT", UIParent, x1 + ux * e1, y1 + uy * e1)
        ln:SetTexCoord((acc - e0) / L, (acc + len + e1) / L, STRANG_V[1], STRANG_V[2])
        ln:SetVertexColor(c[1], c[2], c[3])
        ln:Show()
        acc = acc + len

        -- Stamm darunter
        local s = strips[i]
        if not s then
            s = fillFrame:CreateTexture(nil, "BACKGROUND")
            strips[i] = s
        end
        s:SetTexture(TX(pal.bark), "REPEAT", "REPEAT")
        local h = math.max(1, math.min(y0, y1))
        s:ClearAllPoints()
        s:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x0, 0)
        s:SetSize(x1 - x0 + 0.5, h)
        -- Kachel läuft über alle Streifen durch (unten verankert)
        s:SetTexCoord(x0 / BARK_TILE, (x1 + 0.5) / BARK_TILE, -h / BARK_TILE, 0)
        s:SetVertexColor(tc[1] * fb, tc[2] * fb, tc[3] * fb, fa)
        s:Show()
    end
    for i = n + 1, #lines do lines[i]:Hide() end
    for i = n + 1, #strips do strips[i]:Hide() end

    -- Tiefe: weicher Schatten unter dem Ast auf dem Stamm, Glanzkante oben
    local shadow = pool("shadow", "BORDER", 0)
    local rim = pool("rim", "OVERLAY", 0, "ADD")
    if db.depth ~= false then
        local SOFT = MEDIA .. "weich"
        for i = 1, n do
            local th = (ths[i] + ths[i + 1]) * 0.5
            local sh = take(shadow, SOFT)
            seg(sh, xs[i], ys[i] - th * 0.30, xs[i + 1], ys[i + 1] - th * 0.30, th * 1.4, 0)
            sh:SetTexCoord(0, 1, 0, 1)
            sh:SetVertexColor(0, 0, 0, 0.55)
            local rl = take(rim, SOFT)
            seg(rl, xs[i], ys[i] + th * 0.24, xs[i + 1], ys[i + 1] + th * 0.24, th * 0.18, 0)
            rl:SetTexCoord(0, 1, 0, 1)
            rl:SetVertexColor(1, 0.77, 0.55, 0.26)
        end
    end
    finish(shadow)
    finish(rim)
end

---------------------------------------------------------------------------
-- Ranken mit Schnörkeln: dünne Triebe winden sich um den Ast (nur die vorderen
-- Windungen sind zu sehen) und rollen sich am Ende zu einer kleinen Spirale ein
---------------------------------------------------------------------------
local side = { n = 0, x = {}, y = {}, th = {}, arc = {} } -- Erfahrungs-Ast (siehe unten)
local lastPlats, lastCeils = {}, {}
-- Bereich des Zauber-Asts: von der Schräge rechts der Karte bis zur Krone
local function castRange()
    if db.castBranch == false then return end
    local map, crown
    for _, p in ipairs(lastPlats) do
        if p.name == "MondhainMinimapHolder" then map = p end
        if p.crown then crown = p end
    end
    if not crown then return end
    -- Bauweise Stein: Zauberbalken zwischen den beiden Banner-Säulen des Schreins
    local A = mod.archLast
    if palArch(palette()) and A and A.shrineL and A.shrineR then
        local half = db.thickness * 0.5
        local S2, E2 = A.shrineL + half + 4, A.shrineR - half - 4
        if E2 - S2 >= 120 then return S2, E2 end
    end
    local S = map and (map.r + 4) or (crown.l - 120)
    local E = crown.r - 4
    if E - S < 120 then return end
    return S, E
end
local mainPath = {}                                       -- letzter Verlauf des Hauptasts
local TENDRIL_SPOTS = { 0.13, 0.36, 0.57, 0.80 }
local function yAtLinear(xs, ys, x)
    for i = 1, #xs - 1 do
        if x >= xs[i] and x <= xs[i + 1] then
            return ys[i] + (ys[i + 1] - ys[i]) * (x - xs[i]) / (xs[i + 1] - xs[i])
        end
    end
    return ys[#ys]
end

local function tendrils(xs, ys, ths, ceils, avoidX)
    local vine = pool("vine", "OVERLAY", 3)
    local vineSh = pool("vineShadow", "OVERLAY", 2)
    local vineHi = pool("vineHi", "OVERLAY", 4, "ADD")
    if db.tendrils ~= false and not palArch(palette()) then
        local pal = palette()
        local tex = TX(pal.strand)
        local SOFT = MEDIA .. "weich"
        local vc = pal.vine
        local W = UIParent:GetWidth()
        local base = db.thickness
        for _, f in ipairs(TENDRIL_SPOTS) do
            local x0 = W * f
            local x1 = x0 + W * 0.085
            local skip = avoidX and (x1 > avoidX - base * 2.5 and x0 < avoidX + base * 2.5)
            -- nicht unter dem Erfahrungs-Ast
            if side.n > 1 and x1 > side.x[1] - 40 then skip = true end
            local cS, cE = castRange()
            if cS and x1 > cS - 10 and x0 < cE + 10 then skip = true end
            for _, c in ipairs(ceils) do
                if x1 > c.l and x0 < c.r and c.bottom - yAtLinear(xs, ys, (x0 + x1) / 2) < base * 2.2 then skip = true end
            end
            if not skip then
                local lam = base * 2.0
                local pts = {}
                local x = x0
                while x <= x1 do
                    local y = yAtLinear(xs, ys, x)
                    local th = yAtLinear(xs, ths, x)
                    local ph = 2 * math.pi * (x - x0) / lam
                    local taper = math.max(0.2, math.min(1, math.min(x - x0, x1 - x) / 30))
                    pts[#pts + 1] = { x = x, y = y + th * 0.40 * math.sin(ph), front = math.cos(ph) > 0, w = th * 0.20 * taper }
                    x = x + 4
                end
                local acc = 0
                for k = 1, #pts - 1 do
                    local a, b = pts[k], pts[k + 1]
                    if a.front and b.front then
                        local sh = take(vineSh, SOFT)
                        seg(sh, a.x, a.y - 2, b.x, b.y - 2, a.w * 1.8, 0)
                        sh:SetTexCoord(0, 1, 0, 1)
                        sh:SetVertexColor(0, 0, 0, 0.45)
                        local ln = take(vine, tex)
                        local len = seg(ln, a.x, a.y, b.x, b.y, a.w, 0.8)
                        local L = math.max(1, a.w) * TILE
                        ln:SetTexCoord(acc / L, (acc + len) / L, STRANG_V[1], STRANG_V[2])
                        ln:SetVertexColor(vc[1], vc[2], vc[3])
                        acc = acc + len
                        local hi = take(vineHi, SOFT)
                        seg(hi, a.x, a.y + a.w * 0.3, b.x, b.y + b.w * 0.3, a.w * 0.45, 0)
                        hi:SetTexCoord(0, 1, 0, 1)
                        hi:SetVertexColor(1, 0.75, 0.5, 0.30)
                    end
                end
                -- Schnörkel am Ende: rollt sich nach oben ein
                local y = yAtLinear(xs, ys, x1)
                local th = yAtLinear(xs, ths, x1)
                local cx, cy, rr = x1 + th * 0.2, y + th * 0.75, th * 0.55
                local px, py
                for k = 0, 24 do
                    local t = k / 24
                    local ang = math.pi * 1.1 - t * math.pi * 2.1
                    local r = rr * (1 - 0.7 * t)
                    local qx, qy = cx + r * math.cos(ang), cy + r * math.sin(ang)
                    if px then
                        local w = th * 0.17 * (1 - 0.6 * t)
                        local sh = take(vineSh, SOFT)
                        seg(sh, px, py - 2, qx, qy - 2, w * 1.8, 0)
                        sh:SetTexCoord(0, 1, 0, 1)
                        sh:SetVertexColor(0, 0, 0, 0.40)
                        local ln = take(vine, tex)
                        seg(ln, px, py, qx, qy, w, 0.8)
                        ln:SetTexCoord(0, 0.2, STRANG_V[1], STRANG_V[2])
                        ln:SetVertexColor(vc[1], vc[2], vc[3])
                    end
                    px, py = qx, qy
                end
            end
        end
    end
    finish(vine)
    finish(vineSh)
    finish(vineHi)
end

---------------------------------------------------------------------------
-- Schmuck: Mondsichel auf der Krone, ein paar Blätter, Irrlichter
---------------------------------------------------------------------------
local function yAt(xs, ys, x)
    for i = 1, #xs - 1 do
        if x >= xs[i] and x <= xs[i + 1] then
            local t = (x - xs[i]) / (xs[i + 1] - xs[i])
            return ys[i] + (ys[i + 1] - ys[i]) * t, (ys[i + 1] - ys[i]) / (xs[i + 1] - xs[i])
        end
    end
    return ys[#ys], 0
end

local function blocked(ceils, x, y, size)
    for _, c in ipairs(ceils) do
        if x + size > c.l and x - size < c.r and c.bottom - y < size * 1.6 then return true end
    end
end

-- zwei kleine Efeu-Büschel auf dem Ast (je zwei Blätter)
local LEAF_SPOTS = { 0.07, 0.44 }
local LEAF_CLUSTER = { { dx = 0, s = 1.15, tilt = -0.45 }, { dx = 0.55, s = 0.85, tilt = 0.55 } }

local function ornaments(xs, ys, plats, ceils)
    local W = UIParent:GetWidth()
    local th = db.thickness
    -- Mondsichel mittig auf der Krone
    local crown
    for _, p in ipairs(plats) do if p.crown then crown = p end end
    if not moon then
        moon = ornFrame:CreateTexture(nil, "OVERLAY", nil, 2)
        moon:SetTexture(MEDIA .. "mond")
    end
    local mx
    local arch = palArch(palette())
    if db.moon ~= false and crown and not arch then
        mx = (crown.l + crown.r) / 2
        local my = yAt(xs, ys, mx)
        local size = th * 2.6
        local oc = palette().orn
        moon:SetVertexColor(oc[1], oc[2], oc[3])
        moon:SetSize(size, size)
        moon:ClearAllPoints()
        moon:SetPoint("CENTER", UIParent, "BOTTOMLEFT", mx, my + size * 0.32)
        moon:Show()
    else
        moon:Hide()
    end

    -- Efeu-Büschel sprießen oben aus dem Ast
    local idx = 0
    for i, f in ipairs(LEAF_SPOTS) do
        local x0 = W * f
        local y0 = yAt(xs, ys, x0)
        local ok = db.leaves ~= false and not arch and not (mx and math.abs(x0 - mx) < th * 3)
            and not blocked(ceils, x0, y0, th * 1.3)
        for j, c in ipairs(LEAF_CLUSTER) do
            idx = idx + 1
            local lf = leaves[idx]
            if not lf then
                lf = ornFrame:CreateTexture(nil, "OVERLAY", nil, 1)
                leaves[idx] = lf
            end
            local LV = palLeaves(palette())
            lf:SetTexture(TX(LV[(idx - 1) % #LV + 1]))
            if ok then
                local size = th * c.s
                local x = x0 + c.dx * th
                local y, slope = yAt(xs, ys, x)
                lf:SetSize(size, size)
                lf:ClearAllPoints()
                lf:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y + th * 0.25 + size * 0.32)
                lf:SetRotation(math.atan(slope) + c.tilt)
                lf:Show()
            else
                lf:Hide()
            end
        end
    end
    for k = idx + 1, #leaves do leaves[k]:Hide() end

    -- Irrlichter schweben über dem Ast
    local WISP_SPOTS = { 0.25, 0.68, 0.97 }
    for i, f in ipairs(WISP_SPOTS) do
        local w = wisps[i]
        if not w then
            w = CreateFrame("Frame", nil, ornFrame)
            w.tex = w:CreateTexture(nil, "OVERLAY", nil, 3)
            w.tex:SetAllPoints()
            w.tex:SetTexture(MEDIA .. "irrlicht")
            w.tex:SetBlendMode("ADD")
            local ag = w:CreateAnimationGroup()
            ag:SetLooping("BOUNCE")
            local mv = ag:CreateAnimation("Translation")
            mv:SetOffset(18 + i * 6, 5 + i * 2)
            mv:SetDuration(3.5 + i * 1.3)
            mv:SetSmoothing("IN_OUT")
            local fade = ag:CreateAnimation("Alpha")
            fade:SetFromAlpha(0.9); fade:SetToAlpha(0.35)
            fade:SetDuration(3.5 + i * 1.3)
            fade:SetSmoothing("IN_OUT")
            w.anim = ag
            wisps[i] = w
        end
        local x = W * f
        local y = yAt(xs, ys, x)
        local size = th * 1.0
        if db.wisps ~= false and not arch and not blocked(ceils, x, y + th, size) then
            w:SetSize(size, size)
            w:ClearAllPoints()
            w:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y + th * 1.35)
            w:Show()
            if not w.anim:IsPlaying() then w.anim:Play() end
        else
            w.anim:Stop()
            w:Hide()
        end
    end
    return mx
end

---------------------------------------------------------------------------
-- Bauweise Stein: Säulen, Kapitelle, Zinnen, Banner, Goldleiste, Lichtscheibe
---------------------------------------------------------------------------
-- Wo steht was? (reine Rechnung, ohne Bilder – auch für die Vorschau)
local function archLayout(xs, ys, ths, plats, ceils, arch)
    local L = { pillars = {}, merlons = {}, banners = {} }
    local n = #xs
    local th = ths[1] or db.thickness
    local W = UIParent:GetWidth()
    -- Säulen stehen in den Lücken zwischen den Elementen (dort sieht man sie;
    -- die Elemente wirken wie zwischen Säulen eingelassene Tafeln)
    local pw = th * (arch.pillarW or 0.62)
    local iv = {}
    for _, p in ipairs(plats) do iv[#iv + 1] = { l = p.l, r = p.r } end
    table.sort(iv, function(u, v) return u.l < v.l end)
    local merged = {}
    for _, v in ipairs(iv) do
        local m = merged[#merged]
        if m and v.l <= m.r then m.r = math.max(m.r, v.r) else merged[#merged + 1] = { l = v.l, r = v.r } end
    end
    for k = 1, #merged - 1 do
        local gl, gr = merged[k].r, merged[k + 1].l
        if gr - gl + 12 >= pw * 0.5 then           -- ±6 Rand je Element zählt zur Lücke
            local x = (gl + gr) * 0.5
            L.pillars[#L.pillars + 1] = { x = x, y = yAt(xs, ys, x), w = pw, gl = gl, gr = gr }
        end
    end
    -- Mitte (Leisten): erst der Schrein – links und rechts der Leisten je eine
    -- Säule mit Banner –, dann zwischen den beiden Säulen Zinnen, Mittelstück
    -- und Zauberbalken (Ben 26.11. 05:28: alles zwischen den Bannern)
    local crown
    for _, p in ipairs(plats) do if p.crown then crown = p end end
    if crown then
        local bw = th * (arch.bannerW or 0.72)
        local bl = bw / (arch.bannerAspect or 0.25)
        local shrine = {}
        for side = 1, 2 do
            local edge = side == 1 and crown.l or crown.r
            -- die Säule in der Lücke direkt neben den Leisten; gibt es keine, an den Rand
            local pc
            for _, q in ipairs(L.pillars) do
                if (side == 1 and math.abs(q.gr - crown.l) < th * 2) or (side == 2 and math.abs(q.gl - crown.r) < th * 2) then pc = q end
            end
            if not pc then
                pc = { x = edge, y = yAt(xs, ys, edge), w = pw, gl = edge, gr = edge }
                L.pillars[#L.pillars + 1] = pc
            end
            pc.center = true
            shrine[side] = pc
            L.banners[#L.banners + 1] = { x = pc.x, w = bw, h = bl, flip = side == 2, pillar = pc }
        end
        L.shrineL, L.shrineR = shrine[1].x, shrine[2].x
        local mx = (shrine[1].x + shrine[2].x) * 0.5
        local my = yAt(xs, ys, mx)
        L.mx = mx
        -- flaches Stück um die Mitte, höchstens bis an die Schrein-Säulen
        local a, b = mx, mx
        while a > shrine[1].x and math.abs(yAt(xs, ys, a - 4) - my) < 1 do a = a - 4 end
        while b < shrine[2].x and math.abs(yAt(xs, ys, b + 4) - my) < 1 do b = b + 4 end
        local half = math.min(mx - a, b - mx) - pw * 0.5 - th * 0.15
        -- Zinnen: breiter (Ben: „zwei zusammen etwas breiter“), Höhe bleibt
        local mw = th * (arch.merlonW or 1.05)
        local mh = arch.merlonH and th * arch.merlonH or (mw / (arch.merlonAspect or 1.0) - 4)
        local gap0 = th * (arch.merlonGap or 0.65)
        -- Wappen mittig auf dem Balken (Bild des Gewands); die Zinnen lassen ihm Platz
        local crestHalf = 0
        local ctex, casp, csize = archCrestPick(arch)
        if ctex and db.moon ~= false then
            local cy = my + th * 0.42 - 6
            local ch = th * (csize or 2.6)
            -- nicht in schwebende Rahmen darüber hineinragen
            for _, cl in ipairs(ceils) do
                if mx + ch * casp * 0.5 > cl.l and mx - ch * casp * 0.5 < cl.r and cl.bottom > cy then
                    ch = math.min(ch, cl.bottom - cy - 4)
                end
            end
            if ch >= th then
                local cw = ch * casp
                L.crest = { x = mx, y = cy, w = cw, h = ch, tex = ctex }
                crestHalf = cw * 0.40 + th * 0.20      -- Bild hat seitlich etwas Luft
            end
        end
        local function merlonAt(x)
            local y = yAt(xs, ys, x) + th * 0.42 - 2
            if not blocked(ceils, x, y + mh * 0.5, mh * 0.6) then
                L.merlons[#L.merlons + 1] = { x = x, y = y, w = mw, h = mh }
            end
        end
        -- Reihe genau auf eine Strecke verteilen: außen bündig, Lücken gleich
        -- (keine fehlende Zinne am Rand)
        local function row(x0, x1)
            local len = x1 - x0
            local n = math.floor((len + gap0) / (mw + gap0))
            if n < 1 then return end
            if n == 1 then merlonAt((x0 + x1) * 0.5) return end
            local g = (len - n * mw) / (n - 1)
            for k = 0, n - 1 do merlonAt(x0 + mw * 0.5 + k * (mw + g)) end
        end
        if half > mw then
            if crestHalf > 0 then
                if half - crestHalf > mw then
                    row(mx - half, mx - crestHalf)
                    row(mx + crestHalf, mx + half)
                end
            else
                row(mx - half, mx + half)
            end
        end
        if db.moon ~= false and arch.disc then
            L.disc = { x = mx, y = my, size = th * (arch.discSize or 4.6) }
        end
    end
    -- Oberkante jeder Säule: höchste Balken-Unterkante über der Kapitellbreite
    -- (an einer Schräge entsteht so kein Spalt, der Balken deckt den Rest)
    for _, p in ipairs(L.pillars) do
        local c = p.w * 0.78
        p.top = math.max(yAt(xs, ys, p.x - c), p.y, yAt(xs, ys, p.x + c)) - yAt(xs, ths, p.x) * 0.5 + 2
    end
    -- Kapitell: unten so breit wie der Schaft (Bild-Verhältnis aus dem Gewand)
    L.capW = pw / (arch.capNeck or 0.645)
    L.capH = L.capW / (arch.capAspect or 2)
    -- Banner hängen unter dem Kapitell vor der Säule
    for _, bn in ipairs(L.banners) do
        bn.y = bn.pillar.top - L.capH * 0.92
    end
    return L
end

local archTex = { shafts = {}, caps = {}, bases = {}, merlons = {}, banners = {} }
local archDisc, archCrest
-- Wappen/Scheibe zeitweise aus (Kampf, Zauber)
local archBusy = { combat = false, cast = false }
local function archHide2(key, on)
    archBusy[key] = on
    mod.archHidden = archBusy.combat or archBusy.cast
    local has = mod.archLast
    if archCrest then archCrest:SetShown(not mod.archHidden and has and has.crest ~= nil) end
    if archDisc then archDisc:SetShown(not mod.archHidden and has and has.disc ~= nil) end
end
local function archTake(list, i, frame, layer, sub, tex, wrapV)
    local t = list[i]
    if not t then
        t = frame:CreateTexture(nil, layer, nil, sub)
        list[i] = t
    end
    t:SetTexture(tex, "CLAMP", wrapV and "REPEAT" or "CLAMP")
    t:SetVertexColor(1, 1, 1, 1)
    t:ClearAllPoints()
    t:Show()
    return t
end
local function archHide(list, from)
    for k = from, #list do list[k]:Hide() end
end

local function drawArch(xs, ys, ths, plats, ceils)
    local arch = palArch(palette())
    local rail = pool("archRail", "OVERLAY", 1)
    local nS, nC, nM, nB = 0, 0, 0, 0
    if arch then
        local L = archLayout(xs, ys, ths, plats, ceils, arch)
        mod.archLast = L
        local pal = palette()
        local tc = pal.branch
        -- Säulen: Schaft vom Boden bis hinter den Balken, Goldkapitell darunter,
        -- Fuß unten (gespiegeltes Kapitell)
        for _, p in ipairs(L.pillars) do
            local top = p.top
            if arch.pillar and top > 4 then
                nS = nS + 1
                local t = archTake(archTex.shafts, nS, branchFrame, "BORDER", -3, TX(arch.pillar), true)
                t:SetSize(p.w, top)
                t:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", p.x, 0)
                t:SetTexCoord(0, 1, 1 - top / (p.w * 2), 1)
                t:SetVertexColor(tc[1], tc[2], tc[3])
            end
            if arch.cap then
                local cw, ch = L.capW, L.capH
                nC = nC + 1
                local c = archTake(archTex.caps, nC, branchFrame, "BORDER", -1, TX(arch.cap))
                c:SetSize(cw, ch)
                c:SetPoint("TOP", UIParent, "BOTTOMLEFT", p.x, top + 1)
                c:SetTexCoord(0, 1, 0, 1)
                local b = archTake(archTex.bases, nC, branchFrame, "BORDER", -1, TX(arch.cap))
                b:SetSize(cw, ch * 0.8)
                b:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", p.x, 0)
                b:SetTexCoord(0, 1, 1, 0)
            end
        end
        -- Zinnen stehen auf dem Balken (unten von Balken und Leiste verdeckt);
        -- sie und die Scheibe liegen auf der Stammebene, damit der Zauberbalken
        -- beim Wirken über ihnen liegt
        if arch.merlon then
            for _, m in ipairs(L.merlons) do
                nM = nM + 1
                local t = archTake(archTex.merlons, nM, fillFrame, "ARTWORK", 0, TX(arch.merlon))
                t:SetSize(m.w, m.h + 4)
                t:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", m.x, m.y - 4)
                t:SetTexCoord(0, 1, 0, 1)
                t:SetVertexColor(tc[1], tc[2], tc[3])
            end
        end
        -- Banner hängen vor den Säulen
        if arch.banner then
            for _, bn in ipairs(L.banners) do
                nB = nB + 1
                local t = archTake(archTex.banners, nB, branchFrame, "BORDER", 3, TX(arch.banner))
                t:SetSize(bn.w, bn.h)
                t:SetPoint("TOP", UIParent, "BOTTOMLEFT", bn.x, bn.y)
                if bn.flip then t:SetTexCoord(1, 0, 0, 1) else t:SetTexCoord(0, 1, 0, 1) end
            end
        end
        -- Wappen mittig auf dem Balken (unter dem Zauberbalken; beim Wirken und im
        -- Kampf aus, wie früher der Mond)
        if L.crest then
            if not archCrest then archCrest = fillFrame:CreateTexture(nil, "BORDER", nil, 1) end
            archCrest:SetTexture(TX(L.crest.tex))
            archCrest:SetSize(L.crest.w, L.crest.h)
            archCrest:ClearAllPoints()
            archCrest:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", L.crest.x, L.crest.y)
            archCrest:SetShown(not mod.archHidden)
        elseif archCrest then
            archCrest:Hide()
        end
        -- Lichtscheibe geht hinter Balken und Zinnen auf (nur die obere Hälfte)
        if arch.disc and L.disc then
            if not archDisc then
                archDisc = fillFrame:CreateTexture(nil, "BORDER", nil, 0)
                archDisc:SetBlendMode("ADD")
                local ag = archDisc:CreateAnimationGroup()
                ag:SetLooping("BOUNCE")
                local a = ag:CreateAnimation("Alpha")
                a:SetFromAlpha(1); a:SetToAlpha(0.7)
                a:SetDuration(3.2); a:SetSmoothing("IN_OUT")
                archDisc.anim = ag
            end
            archDisc:SetTexture(TX(arch.disc))
            archDisc:SetTexCoord(0, 1, 0, 0.5)
            archDisc:SetSize(L.disc.size, L.disc.size * 0.5)
            archDisc:ClearAllPoints()
            archDisc:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", L.disc.x, L.disc.y)
            archDisc:SetShown(not mod.archHidden)
            if not archDisc.anim:IsPlaying() then archDisc.anim:Play() end
        elseif archDisc then
            archDisc.anim:Stop()
            archDisc:Hide()
        end
        -- Goldleiste oben auf dem Balken
        if arch.rail then
            local tex = TX(arch.rail)
            local acc = 0
            for k = 1, #xs - 1 do
                local th = (ths[k] + ths[k + 1]) * 0.5
                local rt = th * (arch.railTh or 0.17)
                local off = th * 0.5 - rt * 0.15
                local ln = take(rail, tex)
                local len = seg(ln, xs[k], ys[k] + off, xs[k + 1], ys[k + 1] + off, rt, 0.6)
                local Lr = rt * 16
                ln:SetTexCoord(acc / Lr, (acc + len) / Lr, 0, 1)
                acc = acc + len
            end
        end
    else
        mod.archLast = nil
        if archDisc then archDisc.anim:Stop(); archDisc:Hide() end
        if archCrest then archCrest:Hide() end
    end
    finish(rail)
    archHide(archTex.shafts, nS + 1)
    archHide(archTex.caps, nC + 1)
    archHide(archTex.bases, nC + 1)
    archHide(archTex.merlons, nM + 1)
    archHide(archTex.banners, nB + 1)
end

---------------------------------------------------------------------------
-- Erfahrungs-Ast: über dem Questtracker zweigt ein Seitenast nach rechts ab
-- (mit kleinem Spalt zum Hauptast). Efeu rankt sich darum – je mehr EP,
-- desto weiter. „Ausgeruht“ zeigt sich als blasse Blätter voraus.
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- Buntglas (Bauweise Stein, Ben 25.11. 19:02): statt EP- und Ruf-Ast stehen
-- über dem Questlog Lanzettfenster auf dem Balken – jedes Fenster ein Zehntel
-- der Stufe, das laufende füllt sich von unten mit Licht – und links davon
-- eine Rosette für den Ruf (zwölf Felder leuchten nacheinander auf)
---------------------------------------------------------------------------
local function glassArch()
    local a = palArch(palette())
    return a and type(a.glass) == "table" and a.glass or nil
end
local glassGeo

local function buildGlass(xs, ys, ths, tracker, gl)
    local th = db.thickness
    local W = UIParent:GetWidth()
    local x0, x1 = tracker.l + th, W - th * 0.6
    local n = gl.count or 10
    local ww = th * (gl.w or 1.0)
    local wh = ww * (gl.aspect or 2)
    local gap = th * (gl.gap or 0.34)
    local rose = (gl.rose and repActive()) and true or false
    local rd = th * (gl.roseSize or 2.3)
    local need = n * ww + (n - 1) * gap + (rose and (rd + gap * 1.5) or 0)
    if need > x1 - x0 then
        local k = (x1 - x0) / need
        ww, wh, gap, rd, need = ww * k, wh * k, gap * k, rd * k, x1 - x0
    end
    if ww < 8 then return nil end
    -- steht auf dem Balken: höchste Oberkante unter der Breite
    local function baseY(cx, half)
        local y = -math.huge
        for _, dx in ipairs({ -half, 0, half }) do
            local v = yAtLinear(xs, ys, cx + dx) + yAtLinear(xs, ths, cx + dx) * 0.42
            if v > y then y = v end
        end
        return y - 3
    end
    if gl.sword then
        -- Ben 19:09: Schwert statt Fenster, die Klinge füllt sich mit Licht.
        -- Ben 04:23: größer und bis zum Bildschirmrand wie die Ranken beim
        -- Druiden – Spitze am rechten Rand, Heft in Bildmaßen, die Klinge darf
        -- sich bis swordStretch in die Länge ziehen; Rosette links am Heft
        local asp = gl.swordAspect or 4
        local hiltU = gl.swordHilt or 0.4
        local xr = W - th * (gl.swordEdge or 0.1)
        local sh = th * (gl.swordH or 3.3)
        local roseW = rose and (rd + gap * 1.5) or 0
        local avail = xr - x0 - roseW
        local hw = sh * asp * hiltU                       -- Heft in echten Maßen
        local bn = sh * asp * (1 - hiltU)                 -- Klinge in echten Maßen
        if hw + bn > avail then                           -- zu wenig Platz: kleiner
            local k = avail / (hw + bn)
            sh, hw, bn = sh * k, hw * k, bn * k
        end
        local bw = math.min(bn * (gl.swordStretch or 1.7), avail - hw)
        local total = hw + bw
        local G = { wins = {} }
        local x = xr - total
        if rose then
            G.rose = { x = x - gap * 1.5 - rd * 0.5, size = rd }
            G.rose.y = baseY(G.rose.x, rd * 0.25)
        end
        local top = -math.huge
        for k = 0, 8 do top = math.max(top, baseY(x + total * k / 8, 0)) end
        -- liegt auf dem Balken (Ben 05:26: unten abgeschnittenes Heft sah komisch aus)
        G.sword = { x = x, y = top - sh * (gl.swordSink or 0.18), w = total, h = sh, hw = hw, bw = bw, hiltU = hiltU }
        G.l, G.r = x, x + total
        return G
    end
    local G = { wins = {}, ww = ww, wh = wh, n = n }
    local x = x0 + ((x1 - x0) - need) * (gl.align or 0.5)
    if rose then
        G.rose = { x = x + rd * 0.5, size = rd }
        G.rose.y = baseY(G.rose.x, rd * 0.25)
        x = x + rd + gap * 1.5
    end
    for i = 1, n do
        local cx = x + ww * 0.5
        G.wins[i] = { x = cx, y = baseY(cx, ww * 0.45) }
        x = x + ww + gap
    end
    G.l, G.r = G.wins[1].x - ww * 0.5, G.wins[n].x + ww * 0.5
    return G
end

local function buildSide(xs, ys, ths, plats)
    side.n = 0
    glassGeo = nil
    if db.xpBranch == false then return end
    local tracker
    for _, p in ipairs(plats) do if p.name == "MondhainQuestTracker" then tracker = p end end
    if not tracker then return end
    local gl = glassArch()
    if gl then
        glassGeo = buildGlass(xs, ys, ths, tracker, gl)
        return
    end
    local W = UIParent:GetWidth()
    local xf = tracker.l + 40
    local xe = W + 14
    if xe - xf < 120 then return end
    local base = db.thickness
    local arch = palArch(palette())
    local x, n, acc = xf, 0, 0
    local px, py
    while x <= xe do
        local t = (x - xf) / (xe - xf)
        local ym = yAtLinear(xs, ys, x)
        local thm = yAtLinear(xs, ths, x)
        local rise, sth, full, y
        if arch then
            -- Bauweise Stein: gerade Schräge (45°) hoch, dann flach, gleich dick
            sth = base * 0.58
            full = thm * 0.5 + 6 + sth * 0.5
            rise = math.max(0, math.min(1, (x - xf) / math.max(8, full - thm * 0.12)))
            y = ym + thm * 0.12 + (full - thm * 0.12) * rise
        else
            rise = smoothstep((x - xf) / 120)
            sth = base * 0.70 * (1 - 0.55 * t) * (0.8 + 0.2 * rise)
            full = thm * 0.5 + 6 + sth * 0.5 -- 6 = Spalt zwischen den Ästen
            y = ym + thm * 0.12 + (full - thm * 0.12) * rise + 12 * t * t + 2 * math.sin(x / 37)
        end
        n = n + 1
        if px then acc = acc + math.sqrt((x - px) ^ 2 + (y - py) ^ 2) end
        side.x[n], side.y[n], side.th[n], side.arc[n] = x, y, sth, acc
        px, py = x, y
        x = x + 3
    end
    side.n = n
end

local function pathAt(P, a)
    -- Punkt auf einem Seitenast bei Bogenlänge a
    local n = P.n
    for k = 1, n - 1 do
        if a <= P.arc[k + 1] then
            local t = (a - P.arc[k]) / math.max(0.001, P.arc[k + 1] - P.arc[k])
            local x = P.x[k] + (P.x[k + 1] - P.x[k]) * t
            local y = P.y[k] + (P.y[k + 1] - P.y[k]) * t
            local th = P.th[k] + (P.th[k + 1] - P.th[k]) * t
            local slope = (P.y[k + 1] - P.y[k]) / math.max(0.001, P.x[k + 1] - P.x[k])
            return x, y, th, slope
        end
    end
    return P.x[n], P.y[n], P.th[n], 0
end
local function sideAt(a) return pathAt(side, a) end

local function drawSide()
    local sp = pool("side", "ARTWORK", 1)
    local srim = pool("sideRim", "OVERLAY", 0, "ADD")
    if side.n > 1 then
        local pal = palette()
        local tex = TX(pal.strand)
        local SOFT = MEDIA .. "weich"
        local c = pal.branch
        local acc = 0
        local L = db.thickness * 0.70 * TILE
        for k = 1, side.n - 1 do
            local th = (side.th[k] + side.th[k + 1]) * 0.5
            local ln = take(sp, tex)
            local len = seg(ln, side.x[k], side.y[k], side.x[k + 1], side.y[k + 1], th, 0.4)
            ln:SetTexCoord(acc / L, (acc + len) / L, STRANG_V[1], STRANG_V[2])
            ln:SetVertexColor(c[1], c[2], c[3])
            acc = acc + len
            if db.depth ~= false then
                local rl = take(srim, SOFT)
                seg(rl, side.x[k], side.y[k] + th * 0.34, side.x[k + 1], side.y[k + 1] + th * 0.34, th * 0.26, 0)
                rl:SetTexCoord(0, 1, 0, 1)
                rl:SetVertexColor(1, 0.77, 0.55, 0.22)
            end
        end
    end
    finish(sp)
    finish(srim)
end

-- Maus-Flächen entlang eines Asts: viele schmale Streifen, die dem Verlauf
-- folgen (statt eines großen Rechtecks, das den Nachbar-Ast mit abdeckt)
local function hitStrips(list, P, a0, half, onEnter)
    local used = 0
    if P.n > 1 then
        local total = P.arc[P.n]
        local a = a0
        while a < total do
            local b = math.min(total, a + 36)
            local lo, hi, xl, xr = math.huge, -math.huge, math.huge, -math.huge
            local t = a
            while true do
                local x, y, th = pathAt(P, t)
                lo, hi = math.min(lo, y - th * half), math.max(hi, y + th * half)
                xl, xr = math.min(xl, x), math.max(xr, x)
                if t >= b then break end
                t = math.min(b, t + 6)
            end
            used = used + 1
            local f = list[used]
            if not f then
                f = CreateFrame("Frame", nil, UIParent)
                f:SetFrameStrata("BACKGROUND")
                f:SetFrameLevel(30)
                f:EnableMouse(true)
                f:SetScript("OnLeave", GameTooltip_Hide)
                list[used] = f
            end
            f:SetScript("OnEnter", onEnter)
            f:ClearAllPoints()
            f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", xl, lo)
            f:SetSize(math.max(2, xr - xl), math.max(4, hi - lo))
            f:Show()
            a = b
        end
    end
    for i = used + 1, #list do list[i]:Hide() end
end
local xpHits, repHits = {}, {}
local drawXPFlowers                         -- Blüten auf der EP-Liane (weiter unten)

local ivyLeaves = {}
local IVY_STEM = { 0.55, 0.70, 0.40 }

local function xpProgress()
    local cur, max = UnitXP("player"), UnitXPMax("player")
    if ns.isSecret(cur) or ns.isSecret(max) then return 1, 1, false end
    local atCap = (IsPlayerAtEffectiveMaxLevel and IsPlayerAtEffectiveMaxLevel()) or not max or max == 0
    if atCap then return 1, 1, true end
    local rested = GetXPExhaustion() or 0
    return math.min(1, cur / max), math.min(1, (cur + rested) / max), false
end

local function xpTooltip(self)
    local cur, max = UnitXP("player"), UnitXPMax("player")
    local rested = GetXPExhaustion() or 0
    local f = ns.FormatNumber or tostring
    local _, _, atCap = xpProgress()
    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
    GameTooltip:AddLine("Erfahrung – Stufe " .. UnitLevel("player"), 1, 0.82, 0)
    if atCap then
        GameTooltip:AddLine("Höchststufe – die Liane umschlingt den ganzen Ast.", 0.8, 0.8, 0.8)
    elseif not ns.isSecret(max) and max and max > 0 then
        GameTooltip:AddLine(("%s / %s EP  (%d %%)"):format(f(cur), f(max), math.floor(cur / max * 100)), 1, 1, 1)
        GameTooltip:AddLine("Bis zur nächsten Stufe: " .. f(max - cur), 0.8, 0.8, 0.8)
        if rested > 0 then GameTooltip:AddLine("Ausgeruht: " .. f(rested), 0.75, 0.85, 1) end
    end
    GameTooltip:Show()
end

-- Ben 25.11. 10:10/10:37: bei 25/50/75 % sitzt ein Astknoten im EP-Ast;
-- erreicht die Liane ihn, blüht dort eine Blüte auf (aufspringen, Leuchten)
local XP_MARKS = { 0.25, 0.5, 0.75 }
local xpFlowers, xpBloomDriver = {}, nil
local function bloomStep()
    local now, busy = GetTime(), false
    for _, f in ipairs(xpFlowers) do
        if f.animStart then
            local t = (now - f.animStart) / 1.4
            if t >= 1 then
                f.animStart = nil
                f.flower:SetSize(f.size, f.size)
                f.flower:SetRotation(0)
                f.flower:SetAlpha(1)
                f.glow:SetAlpha(0)
            else
                busy = true
                -- aufspringen mit kleinem Überschwingen, dabei aufdrehen
                local k = math.min(1, t / 0.55)
                local back = 1 + 2.2 * (k - 1) ^ 3 + 1.2 * (k - 1) ^ 2
                local sc = 0.2 + 0.8 * back
                f.flower:SetSize(f.size * sc, f.size * sc)
                f.flower:SetRotation(-0.7 * (1 - k))
                f.flower:SetAlpha(math.min(1, t / 0.2))
                f.glow:SetAlpha(0.9 * math.sin(math.min(1, t / 0.9) * math.pi))
                f.glow:SetSize(f.size * (1.6 + 1.2 * t), f.size * (1.6 + 1.2 * t))
            end
        end
    end
    if not busy and xpBloomDriver then xpBloomDriver:SetScript("OnUpdate", nil) end
end

drawXPFlowers = function(p, total)
    for i, m in ipairs(XP_MARKS) do
        local f = xpFlowers[i]
        if not f then
            f = {}
            f.glow = branchFrame:CreateTexture(nil, "OVERLAY", nil, 6)
            f.glow:SetTexture(MEDIA .. "punkt")
            f.glow:SetBlendMode("ADD")
            f.glow:SetVertexColor(0.85, 0.80, 1.0)
            f.glow:SetAlpha(0)
            f.knot = branchFrame:CreateTexture(nil, "OVERLAY", nil, 1)   -- unter der Liane
            f.flower = branchFrame:CreateTexture(nil, "OVERLAY", nil, 7)
            f.flower:SetTexture(TX(palette().bloom or "ep_bluete"))
            xpFlowers[i] = f
        end
        local x, y, th = sideAt(total * m)
        f.size = math.max(14, th * 2.0)
        -- Astknoten: liegt in Wuchsrichtung auf dem Ast, im Holz der Farbstimmung
        local pal = palette()
        local xa, ya = sideAt(math.max(0, total * m - 3))
        local xb, yb = sideAt(math.min(total, total * m + 3))
        f.knot:SetTexture(TX(palKnot(pal)))
        f.knot:SetVertexColor(pal.branch[1], pal.branch[2], pal.branch[3])
        if pal.knotRound then
            f.knot:SetSize(math.max(14, th * 1.9), math.max(14, th * 1.9))
        else
            f.knot:SetSize(math.max(14, th * 2.1), math.max(10, th * 1.45))
        end
        f.knot:ClearAllPoints()
        f.knot:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y)
        f.knot:SetRotation(pal.knotRound and 0 or math.atan2(yb - ya, xb - xa))
        f.knot:Show()
        for _, t in ipairs({ f.glow, f.flower }) do
            t:ClearAllPoints()
            t:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y + th * 0.15)
        end
        local reached = p >= m
        if reached and f.reached == false then
            -- gerade erreicht: aufblühen lassen
            f.animStart = GetTime()
            f.flower:Show(); f.glow:Show()
            xpBloomDriver = xpBloomDriver or CreateFrame("Frame")
            xpBloomDriver:SetScript("OnUpdate", bloomStep)
        elseif not f.animStart then
            f.flower:SetSize(f.size, f.size)
            f.flower:SetRotation(0)
            f.flower:SetAlpha(1)
            f.flower:SetShown(reached)
            f.glow:SetAlpha(0)
        end
        f.reached = reached
    end
end
local function hideXPFlowers()
    for _, f in ipairs(xpFlowers) do
        f.knot:Hide(); f.flower:Hide(); f.glow:Hide(); f.animStart = nil
    end
end

local glassTex = { dark = {}, rest = {}, lit = {}, glow = {}, frame = {} }
local swordTex = {}
local roseTex = { sec = {}, glow = {} }
local roseDark, roseFrame, glassHit, roseHit
local function glassTake(list, i, sub, tex, blend)
    local t = list[i]
    if not t then
        t = fillFrame:CreateTexture(nil, "ARTWORK", nil, sub)
        list[i] = t
    end
    t:SetTexture(tex)
    t:SetBlendMode(blend or "BLEND")
    if t.SetDesaturated then t:SetDesaturated(false) end
    t:ClearAllPoints()
    t:SetTexCoord(0, 1, 0, 1)
    t:SetVertexColor(1, 1, 1, 1)
    t:Show()
    return t
end
local function glassHitFrame(f, l, b, w, h, onEnter)
    if not f then
        f = CreateFrame("Frame", nil, UIParent)
        f:SetFrameStrata("BACKGROUND")
        f:SetFrameLevel(30)
        f:EnableMouse(true)
        f:SetScript("OnLeave", GameTooltip_Hide)
    end
    f:SetScript("OnEnter", onEnter)
    f:ClearAllPoints()
    f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", l, b)
    f:SetSize(math.max(4, w), math.max(4, h))
    f:Show()
    return f
end

local function drawGlassXP()
    local gl = glassArch()
    local G = gl and glassGeo
    local nD, nR, nL, nF = 0, 0, 0, 0
    local nSw = 0
    if G and G.sword and fillFrame then
        local sw = G.sword
        local p, pr, atCap = xpProgress()
        local TEX = TX(gl.sword)
        local b0 = sw.hiltU                            -- hier beginnt die Klinge (Bildanteil)
        local uf = b0 + (1 - b0) * p
        local ur = b0 + (1 - b0) * pr
        -- Bildanteil → Bildschirm: Heft in echten Maßen, Klinge gestreckt
        local function sx(u)
            if u <= b0 then return sw.x + sw.hw * u / b0 end
            return sw.x + sw.hw + sw.bw * (u - b0) / (1 - b0)
        end
        local function part(u0, u1, sub, blend)
            if u1 - u0 < 0.002 then return nil end
            nSw = nSw + 1
            local t = glassTake(swordTex, nSw, sub, TEX, blend)
            t:SetSize(sx(u1) - sx(u0), sw.h)
            t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", sx(u0), sw.y)
            t:SetTexCoord(u0, u1, 0, 1)
            return t
        end
        part(0, b0, 2)                                    -- Griff, Parierstange
        part(b0, uf, 2)                                   -- gefüllte Klinge
        local g = part(b0, uf, 4, "ADD")
        if g then g:SetVertexColor(1, 0.86, 0.45, gl.swordGlow or 0.75) end
        local rest = math.max(uf, ur)
        local d = part(uf, 1, 1)                          -- Rest der Klinge: matter Stahl
        if d then
            if d.SetDesaturated then d:SetDesaturated(true) end
            d:SetVertexColor(0.45, 0.45, 0.50)
        end
        if rest > uf then                                 -- ausgeruht: blau vorgezeichnet
            local r = part(uf, rest, 3, "ADD")
            if r then r:SetVertexColor(0.45, 0.65, 1.0, 0.35) end
        end
        -- Panzerhand hält das Heft (Ben 05:26); der Unterarm verschwindet hinter dem Balken
        if gl.swordHand then
            local hh = sw.h * (gl.swordHandH or 1.15)
            local hw2 = hh * (gl.swordHandAspect or 0.5)
            local gx = sx(gl.swordHandU or 0.167)                         -- Griffmitte am Schwert
            local gy = sw.y + sw.h * (1 - (gl.swordGripV or 0.51))
            local top = gy + hh * (gl.swordHandGripV or 0.17)            -- Griff in der Hand von oben
            local floor = yAtLinear(mainPath.xs, mainPath.ys, gx)         -- bis zur Balkenmitte
            local vis = top - floor
            if vis > 4 then
                nSw = nSw + 1
                local hd = glassTake(swordTex, nSw, 6, TX(gl.swordHand))
                hd:SetSize(hw2, math.min(hh, vis))
                hd:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", gx - hw2 * (gl.swordHandGripX or 0.438), top)
                hd:SetTexCoord(0, 1, 0, math.min(1, vis / hh))
            end
        end
        if p > 0 and p < 1 and not atCap then             -- Lichtfunke an der Spitze der Füllung
            nSw = nSw + 1
            local sp = glassTake(swordTex, nSw, 5, MEDIA .. "punkt", "ADD")
            sp:SetSize(sw.h * 0.9, sw.h * 0.9)
            sp:SetPoint("CENTER", UIParent, "BOTTOMLEFT", sx(uf), sw.y + sw.h * 0.5)
            sp:SetVertexColor(1, 0.9, 0.6, 0.85)
        end
        glassHit = glassHitFrame(glassHit, sw.x, sw.y, sw.w, sw.h, xpTooltip)
    elseif G and fillFrame and gl.window then
        local p, pr = xpProgress()
        local GL, FR = TX(gl.window), gl.frame and TX(gl.frame)
        local function place(t, w, f)
            t:SetSize(G.ww, G.wh * f)
            t:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", w.x, w.y)
            t:SetTexCoord(0, 1, 1 - f, 1)
        end
        for i, w in ipairs(G.wins) do
            local a = (i - 1) / G.n
            local f = math.max(0, math.min(1, (p - a) * G.n))
            local fr = math.max(0, math.min(1, (pr - a) * G.n))
            nD = nD + 1
            local d = glassTake(glassTex.dark, nD, 1, GL)
            place(d, w, 1)
            if d.SetDesaturated then d:SetDesaturated(true) end
            d:SetVertexColor(0.34, 0.34, 0.38)
            if FR then
                nF = nF + 1
                place(glassTake(glassTex.frame, nF, 5, FR), w, 1)
            end
            if fr > f then                                -- ausgeruht: blau vorgezeichnet
                nR = nR + 1
                local r = glassTake(glassTex.rest, nR, 2, GL)
                place(r, w, fr)
                r:SetVertexColor(0.55, 0.70, 1.0, 0.45)
            end
            if f > 0 then
                nL = nL + 1
                place(glassTake(glassTex.lit, nL, 3, GL), w, f)
                local g = glassTake(glassTex.glow, nL, 4, GL, "ADD")
                place(g, w, f)
                g:SetVertexColor(1, 0.95, 0.8, gl.glow or 0.35)
            end
        end
        glassHit = glassHitFrame(glassHit, G.l, G.wins[1].y, G.r - G.l, G.wh, xpTooltip)
    elseif glassHit then
        glassHit:Hide()
    end
    archHide(glassTex.dark, nD + 1)
    archHide(glassTex.frame, nF + 1)
    archHide(glassTex.rest, nR + 1)
    archHide(glassTex.lit, nL + 1)
    archHide(glassTex.glow, nL + 1)
    archHide(swordTex, nSw + 1)
end

local function drawXP()
    local front = pool("lianeFront", "OVERLAY", 5)
    local back = pool("lianeBack", "OVERLAY", 4)
    local bud = pool("lianeBud", "OVERLAY", 7, "ADD")
    local frayF = pool("frayFront", "OVERLAY", 5)
    local frayB = pool("frayBack", "BORDER", 3)
    local used = 0
    if side.n > 1 and branchFrame then
        local p, pr = xpProgress()
        local total = side.arc[side.n]
        local reach, rreach = total * p, total * pr
        local LIANE = TX(palette().liane or "liane")
        -- gemaltes Lianenbündel (Gemini) als Streifen entlang des Asts gelegt;
        -- der Kern des Bündels ist etwas dicker als der Ast und deckt ihn ganz ab,
        -- Blätter, Schnörkel und Knospen ragen darüber hinaus
        local STRIP = TX(palStrip(palette()))
        local CORE = 0.44                          -- Anteil des Bündelkerns an der Bildhöhe
        local L = db.thickness * 0.70 * 1.6 / CORE * 8 -- Kachellänge (Bild 1024 x 128)
        local function strip(a0, a1, alpha)
            local a = a0
            while a < a1 do
                local nxt = math.min(a1, a + 6)
                local x0, y0, th0 = sideAt(a)
                local x1, y1, th1 = sideAt(nxt)
                local T = (th0 + th1) * 0.5 * 1.6 / CORE
                -- Anfang: wächst dünn aus dem Hauptast heraus und wird erst nach
                -- und nach zum vollen Bündel; Spitze: läuft schmaler aus
                local grow = smoothstep((a - a0) / 80)
                local tipT = smoothstep((a1 - nxt) / 45)
                local width = (0.35 + 0.65 * grow) * (0.55 + 0.45 * tipT)
                local fade = math.min(smoothstep((a - a0 + 2) / 22), smoothstep((a1 - nxt + 2) / 30))
                local ln = take(front, STRIP)
                seg(ln, x0, y0, x1, y1, T * width, 0.3)
                ln:SetTexCoord(a / L, nxt / L, 0, 1)
                ln:SetVertexColor(1, 1, 1, alpha * fade)
                a = nxt
            end
        end
        strip(0, reach, 1)
        if pr > p then strip(reach, rreach, 0.25) end -- ausgeruht: blass voraus
        pcall(drawXPFlowers, p, total)

        -- Übergang an der Gabelung: das Bündel franst nach links in einzelne
        -- dünne Ranken auf, die sich um den Hauptast schlingen (hinten verdeckt
        -- vom Ast) und am Ende zu Schnörkeln einrollen
        local FRAY = {
            { len = 160, pitch = 70, w = 0.17, v = 0.42, ph = 0.0, start = 0 },
            { len = 120, pitch = 56, w = 0.14, v = 0.54, ph = 2.1, start = 8 },
            { len = 92,  pitch = 62, w = 0.12, v = 0.48, ph = 4.0, start = 16 },
            { len = 64,  pitch = 46, w = 0.10, v = 0.36, ph = 1.2, start = 4 },
        }
        if reach > 30 and mainPath.xs then
            local sx0, sy0, sth0 = sideAt(0)
            local Tb = sth0 * 1.6 / CORE
            local VS = 0.06
            for _, f in ipairs(FRAY) do
                local w0 = math.max(2, Tb * f.w)
                local Lf = w0 * (1024 / (2 * VS * 128))
                local px, py, pfront, pw
                local acc, sdist = 0, 0
                while sdist <= f.len do
                    local x = sx0 + f.start - sdist
                    local ym = yAtLinear(mainPath.xs, mainPath.ys, x)
                    local thm = yAtLinear(mainPath.xs, mainPath.ths, x)
                    local ph = 2 * math.pi * sdist / f.pitch + f.ph
                    local wrapY = ym + thm * 0.52 * math.sin(ph)
                    local join = smoothstep(sdist / 35)
                    local startY = sy0 - (f.v - 0.5) * Tb
                    local y = startY + (wrapY - startY) * join
                    local isFront = join < 0.6 or math.cos(ph) > 0
                    local w = w0 * (1 - 0.65 * sdist / f.len)
                    if px then
                        local pl = (isFront and pfront) and frayF or frayB
                        local ln = take(pl, STRIP)
                        local len = seg(ln, px, py, x, y, pw, 0.4)
                        ln:SetTexCoord(acc / Lf, (acc + len) / Lf, f.v - VS, f.v + VS)
                        local d = (pl == frayF) and 1 or 0.7
                        ln:SetVertexColor(d, d, d, math.min(1, (f.len - sdist + 6) / 18))
                        acc = acc + len
                    end
                    px, py, pfront, pw = x, y, isFront, w
                    sdist = sdist + 3
                end
                -- Schnörkel am Ende der Ranke, nach oben eingerollt
                if px then
                    local thm = yAtLinear(mainPath.xs, mainPath.ths, px)
                    local cx, cy, rr = px - thm * 0.2, py + thm * 0.55, thm * 0.38
                    local qx0, qy0
                    for k = 0, 14 do
                        local t = k / 14
                        local ang = -math.pi * 0.2 + t * math.pi * 2.0
                        local r = rr * (1 - 0.65 * t)
                        local qx, qy = cx + r * math.cos(ang), cy + r * math.sin(ang)
                        if qx0 then
                            local ln = take(frayF, STRIP)
                            seg(ln, qx0, qy0, qx, qy, math.max(1.2, w0 * 0.35 * (1 - 0.5 * t)), 0.4)
                            ln:SetTexCoord(0, 0.05, f.v - VS, f.v + VS)
                            ln:SetVertexColor(1, 1, 1, 1)
                        end
                        qx0, qy0 = qx, qy
                    end
                end
            end
        end

        -- Maus-Flächen: schmale Streifen, die genau dem Ast folgen
        hitStrips(xpHits, side, 0, 0.8, xpTooltip)
    else
        hitStrips(xpHits, side, 0, 0.8, xpTooltip) -- blendet alle aus (side.n < 2)
        hideXPFlowers()
    end
    finish(front)
    finish(back)
    finish(bud)
    finish(frayF)
    finish(frayB)
    for i = used + 1, #ivyLeaves do ivyLeaves[i]:Hide() end
    drawGlassXP()
end
mod.DrawXP = drawXP

---------------------------------------------------------------------------
-- Ruf-Ast: ein dünnerer Ast liegt direkt über dem Erfahrungs-Ast, umschlungen
-- von einer blau-türkisen Liane – so weit, wie der Ruf der verfolgten Fraktion
-- in der aktuellen Stufe ist. Ohne verfolgte Fraktion kein Ruf-Ast.
---------------------------------------------------------------------------
local repPath = { n = 0, x = {}, y = {}, th = {}, arc = {} }


local function buildRep()
    repPath.n = 0
    if not repActive() or side.n < 2 then return end
    local W = UIParent:GetWidth()
    local xf = side.x[1] + 34
    local xe = W + 14
    if xe - xf < 100 then return end
    local x, n, acc = xf, 0, 0
    local px, py
    while x <= xe do
        local ys = yAtLinear(side.x, side.y, x)
        local ths = yAtLinear(side.x, side.th, x)
        local arch = palArch(palette())
        local rth = ths * 0.75
        -- über dem Lianenbündel des Erfahrungs-Asts, mit kleinem Spalt
        local full = ths * 1.6 * 0.5 + 3 + rth * 1.6 * 0.5
        local rise = arch and math.max(0, math.min(1, (x - xf) / math.max(8, full - ths * 0.2)))
            or smoothstep((x - xf) / 100)
        local y = ys + ths * 0.2 + (full - ths * 0.2) * rise + (arch and 0 or 1.5 * math.sin(x / 29))
        n = n + 1
        if px then acc = acc + math.sqrt((x - px) ^ 2 + (y - py) ^ 2) end
        repPath.x[n], repPath.y[n], repPath.th[n], repPath.arc[n] = x, y, rth * (0.75 + 0.25 * rise), acc
        px, py = x, y
        x = x + 3
    end
    repPath.n = n
end

local function repProgress()
    local name, standing, min, max, value = watchedFaction()
    if not name then return 0 end
    if ns.isSecret(value) or ns.isSecret(max) or ns.isSecret(min) then return 1 end
    if max <= min then return 1 end -- höchste Stufe
    return math.max(0, math.min(1, (value - min) / (max - min)))
end

local function repTooltip(self)
    local name, standing, min, max, value = watchedFaction()
    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
    GameTooltip:AddLine("Ruf – " .. (name or "?"), 1, 0.82, 0)
    local label = standing and _G["FACTION_STANDING_LABEL" .. standing]
    if label then GameTooltip:AddLine(label, 0.55, 0.85, 1) end
    if name and not ns.isSecret(value) and max and max > min then
        local f = ns.FormatNumber or tostring
        GameTooltip:AddLine(("%s / %s  (%d %%)"):format(f(value - min), f(max - min),
            math.floor((value - min) / (max - min) * 100)), 1, 1, 1)
    end
    GameTooltip:Show()
end

local function drawGlassRep()
    local gl = glassArch()
    local R = gl and glassGeo and glassGeo.rose
    local nS = 0
    if R and fillFrame and gl.rose and gl.roseSector then
        local p = repProgress()
        local _, standing = watchedFaction()
        local col = standing and FACTION_BAR_COLORS and FACTION_BAR_COLORS[standing]
        local cr, cg, cb = 0.45, 0.72, 1
        if col then cr, cg, cb = col.r, col.g, col.b end
        if not roseDark then
            roseDark = fillFrame:CreateTexture(nil, "ARTWORK", nil, 1)
            roseFrame = fillFrame:CreateTexture(nil, "ARTWORK", nil, 5)
        end
        for _, t in ipairs({ roseDark, roseFrame }) do
            t:ClearAllPoints()
            t:SetSize(R.size, R.size)
            t:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", R.x, R.y)
        end
        roseDark:SetTexture(TX(gl.rose))
        if roseDark.SetDesaturated then roseDark:SetDesaturated(true) end
        roseDark:SetVertexColor(0.34, 0.34, 0.38)
        roseDark:Show()
        if gl.roseFrame then roseFrame:SetTexture(TX(gl.roseFrame)); roseFrame:Show() else roseFrame:Hide() end
        local secs = gl.roseSectors or 12
        local lit = p * secs
        for k = 0, secs - 1 do
            local a = math.max(0, math.min(1, lit - k))
            if a > 0 then
                nS = nS + 1
                local rot = -k * 2 * math.pi / secs        -- im Uhrzeigersinn, oben beginnend
                local t = glassTake(roseTex.sec, nS, 3, TX(gl.roseSector))
                t:SetSize(R.size, R.size)
                t:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", R.x, R.y)
                t:SetRotation(rot)
                t:SetVertexColor(1, 1, 1, a)
                local g = glassTake(roseTex.glow, nS, 4, TX(gl.roseSector), "ADD")
                g:SetSize(R.size, R.size)
                g:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", R.x, R.y)
                g:SetRotation(rot)
                g:SetVertexColor(cr, cg, cb, (gl.glow or 0.35) * a)
            end
        end
        roseHit = glassHitFrame(roseHit, R.x - R.size * 0.5, R.y, R.size, R.size, repTooltip)
    else
        if roseDark then roseDark:Hide(); roseFrame:Hide() end
        if roseHit then roseHit:Hide() end
    end
    archHide(roseTex.sec, nS + 1)
    archHide(roseTex.glow, nS + 1)
end

local function drawRep()
    local rb = pool("repBranch", "ARTWORK", 2)
    local rf = pool("repFront", "OVERLAY", 6)
    if repPath.n > 1 and branchFrame then
        local pal = palette()
        local tex = TX(pal.strand)
        local c = pal.branch
        local L = db.thickness * 0.52 * TILE
        local acc = 0
        for k = 1, repPath.n - 1 do
            local th = (repPath.th[k] + repPath.th[k + 1]) * 0.5
            local ln = take(rb, tex)
            local len = seg(ln, repPath.x[k], repPath.y[k], repPath.x[k + 1], repPath.y[k + 1], th, 0.4)
            ln:SetTexCoord(acc / L, (acc + len) / L, STRANG_V[1], STRANG_V[2])
            ln:SetVertexColor(c[1], c[2], c[3])
            acc = acc + len
        end
        -- blau-türkise Liane
        local STRIP = TX(palette().lianeRep or "liane_blau")
        local CORE = 0.44
        local Lv = db.thickness * 0.52 * 1.6 / CORE * 8
        local total = repPath.arc[repPath.n]
        local reach = total * repProgress()
        local a = 0
        while a < reach do
            local nxt = math.min(reach, a + 6)
            local x0, y0, th0 = pathAt(repPath, a)
            local x1, y1, th1 = pathAt(repPath, nxt)
            local T = (th0 + th1) * 0.5 * 1.6 / CORE
            local grow = smoothstep(a / 70)
            local tipT = smoothstep((reach - nxt) / 40)
            local fade = math.min(smoothstep((a + 2) / 18), smoothstep((reach - nxt + 2) / 28))
            local ln = take(rf, STRIP)
            seg(ln, x0, y0, x1, y1, T * (0.3 + 0.7 * grow) * (0.55 + 0.45 * tipT), 0.3)
            ln:SetTexCoord((a + 400) / Lv, (nxt + 400) / Lv, 0, 1) -- versetzt, damit es nicht wie das grüne aussieht
            ln:SetVertexColor(1, 1, 1, fade)
            a = nxt
        end
        -- Maus-Flächen erst dort, wo der Ruf-Ast ganz vom Erfahrungs-Ast abgehoben ist
        hitStrips(repHits, repPath, 100, 0.8, repTooltip)
    else
        repPath.n = 0
        hitStrips(repHits, repPath, 100, 0.8, repTooltip)
    end
    finish(rb)
    finish(rf)
    drawGlassRep()
end

local function hideBlizzRep()
    local h = _G.MondhainHolder_rep
    if h and not h.mhHidden then
        h.mhHidden = true
        h:Hide()
        h:HookScript("OnShow", function(self) self:Hide() end)
    end
end

local function hideBlizzXP()
    if ns.db.root.hideXPBar == false then return end
    local h = _G.MondhainHolder_xp
    if h and not h.mhHidden then
        h.mhHidden = true
        h:Hide()
        h:HookScript("OnShow", function(self) self:Hide() end)
    end
end

---------------------------------------------------------------------------
-- Zauber-Ast: beim Zaubern sprießt an der Schräge rechts der Karte ein Zweig
-- aus dem Hauptast und läuft nach rechts bis ans Ende der Aktionsleisten.
-- Der ganze Raum zwischen Zweig und Hauptast ist der Zauberbalken: er füllt
-- sich von links nach rechts (Kanalisieren: leert sich). Unterbrochen = rot.
-- Ersetzt Blizzards Zauberleiste (außer Blizzard liefert geheime Zeiten).
---------------------------------------------------------------------------
local castGeo
local castFrame, castIcon, castName, castTime, castRing, castGlow
local castMedal                     -- Schablone zum Verschieben des Medaillons
local cWedge = {}
local drawIconFrame, hideIconFrame          -- Symbolrahmen (Gewand), weiter unten
local cStump = {}
local cast = { state = "idle" }
local cTwig, cFill, cEdge = {}, {}, {}
local CAST_STEP = 3
local castFill -- Rahmen UNTER dem Ast: Spur und Füllung (Ast und Zweig decken die Kanten)
-- satte, eher dunkle Farben: darauf ist weiße Schrift gut lesbar
-- Ben 25.11. 09:56: „Waldnacht“ – dunkel statt grell, oben heller, unten
-- dunkler (bot = Farbe an der sichtbaren Unterkante); Kanal/gesperrt/Fehler
-- in derselben Tiefe
local CAST_COLORS = {
    cast    = { 0.173, 0.376, 0.212, bot = { 0.055, 0.149, 0.086 } },
    channel = { 0.120, 0.300, 0.380, bot = { 0.035, 0.100, 0.140 } },
    locked  = { 0.300, 0.300, 0.300, bot = { 0.110, 0.110, 0.110 } },
    fail    = { 0.500, 0.120, 0.090, bot = { 0.190, 0.040, 0.030 } },
}
-- senkrechter Verlauf, alte und neue API
local function vGrad(t, r1, g1, b1, a1, r2, g2, b2, a2)   -- 1 = unten, 2 = oben
    if CreateColor then
        local ok = pcall(t.SetGradient, t, "VERTICAL", CreateColor(r1, g1, b1, a1), CreateColor(r2, g2, b2, a2))
        if ok then return end
    end
    if t.SetGradientAlpha then pcall(t.SetGradientAlpha, t, "VERTICAL", r1, g1, b1, a1, r2, g2, b2, a2) end
end
local cTrack = {}

local function castTarget() return ns.BlizzardFrames and ns.BlizzardFrames:GetTarget("cast") end
local function blizzCastAlpha(a)
    local h = _G.MondhainHolder_cast
    if h then h:SetAlpha(a) end
    local t = castTarget()
    if t then
        if t.SetIgnoreParentAlpha then t:SetIgnoreParentAlpha(false) end
        t:SetAlpha(a)
    end
end

local function buildCastGeo()
    castGeo = nil
    if not mainPath.xs then return end
    local S, E = castRange()
    if not S then return end
    local MX, MY, MT = mainPath.xs, mainPath.ys, mainPath.ths
    local function ymAt(x) return yAtLinear(MX, MY, x) end
    local function edgeAt(x) return yAtLinear(MX, MY, x) + yAtLinear(MX, MT, x) * 0.5 end
    local twTh = math.max(8, db.thickness * 0.45)
    local archCast = palArch(palette()) ~= nil       -- Bauweise Stein: gerade statt gebogen
    local yS = ymAt(S - 6)                      -- Höhe des Asts an der Kartenkante
    -- Zweig auf Höhe des Hubbels, aber mit Platz über dem Ast der Leisten
    local maxMain = 0
    for x = S + 60, E, 10 do maxMain = math.max(maxMain, edgeAt(x)) end
    local yT = math.max(yS, maxMain + 22 + twTh * 0.5) -- Platz für die Schrift
    for _, c in ipairs(lastCeils) do
        if c.r > S and c.l < E then yT = math.min(yT, c.bottom - twTh * 0.5 - 3) end
    end

    -- Linkes Ende (Bens Wunsch): der Zweig wächst an der Gabelung aus dem Hang
    -- des Hauptasts, das Medaillon liegt satt in der Ecke darunter – oben am
    -- Zweig, unten am Ast, links am Hang – und der Zwickel zwischen Hang,
    -- Zweig und Medaillon ist mit Holz ausgefüllt (wie eine echte Astgabel).
    local OV = 5
    local twB = yT - twTh * 0.5                -- Unterkante des Zweigs
    -- Gabelung (Bens Pfeil): wo der Hauptast sich vom Zweig löst – links liegt
    -- der Zweig auf dem Ast, ab hier öffnet sich die Lücke darunter
    local xF
    for xx = S - 40, E - 200 do
        if edgeAt(xx) < twB then xF = xx break end
    end
    xF = xF or S
    -- Größe: so, dass der Ring oben am Zweig und unten am flachen Ast anliegt
    local flatEdge = math.huge
    for xx = xF, math.min(E - 200, xF + 180), 3 do flatEdge = math.min(flatEdge, edgeAt(xx)) end
    if flatEdge == math.huge then flatEdge = edgeAt(xF + 40) end
    local D = math.max(34, math.min(52, twB - flatEdge + 2 * OV))
    local R = D * 0.5
    -- Linker Ansatz mit Symbol-Kasten (Bens Kasten 25.11., Vorschau 3):
    -- Ebenen von vorn nach hinten: Ast + Zweig + Ranke → Zaubersymbol →
    -- wachsender Balken. Das Symbol füllt die ganze Ecke zwischen Zweig und
    -- Ast (Ränder verschwinden dahinter), der Balken beginnt rechts daneben.
    local function edgeV(xx) return ymAt(xx) + yAtLinear(MX, MT, xx) * 0.42 end  -- sichtbare Oberkante
    local gapMax = 30
    for xx = S, E, 4 do gapMax = math.max(gapMax, twB - edgeV(xx)) end
    local xL
    for xx = S - 40, E - 200 do
        if twB - edgeV(xx) >= 0.33 * gapMax then xL = xx break end
    end
    xL = xL or (S + 40)
    -- Symbol quadratisch und fast ganz sichtbar (Ben 25.11. 07:52): so hoch wie
    -- 80 % der größten Lücke, oben knapp unter dem Zweig, so weit links in die
    -- Ecke, wie höchstens 12 % hinter dem Hang verschwinden
    -- Ben 25.11. 08:38 (rotes L): der Ast fällt hinter der Karte steil ab, das
    -- Symbol sitzt frei in der Ecke – links am Hang, unten auf dem Ast, oben
    -- unter dem Zweig. Ecke = wo der Hang (fast) unten angekommen ist.
    local boxT = twB + 1.5
    local eMin = math.huge
    for xx = S - 10, S + 160, 2 do eMin = math.min(eMin, edgeV(xx)) end
    xL = nil
    for xx = S - 10, S + 160 do
        if edgeV(xx) <= eMin + 0.15 * (boxT - eMin) then xL = xx break end
    end
    xL = xL or (S + 20)
    local eMax = -math.huge
    for xx = xL, xL + (boxT - eMin), 2 do eMax = math.max(eMax, edgeV(xx)) end
    local boxB = eMax - 2                     -- Unterkante knapp hinter dem Ast
    local Sz = math.max(20, math.min(gapMax + 2, 84, boxT - boxB))
    boxB = boxT - Sz
    local xR = xL + Sz
    -- Zweig (Bens grüne Linie 07:58): liegt lange flach auf dem Ast und
    -- wächst erst direkt vor dem Symbol steil hoch
    local xTop = xL + 0.05 * Sz
    -- Ben 25.11. 08:38 (roter Strich): Zweig und Ranke beginnen kurz vor der
    -- Kartenkante; was links davon lag, ist weg
    local tipL = twTh * 2.4
    local xP = S - 24                         -- Anfang (Spitze) von Zweig und Ranke
    local xr0 = xL - 0.30 * gapMax            -- Beginn des Anstiegs (nur falls nötig)
    local xs0 = math.max(xP + 4, math.min(xP + tipL, xr0 - 2))  -- ab hier volle Liegestrecke
    xr0 = math.max(xr0, xs0 + 2)
    local lie = twTh * 0.25                   -- so weit liegt er über der Ast-Oberkante
    -- Liegestrecke: folgt dem Ast nach oben, fällt aber nie mit ihm ab
    -- (hinter dem steilen Hang bleibt der Zweig oben)
    local runX, runY = {}, {}
    do
        local m = -math.huge
        local xx = xP
        while true do
            m = math.max(m, math.min(edgeV(xx) + lie, yT))
            runX[#runX + 1], runY[#runY + 1] = xx, m
            if xx >= xr0 then break end
            xx = math.min(xr0, xx + 2)
        end
    end
    local function lieAt(xx)
        if xx <= runX[1] then return math.min(edgeV(xx) + lie, yT) end
        return yAtLinear(runX, runY, math.min(xx, xr0))
    end
    local y0r = lieAt(xr0)
    local function yLeft(xx)
        if xx < xr0 then return lieAt(xx) end
        local t = math.max(0, math.min(1, (xx - xr0) / math.max(1, xTop - xr0)))
        if not archCast then t = t * t * (3 - 2 * t) end
        return y0r + (yT - y0r) * t
    end
    -- Stumpf (Bens rote Form): kurzer Ast wächst aus dem Hauptast hoch, rechts
    -- bündig unter dem Symbol, oben vom Zweig abgeschlossen
    local stW = 0.42 * gapMax
    local stX = xL - stW * 0.5 + 3
    local function branchBot(xx) return ymAt(xx) - yAtLinear(MX, MT, xx) * 0.42 end
    D = 0
    R = 0
    local cx = (xs0 + xR) * 0.5
    local my = (yT + boxB) * 0.5
    local defX, defY = cx, my
    local ymB = ymAt(cx)
    local cy = (yT + ymB) * 0.5                -- (nur noch für die alte Kappe)
    local ryL = (yT - ymB) * 0.5
    local rxL = 0
    local Rt = 0
    -- Rechtes Ende: langer, sanfter Abstieg, läuft flach und spitz in den Ast aus
    local rx = math.max(40, math.min(130, (yT - edgeAt(E)) * 2.3))
    local xa = math.max(xR + 90, E - rx * 0.6)
    local xEnd = math.min(xa + rx, E + 60)
    rx = math.max(20, xEnd - xa)
    xEnd = xa + rx
    if archCast then
        -- Paladin (Ben 06:29): rechts gerade abschließen – kurzer, fast senkrechter Pfosten
        rx = math.max(6, twTh * 0.5)
        xEnd = E
        xa = xEnd - rx
    end
    local yE = math.min(edgeAt(xEnd) - twTh * 0.35, yT - 6)
    local ry = yT - yE
    local function yRight(xx)
        local t = math.max(0, math.min(1, (xx - xa) / rx))
        if archCast then return yT - ry * t end
        return yE + ry * (1 + math.cos(math.pi * t)) * 0.5
    end
    local function topAt(xx)
        if xx < xTop then return yLeft(xx) elseif xx <= xa then return yT end
        return yRight(xx)
    end

    local g = { S = S, E = xEnd, twTh = twTh, yT = yT, flatTop = yT, D = D, mx = cx, my = my, Rt = Rt,
                defX = defX, defY = defY,
                cy = cy, rxL = rxL, ryL = ryL, ymB = ymB,
                xa = xa, rx = rx, ry = ry, yEnd = yE, hasArch = true,
                xs0 = xs0, xTop = xTop, xL = xL, xR = xR, boxT = boxT, boxB = boxB,
                stump = { x0 = stX - stW * 0.5, x1 = stX + stW * 0.5, bot = ymAt(stX) - 2, w = stW },
                branchBot = branchBot, topAt = topAt, botAt = ymAt,
                xs = {}, top = {}, bot = {}, edge = {}, twb = {} }

    -- gerader Teil ab der rechten Kante des Symbols bis zum Abstieg (Füllung, Schrift)
    local x = xR
    local last = false
    while true do
        local ym = ymAt(x)
        local n = #g.xs + 1
        g.xs[n], g.bot[n], g.top[n] = x, ym, math.max(ym + 2, yT)
        g.edge[n] = edgeAt(x)
        g.twb[n] = yT - twTh * 0.5
        if last then break end
        x = x + CAST_STEP
        if x >= xa - 0.1 then x, last = xa, true end
    end
    g.ka = #g.xs + 1
    -- gerader Teil: wenige große Rechtecke, Unterkante je Stück auf der
    -- tiefsten Astmitte darin; Stücke stoßen genau aneinander (kein Überlappen
    -- → beim Ausblenden keine Streifen)
    g.chunks = {}
    local minEdge = math.huge
    local cur
    for k = 1, #g.xs - 1 do
        local x2, ym = g.xs[k], g.bot[k]
        local th2 = yAtLinear(MX, MT, x2)
        minEdge = math.min(minEdge, g.edge[k])
        if cur and (math.max(cur.hi, ym) - math.min(cur.lo, ym)) < th2 * 0.3 then
            cur.x1, cur.lo, cur.hi = x2, math.min(cur.lo, ym), math.max(cur.hi, ym)
        else
            if cur then cur.x1 = x2 end
            cur = { x0 = x2, x1 = x2, lo = ym, hi = ym }
            g.chunks[#g.chunks + 1] = cur
        end
    end
    if cur then cur.x1 = math.max(cur.x1, xa) end
    g.visBot = math.min(minEdge, yT - 4) -- Oberkante Ast = untere Grenze des Sichtbaren
    -- gebogene Teile: schmale Streifen von der Astmitte bis an den Zweig
    local function strips(x0, x1)
        local list = {}
        local xx = x0
        while xx < x1 - 0.01 do
            local xb = math.min(x1, xx + CAST_STEP)
            local hi = topAt((xx + xb) * 0.5)
            local lo = math.min(ymAt(xx), ymAt(xb))
            if hi > lo + 0.5 then list[#list + 1] = { x0 = xx, x1 = xb, lo = lo, hi = hi } end
            xx = xb
        end
        return list
    end
    g.leftStrips = {}                         -- links vom Symbol keine Balkenfläche
    -- Zwickel zwischen Anstieg, Hang und Symbol mit Holz füllen (Ben 07:56);
    -- liegt hinter Ast, Zweig und Symbol, die decken die Ränder
    g.wedge = {}
    local wx = xP                              -- ab dem Anfang: Ecke links vom Symbol ganz zu
    while wx < xL + 3 - 0.01 do
        local wb = math.min(xL + 3, wx + 2)
        local hi = topAt((wx + wb) * 0.5)
        local lo = ymAt((wx + wb) * 0.5)
        if hi > lo + 0.5 then g.wedge[#g.wedge + 1] = { x0 = wx, x1 = wb, y0 = lo, y1 = hi } end
        wx = wb
    end
    g.rightStrips = strips(xa, xEnd)

    -- Tiefe und Glanz: sichtbare Oberkante (Zweig-Unterkante) und typische Höhe
    g.visTop = yT - twTh * 0.5
    do
        local hs = {}
        for xx = xR, xa, 8 do hs[#hs + 1] = g.visTop - edgeV(xx) end
        table.sort(hs)
        g.visH = math.max(10, hs[math.max(1, math.floor(#hs / 2))] or 30)
    end
    g.shade = {}
    local vH = g.visH
    local function piece(x0, x1, y0, y1, aLo, aHi, r, gg, b, sub)
        if x1 > x0 + 0.1 and y1 > y0 + 0.1 then
            g.shade[#g.shade + 1] = { x0 = x0, x1 = x1, y0 = y0, y1 = y1, aLo = aLo, aHi = aHi,
                r = r, g = gg, b = b, sub = sub }
        end
    end
    -- Abschnitte entlang der Oberkante: gerader Teil am Stück, rechts in Streifen
    local tops = { { x0 = xR, x1 = xa, top = g.visTop } }
    for _, st in ipairs(g.rightStrips) do
        tops[#tops + 1] = { x0 = st.x0, x1 = st.x1, top = topAt((st.x0 + st.x1) * 0.5) - twTh * 0.5 }
    end
    for _, tp in ipairs(tops) do
        local t0 = tp.top
        piece(tp.x0, tp.x1, t0 - 16, t0 + 2, 0, 0.62, 0, 0, 0, 0)                       -- Schatten unter Zweig/Ranke
        piece(tp.x0, tp.x1, t0 - 0.26 * vH, t0 - 0.10 * vH, 0.20, 0, 0.82, 0.94, 0.78, 1) -- Glanz, oberer Teil
        piece(tp.x0, tp.x1, t0 - 0.48 * vH, t0 - 0.26 * vH, 0, 0.20, 0.82, 0.94, 0.78, 1) -- Glanz, unterer Teil
        piece(tp.x0, tp.x1, t0 - 0.17 * vH - 0.5, t0 - 0.17 * vH + 0.5, 0.16, 0.16, 0.70, 0.86, 0.66, 1) -- Lichtkante
    end
    -- Schatten am Ast: hängt an der sichtbaren Oberkante des Asts
    local bx = xR
    while bx < xEnd - 0.01 do
        local bx1 = math.min(xEnd, bx + 12)
        local ed = edgeV((bx + bx1) * 0.5)
        piece(bx, bx1, ed - 3, ed + 9, 0.50, 0, 0, 0, 0, 0)
        bx = bx1
    end

    -- Verlauf des Zweigs als Punktliste: Ansatz links im Ast → über das
    -- Medaillon → gerade → sanfter Abstieg rechts (die Ranke folgt genau ihm)
    local P = {}
    local function add(px, py)
        local q = P[#P]
        if q and math.abs(q.x - px) < 0.5 and math.abs(q.y - py) < 0.5 then return end
        P[#P + 1] = { x = px, y = py }
    end
    g.xF = xF
    -- spitzes Ende (Bens lila Kreis): liegt vor dem Ansatz flach auf dem Ast
    for i = 0, 3 do                          -- spitzes Ende, liegt auf dem Ast
        local xx = xP + (xs0 - xP) * i / 4
        add(xx, yLeft(xx))
    end
    for i = 0, 10 do                         -- flach auf dem Ast
        local xx = xs0 + (xr0 - xs0) * i / 10
        add(xx, yLeft(xx))
    end
    for i = 1, 12 do                         -- steil hoch vor dem Symbol
        local xx = xr0 + (xTop - xr0) * i / 12
        add(xx, yLeft(xx))
    end
    add(xTop, yT)
    g.pi0 = #P                               -- Ende des Anstiegs
    if xa > xTop + 1 then add(xa, yT) end
    g.pa = #P                                 -- Beginn des Abstiegs rechts
    for i = 1, 14 do
        local xx = xa + rx * i / 14
        add(xx, yRight(xx))
    end

    g.path, g.arc = P, { 0 }
    if castMedal and not castMedal.mhMoving then
        castMedal:ClearAllPoints()
        castMedal:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, my)
        castMedal:SetSize(D, D)
    end
    for i = 2, #P do
        local dx, dy = P[i].x - P[i - 1].x, P[i].y - P[i - 1].y
        g.arc[i] = g.arc[i - 1] + math.sqrt(dx * dx + dy * dy)
    end
    -- Ben 08:17: an der Biegung wird die Ranke nur dicker – ein gerader Strang
    -- von der Liegestrecke bis oben füllt die Kehle, die Ecke unten bleibt
    -- Start dort, wo die Gerade nach B die Liegestrecke von oben berührt (obere
    -- Hülle): so überbrückt sie auch die Mulde vor dem Anstieg (Ben 08:24)
    local xB = xTop + 0.6 * twTh
    local xA, best = nil, math.huge
    local xx = math.max(xs0 + twTh, xr0 - 0.9 * gapMax)
    while xx < xr0 do
        local m = (yT - yLeft(xx)) / (xB - xx)        -- flachste Gerade, alle Punkte darunter
        if m < best then best, xA = m, xx end
        xx = xx + 2
    end
    xA = xA or (xL - 0.68 * gapMax)
    local function arcAt(xx)                  -- links steigt x entlang des Pfads stetig
        for i = 2, g.pi0 + 1 do
            if P[i] and P[i].x >= xx then
                local t = (xx - P[i - 1].x) / math.max(0.001, P[i].x - P[i - 1].x)
                return g.arc[i - 1] + (g.arc[i] - g.arc[i - 1]) * t
            end
        end
        return g.arc[g.pi0]
    end
    if xA > xs0 and xB > xA + 4 and yT - yLeft(xA) > twTh * 0.3 then
        g.brace = { ax = xA, ay = yLeft(xA), bx = xB, by = yT, a0 = arcAt(xA), a1 = arcAt(xB) }
    end
    castGeo = g
end

local function takeT(list, i, layer, sub, blend, parent)
    local t = list[i]
    if not t then
        t = (parent or castFrame):CreateTexture(nil, layer, nil, sub)
        if blend then t:SetBlendMode(blend) end
        list[i] = t
    end
    t:Show()
    return t
end

-- Punkt auf dem Zweig bei Bogenlänge a
local function pathPoint(g, a)
    local P, A = g.path, g.arc
    if a <= 0 then return P[1].x, P[1].y end
    for i = 2, #P do
        if A[i] >= a then
            local t = (a - A[i - 1]) / math.max(0.001, A[i] - A[i - 1])
            return P[i - 1].x + (P[i].x - P[i - 1].x) * t, P[i - 1].y + (P[i].y - P[i - 1].y) * t
        end
    end
    return P[#P].x, P[#P].y
end

-- Bogenlänge an der Stelle x rechts vom Medaillon (dort wächst x stetig)
local function arcAtX(g, x)
    local P, A = g.path, g.arc
    local i0 = g.pi0
    if x <= P[i0].x then return A[i0] end
    for i = i0 + 1, #P do
        if P[i].x >= x then
            local t = (x - P[i - 1].x) / math.max(0.001, P[i].x - P[i - 1].x)
            return A[i - 1] + (A[i] - A[i - 1]) * t
        end
    end
    return A[#A]
end

-- Verlängerung an Knicken: nur so viel, wie der Knick braucht (gerade Stücke
-- stoßen genau aneinander → beim Ausblenden keine Striche)
local function kinkExt(ax, ay, bx, by, cx, cy, th)
    if not ax or not cx then return 0 end
    local a1 = math.atan2(by - ay, bx - ax)
    local a2 = math.atan2(cy - by, cx - bx)
    local d = math.abs(a2 - a1)
    if d > math.pi then d = 2 * math.pi - d end
    if d < 0.002 then return 0 end
    return th * 0.5 * math.tan(math.min(d, 1.2) * 0.5) + 0.2
end

local function segExt(ln, x0, y0, x1, y1, th, e0, e1)
    local dx, dy = x1 - x0, y1 - y0
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 0.01 then ln:Hide() return 0 end
    local ux, uy = dx / len, dy / len
    ln:SetThickness(math.max(0.5, th))
    ln:SetStartPoint("BOTTOMLEFT", UIParent, x0 - ux * e0, y0 - uy * e0)
    ln:SetEndPoint("BOTTOMLEFT", UIParent, x1 + ux * e1, y1 + uy * e1)
    return len
end

-- Zweig zeichnen (einmal pro Zauber): wächst dünn aus dem Hang, legt sich um
-- das Medaillon, läuft gerade und biegt sich am Ende zurück in den Ast
local function drawTwig(alpha)
    local used = 0
    if castGeo then
        local g = castGeo
        local pal = palette()
        local L = g.twTh * TILE
        local acc = 0
        local total = g.arc[#g.arc]
        local P = g.path
        -- Stumpf: senkrechter Strang in schmalen Streifen, oben vom Zweig
        -- begrenzt (Maserung läuft nach oben), unten im Ast verborgen
        local sused = 0
        local st = g.stump
        if st then
            local Ls = st.w * TILE
            local vA, vB = STRANG_V[1], STRANG_V[2]
            local xx = st.x0
            while xx < st.x1 - 0.01 do
                local xb = math.min(st.x1, xx + 2)
                local top = g.topAt((xx + xb) * 0.5)
                if top > st.bot + 0.5 then
                    sused = sused + 1
                    local t = cStump[sused]
                    if not t then
                        t = castFill:CreateTexture(nil, "ARTWORK", nil, 3)
                        cStump[sused] = t
                    end
                    t:SetTexture(TX(pal.strand), "REPEAT", "CLAMP")
                    t:SetVertexColor(pal.branch[1], pal.branch[2], pal.branch[3], 1)
                    t:ClearAllPoints()
                    t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", xx, st.bot)
                    t:SetSize(xb - xx, top - st.bot)
                    local vL = vA + (xx - st.x0) / st.w * (vB - vA)
                    local vR = vA + (xb - st.x0) / st.w * (vB - vA)
                    local uT = (top - st.bot) / Ls
                    -- gedreht: Bild-Längsrichtung läuft senkrecht nach oben
                    t:SetTexCoord(uT, vL, 0, vL, uT, vR, 0, vR)
                    t:Show()
                end
                xx = xb
            end
        end
        for i = sused + 1, #cStump do cStump[i]:Hide() end
        -- Zwickel der Astgabel mit Holz füllen (unter Ast und Zweig)
        local wused = 0
        if g.wedge then
            local tex = TX(palFill(pal))
            local Lf = g.twTh * TILE
            local Hf = g.twTh * 128 / 95
            for _, w in ipairs(g.wedge) do
                wused = wused + 1
                local t = cWedge[wused]
                if not t then
                    t = castFill:CreateTexture(nil, "ARTWORK", nil, 2)
                    cWedge[wused] = t
                end
                t:SetTexture(tex, "REPEAT", "REPEAT")
                t:SetVertexColor(pal.branch[1] * 0.9, pal.branch[2] * 0.9, pal.branch[3] * 0.9, 1)
                t:ClearAllPoints()
                t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", w.x0, w.y0)
                t:SetSize(w.x1 - w.x0, w.y1 - w.y0)
                t:SetTexCoord(w.x0 / Lf, w.x1 / Lf, -w.y1 / Hf, -w.y0 / Hf)
                t:Show()
            end
        end
        for i = wused + 1, #cWedge do cWedge[i]:Hide() end
        for i = 1, #P - 1 do
            local a, b = P[i], P[i + 1]
            used = used + 1
            local ln = cTwig[used]
            if not ln then ln = castFrame:CreateLine(nil, "ARTWORK", nil, 4); cTwig[used] = ln end
            ln:SetTexture(TX(pal.strand), "REPEAT", "CLAMP")
            -- an der Gabelung wächst der Zweig dünn aus dem Hang
            local root = 0.12 + 0.88 * smoothstep(((g.arc[i] + g.arc[i + 1]) * 0.5) / (g.twTh * 3.5))
            local th = g.twTh * root
            if g.pa and i >= g.pa then
                -- rechter Bogen: erst leicht verdickt, dann spitz in den Ast
                local span = math.max(1, total - g.arc[g.pa])
                local t = math.min(1, ((g.arc[i] + g.arc[i + 1]) * 0.5 - g.arc[g.pa]) / span)
                th = g.twTh * (1 + 0.3 * math.sin(math.pi * t)) * (1 - 0.62 * t * t)
            end
            local pr, nx = P[i - 1], P[i + 2]
            local e0 = pr and kinkExt(pr.x, pr.y, a.x, a.y, b.x, b.y, th) or 0
            local e1 = nx and kinkExt(a.x, a.y, b.x, b.y, nx.x, nx.y, th) or 0
            local len = segExt(ln, a.x, a.y, b.x, b.y, th, e0, e1)
            ln:SetTexCoord((acc - e0) / L, (acc + len + e1) / L, STRANG_V[1], STRANG_V[2])
            ln:SetVertexColor(pal.branch[1], pal.branch[2], pal.branch[3], 1)
            ln:Show()
            acc = acc + len
        end
    end
    for i = used + 1, #cTwig do cTwig[i]:Hide() end
    castFrame:SetAlpha(alpha)
end

-- Fläche vom Medaillon bis x1: Rechtecke im geraden Teil, unter dem Bogen ein
-- einzelnes Rechteck mit runder Maske (Viertelellipse)
local cArch = {}   -- [Liste] = maskierte Textur unter dem Bogen
local cCap = {}    -- [Liste] = maskierte Textur im linken Halbbogen
local archMask, capMask
local function paintRegion(list, x1, r, gC, b, a, layer, bot)
    local g = castGeo
    local used = 0
    -- Verlauf: oben (sichtbare Oberkante) Grundfarbe, unten (sichtbare
    -- Unterkante) „bot“; über die verdeckten Ränder hinaus weitergerechnet
    local vT, vH = g.visTop or g.yT, g.visH or 30
    local function colAt(y)
        local f = math.max(-0.4, math.min(1.4, (vT - y) / vH))
        local function c(top, low) return math.max(0, math.min(1, top + (low - top) * f)) end
        return c(r, bot[1]), c(gC, bot[2]), c(b, bot[3])
    end
    local function rect(x0, xb, lo, hi)
        if xb <= x0 or hi <= lo then return end
        used = used + 1
        local t = takeT(list, used, layer, 1, nil, castFill)
        if bot then
            t:SetColorTexture(1, 1, 1, a)
            local r1, g1, b1 = colAt(lo)
            local r2, g2, b2 = colAt(hi)
            vGrad(t, r1, g1, b1, a, r2, g2, b2, a)
        else
            t:SetColorTexture(r, gC, b, a)
        end
        t:ClearAllPoints()
        t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x0, lo)
        t:SetSize(xb - x0, hi - lo)
    end
    -- links unter dem Bogen, Mitte in großen Stücken, rechts unter dem Abstieg
    for _, st in ipairs(g.leftStrips or {}) do
        if st.x0 >= x1 then break end
        rect(st.x0, math.min(st.x1, x1), st.lo, st.hi)
    end
    for _, c in ipairs(g.chunks) do
        if c.x0 >= x1 then break end
        rect(c.x0, math.min(c.x1, x1), c.lo, g.flatTop)
    end
    for _, st in ipairs(g.rightStrips or {}) do
        if st.x0 >= x1 then break end
        rect(st.x0, math.min(st.x1, x1), st.lo, st.hi)
    end
    for i = used + 1, #list do list[i]:Hide() end
    if cCap[list] then cCap[list]:Hide() end
    if cArch[list] then cArch[list]:Hide() end
end

-- dunkle Spur über die ganze Länge (einmal pro Zauber)
local function drawTrack()
    if castGeo then paintRegion(cTrack, castGeo.E, 0.07, 0.05, 0.04, 1, "BACKGROUND") end
end

local function progressX(p)
    local g = castGeo
    local x0 = g.xR or g.xs0 or g.mx
    return x0 + (g.E - x0) * p
end

-- Ranke: Länge entlang des ganzen Zweigs (aus dem unteren Ast, um das
-- Medaillon, dann nach rechts); die Füllung folgt ihrer Spitze
local function vineReach(p)
    local g = castGeo
    return g.arc[#g.arc] * p
end
local function pathPointX(g, a)
    local px = pathPoint(g, a)
    return px
end
local function fillX(p)
    local g = castGeo
    if cast.vine then
        return math.max(g.xR or 0, pathPointX(g, vineReach(p)))
    end
    return progressX(p)
end

-- Füllung bis zum Fortschritt p (0..1)
-- Tiefe und Glanz (Ben 25.11. 09:59, Vorschlag B): Schatten unter Zweig/Ranke
-- und am Ast, heller Lackschimmer im oberen Drittel – nur über der Füllung
local cShade = {}
local function drawShade(xEnd)
    local g = castGeo
    local used = 0
    for _, pc in ipairs(g and g.shade or {}) do
        if pc.x0 < xEnd then
            used = used + 1
            local t = takeT(cShade, used, "ARTWORK", pc.sub, nil, castFill)
            t:SetColorTexture(1, 1, 1, 1)
            vGrad(t, pc.r, pc.g, pc.b, pc.aLo, pc.r, pc.g, pc.b, pc.aHi)
            t:ClearAllPoints()
            t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", pc.x0, pc.y0)
            t:SetSize(math.min(pc.x1, xEnd) - pc.x0, pc.y1 - pc.y0)
        end
    end
    for i = used + 1, #cShade do cShade[i]:Hide() end
end

local function drawFill(p, col)
    local SOFT = MEDIA .. "weich"
    if castGeo and p > 0 then
        local g = castGeo
        local xEnd = fillX(p)
        paintRegion(cFill, xEnd, col[1], col[2], col[3], 1, "BORDER",
            col.bot or { col[1] * 0.35, col[2] * 0.35, col[3] * 0.35 })
        drawShade(xEnd)
        -- helle Vorderkante
        local bot, top = g.botAt(xEnd), g.topAt(xEnd)
        local e = takeT(cEdge, 1, "ARTWORK", 6, "ADD", castFill)
        e:SetTexture(SOFT)
        e:ClearAllPoints()
        e:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", xEnd, bot)
        e:SetSize(6, math.max(2, top - bot))
        e:SetVertexColor(1, 1, 0.8, p < 0.995 and 0.9 or 0)
    else
        for i = 1, #cFill do cFill[i]:Hide() end
        for i = 1, #cShade do cShade[i]:Hide() end
        if cArch[cFill] then cArch[cFill]:Hide() end
        if cCap[cFill] then cCap[cFill]:Hide() end
        if cEdge[1] then cEdge[1]:Hide() end
    end
end

-- Ranke (nur bei Heilzaubern): sprießt oben aus dem Medaillon und wächst mit
-- dem Fortschritt um den Zweig (gemaltes Lianenbündel wie beim Erfahrungs-Ast),
-- Knospe leuchtet an der Spitze
local cVine, cTip = {}, nil
local function drawVine(p, withered)
    local used = 0
    if castGeo and p > 0 then
        local g = castGeo
        local CORE = 0.44
        local T = g.twTh * 1.15 / CORE
        local L = T * 8
        local a0 = 0
        local a1 = math.max(a0 + 4, vineReach(p))
        local r, gg, b = 1, 1, 1
        if withered then r, gg, b = 0.55, 0.38, 0.26 end
        -- Stützpunkte: Knicke des Zweigs übernehmen, dazwischen alle 6 px
        local pts = { a0 }
        for i = 1, #g.arc do
            if g.arc[i] > a0 and g.arc[i] < a1 then pts[#pts + 1] = g.arc[i] end
        end
        pts[#pts + 1] = a1
        local fine = { pts[1] }
        for i = 2, #pts do
            local s0, s1 = pts[i - 1], pts[i]
            local n = math.max(1, math.ceil((s1 - s0) / 6))
            for k = 1, n do fine[#fine + 1] = s0 + (s1 - s0) * k / n end
        end
        local X, Y = {}, {}
        for i, a in ipairs(fine) do X[i], Y[i] = pathPoint(g, a) end
        for i = 1, #fine - 1 do
            local a, nxt = fine[i], fine[i + 1]
            local grow = 0.45 + 0.55 * smoothstep((a - a0) / 30)
            local tip = 0.4 + 0.6 * smoothstep((a1 - nxt) / 26)
            local th = T * grow * tip
            used = used + 1
            local ln = cVine[used]
            if not ln then
                ln = castFrame:CreateLine(nil, "ARTWORK", nil, 6)
                cVine[used] = ln
            end
            ln:SetTexture(TX(palStrip(palette())), "REPEAT", "CLAMP")
            local e0 = (i > 1) and kinkExt(X[i - 1], Y[i - 1], X[i], Y[i], X[i + 1], Y[i + 1], th * CORE) or 0
            local e1 = (i + 2 <= #fine) and kinkExt(X[i], Y[i], X[i + 1], Y[i + 1], X[i + 2], Y[i + 2], th * CORE) or 0
            segExt(ln, X[i], Y[i], X[i + 1], Y[i + 1], th, e0, e1)
            ln:SetTexCoord((a - e0) / L, (nxt + e1) / L, 0, 1)
            ln:SetVertexColor(r, gg, b, 1)
            ln:Show()
        end
        -- Verdickung an der Biegung: gerader Strang wächst mit, sobald die Ranke dort ist
        local br = g.brace
        if br and a1 > br.a0 then
            local k = math.min(1, (a1 - br.a0) / math.max(1, br.a1 - br.a0))
            local dx, dy = br.bx - br.ax, br.by - br.ay
            local len = math.sqrt(dx * dx + dy * dy)
            local upto = len * k
            local n = math.max(1, math.ceil(upto / 6))
            for i = 0, n - 1 do
                local s0, s1 = upto * i / n, upto * (i + 1) / n
                local grow = 0.85 + 0.15 * smoothstep(s0 / 12)
                local tip = (k < 1) and (0.4 + 0.6 * smoothstep((upto - s1) / 26)) or 1
                local th = T * grow * tip
                used = used + 1
                local ln = cVine[used]
                if not ln then
                    ln = castFrame:CreateLine(nil, "ARTWORK", nil, 6)
                    cVine[used] = ln
                end
                ln:SetTexture(TX(palStrip(palette())), "REPEAT", "CLAMP")
                segExt(ln, br.ax + dx * s0 / len, br.ay + dy * s0 / len,
                    br.ax + dx * s1 / len, br.ay + dy * s1 / len, th, 0, 0)
                ln:SetTexCoord((br.a0 + s0) / L, (br.a0 + s1) / L, 0, 1)
                ln:SetVertexColor(r, gg, b, 1)
                ln:Show()
            end
        end
        if not cTip then
            cTip = castFrame:CreateTexture(nil, "ARTWORK", nil, 7)
            cTip:SetTexture(MEDIA .. "punkt")
            cTip:SetBlendMode("ADD")
        end
        local tx, ty = pathPoint(g, a1)
        cTip:ClearAllPoints()
        cTip:SetPoint("CENTER", UIParent, "BOTTOMLEFT", tx, ty)
        cTip:SetSize(T * 0.75, T * 0.75)
        if withered then cTip:SetVertexColor(0.9, 0.3, 0.15, 0.8) else cTip:SetVertexColor(0.65, 1, 0.6, 0.9) end
        cTip:SetShown(p < 0.995)
    elseif cTip then
        cTip:Hide()
    end
    for i = used + 1, #cVine do cVine[i]:Hide() end
end

-- Heilzauber erkennen (dafür gibt es die Ranke)
local HEAL_WORDS = {
    "heil", "nachwachsen", "verjüng", "gelassenheit", "wildwuchs", "pflege", "lichtblitz",
    "heiliges licht", "welle der", "gebet", "erneuerung", "wiedergeburt", "wiederbeleb",
    "heal", "regrowth", "rejuven", "tranquil", "nourish", "flash of light", "holy light", "rebirth",
}
local function isHeal(name, spellID)
    if spellID and C_Spell and C_Spell.IsSpellHelpful then
        local ok, v = pcall(function() return C_Spell.IsSpellHelpful(spellID) == true end)
        if ok and v then return true end
    end
    if IsHelpfulSpell then
        local ok, v = pcall(function() return IsHelpfulSpell(name) and true or false end)
        if ok and v then return true end
    end
    local ok, low = pcall(function() return name:lower() end)
    if ok and type(low) == "string" then
        for _, w in ipairs(HEAL_WORDS) do
            if low:find(w, 1, true) then return true end
        end
    end
    return false
end

local function castInfo()
    local name, _, tex, startMS, endMS, trade, _, notInt, spellID
    local kind = "cast"
    name, _, tex, startMS, endMS, trade, _, notInt, spellID = UnitCastingInfo("player")
    if not name then
        kind = "channel"
        name, _, tex, startMS, endMS, trade, notInt, spellID = UnitChannelInfo("player")
    end
    if not name then return end
    return kind, name, tex, startMS, endMS, notInt, trade, spellID
end

---------------------------------------------------------------------------
-- Herstellen: Bild des Gegenstands statt Blizzard-Logo, Farbe nach Beruf
---------------------------------------------------------------------------
local CRAFT_COLORS = {
    { "leder",       "leather",     { 0.66, 0.40, 0.16 } }, -- Sattelbraun
    { "schneider",   "tailor",      { 0.58, 0.30, 0.74 } }, -- Seidenviolett
    { "schmied",     "blacksmith",  { 0.90, 0.42, 0.10 } }, -- Glut
    { "alchem",      "alchem",      { 0.12, 0.62, 0.58 } }, -- Trank-Türkis
    { "verzauber",   "enchant",     { 0.46, 0.36, 0.98 } }, -- Arkan
    { "ingenieur",   "engineer",    { 0.78, 0.62, 0.20 } }, -- Messing
    { "koch",        "cook",        { 0.84, 0.30, 0.16 } }, -- Herdfeuer
    { "erste hilfe", "first aid",   { 0.80, 0.22, 0.34 } }, -- Karmin
    { "bergbau",     "mining",      { 0.52, 0.58, 0.66 } }, -- Erz
    { "juwel",       "jewel",       { 0.18, 0.70, 0.88 } }, -- Edelstein
    { "inschrift",   "inscription", { 0.22, 0.38, 0.80 } }, -- Tinte
}
local CRAFT_DEFAULT = { 0.74, 0.58, 0.26 }               -- Gold

local function safeStr(f, ...)
    if not f then return end
    local ok, v = pcall(f, ...)
    if ok and type(v) == "string" and v ~= "" and v ~= "UNKNOWN" and not ns.isSecret(v) then return v end
end

local function craftColor(spellID)
    local line = safeStr(GetTradeSkillLine) or safeStr(GetCraftDisplaySkillLine)
    if not line and spellID and C_TradeSkillUI and C_TradeSkillUI.GetTradeSkillLineForRecipe then
        local ok, _, n, _, parent = pcall(C_TradeSkillUI.GetTradeSkillLineForRecipe, spellID)
        if ok then line = (type(parent) == "string" and parent) or (type(n) == "string" and n) or nil end
    end
    if not line and C_TradeSkillUI and C_TradeSkillUI.GetBaseProfessionInfo then
        local ok, info = pcall(C_TradeSkillUI.GetBaseProfessionInfo)
        if ok and info and type(info.professionName) == "string" then line = info.professionName end
    end
    if not line then return CRAFT_DEFAULT end
    line = line:lower()
    for _, c in ipairs(CRAFT_COLORS) do
        if line:find(c[1], 1, true) or line:find(c[2], 1, true) then return c[3] end
    end
    return CRAFT_DEFAULT
end

local function craftIcon(name, spellID)
    local function same(a, b)
        local ok, eq = pcall(function() return a == b end)
        return ok and eq
    end
    -- neuere Rezept-Daten
    if spellID and C_TradeSkillUI then
        if C_TradeSkillUI.GetRecipeSchematic then
            local ok, sch = pcall(C_TradeSkillUI.GetRecipeSchematic, spellID, false)
            if ok and sch and sch.outputItemID and C_Item and C_Item.GetItemIconByID then
                local ok2, icon = pcall(C_Item.GetItemIconByID, sch.outputItemID)
                if ok2 and icon then return icon end
            end
        end
        if C_TradeSkillUI.GetRecipeInfo then
            local ok, info = pcall(C_TradeSkillUI.GetRecipeInfo, spellID)
            if ok and info and info.icon then return info.icon end
        end
    end
    -- klassisches Berufefenster: ausgewähltes Rezept, sonst gleichnamiges
    if GetNumTradeSkills and GetTradeSkillInfo and GetTradeSkillIcon then
        local sel = GetTradeSkillSelectionIndex and GetTradeSkillSelectionIndex()
        if sel and sel > 0 and same(GetTradeSkillInfo(sel), name) then return GetTradeSkillIcon(sel) end
        for i = 1, (GetNumTradeSkills() or 0) do
            local n, kind = GetTradeSkillInfo(i)
            if kind ~= "header" and same(n, name) then return GetTradeSkillIcon(i) end
        end
    end
    -- klassisches Verzauberfenster
    if GetNumCrafts and GetCraftInfo and GetCraftIcon then
        for i = 1, (GetNumCrafts() or 0) do
            local n, _, kind = GetCraftInfo(i)
            if kind ~= "header" and same(n, name) then return GetCraftIcon(i) end
        end
    end
    -- Gegenstand gleichen Namens (wenn das Spiel ihn kennt, z. B. in der Tasche)
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, _, _, _, _, icon = pcall(C_Item.GetItemInfoInstant, name)
        if ok and icon then return icon end
    end
end

-- Zaubersymbol im Kasten: schmale Streifen, oben vom Zweig beschnitten, unten
-- hinter dem Ast; „füllend“ zugeschnitten (Mitte des Symbols, Seitenverhältnis des Kastens)
local cIconStrips = {}

-- Gewänder für den Rahmen ums Zaubersymbol: je Thema eigenes Material.
-- Bisher „Hain“ (Druide); Krieger, Schurke & Co. bekommen später eigene Einträge
-- (Stahl mit Nieten, Leder mit Naht …) – gleiche Felder, andere Bilder/Farben.
-- Stärken in Vielfachen der Zweigdicke; links/unten dicker, damit die Fuge zu
-- Zweig und Ast geschlossen ist.
local ICON_FRAMES = {
    hain = {
        body = { "zweig_fuell", "zweig_fuell_mahagoni" },   -- dichtes Holz (normal / Mahagoni)
        lift = 0.25,                                        -- Holz etwas heller als der Ast
        thick = { left = 0.75, bottom = 0.75, right = 0.40, top = 0.40 },
        edge = { 0.05, 0.03, 0.015, 1 },                    -- dunkle Außenkante
        bevel = { 0.84, 0.63, 0.36, 0.55 },                 -- helle Fase innen (Licht von oben links)
        shadow = { 0.02, 0.015, 0.008, 0.8 },               -- Schattenfuge innen
        leafSize = 2.0,                                     -- Efeu unten rechts, wächst über den Ast
        leaves = {
            { tex = 1, dx = 0.05, dy = 0.12, s = 1.0, rot = -50 },
            { tex = 2, dx = -0.32, dy = -0.12, s = 0.75, rot = 35 },
        },
    },
}
local function iconFrameStyle()
    return ICON_FRAMES[db and db.iconFrame or "hain"] or ICON_FRAMES.hain
end

local cFrameTex, cFrameLeaves = {}, {}
local nFrameTex = 0
hideIconFrame = function()
    for i = 1, #cFrameTex do cFrameTex[i]:Hide() end
    for i = 1, #cFrameLeaves do cFrameLeaves[i]:Hide() end
end

-- Rechteck zeichnen, oben vom Zweig und unten vom Ast beschnitten: in 2er-Spalten
-- prüfen, unbeschnittene Spalten zu einem Stück zusammenfassen
local function clipRect(g, x0, y0, x1, y1, paint)
    if x1 - x0 <= 0 or y1 - y0 <= 0 then return end
    local runA, runB, runLo, runHi
    local function flush()
        if runA then paint(runA, runB, runLo, runHi) end
        runA = nil
    end
    local xx = x0
    while xx < x1 - 0.01 do
        local xb = math.min(x1, xx + 2)
        local xm = (xx + xb) * 0.5
        local lo = math.max(y0, g.branchBot(xm) + 1)
        local hi = math.min(y1, g.topAt(xm))
        if hi > lo + 0.3 then
            if runA and lo == runLo and hi == runHi then runB = xb
            else flush(); runA, runB, runLo, runHi = xx, xb, lo, hi end
        else
            flush()
        end
        xx = xb
    end
    flush()
end

local function frameTex(layer, sub)
    nFrameTex = nFrameTex + 1
    local t = cFrameTex[nFrameTex]
    if not t then
        t = castFill:CreateTexture(nil, layer, nil, sub)
        cFrameTex[nFrameTex] = t
    end
    t:SetDrawLayer(layer, sub)
    t:SetBlendMode("BLEND")
    t:SetVertexColor(1, 1, 1, 1)
    t:SetTexCoord(0, 1, 0, 1)
    t:ClearAllPoints()
    return t
end

drawIconFrame = function(g, x0, x1, top, bot)
    nFrameTex = 0
    local st = iconFrameStyle()
    local pal = palette()
    local tw = g.twTh
    local ovl = 2
    local tL, tB = tw * st.thick.left, tw * st.thick.bottom
    local tR, tT = tw * st.thick.right, tw * st.thick.top
    -- außen (Leiste) und innen (Fenster)
    local OX0, OX1, OY0, OY1 = x0 + ovl - tL, x1 - ovl + tR, bot + ovl - tB, top - ovl + tT
    local IX0, IX1, IY0, IY1 = x0 + ovl, x1 - ovl, bot + ovl, top - ovl
    local body = TX(pal.fill or st.body[(pal.strand == M_STRAND) and 2 or 1])
    local Lf, Hf = tw * TILE, tw * 128 / 95
    local c = pal.branch
    -- Holzleisten; senkrechte Leisten mit gedrehter Maserung
    local function wood(ax, ay, bx, by, vertical)
        clipRect(g, ax, ay, bx, by, function(xa, xb, lo, hi)
            for pass = 1, (st.lift > 0) and 2 or 1 do
                local t = frameTex("OVERLAY", pass == 1 and 3 or 4)
                t:SetTexture(body, "REPEAT", "REPEAT")
                if pass == 1 then
                    t:SetVertexColor(c[1], c[2], c[3], 1)
                else
                    t:SetBlendMode("ADD")
                    t:SetVertexColor(c[1], c[2], c[3], st.lift)
                end
                t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", xa, lo)
                t:SetSize(xb - xa, hi - lo)
                if vertical then
                    t:SetTexCoord(hi / Lf, xa / Hf, lo / Lf, xa / Hf, hi / Lf, xb / Hf, lo / Lf, xb / Hf)
                else
                    t:SetTexCoord(xa / Lf, xb / Lf, -hi / Hf, -lo / Hf)
                end
                t:Show()
            end
        end)
    end
    local function flat(ax, ay, bx, by, col, sub)
        clipRect(g, ax, ay, bx, by, function(xa, xb, lo, hi)
            local t = frameTex("OVERLAY", sub)
            t:SetColorTexture(col[1], col[2], col[3], col[4])
            t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", xa, lo)
            t:SetSize(xb - xa, hi - lo)
            t:Show()
        end)
    end
    wood(OX0, IY1, OX1, OY1)                        -- oben (liegt meist unterm Zweig)
    wood(OX0, OY0, OX1, IY0)                        -- unten
    wood(OX0, IY0, IX0, IY1, true)                  -- links
    wood(IX1, IY0, OX1, IY1, true)                  -- rechts
    local e, hi, sh = st.edge, st.bevel, st.shadow
    flat(OX0, OY1 - 1, OX1, OY1, e, 5); flat(OX0, OY0, OX1, OY0 + 1, e, 5)
    flat(OX0, OY0, OX0 + 1, OY1, e, 5); flat(OX1 - 1, OY0, OX1, OY1, e, 5)
    flat(IX0 - 1, IY1, IX1 + 1, IY1 + 1, hi, 5)     -- Fase oben
    flat(IX0 - 1, IY0 - 1, IX0, IY1 + 1, hi, 5)     -- Fase links
    flat(IX0 - 1, IY0 - 1, IX1 + 1, IY0, sh, 6)     -- Schatten unten
    flat(IX1, IY0 - 1, IX1 + 1, IY1 + 1, sh, 6)     -- Schatten rechts
    flat(IX0, IY1 - 1, IX1, IY1, sh, 6)             -- Fuge innen oben
    flat(IX0, IY0, IX0 + 1, IY1, sh, 6)             -- Fuge innen links
    for i = nFrameTex + 1, #cFrameTex do cFrameTex[i]:Hide() end
    -- Efeu an der Ecke unten rechts (über dem Ast, unter der Schrift)
    local lz = tw * (st.leafSize or 2)
    for i, lf in ipairs(st.leaves or {}) do
        local t = cFrameLeaves[i]
        if not t then
            t = castFrame:CreateTexture(nil, "ARTWORK", nil, 7)
            cFrameLeaves[i] = t
        end
        local LV = palLeaves(pal)
        t:SetTexture(TX(LV[(lf.tex - 1) % #LV + 1]))
        t:SetVertexColor(pal.orn[1], pal.orn[2], pal.orn[3], 1)
        t:SetSize(lz * lf.s, lz * lf.s)
        t:ClearAllPoints()
        t:SetPoint("CENTER", UIParent, "BOTTOMLEFT", OX1 + lz * lf.dx, OY0 + lz * lf.dy)
        t:SetRotation(math.rad(lf.rot))
        t:Show()
    end
    for i = #(st.leaves or {}) + 1, #cFrameLeaves do cFrameLeaves[i]:Hide() end
end

local function drawIconBox(tex)
    local g = castGeo
    local used = 0
    if g and g.xR and tex then
        local x0, x1, top, bot = g.xL, g.xR, g.boxT, g.boxB
        local w, h = x1 - x0, top - bot
        if w > 4 and h > 4 then
            local U0, U1, V0, V1 = 0.08, 0.92, 0.08, 0.92
            local xx = x0
            while xx < x1 - 0.01 do
                local xb = math.min(x1, xx + 2)
                local xm = (xx + xb) * 0.5
                local yt = math.min(top, g.topAt(xm))          -- oben: Zweig
                local yb = math.max(bot, g.branchBot(xm) + 1)  -- unten: nie unter dem Ast heraus
                if yt > yb + 0.5 then
                    used = used + 1
                    local t = cIconStrips[used]
                    if not t then
                        t = castFill:CreateTexture(nil, "OVERLAY", nil, 2)
                        cIconStrips[used] = t
                    end
                    t:SetTexture(tex)
                    t:SetVertexColor(1, 1, 1, 1)
                    t:ClearAllPoints()
                    t:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", xx, yb)
                    t:SetSize(xb - xx, yt - yb)
                    t:SetTexCoord(U0 + (xx - x0) / w * (U1 - U0), U0 + (xb - x0) / w * (U1 - U0),
                        V0 + (top - yt) / h * (V1 - V0), V0 + (top - yb) / h * (V1 - V0))
                    t:Show()
                end
                xx = xb
            end
            drawIconFrame(g, x0, x1, top, bot)
        end
    end
    for i = used + 1, #cIconStrips do cIconStrips[i]:Hide() end
    if used == 0 then hideIconFrame() end
end

local function startCast()
    if not castFrame or not castGeo then return end
    local kind, name, tex, startMS, endMS, notInt, trade, spellID = castInfo()
    if not kind then return end
    if ns.isSecret(startMS) or ns.isSecret(endMS) then
        -- Zeiten geheim → Blizzards Leiste zeigen
        cast.state = "idle"
        archHide2("cast", false)
        castFrame:Hide()
        if castFill then castFill:Hide() end
        blizzCastAlpha(1)
        return
    end
    blizzCastAlpha(0)
    cast.kind, cast.startMS, cast.endMS = kind, startMS, endMS
    cast.color = notInt and CAST_COLORS.locked or CAST_COLORS[kind]
    if kind == "cast" and not notInt and palette().cast then cast.color = palette().cast end
    local okT, isTrade = pcall(function() return trade and true or false end)
    isTrade = okT and isTrade
    -- falls das Spiel das Herstellen nicht meldet: offenes Berufefenster + Rezept gleichen Namens
    if not isTrade then
        local open = false
        for _, fn in ipairs({ "TradeSkillFrame", "CraftFrame", "ProfessionsFrame" }) do
            local f = _G[fn]
            if f and f.IsShown and f:IsShown() then open = true end
        end
        if open and craftIcon(name, spellID) then isTrade = true end
    end
    if isTrade then
        cast.color = craftColor(spellID)
        tex = craftIcon(name, spellID) or tex
    end
    -- Ranke nur bei Heilzaubern; Herstellen und alles andere füllt nur
    cast.vine = (not isTrade) and isHeal(name, spellID)
    cast.state = "run"
    archHide2("cast", true)
    cast.fade = 1
    cast.p, cast.withered, cast.hold = 0, nil, 0
    castIcon:SetTexture(tex)
    castName:SetText(name)
    cast.tex = tex
    local g = castGeo
    local pal = palette()
    castRing:SetVertexColor(pal.branch[1], pal.branch[2], pal.branch[3], 1)
    castGlow:SetVertexColor(cast.color[1] * 1.4, cast.color[2] * 1.4, cast.color[3] * 1.4)
    local mx, my = g.mx, g.my
    castRing:SetSize(g.D, g.D)
    castIcon:SetSize(g.D * 0.72, g.D * 0.72)
    castGlow:SetSize(g.D * 1.45, g.D * 1.45)
    castRing:ClearAllPoints(); castRing:SetPoint("CENTER", UIParent, "BOTTOMLEFT", mx, my)
    castIcon:ClearAllPoints(); castIcon:SetPoint("CENTER", UIParent, "BOTTOMLEFT", mx, my)
    castGlow:ClearAllPoints(); castGlow:SetPoint("CENTER", UIParent, "BOTTOMLEFT", mx, my)
    -- statt Medaillon: Symbol füllt die Ecke
    local boxMode = g.xR ~= nil
    castRing:SetShown(not boxMode)
    castIcon:SetShown(not boxMode)
    castGlow:SetShown(not boxMode)
    if boxMode then drawIconBox(tex) end
    -- Schrift in die Lücke zwischen Zweig-Unterkante und Ast-Oberkante – dort
    -- gemessen, wo sie wirklich steht; reicht der Platz nicht, über den Zweig
    local function spot(x0, x1)
        local bt, tb = -math.huge, math.huge
        for k = 1, #g.xs do
            if g.xs[k] >= x0 - 6 and g.xs[k] <= x1 + 6 then
                bt = math.max(bt, g.edge[k])
                tb = math.min(tb, g.twb[k])
            end
        end
        if bt == -math.huge then return (g.yT - g.twTh * 0.5 + g.visBot) * 0.5 end
        if tb - bt >= 15 then return (tb + bt) * 0.5 end
        return g.yT + g.twTh * 0.5 + 9
    end
    local ok, w = pcall(castName.GetStringWidth, castName)
    if not ok or ns.isSecret(w) or type(w) ~= "number" then w = 140 end
    local nx = g.xR and (g.xR + 12) or math.max(g.mx + g.D * 0.5 + 10, (g.xTop or 0) + 8)
    -- mit Ranke hängt oben Laub in den Balken → Schrift ein Stück tiefer
    local dy = cast.vine and -3.5 or 0
    castName:ClearAllPoints()
    castName:SetPoint("LEFT", UIParent, "BOTTOMLEFT", nx, spot(nx, nx + w) + dy)
    castTime:ClearAllPoints()
    castTime:SetPoint("RIGHT", UIParent, "BOTTOMLEFT", g.xa - 6, spot(g.xa - 46, g.xa - 6) + dy)
    drawTrack()
    drawTwig(1)
    drawFill(0)
    drawVine(0)
    castFill:SetAlpha(1)
    castFill:Show()
    castFrame:SetAlpha(1)
    castFrame:Show()
end

-- Ende: alles blendet gemeinsam aus (Balken, Ranke, Zweig, Medaillon, Schrift).
-- Unterbrochen: rot, Ranke verwelkt, kurz stehen lassen, dann ausblenden.
local function endCast(failed)
    if cast.state ~= "run" then return end
    castTime:SetText("")
    if failed then
        cast.color = CAST_COLORS.fail
        cast.withered = true
        castGlow:SetVertexColor(0.9, 0.15, 0.1)
        cast.hold = 0.45
    else
        if cast.kind ~= "channel" then cast.p = 1 end
        cast.hold = 0
    end
    drawFill(cast.p or 0, cast.color)
    if cast.vine then drawVine(cast.p or 0, cast.withered) end
    cast.state = "fade"
    cast.fade, cast.fadeTime = 1, 0.3
end

local function castUpdate(_, elapsed)
    if cast.state == "run" then
        local now = GetTime() * 1000
        local span = math.max(1, cast.endMS - cast.startMS)
        local p = (now - cast.startMS) / span
        if cast.kind == "channel" then p = 1 - p end
        p = math.max(0, math.min(1, p))
        cast.p = p
        drawFill(p, cast.color)
        if cast.vine then drawVine(p, false) end
        castGlow:SetAlpha(0.35 + 0.15 * math.sin(GetTime() * 5))
        castTime:SetText(("%.1f"):format(math.max(0, (cast.endMS - now) / 1000)))
        if now > cast.endMS + 300 then endCast(false) end
    elseif cast.state == "fade" then
        if (cast.hold or 0) > 0 then
            cast.hold = cast.hold - elapsed
            return
        end
        cast.fade = cast.fade - elapsed / cast.fadeTime
        if cast.fade <= 0 then
            cast.state = "idle"
            archHide2("cast", false)
            castFrame:Hide()
            castFill:Hide()
            castFrame:SetAlpha(1)
            castFill:SetAlpha(1)
        else
            castFrame:SetAlpha(cast.fade)
            castFill:SetAlpha(cast.fade)
        end
    end
end

local function buildCastFrame()
    -- Spur und Füllung liegen UNTER dem Ast (Ebene 19), Zweig/Symbol/Schrift darüber
    castFill = CreateFrame("Frame", "MondhainCastFill", UIParent)
    castFill:SetAllPoints(UIParent)
    castFill:SetFrameStrata("BACKGROUND")
    castFill:SetFrameLevel(19)
    castFill:Hide()
    castFrame = CreateFrame("Frame", "MondhainCastBranch", UIParent)
    castFrame:SetAllPoints(UIParent)
    castFrame:SetFrameStrata("BACKGROUND")
    castFrame:SetFrameLevel(22)
    castFrame:Hide()
    castFrame:SetScript("OnUpdate", castUpdate)
    -- Medaillon am Ansatz: weicher Schein in Zauberfarbe, rundes Symbol, Holzring
    -- (liegt im Rahmen UNTER dem Ast: Ast, Zweig und Ranke decken seine Ränder → eingefasst)
    castGlow = castFill:CreateTexture(nil, "ARTWORK", nil, 7)
    castGlow:SetTexture(MEDIA .. "punkt")
    castGlow:SetBlendMode("ADD")
    castGlow:SetSize(64, 64)
    castIcon = castFill:CreateTexture(nil, "OVERLAY", nil, 5)
    castIcon:SetSize(27, 27)
    castIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    local mask = castFill:CreateMaskTexture()
    mask:SetTexture(MEDIA .. "rund_maske", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(castIcon)
    castIcon:AddMaskTexture(mask)
    castRing = castFill:CreateTexture(nil, "OVERLAY", nil, 7)
    castRing:SetTexture(MEDIA .. "zauber_ring")
    castRing:SetSize(40, 40)
    castName = castFrame:CreateFontString(nil, "OVERLAY")
    castName:SetFont(STANDARD_TEXT_FONT, 14, "OUTLINE")
    castName:SetTextColor(1, 1, 1)
    castName:SetShadowOffset(1, -1)
    castTime = castFrame:CreateFontString(nil, "OVERLAY")
    castTime:SetFont(STANDARD_TEXT_FONT, 13, "OUTLINE")
    castTime:SetTextColor(1, 0.95, 0.8)
    castTime:SetShadowOffset(1, -1)
    -- Medaillon verschiebbar (Bearbeitungsmodus): gemerkt wird der Versatz zur
    -- Grundstellung, damit es mit dem Ast mitwandert
    db.castMedal = db.castMedal or {}
    -- Bens Versatz steckt jetzt in der Grundstellung → gespeicherten einmal leeren
    if not db.castMedal.ver then
        db.castMedal.ver = 1
        db.castMedal.dx, db.castMedal.dy, db.castMedal.point = nil, nil, nil
    end
    if true then return end                -- Medaillon entfällt (Symbol-Kasten), Schablone nicht mehr nötig
    castMedal = CreateFrame("Frame", "MondhainCastMedal", UIParent)
    castMedal:SetSize(40, 40)
    castMedal:SetFrameStrata("MEDIUM")
    castMedal:SetPoint("CENTER", UIParent, "BOTTOMLEFT", -200, -200)
    ns.MakeMovable(castMedal, db.castMedal, "Zauber-Medaillon", function()
        local md = db.castMedal
        md.point = nil
        local g = castGeo
        if not g then return end
        local x, y = castMedal:GetCenter()
        if not x then return end
        local k = castMedal:GetEffectiveScale() / UIParent:GetEffectiveScale()
        md.dx = math.floor(x * k - g.defX + 0.5)
        md.dy = math.floor(y * k - g.defY + 0.5)
        ns.Print(("Zauber-Medaillon: %+d / %+d gegenüber der Grundstellung  (|cffffd100/mh medaillon|r = zurück)"):format(md.dx, md.dy))
        mod:Refresh()
    end, true)
end

function mod:ResetMedal()
    if not db then return end
    db.castMedal = db.castMedal or {}
    db.castMedal.dx, db.castMedal.dy, db.castMedal.point = nil, nil, nil
    ns.Print("Zauber-Medaillon: zurück in der Grundstellung an der Gabelung.")
    mod:Refresh()
end

local function update(force)
    if not branchFrame then return end
    local plats, ceils, sig = collect()
    lastPlats, lastCeils = plats, ceils
    if not force and sig == lastSig then return end
    local ok, err = pcall(function()
        local xs, ys, ths = compute(plats, ceils)
        mainPath.xs, mainPath.ys, mainPath.ths = xs, ys, ths
        draw(xs, ys, ths)
        buildSide(xs, ys, ths, plats)
        local mx = ornaments(xs, ys, plats, ceils)
        tendrils(xs, ys, ths, ceils, mx)
        -- Sockelschmuck darf den Rest nie mitreißen (0.40.0: ein Fehler hier ließ
        -- Zauberbalken, EP und Ruf auf altem Stand stehen)
        local okA, errA = pcall(drawArch, xs, ys, ths, plats, ceils)
        if not okA and not mod.warnedArch then
            mod.warnedArch = true
            ns.Print("|cffff5555Sockel-Fehler:|r " .. tostring(errA))
        end
        drawSide()
        drawXP()
        buildRep()
        drawRep()
        buildCastGeo()
        if cast.state == "run" then drawTwig(1); drawIconBox(cast.tex) end
        if ns.QuestTracker and ns.QuestTracker.ApplyAccent then pcall(ns.QuestTracker.ApplyAccent, ns.QuestTracker) end
    end)
    if ok then
        lastSig = sig
    elseif not mod.warned then
        mod.warned = true
        ns.Print("|cffff5555Ast-Fehler:|r " .. tostring(err))
    end
end

function mod:Refresh() update(true) end

-- Oberkante des Zauber-Zweigs samt Rankenlaub (UIParent-Einheiten); darüber
-- setzt die Mitte den Schwungtimer
function mod.CastTop()
    local g = castGeo
    if not g then return end
    local vineHalf = g.twTh * 1.15 / 0.44 * 0.5
    return g.yT + math.max(g.twTh * 0.5, vineHalf * 0.8)
end

-- /mh ast: was der Ast gerade sieht
function mod:Debug()
    if not db or not db.enabled then ns.Print("Ast ist aus.") return end
    local plats, ceils = collect()
    ns.Print(("Ast: Bildschirmbreite %d, Dicke %d"):format(UIParent:GetWidth(), db.thickness))
    for _, p in ipairs(plats) do
        print(("  unten: %s  %d–%d  Oberkante %d"):format(p.name or "?", p.l, p.r, p.top))
    end
    for _, c in ipairs(ceils) do
        print(("  darüber: %s  %d–%d  Unterkante %d"):format(c.name or "?", c.l, c.r, c.bottom))
    end
end

-- Im Kampf tritt der Mond zurück (Schwung/Zauber erscheinen darüber)
local function moonCombat(on)
    if moon then
        if on then moon:SetAlpha(0) else moon:SetAlpha(1) end
    end
    archHide2("combat", on)
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
function mod:OnEnable()
    db = ns.db.branch
    if not db.enabled then return end
    -- Klassen-Voreinstellung: ein angemeldetes Gewand der Klasse, sonst für
    -- Paladine „Licht“ – nur solange keine Farbstimmung selbst gewählt wurde
    local function classDefault()
        if db.palettePicked then return end
        local _, cls = UnitClass("player")
        local want = mod.classPalette and mod.classPalette[cls] or (cls == "PALADIN" and "licht")
        if want and PALETTES[want] and db.paletteAuto ~= want then
            db.palette, db.paletteAuto = want, want
        end
    end
    classDefault()
    C_Timer.After(0.5, classDefault)
    C_Timer.After(0.9, function()
        fillFrame = CreateFrame("Frame", "MondhainTrunk", UIParent)
        fillFrame:SetAllPoints(UIParent)
        fillFrame:SetFrameStrata("BACKGROUND")
        fillFrame:SetFrameLevel(0)
        branchFrame = CreateFrame("Frame", "MondhainBranch", UIParent)
        branchFrame:SetAllPoints(UIParent)
        branchFrame:SetFrameStrata("BACKGROUND")
        branchFrame:SetFrameLevel(20)
        ornFrame = CreateFrame("Frame", "MondhainBranchDecor", UIParent)
        ornFrame:SetAllPoints(UIParent)
        ornFrame:SetFrameStrata("BACKGROUND")
        ornFrame:SetFrameLevel(24)
        update(true)
        C_Timer.NewTicker(0.5, function() update() end)
    end)
    local function xpChanged() if branchFrame then pcall(drawXP) end end
    -- Ruf: Fortschritt neu ranken; wechselt die verfolgte Fraktion an/aus, wächst alles neu
    local lastRep
    local function repChanged()
        if not branchFrame then return end
        local active = repActive()
        if active ~= lastRep then
            lastRep = active
            update(true)
        else
            pcall(drawRep)
        end
    end
    ns.RegisterEvent("UPDATE_FACTION", repChanged)
    ns.RegisterEvent("CHAT_MSG_COMBAT_FACTION_CHANGE", function() C_Timer.After(0.3, repChanged) end)
    if db.repBranch ~= false then
        C_Timer.After(1.5, hideBlizzRep)
    end
    ns.RegisterEvent("PLAYER_XP_UPDATE", xpChanged)
    ns.RegisterEvent("UPDATE_EXHAUSTION", xpChanged)
    ns.RegisterEvent("PLAYER_LEVEL_UP", function() C_Timer.After(0.5, xpChanged) end)
    if db.xpBranch ~= false then C_Timer.After(1.5, hideBlizzXP) end
    -- Zauber-Ast
    if db.castBranch ~= false then
        buildCastFrame()
        local function onStart(_, unit) if unit == "player" then startCast() end end
        local function onStop(_, unit) if unit == "player" then endCast(false) end end
        local function onFail(_, unit) if unit == "player" then endCast(true) end end
        local function onDelay(_, unit)
            if unit ~= "player" or cast.state ~= "run" then return end
            local kind, _, _, startMS, endMS = castInfo()
            if kind and not ns.isSecret(startMS) then cast.startMS, cast.endMS = startMS, endMS end
        end
        ns.RegisterEvent("UNIT_SPELLCAST_START", onStart)
        ns.RegisterEvent("UNIT_SPELLCAST_CHANNEL_START", onStart)
        ns.RegisterEvent("UNIT_SPELLCAST_STOP", onStop)
        ns.RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP", onStop)
        ns.RegisterEvent("UNIT_SPELLCAST_INTERRUPTED", onFail)
        ns.RegisterEvent("UNIT_SPELLCAST_FAILED", function(_, unit, castGUID)
            if unit == "player" and cast.state == "run" and not UnitCastingInfo("player") and not UnitChannelInfo("player") then
                endCast(true)
            end
        end)
        ns.RegisterEvent("UNIT_SPELLCAST_DELAYED", onDelay)
        ns.RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE", onDelay)
        C_Timer.After(1.6, function() blizzCastAlpha(0) end)
    end
    ns.RegisterEvent("PLAYER_REGEN_DISABLED", function() moonCombat(true) end)
    ns.RegisterEvent("PLAYER_REGEN_ENABLED", function() moonCombat(false) end)
    ns.RegisterEvent("UI_SCALE_CHANGED", function() C_Timer.After(0.2, function() update(true) end) end)
    ns.RegisterEvent("DISPLAY_SIZE_CHANGED", function() C_Timer.After(0.2, function() update(true) end) end)
end
