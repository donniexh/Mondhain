-- Mondhain – Addon-Beutel in der Karte
-- Blizzards Addon-Sammelknopf (zeigte eine Zahl) wird zum Beutel-Symbol und
-- sitzt unten links in der Karte – wie die Lupe oben links. Ein Klick zeigt
-- die Liste deiner Addons.
--
-- Die einzelnen runden Kartenknöpfe der Addons werden weggesteckt, denn sie
-- sind im Beutel erreichbar. (Abschaltbar in den Optionen unter „Karte“.)

local _, ns = ...
local mod = ns.NewModule("ButtonBag")
ns.ButtonBag = mod

local SIZE = 22
local ICON = "Interface\\Icons\\INV_Misc_Bag_10"
local db
local hider = CreateFrame("Frame")
hider:Hide()
local stashed = {}

local SKIP = {
    MinimapZoomIn = true, MinimapZoomOut = true, MiniMapWorldMapButton = true,
    MiniMapTracking = true, MiniMapTrackingButton = true, MiniMapTrackingFrame = true,
    MiniMapMailFrame = true, GameTimeFrame = true, TimeManagerClockButton = true,
    MinimapBackdrop = true, QueueStatusMinimapButton = true, MiniMapLFGFrame = true,
    MiniMapBattlefieldFrame = true, ExpansionLandingPageMinimapButton = true,
    MondhainMinimapHolder = true, AddonCompartmentFrame = true,
}

local function isAddonButton(f)
    if not f.GetName then return false end
    local n = f:GetName()
    if not n or SKIP[n] then return false end
    if n:find("^LibDBIcon10_") then return true end
    local l = n:lower()
    local mm = l:find("minimap") or l:find("mmb")
    local btn = l:find("button") or l:find("btn")
    return (mm and btn) and true or false
end

---------------------------------------------------------------------------
-- Beutel (Blizzards Addon-Sammelknopf) unten links in die Karte
---------------------------------------------------------------------------
local function placeBag()
    local f = _G.AddonCompartmentFrame
    local holder = _G.MondhainMinimapHolder
    if not f or not holder then return end

    if not f.mondhainStyled then
        f.mondhainStyled = true
        for _, r in ipairs({ f:GetRegions() }) do
            if r.SetAlpha then r:SetAlpha(0) end -- Zahl und runder Rahmen weg
        end
        if f.Text then f.Text:SetAlpha(0) end
        local ic = f:CreateTexture(nil, "OVERLAY", nil, 7)
        ic:SetAllPoints()
        ic:SetTexture(ICON)
        ic:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        f:HookScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("Addons", 1, 0.82, 0)
            GameTooltip:AddLine("Klick: Liste deiner Addons", 0.8, 0.8, 0.8)
            GameTooltip:Show()
        end)
        f:HookScript("OnLeave", GameTooltip_Hide)
    end

    local busy = false
    local function place()
        if busy then return end
        busy = true
        local layer = _G.MondhainMinimapOverlay or holder
        if f:GetParent() ~= layer then f:SetParent(layer) end
        f:ClearAllPoints()
        f:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", 0, 0) -- bündig in der Ecke
        f:SetSize(SIZE, SIZE)
        f:SetScale(1)
        f:SetAlpha(1)
        f:SetFrameLevel(holder:GetFrameLevel() + 30) -- vor dem Wurzelknoten
        f:Show()
        busy = false
    end
    if not f.mondhainPlaced then
        f.mondhainPlaced = true
        hooksecurefunc(f, "SetPoint", function() if not busy then place() end end)
        hooksecurefunc(f, "SetParent", function() if not busy then place() end end)
    end
    place()
end

---------------------------------------------------------------------------
-- Einzelne Addon-Kartenknöpfe wegstecken
---------------------------------------------------------------------------
local function stash(f)
    if stashed[f] then return end
    stashed[f] = true
    f:SetParent(hider)
    hooksecurefunc(f, "SetParent", function(self, parent)
        if parent ~= hider and db.hideButtons then self:SetParent(hider) end
    end)
end

function mod:Collect()
    if not db.hideButtons or InCombatLockdown() then return end
    local lib = LibStub and LibStub("LibDBIcon-1.0", true)
    if lib and lib.objects then
        for _, f in pairs(lib.objects) do stash(f) end
    end
    for _, parent in ipairs({ Minimap, _G.MinimapBackdrop }) do
        if parent and parent.GetChildren then
            for _, f in ipairs({ parent:GetChildren() }) do
                if isAddonButton(f) then stash(f) end
            end
        end
    end
end

-- Test: /mh knöpfe
function mod:Debug()
    local n = 0
    for f in pairs(stashed) do
        n = n + 1
        print("   weggesteckt: " .. (f:GetName() or "?"))
    end
    ns.Print(("Addon-Beutel: %s · weggesteckte Kartenknöpfe: %d"):format(
        _G.AddonCompartmentFrame and "da" or "|cffff5555nicht gefunden|r", n))
end

---------------------------------------------------------------------------
-- Mikro-Knopf unten rechts in der Karte: klappt Blizzards Mikroleiste aus
-- (Charakter, Zauberbuch, Talente …). Die Taschenleiste wird ausgeblendet.
---------------------------------------------------------------------------
local MICRO_ICON = "Interface\\Icons\\INV_Misc_Gear_01"
local function buildMicro()
    local holder = _G.MondhainMinimapHolder
    local micro = _G.MondhainHolder_micro
    if not holder or not micro or _G.MondhainMicroToggle then return end
    local b = CreateFrame("Button", "MondhainMicroToggle", _G.MondhainMinimapOverlay or holder)
    b:SetSize(SIZE, SIZE)
    b:SetPoint("BOTTOMRIGHT", holder, "BOTTOMRIGHT", 0, 0)
    b:SetFrameLevel(holder:GetFrameLevel() + 30)
    local ic = b:CreateTexture(nil, "ARTWORK")
    ic:SetAllPoints()
    ic:SetTexture(MICRO_ICON)
    ic:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b:SetHighlightTexture("Interface\\Buttons\\WHITE8x8")
    b:GetHighlightTexture():SetVertexColor(1, 1, 1, 0.15)

    -- ausklappende Fläche hinter der Mikroleiste
    local bg = CreateFrame("Frame", nil, micro, "BackdropTemplate")
    bg:SetPoint("TOPLEFT", -8, 8)
    bg:SetPoint("BOTTOMRIGHT", 8, -8)
    bg:SetFrameLevel(math.max(0, micro:GetFrameLevel() - 1))
    bg:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    bg:SetBackdropColor(0.04, 0.05, 0.05, 0.92)
    ns.WoodFrame(bg, 20)
    micro:SetFrameStrata("DIALOG")
    micro:Hide()

    local function open()
        micro:ClearAllPoints()
        micro:SetPoint("BOTTOMRIGHT", b, "TOPRIGHT", 0, 12)
        micro:Show()
    end
    b:SetScript("OnClick", function()
        if InCombatLockdown() then return end
        if micro:IsShown() then micro:Hide() else open() end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Menü", 1, 0.82, 0)
        GameTooltip:AddLine("Klick: Charakter, Zauberbuch, Talente …", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)

    -- Taschenleiste ganz weg (Taschen öffnen mit B oder über die Tafel)
    local bags = _G.MondhainHolder_bags
    if bags then
        bags:Hide()
        bags:HookScript("OnShow", function(self) self:Hide() end)
    end
end

function mod:OnEnable()
    db = ns.db.buttonBag
    C_Timer.After(1.2, buildMicro)
    if not db.enabled then return end
    for _, t in ipairs({ 0.5, 2, 5, 12, 20 }) do
        C_Timer.After(t, function()
            placeBag()
            mod:Collect()
        end)
    end
    local lib = LibStub and LibStub("LibDBIcon-1.0", true)
    if lib and lib.RegisterCallback then
        lib.RegisterCallback(mod, "LibDBIcon_IconCreated", function()
            C_Timer.After(0.5, function() mod:Collect() end)
        end)
    end
end
