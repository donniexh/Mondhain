-- Mondhain – Charakterfenster
-- · Neben jedem Ausrüstungsteil steht seine Verzauberung, zur Fenstermitte hin
--   (linke Spalte rechts daneben, rechte Spalte links daneben, Waffenhand links,
--   Schildhand darunter, Distanz rechts). Grün = dauerhaft, hellblau = auf Zeit
--   (Öl, Wetzstein …).
-- · Das Fenster wird dafür breiter: die rechte Spalte rückt nach außen, Modell,
--   Werte und Waffen rücken zur Mitte nach.
-- · Mondhain-Look: dunkler Grund mit Holzrahmen statt Blizzard-Pergament,
--   Rand jedes Teils in seiner Qualitätsfarbe.
-- Alles nur außerhalb des Kampfes umgebaut; Texte werden jederzeit aktualisiert.

local _, ns = ...
local mod = ns.NewModule("Character")
ns.Character = mod

local WHITE = "Interface\\Buttons\\WHITE8x8"
local WIDEN = 150          -- so viel breiter wird das Fenster
local TEXT_W = 120         -- höchstens so breit wird ein Verzauberungstext
local db
local skinned, texts, edges = false, {}, {}

local LEFT_SLOTS   = { "Head", "Neck", "Shoulder", "Back", "Chest", "Shirt", "Tabard", "Wrist" }
local RIGHT_SLOTS  = { "Hands", "Waist", "Legs", "Feet", "Finger0", "Finger1", "Trinket0", "Trinket1" }
local WEAPON_SLOTS = { "MainHand", "SecondaryHand", "Ranged" }

local function slot(name) return _G["Character" .. name .. "Slot"] end

---------------------------------------------------------------------------
-- Verzauberung lesen
---------------------------------------------------------------------------
local LT = Enum and Enum.TooltipDataLineType
local ENCH_PAT = ENCHANTED_TOOLTIP_LINE and ("^" .. ENCHANTED_TOOLTIP_LINE:gsub("%%s", "(.+)") .. "$")
local TRIGGERS = { ITEM_SPELL_TRIGGER_ONEQUIP, ITEM_SPELL_TRIGGER_ONUSE, ITEM_SPELL_TRIGGER_ONPROC }
local SET_PREFIX = ITEM_SET_BONUS and ITEM_SET_BONUS:match("^(.-)%%s")

local scanTip
local function tooltipLines(slotID)
    local lines = {}
    if C_TooltipInfo and C_TooltipInfo.GetInventoryItem then
        local ok, data = pcall(C_TooltipInfo.GetInventoryItem, "player", slotID)
        if ok and data and data.lines then
            for _, l in ipairs(data.lines) do
                local c = l.leftColor
                lines[#lines + 1] = { text = l.leftText, type = l.type,
                    r = c and c.r, g = c and c.g, b = c and c.b }
            end
            return lines
        end
    end
    -- klassischer Weg: unsichtbaren Tooltip füllen und ablesen
    if not scanTip then
        scanTip = CreateFrame("GameTooltip", "MondhainScanTip", UIParent, "GameTooltipTemplate")
    end
    scanTip:SetOwner(WorldFrame, "ANCHOR_NONE")
    scanTip:ClearLines()
    if not pcall(scanTip.SetInventoryItem, scanTip, "player", slotID) then return lines end
    for i = 1, scanTip:NumLines() do
        local fs = _G["MondhainScanTipTextLeft" .. i]
        if fs then
            local r, g, b = fs:GetTextColor()
            lines[#lines + 1] = { text = fs:GetText(), r = r, g = g, b = b }
        end
    end
    return lines
end

local function isTrigger(t)
    for _, p in ipairs(TRIGGERS) do
        if p and t:sub(1, #p) == p then return true end
    end
    if SET_PREFIX and SET_PREFIX ~= "" and t:sub(1, #SET_PREFIX) == SET_PREFIX then return true end
    return t:find("%(%d+/%d+%)") ~= nil
end

local function enchantOf(slotID)
    local link = GetInventoryItemLink("player", slotID)
    if not link or ns.isSecret(link) then return end
    local enchID = tonumber(link:match("item:%d+:(%d+)") or "")
    local perm, temp
    local lines = tooltipLines(slotID)
    for _, l in ipairs(lines) do
        local t = l.text
        if type(t) == "string" and not ns.isSecret(t) then
            if LT and LT.ItemEnchantmentPermanent and l.type == LT.ItemEnchantmentPermanent then
                perm = perm or t
            elseif LT and LT.ItemEnchantmentTemporary and l.type == LT.ItemEnchantmentTemporary then
                temp = temp or t
            elseif ENCH_PAT then
                local m = t:match(ENCH_PAT)
                if m then perm = perm or m end
            end
        end
    end
    -- klassische Tooltips: Verzauberung ist die erste grüne Zeile, die kein
    -- „Anlegen:“/„Benutzen:“/Set-Text ist
    if not perm and enchID and enchID > 0 then
        for i = 2, #lines do
            local l = lines[i]
            local t = l.text
            if type(t) == "string" and not ns.isSecret(t) and l.g and l.g > 0.9 and (l.r or 1) < 0.3
                and (l.b or 1) < 0.3 and not isTrigger(t) then
                perm = t
                break
            end
        end
        perm = perm or "verzaubert"
    end
    if perm and ENCH_PAT then perm = perm:match(ENCH_PAT) or perm end
    return perm, temp
end

---------------------------------------------------------------------------
-- Anzeige neben den Plätzen
---------------------------------------------------------------------------
local function makeText(btn, side)
    local fs = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    local font = fs:GetFont()
    if font then fs:SetFont(font, 10, "OUTLINE") end
    fs:SetShadowOffset(0, 0)
    fs:SetWordWrap(true)
    if fs.SetMaxLines then fs:SetMaxLines(2) end
    if side == "right" then          -- linke Spalte: Text rechts daneben
        fs:SetPoint("LEFT", btn, "RIGHT", 6, 0)
        fs:SetJustifyH("LEFT")
        fs:SetWidth(TEXT_W)
    elseif side == "left" then       -- rechte Spalte, Waffenhand: links daneben
        fs:SetPoint("RIGHT", btn, "LEFT", -6, 0)
        fs:SetJustifyH("RIGHT")
        fs:SetWidth(TEXT_W)
    else                             -- Schildhand: darunter (darüber stehen die Werte)
        fs:SetPoint("TOP", btn, "BOTTOM", 0, -3)
        fs:SetJustifyH("CENTER")
        fs:SetWidth(110)
    end
    return fs
end

local function qualityEdge(btn)
    local e = CreateFrame("Frame", nil, btn, "BackdropTemplate")
    e:SetPoint("TOPLEFT", -1, 1)
    e:SetPoint("BOTTOMRIGHT", 1, -1)
    e:SetFrameLevel(btn:GetFrameLevel() + 2)
    e:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
    e:Hide()
    return e
end

function mod:Update()
    if not db or not db.enchants then
        for _, fs in pairs(texts) do fs:SetText("") end
    end
    for name, fs in pairs(texts) do
        local btn = slot(name)
        local id = btn and btn:GetID()
        if id and db.enchants then
            local perm, temp = enchantOf(id)
            local out = {}
            if perm then out[#out + 1] = "|cff59ff59" .. perm .. "|r" end
            if temp then out[#out + 1] = "|cff80ccff" .. temp .. "|r" end
            fs:SetText(table.concat(out, "\n"))
        end
    end
    for name, e in pairs(edges) do
        local btn = slot(name)
        local id = btn and btn:GetID()
        local q = id and GetInventoryItemQuality and GetInventoryItemQuality("player", id)
        local c = q and not ns.isSecret(q) and q >= 2 and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
        if c and db.skin then
            e:SetBackdropBorderColor(c.r, c.g, c.b, 0.9)
            e:Show()
        else
            e:Hide()
        end
    end
end

---------------------------------------------------------------------------
-- Breiter und im Mondhain-Look
---------------------------------------------------------------------------
-- Rahmen soll nach dem Verbreitern um dx gegenüber vorher versetzt stehen.
-- Gemessen statt gerechnet: was am rechten Rand hängt, wandert beim
-- Verbreitern ja schon von selbst mit – das wird so automatisch berücksichtigt.
local function shiftBy(frame, before, dx)
    if not frame or frame.mhShifted or not frame.GetNumPoints then return end
    local n = frame:GetNumPoints()
    local now = frame:GetLeft()
    if n == 0 or not before or not now then return end
    local delta = before + dx - now
    local pts = {}
    for i = 1, n do pts[i] = { frame:GetPoint(i) } end
    frame:ClearAllPoints()
    for _, p in ipairs(pts) do
        local rel = p[2]
        local x = p[4] or 0
        if rel == CharacterFrame or rel == PaperDollFrame or rel == nil then x = x + delta end
        frame:SetPoint(p[1], rel, p[3], x, p[5] or 0)
    end
    frame.mhShifted = true
end

-- nur verschieben, wenn der Rahmen am Fenster selbst hängt (nicht an einem
-- anderen Teil, das schon mitwandert)
local function hangsOnWindow(frame)
    if not frame or not frame.GetPoint then return false end
    local _, rel = frame:GetPoint(1)
    return rel == CharacterFrame or rel == PaperDollFrame or rel == nil
end

local function hideArt(frame, bigOnly)
    if not frame or not frame.GetRegions then return end
    for _, r in ipairs({ frame:GetRegions() }) do
        if r.GetObjectType and r:GetObjectType() == "Texture" then
            local w, h = r:GetWidth() or 0, r:GetHeight() or 0
            if not bigOnly or (w * h > 15000) then r:SetAlpha(0) end
        end
    end
    for _, k in ipairs({ "NineSlice", "Bg", "Background", "TopTileStreaks", "PortraitContainer" }) do
        if frame[k] and frame[k].SetAlpha then frame[k]:SetAlpha(0) end
    end
end

local function skin()
    if skinned or InCombatLockdown() then return end
    local cf, head, hands, main = CharacterFrame, slot("Head"), slot("Hands"), slot("MainHand")
    if not (cf and head and hands and main) then return end
    skinned = true

    -- was wohin soll: rechte Spalte nach außen, Waffen und Mitte zur neuen Mitte;
    -- die linke Spalte bleibt, wo sie ist
    local moves = {}
    for _, n in ipairs(RIGHT_SLOTS) do
        local b = slot(n)
        if hangsOnWindow(b) then moves[#moves + 1] = { b, WIDEN } end
    end
    for _, n in ipairs(WEAPON_SLOTS) do
        local b = slot(n)
        if hangsOnWindow(b) then moves[#moves + 1] = { b, WIDEN / 2 } end
    end
    for _, n in ipairs({ "CharacterModelFrame", "CharacterModelScene", "CharacterAttributesFrame",
        "CharacterResistanceFrame", "CharacterNameFrame", "CharacterNameText", "CharacterLevelText",
        "CharacterTitleText", "CharacterGuildText" }) do
        local f = _G[n]
        if hangsOnWindow(f) then moves[#moves + 1] = { f, WIDEN / 2 } end
    end
    for _, m in ipairs(moves) do m[3] = m[1]:GetLeft() end
    -- breiter: das Fenster selbst (Mausfläche, Platz neben anderen Fenstern)
    pcall(cf.SetWidth, cf, cf:GetWidth() + WIDEN)
    for _, m in ipairs(moves) do shiftBy(m[1], m[3], m[2]) end

    if not db.skin then return end
    -- Blizzard-Pergament weg (auch auf den anderen Reitern)
    hideArt(cf)
    hideArt(PaperDollFrame)
    for _, n in ipairs({ "ReputationFrame", "SkillFrame", "HonorFrame", "PetPaperDollFrame", "TokenFrame",
        "PaperDollItemsFrame" }) do
        hideArt(_G[n], true)
    end
    if CharacterFramePortrait then CharacterFramePortrait:SetAlpha(0) end

    -- dunkler Grund mit Holzrahmen, von den Ausrüstungsplätzen aus bemessen
    local bg = CreateFrame("Frame", "MondhainCharacterBg", cf)
    bg:SetFrameLevel(math.max(0, cf:GetFrameLevel()))
    bg:SetPoint("TOPLEFT", head, "TOPLEFT", -14, 62)
    bg:SetPoint("RIGHT", hands, "RIGHT", 14, 0)
    bg:SetPoint("BOTTOM", main, "BOTTOM", 0, -34) -- Platz für den Text unter der Schildhand
    local t = bg:CreateTexture(nil, "BACKGROUND", nil, -8)
    t:SetAllPoints()
    t:SetColorTexture(0.04, 0.05, 0.05, 0.95)
    local glow = bg:CreateTexture(nil, "BACKGROUND", nil, -7)
    glow:SetPoint("TOPLEFT", 4, -4)
    glow:SetPoint("TOPRIGHT", -4, -4)
    glow:SetHeight(60)
    glow:SetColorTexture(0.30, 0.55, 0.40, 0.08)
    ns.WoodFrame(bg, 20)
    -- Fläche fängt die Maus (kein Klick in die Welt) und zieht das Fenster mit
    bg:EnableMouse(true)
    bg:RegisterForDrag("LeftButton")
    bg:SetScript("OnDragStart", function() if ns.Windows then ns.Windows:BeginDrag(cf) end end)
    bg:SetScript("OnDragStop", function() if ns.Windows then ns.Windows:EndDrag(cf, "CharacterFrame") end end)
    -- Schließen-Knopf in die neue Ecke
    if CharacterFrameCloseButton then
        CharacterFrameCloseButton:ClearAllPoints()
        CharacterFrameCloseButton:SetPoint("TOPRIGHT", bg, "TOPRIGHT", 4, 4)
        CharacterFrameCloseButton:SetFrameLevel(bg:GetFrameLevel() + 10)
    end
end

local function build()
    for _, n in ipairs(LEFT_SLOTS) do
        local b = slot(n)
        if b then texts[n] = makeText(b, "right"); edges[n] = qualityEdge(b) end
    end
    for _, n in ipairs(RIGHT_SLOTS) do
        local b = slot(n)
        if b then texts[n] = makeText(b, "left"); edges[n] = qualityEdge(b) end
    end
    local side = { MainHand = "left", SecondaryHand = "top", Ranged = "right" }
    for _, n in ipairs(WEAPON_SLOTS) do
        local b = slot(n)
        if b then texts[n] = makeText(b, side[n]); edges[n] = qualityEdge(b) end
    end
end

function mod:OnEnable()
    ns.db.character = ns.db.character or {}
    db = ns.db.character
    if db.enabled == false or not CharacterFrame then return end
    build()
    local function onShow()
        if not skinned then
            if InCombatLockdown() then
                ns.RegisterEvent("PLAYER_REGEN_ENABLED", function()
                    if not skinned and CharacterFrame:IsShown() then skin() end
                end)
            else
                skin()
            end
        end
        mod:Update()
    end
    CharacterFrame:HookScript("OnShow", onShow)
    if PaperDollFrame then PaperDollFrame:HookScript("OnShow", function() mod:Update() end) end
    local function refresh()
        if CharacterFrame:IsShown() then mod:Update() end
    end
    ns.RegisterEvent("PLAYER_EQUIPMENT_CHANGED", refresh)
    ns.RegisterEvent("UNIT_INVENTORY_CHANGED", function(_, unit) if unit == "player" then refresh() end end)
    ns.RegisterEvent("GET_ITEM_INFO_RECEIVED", refresh)
end
