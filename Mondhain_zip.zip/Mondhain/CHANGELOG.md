# Mondhain – Änderungsprotokoll

## Offen (To-Do)
- Einrichtungs-Assistent wie bei ElvUI (Ben 26.11. 05:29): Schritt für Schritt „Willst du das? Ja/Nein“ für die Kernfunktionen – Konzept an Ben, Bau nach seiner Freigabe
- FINALE (Ben 26.11. 05:11): Menü neu nach dem Gerüst von ElvUI (Kategorien links als Baum, Einstellungen rechts, Punkte schnell auffindbar); Ast-/Sockel-Einstellungen klassenneutral verallgemeinern (kein „Teldrassil-Ast“, „Mondsichel“, „Liane“ in den Texten, wenn ein Gewand alles anders macht – Begriffe aus dem Gewand oder neutral: Unterbau, Mittelstück, EP-Anzeige, Ruf-Anzeige)
- Bearbeitungsmodus: Breite einstellbar machen (Regler bzw. eigene Geste neben dem Skalieren per Mausrad), zuerst für Schwungtimer, dann für alle Leisten/Rahmen, bei denen Breite Sinn ergibt
- Greifzeit: eigenes Wappen-Set für die Fraktionen (optional, braucht Bilder)
- Symbolrahmen-Gewänder für weitere Klassen (Krieger: Stahl/Nieten, Schurke: Leder/Naht …) und Wahl im Menü
- Paladin: Größe des Mittelstücks im Spiel prüfen (Hand 2,6 / Hammer 2,8 / Libram 2,5 × Dicke)
- Paladin: Schwert und Rosette im Spiel prüfen; gefällt es nicht → Lichtrinne im Balken (Bens Ersatzwahl)
- Paladin: Rosette als Gemini-Bild (jetzt Platzhalter); Schwertgröße im Spiel prüfen
- Bauweise für weitere Klassen (jede Klasse eigene Baseline, Ben 25.11.)
- PvP-Wappen: Lage/Größe an der Porträt-Ecke im Spiel prüfen (Allianz und Horde)
- Elite-/Rare-Drache: prüfen, ob Blizzards Drachengrafik in Forever da ist – sonst eigener Drache
- Schadensmesser: Ursache klären (Ausgabe von /mh meter bzw. den /dump-Zeilen, Test ohne Mondhain)
- Greifzeit: Flugzeiten-Startwerte aus InFlight (MIT-Lizenz), sobald Ben die Zip schickt; Abgleich für Forever-Vielflieger-Tempo über eigene Flüge

## 0.40.8
- Neu: Stufenaufstieg-Animation – Lichtblitz in der Akzentfarbe, neue Stufe groß in Morpheus oben, Zeichen der Spezialisierung wächst halbtransparent aus der Mitte (Druide: vorerst Talentbaum-Symbol, eigene Silhouetten folgen; Paladin: Wappen). Blizzards Banner aus. Optionen → Kampf, Test: /mh levelup
- Kampfanzeige richtet sich nach dem Gewand: Paladin bekommt Goldleisten mit Wappen an den Enden, Gold rein, Silberblau raus
- Mondhain_Paladin 0.2.3: Kampfanzeige und Stufenaufstieg im Paladin-Stil
- Neu: Stufenaufstieg – Blitz über den Bildschirm, neue Stufe in Morpheus oben, halbtransparentes Zeichen der Spezialisierung wächst aus der Mitte; Blizzards Banner aus; Test /mh levelup (Druiden-Silhouetten folgen, bis dahin runde Spielsymbole)
- Kampfanzeige folgt dem Gewand (Farbstimmung combat = {…})
- Mondhain_Paladin 0.2.3: Kampfanzeige mit Goldleisten und Wappen, Gold rein / Silberblau raus; Stufenaufstieg mit Libram / Hand / Hammer je Talentbaum
- Questtracker: „(+2)“ hinter dem Questtitel, wenn Gruppenmitglieder die Quest auch haben; Questlog-Liste erkennt auch die Rollliste; /mh questgruppe zeigt, woher die Infos kommen
- Questtracker-Kopf: Suche rückt nach links, damit die Haken „annehmen/abgeben“ den Zähler nicht überdecken; ist es zu eng, weicht der Zähler
- Mondhain_Multibox 0.2.5: Taste 4 bufft schon bei unter 30 Sek. Rest nach

## 0.40.7
- Mondhain_Multibox 0.2.5: Rechtsklick auf einen der vier Knöpfe öffnet die Einstellungen (Zauberfolge, Reittier, Heilzauber, Segen); Reittier aus der Reittiersammlung wird sauber erkannt (Reittier-ID, Ruf über die Sammlung statt über den Namen), Symbol im Slot, Bestätigung im Chat
- Abklingzeitmanager: auch „Stärkungen“, „Wichtig“ und „Nützlich“ bekommen eine Mondhain-Schablone und lassen sich in /mh bearbeiten verschieben (waren bei Steve über den Aktionsleisten nicht greifbar)

## 0.40.6
- Quests melden: Annahme nur mit Titel („Quest angenommen: [Die obere Wildnis]“), Zwischenstände einzeln abschaltbar (Standard aus), „Quest fertig“ erst wenn alle Ziele erfüllt – drei Haken auf der Seite Quests
- Mondhain_Multibox 0.2.4: Länge der Zauberfolge einstellbar (1–10 Zauber, –/+ im /mbx-Fenster)
- Mondhain_Multibox 0.2.3: Taste 4 „Buffs nachlegen“ – pro Gruppenmitglied Buff per Auswahlliste festlegen; ein Druck bufft den, dem er fehlt oder unter 1 Min. hat (Großer Segen zählt mit)
- Mondhain_Multibox 0.2.2: Taste 2 wechselt nach Lage – folgst du schon und sitzt nicht auf, ruft sie das Reittier (eigener Slot im /mbx-Fenster, Reittier oder Zauber hineinziehen)
- Mondhain_Multibox 0.2.1: Leiste jederzeit am Rahmen verschiebbar (nicht nur im Bearbeiten-Modus; im Kampf gesperrt)
- Ast/Sockel über den Leisten (Ben 06:33: Balken schnitt bei Steve durch die oberste Tastenreihe): die Krone richtet sich jetzt auch nach den sichtbaren Tasten der Leisten, nicht nur nach der Platte darunter

## 0.40.5
- Schmales Bild, Teil 2 (Ben 06:28 nach Steves Grundaufstellung): die linke Tafel (Haltbarkeit, Gilde, Gold, Taschen) verschwand hinter dem Chat – sie sitzt jetzt rechts an der Karte, die Vorratsleiste rechts an der Tafel
- Bauweise Stein: mehr Luft zwischen Leisten und Balken (crownGap, 0,45 × Dicke); schmales Bild: Leisten in der Grundaufstellung bündig am unteren Rand
- Zauberbalken Bauweise Stein: rechts gerade abgeschlossen (kurzer senkrechter Pfosten) statt geschwungenem Abstieg (Ben 06:29)
- Questtracker: zwei Spalten schon ab ca. 400 Breite (vorher erst ab 620) – auch bei 16:9 zwei Quests nebeneinander

## 0.40.4
- Grundaufstellung passt sich der Bildbreite an (Ben 06:20: gebaut für Bens Curved-Breitbild, Steve hat 16:9): unter 2200 UI-Breite schmalerer Chat und Questtracker, Leisten 100 % statt 125 %, Spieler/Ziel/Begleiter und Gruppe über Ast und Zauberbalken statt neben den Leisten. Anwenden: /mh grundaufstellung
- Questtracker: ist er schmal, weicht die Questzahl den Haken „annehmen/abgeben“

## 0.40.3
- Akzentfarbe aus dem Gewand (pal.accent): Questzone, Questliste-Markierungen und Questlog-Knopf folgen der Farbstimmung; Paladin in Gold statt Druiden-Orange (Ben 05:58)
- Questtracker: rechts neben der Suche zwei Haken „annehmen“ und „abgeben“ für die Quest-Automatik (Ben 05:59), gleiche Schalter wie in Optionen → Quests
- Questie-Anbindung (Ben 06:02, aus Bens Questie 12.15.0 gelesen): hat man Questie, liest Mondhain dessen Gruppen-Questlogs (QuestieComms:GetQuest) – „Auch in deiner Gruppe“ zeigt dann auch Mitspieler nur mit Questie, mit Fortschritt („Steve (4/6 · 1/1)“ / „fertig“); ohne Questie oder bei anderer Questie-Version still aus
- Mondhain_Paladin 0.2.2: accent Gold

## 0.40.2
- Bearbeiten-Modus: Tafeln (links/rechts), Questtracker und Chat lassen sich an jedem Rand einzeln ziehen – gelbe Leisten links, rechts, oben, unten; die gegenüberliegende Kante bleibt stehen (Ben 05:26). Gezogene Tafelgröße hat Vorrang vor der automatischen Höhe; „Tafeln zurück an ihren Platz“ setzt auch die Größe zurück
- Bauweise Stein, Schrein (Ben 05:28): erst die beiden Banner-Säulen, dazwischen alles Weitere – Zinnen genau zwischen den Säulen verteilt (außen bündig, gleiche Lücken, keine fehlt mehr), Mittelstück in der Mitte zwischen den Säulen; Zinnen können breiter werden, ohne höher zu werden (merlonH)
- Zauberbalken in der Bauweise Stein liegt zwischen den beiden Banner-Säulen statt ab der Kante rechts der Karte – damit sitzt er auch tiefer (auf Höhe des flachen Balkens)
- Schwert kann auf dem Balken aufliegen statt einzusinken (swordSink)
- Schwert: Panzerhand am Heft möglich (glass.swordHand) – Faust über dem Griff, Unterarm bis zur Balkenmitte, darunter abgeschnitten (verschwindet hinter dem Balken)
- Mondhain_Paladin 0.2.1: Zinnen breiter (1,5 × Dicke, Höhe wie bisher), Bens Gemini-Panzerhand hält das Heft (hand.tga, Griffstummel entfernt, gespiegelt – Daumen rechts); Schwert und Hand stecken hinter der Mauer (Ben 05:40): Schwert sinkt 22 % ein, über dem Balken sieht man die Faust, Handgelenk und Unterarm verschwinden dahinter

## 0.40.1
- Zauberbalken beim Paladin (Ben 05:19: Schrift auf dem Balken, dunkler Streifen darunter, Stummel links): gleiche Ursache wie der Ast-Fehler – der Zauber-Zweig wurde danach nicht neu berechnet und stand noch auf dem alten, tieferen Ast. Mit der Reparatur passt er wieder; zusätzlich kann ein Fehler im Sockelschmuck Zauberbalken, EP und Ruf nicht mehr mitreißen
- Gestaltleiste / Paladin-Auren (Ben 05:16: saß bei Steve mitten in den Leisten; beim Druiden „verschwunden“ = lag dort hinter dem Leistengrund): sie stand auf einem eigenen gespeicherten Platz statt in der Tafel (Merker „in der Tafel“ aus, z. B. nach Verschieben im Bearbeiten-Modus) oder die Tafel fehlte. Jetzt prüft sie alle 2 s, solange der Merker an ist, und setzt sich unten mittig in die rechte Tafel; fehlt die Tafel, mittig über die Leisten. Neu: Knopf „Zurück an ihren Platz“ (Optionen → Gestalten) und /mh gestalten tafel; /mh gestalten zeigt jetzt auch den Platz
- Mondhain_Multibox 0.2.0 (Ben 05:13): Leiste größer (Knöpfe 46) mit Rahmen; links ein Haken „aktiv“ – drin: Tasten 1–3 gehen an Multibox, raus: wieder an die Leisten; Knöpfe bleiben immer sichtbar (aus = blass, ohne Tastenziffer), Rahmen leuchtet, wenn aktiv; Rechtsklick auf Haken oder Leiste → Einstellungen (ersetzt den „MB“-Schalter)
- Behoben (Ben 26.11. 05:08, Steves Paladin): „Ast-Fehler Branch.lua:82 … global 'db' (a nil value)“ – die Wahl des Mittelstücks griff auf die Einstellungen zu, bevor sie geladen waren; dadurch brach der Sockelschmuck ab (keine Säulen, Zinnen, Banner, kein Schwert – stattdessen die alte goldene Liane). Probe ohne Spiel jetzt streng: unbekannte globale Namen fallen auf

## 0.40.0
- Eigene Optionsseite „Quests“ (Ben 26.11.: Automatik nicht gefunden – stand ganz unten auf „Aufstellung“ und rutschte aus dem Fenster): automatisch annehmen, automatisch abgeben, Fortschritt melden mit Hauptschalter und Zielen „an mich“ (nur eigener Chat), „an die Gruppe“, „an den Schlachtzug“ (Gilde bewusst nicht), dazu beste Belohnung und Gruppe im Questlog. Meldungen jetzt auch im Schlachtzug möglich
- Gestaltleiste (Ben 26.11. „verschwunden“): Ebene fest über Tafel und Questliste, Zahl der Gestalten abgesichert (geheim/fehlend → 0), Nachfassen 2 s und 6 s nach dem Einloggen und alle 3 s außerhalb des Kampfes, ohne Gestalten ausgeblendet. Ursache im Code nicht eindeutig – falls sie wieder fehlt: /mh gestalten
- MondhainAPI.SkinButton, MakeMovable, Print für Zusatz-Addons
- Neues privates Zusatz-Addon Mondhain_Multibox 0.1.0 (nur Ben/Steve): Modus an → Taste 1 Assist auf den Anführer + Zauberfolge (/castsequence aus bis zu 5 hineingezogenen Zaubern, Neustart wählbar), Taste 2 Folgen, Taste 3 Heilzauber auf den Anführer; Anführer per Name oder leer = party1; Knöpfe auch auf dem Bildschirm (verschiebbar), kleiner MB-Schalter, /mbx, /mbx an|aus; nur außerhalb des Kampfes umschaltbar
- Bauweise (Ben 16:58 „Ecken und Kanten … jede Klasse so individuell wie möglich die Baseline“, Wahl „A + B + C komplett“): ein Gewand kann statt des gewachsenen Asts einen gemauerten Sockel bestellen (def.arch). Verlauf: flach über den Elementen, dazwischen gerade 45°-Schrägen, rechts der Karte steiler (Zaubersymbol bleibt frei), schmale V-Kerben werden zugemauert, keine Wellen, überall gleich dick
- Bauweise Stein, Schmuck: Säulen in jeder Lücke zwischen den Elementen (Marmorschaft bis zum Boden, Goldkapitell unter dem Balken, Fuß unten; an Schrägen ohne Spalt), Goldleiste obenauf, Zinnen auf dem flachen Stück über den Leisten, Banner an den beiden Säulen neben den Leisten (Schrein), Lichtscheibe geht hinter den Zinnen auf (atmet langsam, im Kampf aus). Keine Blätter, Ranken, Irrlichter
- Bauweise Stein: EP- und Ruf-Ast als gerade Balken (45° hoch, dann flach), Zauber-Zweig steigt gerade an und fällt gerade ab; Zinnen und Scheibe liegen unter dem Zauberbalken
- MondhainAPI.version = 40 (Gewänder können prüfen, ob die Bauweise da ist)
- Bauweise Stein gerader (Ben 17:06 „nicht so eingeknickt“): nahe Höhen (unter 0,9 × Dicke) bekommen eine gemeinsame Ebene, Senken bis 12 × Dicke werden zugemauert – auf Bens Bildschirm bleiben zwei Stufen (Chat oben → lange gerade Mitte über Tafel, Karte, Leisten → Questlog oben)
- Bauweise Stein: Maße aus den Bildern des Gewands (Kapitell unten so breit wie der Schaft, Seitenverhältnisse von Zinne und Banner); Mittelstück als Wappen-Bild möglich (arch.crest, steht mittig auf dem Balken, Zinnen lassen Platz, beim Wirken und im Kampf aus)
- Mittelstück wählbar: Gewänder können mehrere Mittelstücke mitbringen (arch.crests); Menü „Ast“ hat dafür den Knopf „Mittelstück: …“, die Zinnen ordnen sich vom Mittelstück aus nach außen; ragt ein schwebender Rahmen darüber, wird es kleiner. Häkchen heißt jetzt „Mondsichel / Mittelstück auf der Krone“
- Buntglas statt EP- und Ruf-Ast (Ben 19:02, für Gewänder mit arch.glass): über dem Questlog stehen zehn Lanzettfenster auf dem Balken, je Fenster ein Zehntel der Stufe; das laufende füllt sich von unten mit Licht, ausgeruhte EP zeichnen blau vor, dunkle Fenster sind entsättigt. Links davon eine Rosette für den Ruf: zwölf Felder leuchten im Uhrzeigersinn auf, Schein in der Farbe der Rufstufe; ohne verfolgte Fraktion keine Rosette. Tooltips wie bisher (Maus auf Fenster/Rosette)
- Großschwert statt Fenster (Ben 19:09 „der kann sich füllen“, arch.glass.sword): liegt auf dem Balken über dem Questlog, die Klinge füllt sich vom Heft zur Spitze mit Licht, ein Lichtfunke wandert mit, ausgeruhte EP blau vorgezeichnet, der ungefüllte Rest ist matter Stahl. Die Ruf-Rosette steht links davon. Ohne sword bleiben die zehn Fenster
- Mondhain_Paladin 0.2.0: Bens Gemini-Schwert (26.11.) für die EP – gespiegelt (Heft links), Grün, Blitz und Splitter am Knauf entfernt; die zerbrochene Klinge leuchtet Splitter für Splitter auf (Klinge ab 40 % des Bildes; Ben 04:23 „größer, bis zum Bildschirmrand wie die Ranken“: 4,5 × Dicke hoch (Ben 04:35 „noch mehr skalieren“), Spitze am rechten Rand, Heft in echten Maßen, Klinge bis 1,7-fach gestreckt, Rosette links am Heft)
- Mondhain_Paladin 0.2.0: Buntglas-Bilder (glas_fenster, glas_rahmen, glas_rose, glas_rose_sektor, glas_rose_rahmen) als Platzhalter
- Mondhain_Paladin 0.2.0: Mittelstücke Silberne Hand (Standard), Kriegshammer, Libram (Bens Gemini-Bilder, Grün und Lichtschein entfernt)
- Mondhain_Paladin 0.2.0: Bauweise Stein mit Bens Gemini-Bildern (Säule nahtlos, Goldkapitell mit Flügeln und Saphir, Marmorzinne mit Goldabdeckung, blaues Banner mit Goldborte; Grün entfernt) und Goldleiste; Lichtscheibe gestrichen (Ben: „nimm was wirklich WoW-Paladin“), Mittelstück folgt

## 0.39.3
- PvP-Wappen größer (Ben 13:40 „so groß wie die Stufe“): 40 hoch an Spieler/Ziel, 32 am Fokus, 26 an kleinen Rahmen
- Kampf-Schwerter am Spielerrahmen (Ben 13:40): Blizzards Bild (UI-StateIcon) fehlt in Forever → eigenes Bild kampf_schwerter.tga (Silberklingen, Goldparier, dunkle Kontur), 28 px an der unteren Porträt-Ecke, mit rotem Schein, pulsiert im Kampf
- Ereignisse: ein fehlerhafter Empfänger schneidet die anderen nicht mehr ab (jeder läuft für sich, Fehler werden gemeldet) – Kampfbeginn/-ende erreichen jetzt sicher alle Module
- Gegenstandsleiste (Ben 13:49): gemerkte Gegenstände, die nicht im Inventar sind, verschwinden aus der Leiste (im Kampf unsichtbar, danach neu geordnet) und tauchen wieder auf, sobald sie im Inventar sind; im Bearbeiten-Modus bleiben alle sichtbar
- Neues Modul Questhilfe (Ben 13:49): Stufe der Quest auf der Annahmetafel und im Questlog vor dem Titel („[24] …“ in Schwierigkeitsfarbe; Quelle: Questdaten, sonst Gesprächsliste/Begrüßung, sonst Questlog). Bei der Belohnungswahl bekommt die Belohnung mit dem höchsten Verkaufswert (Preis × Menge) eine Goldmünze; wartet kurz, falls Gegenstandsdaten noch laden
- Händlerbesuch im Chat (Ben 13:49): beim Schließen „Händler: verkauft für … · repariert für … · repariert über die Gildenbank für … · eingekauft für …“ (nur was vorkam; Geld, das kurz nach dem Schließen ankommt, zählt noch mit)
- Questhilfe Gruppe (Ben 15:52, angelehnt an Questie, eigene Umsetzung): im Questlog steht hinter dem Titel „(+2)“, in den Details „Auch in deiner Gruppe: Steve, …“ (Blizzard-Abfrage IsUnitOnQuest; zusätzlich tauschen Mondhain-Spieler ihre Questlisten per Addon-Nachricht „MondhainQ“). Eigener Fortschritt geht in den Gruppenchat: „[Quest] Wolf getötet: 3/8“, beim Abschluss „[Quest] fertig – kann abgegeben werden“ (gesammelt, kein Spam beim Einloggen, nicht im Schlachtzug). Drei Schalter unter Anordnung
- Bannen in den Gruppenrahmen (Ben 16:16 „wie Retail/Forever, nur bannbare“): nur Schwächungen, die DU entfernen kannst (Filter HARMFUL|RAID, außerhalb des Kampfs zusätzlich gegen die eigenen Bann-Zauber geprüft). Farbiger Rand in Blizzards Typfarbe (Magie blau, Fluch lila, Krankheit braun, Gift grün), Farbschleier von unten über das Leben, unten links das Symbol der Schwächung mit farbigem Rand und Blizzards Typ-Zeichen. Im Kampf (Typ geheim) Farbe über Blizzards Farbkurve, sonst orange
- Quests automatisch annehmen und abgeben (Ben 16:19), zwei getrennte Schalter unter Anordnung (Standard an): Gesprächsfenster/Begrüßung wählen fertige Quests zum Abgeben und neue Quests zum Annehmen (graue/triviale nicht), Annahmetafel nimmt an (auch Begleitquests von Mitspielern), Fortschritt schließt ab, Belohnung wird nur genommen, wenn es keine Auswahl gibt. Shift gedrückt = diesmal nichts automatisch
- Paladin (Ben 16:22, für Steve): Farbstimmung „Licht (Paladin)“ als Übergang bis zum echten Gewand – vergoldetes Holz, Kalkstein-Stamm, goldene Liane statt grün, Goldlaub, Astknoten und Zwickelholz passend, Zauberleiste in dunklem Lichtgold. Neue Bilder *_licht.tga (aus den vorhandenen umgefärbt). Paladine starten einmalig damit, solange keine Farbstimmung selbst gewählt wurde. Wächter für Paladine: irgendein Segen (auch Großer Segen), irgendeine Aura, Zorn der Gerechtigkeit (Standard aus)
- Gewänder als Zusatz-Addon: Mondhain bietet MondhainAPI.RegisterPalette(key, def) (Bilder als volle Pfade, def.class = Klassen-Voreinstellung); alle Bildstellen des Asts gehen über TX() (Ast, Stamm, Zwickel, Knoten rund/gedreht, Blüte, Liane, Ruf-Liane, Laub, Symbolrahmen). Klassen-Voreinstellung greift nach dem Laden aller Addons, solange keine Farbstimmung selbst gewählt wurde
- Neues Zusatz-Addon Mondhain_Paladin 0.1.0 aus Bens Gemini-Bildern: Marmorbalken mit Goldleisten und Saphiren (nahtlos aus der Vorlage geschnitten), Kathedralenstein (dunkler gestellt), goldenes Lichtband (Schachbrett-Hintergrund entfernt, nahtlos), silberblaues Band für Ruf, Goldlaub, EP-Meilenstein Goldbuckel mit Saphir → Lichtstrahl beim Erreichen, Zauberleiste in dunklem Lichtgold

## 0.39.2
- Greifzeit 1.17.0 (gleiches Paket): auf der Flugkarte steht im Tooltip eines Ziels die Flugzeit von hier dorthin („Flugzeit 2:35 · aus 3 Flügen, schnellster 2:31“), sobald die Strecke irgendein Charakter schon geflogen ist; sonst „noch nicht geflogen“. Klappt mit alter (TaxiButton) und neuer Flugkarte (Pins)
- PvP neu (Ben 10:29 „zurück auf Anfang“): Stufen-Plakette links bleibt immer schlicht (Ring + Zahl). Das PvP-Wappen ist ein eigenes Zeichen oben in der Porträt-Ecke – Ziel und Fokus rechts, Spieler links –, über einem Elite-/Rare-Drachen. Allianz/Horde: Schilde aus Bens Vorlage freigestellt (schild_allianz/schild_horde.tga, Saphir bzw. Rubin statt Zahl), Höhe 30 (Fokus 24); „frei für alle“ mit Blizzards Zeichen
- Arbeitsweise (Ben 10:13): Patch nur nach Rückfrage bauen
- Tooltip-IDs nur noch für Zauber (inkl. Buffs/Debuffs) und Gegenstände – keine NPC-, Quest-, Währungs-, Erfolgs-, Reittier- oder Haustier-IDs mehr (Ben 13:24)
- Blizzards Schadensmesser (Ben 11:01 „zeigt nichts mehr an“): Mondhain fasst ihn nirgends gezielt an. Neu: beim Einloggen leise prüfen und richten (nicht unter Mondhains Hintergrund-Ebene, nicht unsichtbar, nicht außerhalb des Bildes); /mh meter zeigt Datenverfügbarkeit samt Grund, Einstellung und Zustand jedes Messer-Fensters und richtet es
- Auren über dem Ziel wieder da (Ben 10:37 „aktuell weg“): ein einziger Fehler beim Umhängen von Blizzards Symbolen sperrte die Anordnung bis zum Neuladen – jetzt abgesichert. Zeigt Blizzards Zielfenster gerade keine Symbole, zeichnet Mondhain sie selbst. /mh ziel zeigt zusätzlich eigenen Weg, Filter und letzten Fehler
- EP-Ast (Ben 10:37): statt Knospen sitzen bei 25/50/75 % Astknoten im Ast (neue Bilder ast_knoten / ast_knoten_mahagoni, in Wuchsrichtung gedreht, Farbe der Farbstimmung); erreicht die Liane einen Knoten, blüht dort die Mondblüte auf

## 0.39.1
- Zauberleiste „Waldnacht“ (Ben 09:56, Vorschlag 2): dunkles Grün mit senkrechtem Verlauf (oben 0,17/0,38/0,21 → unten 0,06/0,15/0,09); Kanal (dunkles Petrol), gesperrt (Grau) und Fehler (dunkles Rot) in derselben Tiefe; Berufsfarben bekommen unten automatisch 35 %
- Tiefe und Glanz (Ben 09:59, Vorschlag B): Schatten unter Zweig/Ranke (16 px, 62 %) und am Ast (12 px, 50 %), Lackschimmer im oberen Drittel (20 %) mit feiner Lichtkante – nur über der Füllung, wandert mit
- Arbeitsweise (Ben 09:59): Änderungen sammeln und in größeren Paketen ausliefern
- IDs im Tooltip (Ben 10:03): Zauber, Stärkungen/Schwächungen, Gegenstände, Spielzeuge, Reittiere, Währungen, Erfolge, Quests, Haustiere und NPC-ID (aus der GUID); hellblau unten im Tooltip, nicht doppelt. Schalter unter Anordnung. Geheime Werte (Auren im Kampf) werden still übersprungen. Die alte Item-ID der Vorratsleiste tritt zurück, solange das an ist
- PvP-Wappen größer (Ben 10:03 „proportional“): 76 statt 60, Versatz wächst mit
- Castbar: Ranke und Ecke so lassen (Ben 10:03 „gut so“)
- EP-Liane mit Blüten (Ben 10:10): bei 25/50/75 % sitzt eine Knospe (ep_knospe) in der Liane; erreicht die Liane sie, springt eine Mondblüte auf (neues Bild ep_bluete.tga, 1,4 s: wächst mit kleinem Überschwingen, dreht sich auf, leuchtet kurz). Nach Stufenaufstieg wieder Knospen; auf Höchststufe alle offen
- Wächter: in Städten und Gasthäusern (Ruhebereich) keine Erinnerungen (Schalter, Standard an)
- Wächter: jede Erinnerung kann einen eigenen Platz bekommen („eigener Platz“ auf der Wächter-Seite → eigene Schablone „Nachbuffen: …“); ohne teilen sie sich die Mitte
- Wächter: Essens-Buff „Satt“ als Erinnerung für alle Klassen (Standard aus; erkennt alle Speisen am Namen)

## 0.39.0
- Zauberleiste links neu nach Bens Skizze 08:38:
  - Grüne Linie: rechts neben der Karte fällt der Hauptast jetzt steil ab (Hang über ~0,9 × Astdicke statt 170 px, nicht weichgezeichnet) – nur wenn der Zauber-Zweig an ist. Links über der Karte bleibt der Ast, wie er ist
  - Rotes L: das Zaubersymbol sitzt frei in der Ecke – links am Hang, unten auf dem Ast (2 px dahinter), oben unter dem Zweig; Größe = Lücke zwischen Zweig und Ast an dieser Stelle (höchstens größte Lücke + 2, max. 84). Die kleine Lücke zwischen Hang und Symbol ist mit Holz gefüllt
  - Rotes X / Strich: Zweig und Ranke beginnen erst 24 px vor der Kartenkante (spitzes Ende), alles links davon ist weg. Die Liegestrecke folgt dem Ast nur nach oben, nie den Hang hinunter – der Zweig läuft von dort gerade über das Symbol
  - Rankenverdickung (0.38.9/10) nur noch, wenn es überhaupt eine Kehle gibt
- Geometrie-Probe (luatest/geo.lua) rechnet Ast und Zweig mit Bens Maßen durch

## 0.38.10
- Rankenverdickung an der Biegung (Ben 08:24, Video): die Oberkante hatte vor dem Anstieg noch eine Mulde, weil der gerade Strang erst in der Senke der Liegestrecke begann. Jetzt startet er dort, wo eine Gerade zum Symbol die Liegestrecke von oben berührt (obere Hülle, gesucht im Bereich 0,9 × größte Lücke vor dem Anstieg), und ist von Anfang an fast voll dick – die Kante läuft gerade bis oben

## 0.38.9
- 0.38.8 zurückgenommen (Ben 08:17 „genau so nicht – die Ranke wird an der Stelle nur dicker“): Zweig wieder flach auf dem Ast und steil vor dem Symbol, die Ecke unten bleibt. Stattdessen wächst bei Heilzaubern ein gerader Rankenstrang von der Liegestrecke (0,68 × größte Lücke vor dem Symbol) bis oben aufs Symbol mit – die Ranke wird in der Biegung dicker, die Oberkante läuft gerade, ohne Knick

## 0.38.8
- Zweig links ohne Knick (Ben 08:16, rote Linie): der Anstieg vor dem Symbol beginnt früher (0,68 statt 0,30 × größte Lücke vor dem Symbol) und läuft fast gerade hoch, nur an den Enden leicht gerundet. Die Ecke unten (Holz im Zwickel, Stumpf, Rahmen) bleibt wie sie ist

## 0.38.7
- Zaubersymbol mit Themen-Rahmen statt dünner Linie (Ben 08:05 „Druiden-Rahmen mit Thema, links und unten dicker“): Gewand „Hain“ – geschnitzte Holzleiste aus dichtem Holz (zweig_fuell, je Farbstimmung, etwas heller als der Ast), dunkle Außenkante, helle Fase oben/links, Schattenfuge unten/rechts; links und unten 0,75 × Zweigdicke (schließt die Fuge zu Zweig und Ast), oben/rechts 0,4. Efeu wächst unten rechts über die Ecke. Oben vom Zweig, unten vom Ast beschnitten wie das Symbol. Als Tabelle ICON_FRAMES aufgebaut, damit Krieger, Schurke & Co. später eigene Gewänder bekommen (db.branch.iconFrame)
- PvP-Stufe (Ben 08:06): Plakette liegt jetzt deckend AUF dem Wappen – Goldring 31 px + dunkle Scheibe 27 px, mittig auf der Schildmitte (Blizzard-Wappen um 3 px nach rechts versetzt, weil die Grafik nicht mittig sitzt; Horde-Versatz geschätzt)

## 0.38.6
- PvP-Stufe besser lesbar: Wappen 60 statt 42 px, dunkle Scheibe 28 statt 22 px, Zahl 17 statt 15 pt (ohne PvP wieder 15)

## 0.38.5
- Zaubersymbol mit dünnem Rahmen im Mondhain-Look (Ben 08:02 „dann is perfekt“): außen 2 px dunkles Holz, innen 1 px Bronzelinie; liegt mit dem Symbol hinter Ast und Zweig (verdeckte Stücke bleiben verdeckt), die Unterkante nur dort, wo das Symbol nicht vom Ast abgeschnitten ist. Ersetzt den dunklen Strich an der rechten Kante

## 0.38.4
- Stufen-Plakette bei PvP (Ziel/Fokus): die Zahl war auf dem gedämpften Wappen nicht lesbar. Jetzt ist das Fraktionswappen (Allianz/Horde wie bei Blizzard, 42 px) selbst der Rahmen – Goldring und dunkle Mitte treten zurück –, die Zahl sitzt auf einer dunklen runden Scheibe in der Mitte

## 0.38.3
- Zauberleiste links nach Bens Skizze 07:58 (Vorschau 6): der Zweig liegt lange flach auf dem Ast (Mitte 0,25 Zweigdicken über der Ast-Oberkante, spitzes Ende) und wächst erst direkt vor dem Symbol steil hoch (sanfte S-Kurve über 0,3 × größte Lücke). Darunter ein Stumpf: kurzer Ast wächst aus dem Hauptast hoch, rechts bündig unter dem Symbol, oben vom Zweig abgeschlossen (senkrechter Strang in 2-px-Streifen, Maserung nach oben, hinter Ast und Zweig). Holz im Zwickel bleibt dahinter

## 0.38.2
- Zauberleiste fertig (Ben 25.11.: „dann solls das sein“): die kleine Lücke links vom Symbol zwischen Anstieg und Hang ist mit Holz gefüllt (Kachel zweig_fuell, Ast-Farbe gedämpft, hinter Ast, Zweig und Symbol) – Vorschau 5

## 0.38.1
- Zaubersymbol fast ganz sichtbar (Ben 25.11.: „wie weit kannst du es verkleinern, dass man ≥ 85 % sieht, ohne dass dahinter etwas sichtbar ist?“, Vorschau 4): quadratisch, Kantenlänge 80 % der größten Lücke unter dem Zweig, oben knapp unter dem Zweig, so weit links in die Ecke, wie höchstens 12 % hinter dem Hang verschwinden; der Zweig hat über dem Symbol schon volle Höhe und steigt davor aus dem Ast. Unten nie mehr unter dem Ast hervor (Streifen enden an der Ast-Unterkante – das war das rot markierte Stück). Links vom Symbol keine Balkenfläche mehr, der Balken beginnt rechts daneben

## 0.38.0
- Zauberleiste: Medaillon entfällt (Bens Kasten 25.11., Vorschau 3 auf seinem Screenshot). Das Zaubersymbol füllt die ganze linke Ecke zwischen Zweig und Ast – füllend zugeschnitten auf das Seitenverhältnis des Kastens, oben vom Zweig-Anstieg beschnitten (schmale Streifen), unten hinter dem Ast. Ebenen von vorn nach hinten: Ast + Zweig + Ranke → Symbol → wachsender Balken; kein Grün hinter oder neben dem Symbol, der Balken beginnt an dessen rechter Kante (schmaler dunkler Strich). Kasten: beginnt, wo die Lücke unter dem Zweig ein Drittel der größten Lücke erreicht, 1,65 × so breit wie die größte Lücke; der Zweig steigt kurz davor aus dem Ast. Sichtbare Ast-Oberkante jetzt mit 0,42 statt 0,5 der Dicke gerechnet (das Strang-Bild hat oben/unten durchsichtige Ränder)
- Schrift rechts vom Symbol; Schablone „Zauber-Medaillon“ entfällt
- Ablauf: Vorschau-Werkzeug /home/claude/art/castmock.py (rendert den Zweig mit den echten Bildern auf Bens Screenshot, Ast-Kante aus dem Bild gemessen)

## 0.37.6
- Zauber-Medaillon ins Dreieck eingefasst (Bens rotes Dreieck 25.11.): der Anstieg des Zweigs ist länger (3,4 Radien) und endet erst rechts vom Medaillon; das Medaillon sitzt im Dreieck zwischen Zweig und Ast, so groß wie die Lücke plus 6 px Überdeckung je Seite (34–56 px). Es liegt jetzt UNTER dem Ast (Rahmen der Balkenfläche), Zweig und Ranke darüber → die Ränder verschwinden im Holz statt obenauf zu liegen
- Schrift beginnt rechts vom Dreieck
- Spitzes linkes Ende (Bens lila Kreis): vor dem Ansatz liegt der Zweig noch 2,4 Zweigdicken flach auf dem Ast und läuft dort spitz aus (Wurzel 12 % → voll über 3,5 Zweigdicken); die Ranke beginnt an derselben Spitze
- Medaillon-Versatz aus der Schablone gilt weiter (relativ zur neuen Grundstellung)

## 0.37.5
- Zauber-Zweig nach Bens roter Linie (25.11.): links steigt der Zweig 2,4 Radien vor dem Medaillon bündig aus dem Ast (steil heraus, oben flach – Viertel-Parabel), wölbt sich knapp über den Ring und läuft gerade; rechts ein langer, sanfter Abstieg (Kosinus, bis 130 px, endet bis zu 60 px hinter der Krone flach im Ast) statt des engen Bogens. Die Ranke bei Heilzaubern liegt genau auf diesem Zweig: beginnt am linken Ansatz, läuft rechts spitz aus. Holzfüllung des Zwickels entfällt; unter dem Bogen und dem Abstieg ist jetzt Balkenfläche (schmale Streifen, stoßen genau aneinander → kein Streifen beim Ausblenden); die Füllung beginnt am linken Ansatz
- PvP am Ziel/Fokus: das Fraktionswappen liegt jetzt gedämpft als Hintergrund in der Stufen-Plakette (z. B. „55“ auf dem Allianz-Wappen) statt als eigene Plakette darunter. Spieler behält seine Plakette am Porträt

## 0.37.4
- Notfall-Fix: 0.37.3 rief in Core.lua beim Laden ns.RegisterEvent auf, bevor es definiert ist → Core.lua brach ab, Mondhain lud gar nicht (Blizzard-Oberfläche pur). Die Pfeiltasten-Auswahl nutzt jetzt ein eigenes Ereignis. Neu im Ablauf: Ladeprobe aller Dateien in TOC-Reihenfolge mit nachgebildeter WoW-API (texlua, /home/claude/luatest/load.lua) vor jeder Auslieferung – hätte diesen Fehler gefunden

## 0.37.3
- Bearbeitungsmodus: Schablone anklicken (goldener Rand, Position wird angezeigt), dann Pfeiltasten = 1 Pixel, Umschalt + Pfeil = 10 Pixel; Esc hebt die Auswahl auf, im Kampf wird sie aufgehoben. Gespeichert wie nach dem Ziehen. Andere Tasten gehen normal ans Spiel weiter
- HUD-Fenster passte erst nach /mh hud an: beim Öffnen ordnet Blizzard das Fenster mehrmals selbst um, das wurde als „Tauziehen“ gewertet und Mondhain gab auf. Jetzt zählt nur, wenn Blizzard Mondhains Höhe gleich wieder kürzt (Schwelle höher), nach 3 s neuer Versuch; beim Öffnen wird mehrmals nachgezogen (0 / 0,1 / 0,4 / 1 / 2 s)
- Zauber-Medaillon: Bens Feinjustierung (+42 / −4) ist jetzt die Grundstellung; der gespeicherte Versatz wurde einmalig geleert, damit er nicht doppelt zählt

## 0.37.2
- Schwungtimer sprang im Kampf zurück über den Zauber-Zweig (Screenshot 25.11.): Blizzard setzt seinen Balken im Kampf an die Stelle (und Breite) aus dem HUD-Bearbeitungsmodus zurück, und im Kampf darf Mondhain ihn nicht zurückholen. Jetzt bleibt Blizzards Balken unsichtbar, und Mondhain zeigt unter dem Spielerrahmen eigene Spiegel-Balken (Waffenhand, Schildhand, Distanz untereinander, so breit wie der Rahmen, Mondhain-Look), die jedes Bild Wert, Grenzen und Texte von Blizzards Balken übernehmen. Klappt das Übernehmen nicht, zeigt Mondhain wieder Blizzards Balken. Der unsichtbare Blizzard-Balken zählt nicht mehr in die Höhe der Ast-Krone
- Wächter-Balken zwischen den Rahmen: rechts 34 px Abstand – die Stufen-Plakette des Ziels ragte über das Ende von „Feenfeuer“

## 0.37.1
- Gabelung richtig erkannt (Bens Pfeile 25.11.): bisher galt „Hang-Oberkante unter Zweig-Oberkante“ – das traf schon weit links zu, wo der Zweig noch auf dem Ast liegt, darum lief die Ranke über den ganzen Ast nach links. Jetzt ist die Gabelung die Stelle, an der sich der Ast vom Zweig löst (Lücke darunter öffnet sich); Zweig und Ranke beginnen genau dort
- Medaillon in die Ecke an der Gabelung gesetzt (Grundstellung 2 Radien rechts der Gabelung, oben am Zweig; der Ring liegt unten links im Holz des Hangs, eingefasst wie ein Stein) statt erst dort, wo der Ring den Hang nur berührt (bei flachem Hang weit rechts)
- Medaillon verschiebbar: Schablone „Zauber-Medaillon“ im Bearbeitungsmodus. Gemerkt wird der Versatz zur Grundstellung (wandert mit dem Ast mit), im Chat steht der Versatz; /mh medaillon setzt zurück. Holzfüllung, Schrift und Balkenbeginn folgen dem Medaillon

## 0.37.0
- Zauberleiste, linkes Ende neu gebaut (Knauf wieder raus): der Zweig wächst an der Gabelung dünn aus dem Hang des Hauptasts. Das Medaillon liegt satt in der Ecke darunter – oben am Zweig, unten am flachen Ast, links am Hang (Größe aus dem Abstand Zweig↔Ast, dann so weit nach links geschoben, bis der Ring den Hang berührt). Der Zwickel zwischen Hang, Zweig und Ring ist mit Holz gefüllt wie eine echte Astgabel (neue Kachel zweig_fuell(_mahagoni).tga aus der Strang-Mitte, ohne Lichtverlauf, gespiegelt kachelbar; liegt unter Ast und Zweig, die decken die Ränder). Die Ranke bei Heilzaubern startet links an der Gabelung im Hang und läuft herüber
- Rechtes Ende spitzer: Bogen etwas gestreckt, der Zweig wird zum Ende hin deutlich dünner und läuft spitz in den Ast
- Ziel-Auren aktualisieren sich jetzt auch im Kampf: Mondhain übernimmt die Symbole aus Blizzards verstecktem Zielfenster (das bekommt die Daten im Kampf) und ordnet sie im eigenen Raster über dem Zielrahmen (Größe, Höchstzahl, Schwächungen zuerst, stabile Reihenfolge nach Aura-Kennung). Filter „nur meine“/„nur bannbare“ greifen, wo lesbar; im Kampf entscheidet Blizzard. Abschaltbar (Optionen → Einheiten → Auren am Ziel). /mh ziel zeigt, was übernommen wird
- Schwungtimer: einmalig wieder an den Spielerrahmen geheftet (war früher von Hand verschoben und hing deshalb nicht mehr darunter) – passgenau unter dem Rahmen, so breit wie er
- Neue Bilder → kompletter Neustart nötig

## 0.36.6
- Holzknauf (Screenshot 25.11.): seine untere Hälfte lag als dunkler Fleck mit senkrechter Schnittkante auf dem Hauptast. Jetzt läuft der Knauf unterhalb des Medaillons weich im Ast aus (Deckkraft nach unten und zur Mitte hin auslaufend), Holz insgesamt heller (weniger Abdunklung an Spitze und Lochrand) – passt zum Ast statt davon abzustechen. Nur Bilder geändert → kompletter Neustart

## 0.36.5
- Zauberleiste: Ranke (Heilzauber) sprießt erst ab der Mitte des Knaufs – vorne an der Spitze ist der Knauf schmaler als die Ranke, sie stand dort in der Luft (Screenshot „Nachwachsen“; dort fehlte zudem der Knauf selbst = neue Bilder aus 0.36.3 erst nach komplettem Neustart geladen)

## 0.36.4
- PvP-Wappen am Ziel saß auf dem Elite-Drachen (rechts oben am Porträt) → jetzt links unten an der Balkenseite, unter der Stufen-Plakette; beide Plaketten bilden eine Spalte. Spieler (oben am Porträt) und Fokus unverändert

## 0.36.3
- Zauberleiste, linkes Ende nach Bens Skizze: das Medaillon sitzt jetzt in einem Holzknauf, der links spitz ausläuft (Tropfenform, Maserung fächert in die Spitze, Kanten leicht wellig wie Rinde) statt im dünnen Halbbogen aus dem unteren Ast. Ein einziges Bild (media/zauber_knauf.tga, Mahagoni-Fassung zauber_knauf_mahagoni.tga, erzeugt aus dem Ast-Strang mit /home/claude/art/knauf.py) → blendet ohne Streifen aus, Farbstimmung wie der Zweig. Größe so, dass die Oberkante bündig in den Zweig übergeht und das Loch unter dem Ring liegt; rechts offen, dort beginnt der Balken. Die Ranke bei Heilzaubern wächst aus der Knaufspitze über die Oberkante in den Zweig
- Neue Bilder → kompletter Neustart nötig

## 0.36.2
- Auren am Ziel einstellbar (Optionen → Einheiten → Auren am Ziel, wirkt sofort): Symbolgröße 16–44 px, Höchstzahl 4–32, Schwächungen an/aus und „nur meine eigenen“, Stärkungen an/aus und „bei Gegnern nur bannbare (Magie)“. Reihen brechen um, so breit wie der Zielrahmen, und wachsen nach oben; Stapelzahl wächst mit der Größe
- Uhr oben rechts griff nicht: Mondhain suchte nur Symbole klassischer Bauart (BuffButton1 …). Jetzt alle Bauarten (auch BuffFrame.auraFrames / AuraContainer); kennt das Symbol Ablauf und Dauer selbst, wird direkt daraus gestellt. Einzelne geheime Auren werden übersprungen statt das ganze Lesen abzubrechen. /mh buffs zeigt jetzt auch, wie viele Symbole gefunden wurden, wie viele eine Uhr haben und woher

## 0.36.1
- Stärkungen/Schwächungen oben rechts mit Uhr: der abgelaufene Teil wird dunkel (Tortenstück, das wächst), Zeit bleibt darunter. Forever verrät Restzeiten im Kampf nicht → außerhalb des Kampfs genau gelesen und je Symbolbild gemerkt; einmal gestellt läuft die Uhr im Kampf von selbst weiter. Neue Stärkungen im Kampf starten mit der zuletzt gemessenen Dauer, eigenes Nachwirken auf dich (z. B. Verjüngung) stellt die Uhr neu. Verschieben sich im Kampf die Plätze und ist das Symbolbild nicht lesbar, verschwindet die Uhr lieber, als falsch zu laufen. Waffen-Symbole (Öl, Wetzstein, Gift): Uhr aus der Restzeit, Gesamtdauer = größte gesehene
- Ziel-Auren: Uhr lief verkehrt herum (dunkel = Restzeit, eine 24-Minuten-Stärkung war fast schwarz) → jetzt dunkel = abgelaufen. Sind die Werte geheim, stellt Blizzards Dauer-Objekt die Uhr, wenn Forever es anbietet

## 0.36.0
- Neues Modul Wächter (Ersatz für die wichtigsten Weak Auras):
  - Nachbuffen: fehlt Dornen oder Mal der Wildnis (Gabe der Wildnis zählt mit), springt das Symbol als Medaillon (Zauber-Ring, runder Ausschnitt, Leuchten) über der Bildmitte auf – im goldenen Schnitt, wo der Blick über der Spielfigur liegt – und blinkt mit „nachbuffen!“, bis die Stärkung wieder drauf ist. Außerhalb des Kampfs ruhige Vorwarnung 30 s vorher mit Restzeit. Nicht bei Tod, Flugroute, Fahrzeug
  - Zeiten am Gegner: Krallenhieb und Feenfeuer (auch Tiergestalt) als Balken mit Symbol, Name und Restzeit zwischen Spieler- und Zielrahmen (Platz und Breite werden aus der Lücke gemessen, solange nicht verschoben); die letzten 3 s pulsiert der Balken = jetzt erneuern. Je Ziel gemerkt (beim Zurückwechseln wieder da), Tod des Ziels und Kampfende räumen auf
  - Forever verrät Auren im Kampf nicht: außerhalb wird genau gelesen und die echte Dauer gemerkt; im Kampf läuft eine Eieruhr ab dem erfolgreichen Wirken (Dornen auf andere zählt nicht für dich). Dauer notfalls aus der Zauberbeschreibung
  - Schablonen „Nachbuffen“ und „Zeiten am Gegner“; Optionen-Seite „Wächter“ (je Zauber an/aus, Vorwarnung, Probe zeigen)
- Neue Datei → kompletter Neustart nötig

## 0.35.4
- PvP-Wappen an Ziel, Spieler und Fokus: ist die Einheit PvP-markiert, sitzt eine runde Plakette an der äußeren oberen Porträt-Ecke (Ziel rechts, Spieler links, spiegelgleich; Fokus rechts) – Ring in Fraktionsfarbe (Allianz blau, Horde rot, Jeder gegen jeden gold), Wappen innen (Blizzards HUD-Symbol, notfalls das klassische). Aktualisiert bei Zielwechsel, beim An-/Ausschalten des eigenen PvP und wenn sich die Markierung anderer ändert. Abschaltbar: Optionen → Einheiten → Mehr

## 0.35.3
- Eigentliche Ursache gefunden: Forever lädt den HUD-Bearbeitungsmodus erst nach dem Login – beim Start gab es EditModeManagerFrame noch nicht, darum hing keiner von Mondhains Haken daran (Fensterhöhe, ausgeblendete Blizzard-Vorschauen für Spieler/Ziel/Gruppe, Schwächungen unter den Beispiel-Stärkungen). Neu: ns.OnEditMode wartet, bis das Fenster existiert (ADDON_LOADED + Nachsehen jede Sekunde), und hängt dann alles ein – auch wenn es gerade offen ist
- Fensterhöhe: setzt Blizzard die Höhe ständig zurück (Tauziehen), gibt Mondhain für dieses Öffnen nach statt zu flackern; nie tiefer als der Bildschirmrand
- /mh hud an · /mh hud aus (statt nur Umschalten); /mh hud info zeigt zusätzlich, ob eingehängt und ob Blizzard zurücksetzt

## 0.35.2
- HUD-Bearbeitungsmodus, zweiter Anlauf (Screenshot: „Kampf“ und „Verschiedenes“ hingen weiter unter dem Fenster, die Knöpfe mitten im Inhalt): 0.35.1 hat Kästen, die bis zum unteren Rand gespannt sind, samt ihrem Inhalt übersprungen – also genau die Häkchen. Jetzt wird jede Kante einzeln geprüft (bleibt sie beim Wachsen stehen?), durch den ganzen Rahmenbaum bis 8 Ebenen tief; gespannte Kästen zählen selbst nicht, ihr Inhalt schon. Platz für die Knopfleiste wird aus den unten festgemachten Knöpfen gemessen. Setzt Blizzard die Höhe neu, passt Mondhain gleich danach wieder an
- /mh hud info (bei offenem HUD-Bearbeitungsmodus): zeigt Höhe, gemessenen Inhalt, unterstes Teil, Knopfleiste, Anker und Soll-Höhe
- Stärkungen/Schwächungen im HUD-Bearbeitungsmodus: Blizzard zeigt dort Dutzende Beispiel-Stärkungen, die über die Schwächungen liefen → solange der Modus offen ist, stehen die Schwächungen direkt unter der letzten Beispielreihe, danach wieder an ihrer Schablone

## 0.35.1
- HUD-Bearbeitungsmodus repariert: die Höhenanpassung aus 0.34.1 schaukelte sich auf – Rand und Hintergrund hängen am unteren Fensterrand und wuchsen mit, alle 0,3 s kamen 56 px dazu, bis das Fenster zerstört war. Jetzt zählt nur Inhalt, der von oben her hängt; Blizzards eigene Höhe ist die Untergrenze, nie höher als der Bildschirm, beim Schließen bekommt das Fenster seine Originalhöhe zurück
- /mh hud schaltet die Anpassung an/aus (aus = Blizzard-Original, zum Vergleichen)

## 0.35.0
- Neues Modul Beute: automatisch plündern (Blizzards Einstellung, in den Optionen an/aus); bei guter Beute (ab Grün, umschaltbar Blau/Lila) ein kleiner Hinweis im Mondhain-Look mit Symbol, Name in Qualitätsfarbe und Herkunft („aus Wildschrammyeti · Feralas“, beim Sammeln z. B. „Kürschnern: …“, Quest-Belohnungen erkannt). Grau/Weiß bleibt still. Bis zu 5 Hinweise gestapelt, je 7 s, Maus drüber hält sie an und zeigt den Tooltip, Umschalt-Klick verlinkt im Chat, Klick schließt. Schablone „Beute-Hinweise“ im Bearbeitungsmodus
- Herkunft bleibt am Gegenstand: im Tooltip steht später „Beute: Wildschrammyeti · Feralas · 24.11. 18:31“; /mh beute listet die letzten 15 Funde
- Optionen: neue Seite „Beute“ (an/aus, automatisch plündern, Hinweise, Tooltip-Zeile, Schwelle, Probe-Hinweis)
- Neue Datei → kompletter Neustart nötig

## 0.34.7
- Stärkungen: Sortierung neu – statt Blizzards Plätze umzuverteilen (das ließ Lücken stehen, z. B. nach Rudelführer beim Verlassen der Bärengestalt, und sprang alle 0,3 s hin und her) ordnet Mondhain die Symbole selbst in einem festen Raster: rechts oben beginnend, Waffen-Symbole, lange Stärkungen, dann Kurzes/HoTs ganz links; Schwächungen darunter. Läuft sofort bei jeder Änderung (Blizzard setzt/zeigt/versteckt ein Symbol), kein Hin-und-her mehr. Dauerhafte Stärkungen werden nicht mehr fälschlich als „kurz“ erkannt (alter Ablaufwert am wiederverwendeten Symbol)
- Schwungtimer (alle drei) direkt unter dem Spielerrahmen, untereinander, so breit wie der Rahmen (centerBlock.swingUnderPlayer)

## 0.34.6
- Dornen-Leiste: im HUD-Bearbeitungsmodus nicht zu greifen → Mondhain übernimmt sie wieder, diesmal ohne Umhängen: die Leiste wird nur an eine eigene Schablone „Dornen-Leiste (Abklingzeiten)“ geheftet (220×30, gut greifbar); setzt Blizzard sie woanders hin, wird sie zurückgeheftet. Verschieben im Mondhain-Bearbeitungsmodus

## 0.34.5
- Stärkungen sortiert: Heilung, HoTs und alles mit höchstens 60 s Restzeit stehen ganz links, lange Stärkungen (Mal, Dornen, Essen …) rechts. Blizzards Plätze bleiben, die Symbole werden darauf neu verteilt (direkt nach Blizzards Anordnen, zur Sicherheit alle 0,3 s). Restzeit aus Blizzards Symbol, notfalls aus dem Zeittext. Abschalten: auras.healFirst = false
- Dornen-Leiste bestätigt: BuffBarCooldownViewer (Abklingzeitmanager) – bleibt bei Blizzard, Verschieben im HUD-Bearbeitungsmodus + Speichern

## 0.34.4
- Stärkungen/Schwächungen über Blizzards eigene Leiste: Forever gibt Auren im Kampf an Addons überhaupt nicht heraus (alle vier Lesewege leer) – Blizzards Leiste liest sie selbst und funktioniert im Kampf. Mondhain setzt sie an seinen Platz (Schablonen „Stärkungen“/„Schwächungen“), skaliert sie auf die eingestellte Symbolgröße und gibt ihr den Mondhain-Look (beschnittene Symbole, dunkler Rand, Zeit/Anzahl mit Kontur). Klassisch hängen die Symbole an der Waffenverzauberungs-Leiste – die wandert mit. Eigene Symbole nur noch im Test zum Ausrichten; alter Weg: auras.blizzardMode = false

## 0.34.3
- Stärkungen im Kampf: Forever gibt sie über den üblichen Weg (nach Nummer) im Kampf nicht heraus → neue Stärkungen (z. B. Nachwachsen) erschienen nicht. Jetzt vier Lesewege nacheinander (Nummer, ForEachAura, Plätze, klassisches UnitAura) und ein eigenes Gedächtnis aus Blizzards UNIT_AURA-Meldungen (neue/geänderte/entfernte Auren kommen dort auch im Kampf mit). Ist im Kampf gar nichts lesbar, bleibt die Anzeige stehen, Abgelaufenes wird aber ausgeblendet
- /mh buffs: zeigt, welcher Weg gerade wie viele Stärkungen liefert (am besten im Kampf aufrufen)

## 0.34.2
- Stärkungen oben rechts: im Kampf ausgelaufene Stärkungen (z. B. Nachwachsen, Verjüngung) blieben als Symbol stehen. Ursache: die „im Kampf nichts lesbar → Bisheriges stehen lassen“-Regel griff auch, wenn die Liste wirklich leer war, und das Auslaufen wird im Kampf nicht immer gemeldet. Jetzt: stehen lassen nur, wenn das Spiel mit einem Fehler antwortet; abgelaufene Symbole lösen sofort ein Neulesen aus; dazu Sicherheitsnetz (im Kampf alle 0,5 s, sonst jede Sekunde neu lesen)

## 0.34.1
- Dornen-Timer & Co. (Blizzards Abklingzeitmanager): bleiben wieder bei Blizzard und werden im HUD-Bearbeitungsmodus verschoben – das klappt dort (Video), während Mondhains Schablone nur noch als Geist in der Mitte hing (zwei Systeme haben sich gestritten). Wer Mondhain ranlassen will: ns.db.manageCooldowns = true
- HUD-Bearbeitungsmodus: mit „Erweiterte Optionen“ ragten Kampf/Verschiedenes unten aus dem Fenster, die Knöpfe standen mitten in den Häkchen – Fensterhöhe passt sich jetzt dem Inhalt an

## 0.34.0
- Charakterfenster (neues Modul): neben jedem Ausrüstungsteil steht seine Verzauberung zur Mitte hin – linke Spalte rechts daneben, rechte Spalte links daneben, Waffenhand links, Schildhand darunter, Distanz rechts; grün = dauerhaft, hellblau = auf Zeit (Öl, Wetzstein). Liest Tooltip-Daten (neuere Schnittstelle oder unsichtbarer Tooltip), notfalls die erste grüne Zeile, die kein „Anlegen:“/„Benutzen:“/Set-Text ist
- Charakterfenster 150 px breiter: rechte Spalte rückt nach außen, Modell, Werte, Name und Waffen zur neuen Mitte (gemessen, nicht geraten); Mondhain-Look: dunkler Grund mit Holzrahmen statt Pergament (auch auf den anderen Reitern), Rand jedes Teils in Qualitätsfarbe, Schließen-Knopf in der Ecke; der breitere Grund zieht das Fenster mit. /mh charakter schaltet das Ganze ab (nach /reload)
- Schwungtimer im Mondhain-Look: Forevers Balken behalten ihre Funktion, bekommen dunkle Spur, Bernstein-Füllung (Schildhand Eichenholz, Distanz Mondlicht), helle Vorderkante, schmalen Holzrahmen, klare Schrift; sitzt wieder über dem Zauber-Zweig samt Rankenlaub (die Höhenangabe dafür fehlte seit dem Umbau)
- Abklingzeitmanager (z. B. Dornen): Rahmen werden auch unter abweichenden Namen gefunden, jede weitere „…CooldownViewer“-Leiste bekommt eine eigene Schablone; leere Leisten haben eine gut greifbare Schablone (160×28); /mh rahmen listet alle Abklingzeit-Rahmen im Spiel
- Fenster-Verschieben: Ziehen-Logik für andere Module nutzbar
- Hain-Tafel: kein „Klick: …“ mehr in den Tooltips (Haltbarkeit, Gilde, Gold); Taschen-Zeile ohne Tooltip – die Zeilen sind einfach klickbar
- Mondhain-Knopf (und Kartenknopf): Tooltip steht seitlich daneben zur Bildschirmmitte hin statt über dem Knopf
- Neue Datei → kompletter Neustart nötig

## 0.33.3
- Vorratsleiste: höchstens 8 Fächer, 4 je Reihe – das fünfte beginnt unter dem ersten (senkrecht: 4 übereinander, dann Spalte rechts daneben); erste Reihe bleibt an ihrem Platz
- Bearbeiten (/mh vorrat): Gegenstand aus der Tasche auf ein Fach ziehen → davor (linke Hälfte) oder dahinter (rechte Hälfte) einfügen, grüne Linie zeigt die Stelle; schon angeheftete Gegenstände so verschieben; [+] hängt hinten an und verschwindet bei 8; volle Leiste meldet sich
- Optionen: „Höchstens so viele Fächer“ 1–8

## 0.33.2
- Zauber-Ast links wie rechts: der Zweig wächst bündig aus dem unteren Ast unter dem Medaillon, steigt links im Halbbogen herum und läuft oben gerade weiter; Medaillon sitzt mittig darin, Spur/Füllung füllen auch den Halbbogen (Maske). Platz: erste Stelle rechts vom Hang, an der der untere Ast unter dem ganzen Bogen flach liegt
- Ranke (Heilzauber) startet unten am Ast, rankt um das Medaillon und dann nach rechts; die Füllung folgt ihrer Spitze
- Schrift bei Ranke 3,5 px tiefer (Laub hängt in den Balken)
- Rechter Bogen enger und knubbelig: in der Biegung bis 1,5-fach verdickt wie ein Knöchel, kein dünner Auslauf mehr

## 0.33.1
- Zauber-Ast: Medaillon sitzt jetzt wirklich in der Ecke – der Zweig wächst aus dem Hang, legt sich links und oben eng um den Ring und läuft dann gerade weiter (keine Holz-Füllung der Gabel mehr nötig); Balken beginnt am Medaillon mit gerader Oberkante
- Ranke nur noch bei Heilzaubern (Blizzard „hilfreicher Zauber“, sonst Namensliste: Nachwachsen, Heilende Berührung, Gelassenheit …); sie sprießt oben aus dem Medaillon. Herstellen und alles andere: nur Füllung
- Ende: kein Zurückziehen mehr – alles blendet gemeinsam aus (0,3 s); unterbrochen: rot/verwelkt kurz stehen, dann ausblenden. Damit das ohne Streifen geht: Balkenstücke stoßen genau aneinander, unter dem Bogen ein einzelnes Stück mit runder Maske, Zweig und Ranke nur an echten Knicken verlängert

## 0.33.0
- Herstellen: Medaillon zeigt den hergestellten Gegenstand statt Blizzard-Logo (Rezeptdaten, sonst klassisches Berufe-/Verzauberfenster, sonst Gegenstand gleichen Namens); Balken und Schein in Berufsfarbe: Leder Sattelbraun, Schneiderei Seidenviolett, Schmiedekunst Glut, Alchemie Türkis, Verzauberkunst Arkan, Ingenieurskunst Messing, Kochkunst Herdfeuer, Erste Hilfe Karmin, Bergbau Erz, Juwelier Edelstein, Inschrift Tinte (sonst Gold). Erkennt Herstellen auch, wenn das Spiel es nicht meldet (offenes Berufefenster + Rezept gleichen Namens)
- Neues Modul Fenster: Blizzard-Fenster (Beruf, Charakter, Zauberbuch, Händler, Post, Bank, Gilde, Auktionshaus, Talente …) mit gedrückter linker Maustaste an freier Stelle verschiebbar; Platz bleibt gespeichert, auch wenn Blizzard das Fenster beim Öffnen zurückschieben will. Geschützte Fenster nicht im Kampf. /mh fenster setzt alle zurück
- Ast nicht mehr rissig/durchlässig: Holzband-Bilder (ast_strang, ast_strang_mahagoni) neu – geschlossene Silhouette statt löchriger Faser-Ränder, Löcher farblich aufgefüllt, Kante leicht abgedunkelt; an Knicken verlängert sich jedes Aststück genau so weit, wie der Knick braucht (vorher klafften außen keilförmige Spalten – sah wie Risse aus, v. a. an Schultern über Parkleiste und Hängen); Holzmuster läuft dabei bündig weiter; Glanzkante liegt ganz im Holz
- Neue Dateien + geänderte Bilder → kompletter Neustart

## 0.32.0
- Zauber-Ast geschlossen: der Zweig biegt sich am Ende als Bogen zurück in den Ast (Viertelellipse, am Ende wieder dünner); Balken und Spur folgen dem Bogen, Restzeit sitzt innen vor dem Bogen
- Wachsende Ranke: mit dem Fortschritt wächst das gemalte Lianenbündel (wie beim Erfahrungs-Ast) vom Medaillon aus um den Zweig, Knospe leuchtet an der Spitze. Danach ziehen sich Ranke und Füllung zum Medaillon zurück (0,35 s), dann blenden Zweig und Medaillon aus. Unterbrochen: rot, Ranke verwelkt braun, kurz stehen, dann zurück
- Tooltips auf Spieler, Ziel, Fokus, Ziel des Ziels und Begleiter beim Drüberfahren
- Neues Modul Tooltip: fester Anker (Schablone „Tooltip“ im Bearbeitungsmodus, Standard rechts über dem Questtracker); alle Tooltips an Blizzards Standardstelle hängen dort, wachsen von der Ecke zur Bildschirmmitte. Mondhain-Look: dunkler Grund + Holzrahmen für GameTooltip, Gegenstands-Links und Vergleichs-Tooltips
- Eingehende Heilung in Spieler-, Ziel-, Fokus- und Gruppenrahmen: eigene Heilung kräftig grün, fremde blasser, Schilde als heller Schimmer dahinter, Heil-Absorbs dunkelrot im Leben, helle Kante rechts bei Überheilung. Balken hängen aneinander statt gerechnet zu werden → funktioniert auch mit geheimen Werten (dann eigene/fremde in einem Abschnitt). Schrift liegt über der Vorschau
- Neue Datei → kompletter Neustart nötig

## 0.31.9
- Zauber-Ast: Medaillon als runde Kappe ganz links in der Ecke – so groß wie der Balken hoch ist (+5 px Überstand auf Zweig- und Astkante), so weit links, wie der Kreis zwischen Zweig und Hang passt. Die schmale Gabel links davon wird mit Holz gefüllt, Zweig und Ast wachsen dort zusammen – das Symbol sitzt damit genau in der Ecke. Balken beginnt am Medaillon. Schein nur noch als schmaler Hauch um den Ring

## 0.31.8
- Zauber-Ast: Medaillon sitzt jetzt am Anfang des Balkens, eingeklemmt in die Gabel zwischen Zweig und abfallendem Ast (Größe passt sich der Lücke an); Balken und Füllung beginnen am Medaillon, links davon bleibt die Gabel offen. Schrift rechts daneben. Schein rund statt eckig

## 0.31.7
- Zauber-Ast: Symbol als Medaillon – rundes Symbol (Ränder beschnitten), Holzring aus dem Ast-Holz mit mondsilberner Innenkante, sanft pulsierender Schein in Zauberfarbe (rot bei Unterbrechung). Neue Bilder zauber_ring.tga, rund_maske.tga
- Schrift sitzt in der Lücke zwischen Zweig und Ast, gemessen an der Stelle, wo sie steht (vorher konnte sie auf dem Ast landen); Zweig 6 px höher für Platz; reicht es trotzdem nicht, steht sie über dem Zweig
- Keine Ranken-Schnörkel mehr auf dem Ast unter dem Zauber-Ast

## 0.31.6
- Aktionstasten: Drücken ohne genug Wut/Energie ließ die Taste orange-rot getönt hängen (die Taste hatte sich selbst auf „aktiv“ geschaltet, kein Ereignis nahm das zurück). Jetzt wird nach jedem Druck der echte Zustand gesetzt; Tönung erscheint nur noch, solange der Zauber wirklich läuft (z. B. Automatischer Angriff)

## 0.31.5
- Zauber-Ast: Füllung liegt jetzt unter Ast und Zweig, deren Rinde deckt die Kanten → keine Treppenstufen mehr am Ansatz; im geraden Teil ein einziges Rechteck; am Ende kein streifiges Ausblenden mehr (Erfolg: Balken sofort weg, Zweig blendet kurz aus; unterbrochen: rot halten, dann weg)
- Stärkungen/Schwächungen: verschwinden im Kampf nicht mehr (Forever liefert dort teils keine Daten – die Anzeige bleibt stehen) und werden nach dem Kampf sofort neu gelesen

## 0.31.4
- Zauber-Ast besser lesbar: dunkle Spur über die ganze Länge, satte deckende Füllung ohne Streifenmuster, Name und Restzeit größer mit Kontur (Zeit innen am rechten Ende), Zaubersymbol größer

## 0.31.3
- Händler: Mauszeiger wird über den Kacheln zum Kauf-Säckchen wie bei Blizzard (rot, wenn zu teuer)

## 0.31.2
- Fix Händler leer bei Waren mit Goldpreis: Forever kennt GetCoinTextureString nicht mehr – eigene Münzanzeige (ns.CoinString), auch für Reparaturkosten und Kontobuch
- Händler: ein fehlerhafter Gegenstand bricht die Liste nicht mehr ab, Fehler wird einmal im Chat gemeldet

## 0.31.1
- Fix Händler: Filter „Zeigen“ steht bei jedem Händler wieder auf „Alle“ (vorher blieb z. B. „Bekannt“ hängen → leere Liste); Sortierung bleibt gemerkt
- Lässt ein Filter nichts übrig: Knopf „Nichts passt – alles zeigen“
- Ansicht ganz deckend, Blizzards Kacheln darunter unsichtbar (schimmerten durch)

## 0.31.0 – Zauber-Ast
- Beim Zaubern sprießt an der Schräge rechts der Karte ein Zweig aus dem Ast und läuft bis ans Ende der Aktionsleisten; der ganze Raum zwischen Zweig und Ast ist der Zauberbalken (füllt sich, Kanalisieren leert sich), helle Vorderkante, Zaubersymbol am Ansatz, Name und Restzeit
- Farben: Zauber grün, Kanalisieren türkis, nicht unterbrechbar grau, unterbrochen rot (welkt weg)
- Ersetzt Blizzards Zauberleiste (bei geheimen Zeiten springt Blizzards Leiste ein); Schwungtimer rückt über den Zweig
- Abschaltbar unter Optionen → Ast

## 0.30.5
- Fix: weiße „Zentimetermaß“-Striche auf dem Ast weg – Glanzkante, Schatten und Rankenlicht überlappten an jedem Teilstück und leuchteten dort doppelt; Aststücke überlappen nur noch minimal

## 0.30.4
- Ast klammert Leisten mit ein, die auf einem unteren Element aufsitzen (Parkleiste über dem Chat, Vorratsleiste): er legt sich dann über sie statt hindurchzulaufen; frei schwebende Leisten bleiben draußen

## 0.30.3
- Hain-Tafel: Maus über „Haltbarkeit“ zeigt jeden Gegenstand mit Haltbarkeit (schlechteste zuerst, farbig, aktuell/max) und die geschätzten Reparaturkosten

## 0.30.2
- Händler: Suchfeld nach rechts (nicht mehr unter dem Händlerkopf); Suche findet auch Werte aus dem Tooltip (z. B. „Ausdauer“, „Rüstung“)
- Filter als Ausklappmenü: Zeigen (Alle/Lernbar/Benutzbar/Bekannt), Platz (Kopf, Brust, Hände, Füße … mit Anzahl), Set (aus den Namen erkannt, mit Fortschritt bekannt/gesamt, Haken bei vollständigen Sets), alles zurücksetzen
- Sortierung ebenfalls als Ausklappmenü

## 0.30.1
- Händler wieder als Kacheln wie bei Blizzard (zwei Spalten, Seiten, Mausrad blättert), Suche/Filter/Sortierung bleiben
- Filter: Alle / Lernbar / Benutzbar / Bekannt; Sortierung: Händler / Lernbar zuerst / Name / Preis / Seltenheit
- „Lernbar“ = Rezept, Reittier oder Haustier, das du noch nicht kennst und benutzen kannst (warm hervorgehoben); bekannt grün, nicht benutzbar rot

## 0.30.0 – Händlerliste
- Beim Händler eine durchgehende Liste statt 10er-Seiten: Suchfeld, Filter (Alle / Unbekannt / Bekannt), Sortierung (Händler, Name, Preis, Seltenheit, Unbekannt zuerst)
- Bereits bekannte Rezepte, Reittiere usw. grün mit Haken, nicht benutzbare Waren rot; Zähler „x von y · z bekannt“
- Rechtsklick kauft (mit Blizzards Rückfrage bei Sonderwährung), Umschalt+Rechtsklick Menge, Umschalt+Linksklick Chatlink, Strg+Linksklick anprobieren; Rückkauf-Reiter unverändert
- Abschaltbar unter Optionen → Anordnung

## 0.29.3
- Blizzards HUD-Bearbeitungsmodus: von Mondhain ersetzte Blizzard-Fenster (Spieler, Ziel, Fokus, Begleiter, Gruppe, Schlachtzug, Stärkungen) werden dort nicht mehr als doppelte Vorschau gezeigt

## 0.29.2
- Blizzards Abklingzeitmanager in Mondhain-Rahmen: Leisten (z. B. „Dornen“), Stärkungs-Symbole, Wichtig, Nützlich – mit /mh verschieben frei verschieb- und skalierbar; Leisten starten mittig über der Krone
- Später geladene Blizzard-Teile werden nachträglich eingefangen

## 0.29.1
- Fix: Maus-Flächen von Erfahrungs- und Ruf-Ast folgen jetzt als schmale Streifen genau dem jeweiligen Ast (vorher ein großes Rechteck, Ruf lag über beiden)
- Tooltips erscheinen am Mauszeiger und nennen „Erfahrung“ bzw. „Ruf“ im Titel

## 0.29.0 – Ruf-Ast
- Dünnerer Ast direkt über dem Erfahrungs-Ast, umschlungen von einer blau-türkisen Liane (eigenes Bild liane_blau): so weit, wie der Ruf der verfolgten Fraktion in der aktuellen Stufe reicht; ohne verfolgte Fraktion kein Ruf-Ast; Maus drüber: Fraktion, Stufe, Fortschritt
- Blizzards Rufleiste wird ausgeblendet

## 0.28.3
- Übergang an der Gabelung wie in deinem Bild: das Lianenbündel franst nach links in vier dünne Ranken auf, die sich um den Hauptast schlingen (hinten vom Ast verdeckt) und am Ende zu Schnörkeln einrollen; Bündel setzt kräftiger an

## 0.28.2
- Lianenbündel wächst an der Gabelung dünn aus dem Hauptast heraus und wird erst allmählich voll; Spitze läuft schmaler aus (statt harter Kante)

## 0.28.1
- Erfahrungs-Ast mit deinem gemalten Lianenbündel (liane_strang, nahtlos gekachelt) statt der gezeichneten Stränge; Bündel blendet an den Enden weich ein/aus, ausgeruht = blass voraus

## 0.28.0 – Lianenbündel
- Erfahrungs-Ast nach deinem Vorbild: mehrere grüne Stränge winden sich umeinander und um den Ast (vorne hell, hinten dunkel), Schnörkel-Triebe, Blätter, kleine leuchtende Knospen; ausgeruht = blasses Bündel voraus
- Neues Bild: punkt (weicher Lichtpunkt)

## 0.27.2
- Liane Windung an Windung gewickelt: deckt den Erfahrungs-Ast so weit, wie die EP reichen, vollständig ab (die runde Schattierung jeder Windung ergibt die Rillen)

## 0.27.1
- Erfahrungs-Ast: statt Efeu-Blättern eine eng gewundene grüne Liane (vordere Windungen über dem Ast, hintere schauen an den Rändern hervor), kleiner Schnörkel an der Spitze; ausgeruht = blasse Windungen voraus
- Fix: Linksklick auf eine Quest öffnet die Karte jetzt direkt bei der Quest; Buch-Knopf öffnet das Questlog direkt (der sichere Klick auf den versteckten Mikroknopf kam nicht an)

## 0.27.0 – Erfahrungs-Ast
- Über dem Questtracker zweigt ein Seitenast nach rechts ab (mit Spalt zum Hauptast); Efeu rankt sich darum, je mehr EP, desto weiter – blasse Blätter voraus zeigen „ausgeruht“; auf Höchststufe ganz bewachsen; Maus drüber: EP-Tooltip
- Ersetzt den EP-Balken im Leistengrund und Blizzards EP-Balken
- Irrlichter aus; statt leuchtender Blätter zwei kleine Efeu-Büschel auf dem Ast (neue Efeu-Blätter)
- Keine Ranke mehr unter dem Erfahrungs-Ast

## 0.26.0 – Mahagoni und Tiefe
- Ast und Stamm in Mahagoni (eigene Bilder aus den Nachtelfen-Grafiken umgefärbt); Stamm dunkler und ruhiger
- Tiefe: weicher Schatten unter dem Ast auf dem Stamm, warme Glanzkante oben
- Schnörkel: vier dünne Ranken winden sich um den Ast (nur vordere Windungen sichtbar), rollen sich am Ende ein
- Farbstimmungen: Mahagoni, Mahagoni dunkel, Nachtelf (violett), Mondsilber, Waldgrün
- Optionen: Schatten/Glanz und Ranken einzeln abschaltbar

## 0.25.1
- Fix: Ast wurde nicht gezeichnet (Farbstimmung griff auf noch nicht gesetzte Einstellungen zu)
- Fix: Schwungtimer-Breite/Ausblenden liefen in einen Fehler (Leistenbreite falsch ermittelt) → Ausblenden außerhalb des Kampfes greift jetzt
- Fehler im Ast werden einmalig im Chat gemeldet statt still zu scheitern

## 0.25.0 – weniger Fläche
- Ast schlanker (28), liegt direkt auf den Oberkanten auf, Hänge kürzer → deutlich weniger Spielfeld verdeckt
- Schwung- und Zauberleiste nicht mehr in der Krone, sondern schwebend über dem Ast (nur bei Bedarf sichtbar)
- Schwungtimer verschwindet jetzt wirklich außerhalb des Kampfes; Mondsichel tritt im Kampf zurück
- Chat-Reiter mit fester Höhe berücksichtigt; Blätter kleiner
- Farbstimmungen: Nachtelf, Dämmerholz, Mondsilber, Waldgrün, Dunkel (Optionen → Ast)
- /mh ast zeigt, woran sich der Ast ausrichtet

## 0.24.0 – Nachtelfen-Grafiken
- Ast kräftiger (Dicke 34) mit sanften Hängen statt Stufen
- Ast mit eigener Rinde (violett, silbriges Mondlicht, Moos), nahtlos gekachelt
- Stamm darunter als durchgehende Rindenfläche (Helligkeit einstellbar)
- Schmuck: Mondsichel auf der Krone, Blätter am Ast, drei schwebende Irrlichter (je abschaltbar)
- Neue Bilder: ast_strang, stamm, mond, blatt/blatt2/blatt3, irrlicht

## 0.23.0 – der Ast
- Ein durchgehender Ast (Teldrassil) läuft über den ganzen unteren Rand und legt sich über Chat, Tafeln, Karte, Mittelblock mit Schwung/Zauber und Quests; Krone über der Mitte, Senken dazwischen
- Darunter durchgehender Stamm (dunkles Violett); Spieler, Ziel, Parkleiste und Menü bleiben draußen
- Wächst neu, sobald etwas verschoben wird; dicker links, läuft rechts dünn aus
- Ersetzt Wurzel, Umrankungen und Holzrahmen am unteren Rand; Tafeln und Leistengrund nur noch leicht vertieft
- Optionsseite „Ast“ (Dicke, Höhen und Tiefen, Deckkraft – wirken sofort)
- Platzhalter-Rinde aus dem Wurzelstrang, bis die Nachtelfen-Grafiken da sind

## 0.22.0 – ruhige Mitte
- Dunkler Grund hinter den drei Leisten, von der Wurzel umrankt; rechte Tafel oben/unten bündig daneben
- Ranken in der Mitte entfernt (Bogen, Triebe, EP-Ranke); stattdessen schmaler EP-Balken im Grund
- Schwung- und Zauberleiste gestapelt direkt über dem Block, so breit wie die Leisten; Schwungtimer nur im Kampf
- Ziel steht spiegelgleich zum Spieler (folgt beim Verschieben)
- Tastenkürzel kleiner und gedämpft, abschaltbar; Gestaltleiste füllt die Tafel unten mittig
- Rechte Tafel ohne Titel und Platzhalter
- Verschiebe-Schablonen liegen unter den Optionen (Ebene HIGH), Optionen springen nach vorn
- Neue Optionsseite „Mitte“

## 0.21.3
- Optionen und Kontobuch liegen immer vor den Verschiebe-Schablonen

## 0.21.2
- Tafeln selbst verschiebbar (und per Mausrad skalierbar); „Tafeln zurück an ihren Platz“ unter Karte
- Verschiebe-Schablonen dunkler, gedecktes Blau
- Rechtsklick auf eine Schablone öffnet die Einstellungen des Bereichs; 100 % jetzt Umschalt + Rechtsklick

## 0.21.1
- Tafel-Klicks (Haltbarkeit, Gilde, Taschen) öffnen die Fenster jetzt direkt; Charakter/Gilde nicht im Kampf
- Rechte Tafel reicht bis auf den Wurzelstrang hinunter

## 0.21.0
- Tafeln wachsen aus der Wurzel (umrankt statt flacher Rahmen)
- Linke Tafel: Haltbarkeit (→ Charakter), Gilde online mit Liste (→ Gildenfenster), Gold mit Sitzungsbilanz (→ Kontobuch), Taschenplätze (→ Taschen)
- Kontobuch pro Charakter: Einnahmen/Ausgaben nach Art, Zeiträume Sitzung bis gesamt
- Mikro-Knopf unten rechts in der Karte klappt die Mikroleiste aus; Taschenleiste ausgeblendet
- Gestaltleiste in der rechten Tafel; Addon-Beutel liegt vor dem Wurzelknoten

## 0.20.1
- Linke Tafel bündig mit dem Chat, rechte Tafel neben den Aktionsleisten (Höhe der drei Reihen)
- Chat-Eingabezeile so breit wie der Chat; Parkleiste auf 80 %

## 0.20.0
- Questtracker: Linksklick öffnet die Karte, Rechtsklick-Menü mit Teilen und Abbrechen (eigene Rückfrage), Mittelklick pinnt; Umbau im Kampf wird nach dem Kampf nachgeholt
- Tafeln links und rechts neben der Karte (Platzhalter); Vorratsleiste rückt neben die rechte Tafel
- Mulde ersetzt durch Wurzelbogen über die oberste Tastenreihe; Wurzelbett links bis zur ersten Taste, rechts gespiegelt bis unter den Tracker; EP-Ranke direkt unter den Leisten

## 0.19.2
- Wurzel liegt ganz hinten; Chat-Schleier ohne harte Kanten (weicher Auslauf oben/rechts)
- Wurzelbett 240 hoch
- Wurzel umrankt den Questtracker (Strang + Eckknoten), Dicke einstellbar

## 0.19.1
- Wurzelbett links hinter Chat und Karte (Gemini-Grafik), Breite folgt den Leisten

## 0.19.0
- Wurzel: Strang, Kartenknoten, Mulde unter den Leisten, Triebe hinter Spieler/Ziel, Wurzelende rechts
- EP-Ranke in der Mulde mit Ausgeruht-Knospe und Tooltip; Blizzard-EP-Balken aus
- Leisten, Schwungtimer, Zauberbalken, Absteigen-Knopf ~20 höher
- Optionen: Kachel „Wurzel“, Startseite mit 5 Kacheln pro Reihe

## 0.18.x
- Eigene Stärkungen/Schwächungen oben rechts (größer, Restzeit, Schwächungsfarben, Rechtsklick entfernt außerhalb des Kampfes)
- Testmodus Stärkungen (je zwei Reihen)
- Kampfanzeige neu: „Kampf“ in Morpheus-Schrift, Ranken wachsen; „Kampf verlassen“, Ranken ziehen sich zurück

## 0.17.0
- Kampfanzeige mitten im Bild, gekreuzte Schwerter am Spielerfenster
- Testmodus für Gruppe und Schlachtzug

## 0.16.0
- Gruppenfenster (Gruppe + Schlachtzug), Klickzauber (Rechtsklick = Verjüngung, Editor in den Optionen)
- Mouseover-Aufkleber je Zauber und Gestalt (nur Freunde)
- Holzrahmen aus Einzelteilen (9-Slice) an Einheitenfenstern, Karte, Questtracker, Optionen
- Zahlen mit Tausenderpunkt, ab Million „M“; Absteigen-Knopf links neben Leiste 1

## 0.15.x
- Einheitenfenster: Spieler, Ziel (Stufen-Plakette, Elite-/Rare-Drache, Auren), Ziel des Ziels, Begleiter, Fokus
- Druiden-Mana in Gestalt, Kombopunkte; Aussehen einstellbar (Farbstärke, Hintergründe, Schrift)

## 0.14.0
- Wandeltasten-Kennzeichnung frei einstellbar (Rahmen/Ecke/Unterstrich/Blatt, Dicke, Aufleuchten)

## 0.13.x
- Eigener Tastenbelegungs-Modus (Strg/Alt/Shift, Maustasten, Mausrad)
- Vorratsleiste selbst bestücken (Item-ID, Name, Shift-Klick), Item-ID im Tooltip
- Addon-Beutel unten links in der Karte; Chat-Hintergrund einstellbar, Rechtsklick auf Chat-Reiter → Mondhain-Optionen

## 0.12.x
- Optionen als Bildübersicht mit Kacheln; Menüknopf (Rechtsklick Menü, Strg+Rechtsklick Reload)

## 0.11.x
- Schlanker Chat, Reiter Allgemein · Kampflog · Handel; Verfolgung/Post an der Karte

## 0.10.x
- Vorratsleiste, Parkleiste, Gestaltleiste, Tastenzahl je Leiste einstellbar
- Grundaufstellung, eckige Minikarte, Schwungtimer eingebunden

---

# Greifzeit
- 1.14.1 Historie: Start/Ziel robust erfasst, „»“ statt Pfeil, „?«-Einträge bereinigt
- 1.14.0 Erster Flug, Reiter Historie, /greif historie

## Greifzeit 1.16.0
- Flugtimer: im Flug ein kleines Fenster mit Ziel, Restzeit und Fortschrittsbalken in Fraktionsfarben; Dauer je Strecke aus früheren Flügen aller Charaktere (Ausreißer wie Ladebildschirme zählen nicht: dann gilt der schnellste Flug). Unbekannte Strecke: zählt hoch, ab dem nächsten Mal bekannt. Fenster mit der Maus verschiebbar; /greif timer an/aus, /greif timer reset

## Greifzeit 1.15.0
- Wappen-Abfrage am Flugmeister: neben den Hauptstädten „Andere …“ mit allen Fraktionen aus dem Ruf-Fenster (Menü nach Rubriken), dazu „Keins“
- Fraktions-Wappen: Hauptstadt-Fraktionen mit Stadtwappen, übrige mit passendem Spielsymbol (wird im Spiel auf Vorhandensein geprüft, sonst Ersatzsymbol)
- Flusslande/Riverglades: Vorschlag „Bruderschaft des Pferdes“; bisherige Antwort dort einmalig zurückgesetzt
- „ändern“ neben dem Wappen im Fenster und /greif hier: Wappen für das aktuelle Gebiet neu wählen

