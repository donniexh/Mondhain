-- Mondhain – Fundament
-- Alles läuft ereignisgesteuert: Code wird nur ausgeführt, wenn das Spiel etwas meldet.
-- Kein OnUpdate pro Bild, damit das Interface leicht bleibt.

local ADDON, ns = ...
ns.name = ADDON

-- Mondhain-Symbol (vorläufig) – an einer Stelle, damit ein neues Logo überall greift
ns.ICON = "Interface\\Icons\\Spell_Arcane_TeleportMoonglade"
-- Als Textsymbol für Menüs und Chat: ns.IconText(16) .. " Mondhain"
function ns.IconText(size)
    size = size or 16
    return ("|T%s:%d:%d:0:0:64:64:5:59:5:59|t"):format(ns.ICON, size, size)
end

---------------------------------------------------------------------------
-- Standardeinstellungen (werden mit den gespeicherten Werten zusammengeführt)
---------------------------------------------------------------------------
ns.defaults = {
    locked = true,
    formIndicator = {
        enabled = false, -- ersetzt durch die Gestaltleiste
        point = { "CENTER", "UIParent", "CENTER", 0, -180 },
        width = 180,
        height = 26,
    },
    questTracker = {
        enabled = true,
        point = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -12, 12 },
        width = 680,
        fontSize = 14,
        hideBlizzard = true, -- Blizzard-Questtracker rechts ausblenden
    },
    blizz = {}, -- Positionen/Größen von Mikromenü, Taschen, Erfahrung, Ruf …
    manageBlizz = true, -- Blizzard-Teile in Mondhain-Rahmen stecken
    minimap = { angle = 200, hide = false }, -- Mondhain-Knopf am Kartenrand
    chat = { -- schlanker Chat unten links, ohne Kasten
        enabled = true,
        width = 390,
        height = 150,
        point = { "BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 8, 8 },
        imStyle = true, -- Eingabezeile nur beim Schreiben
        bgAlpha = 40,          -- Hintergrund-Deckkraft in Prozent (0 = unsichtbar)
        bgColor = "schwarz",   -- Farbe des Hintergrunds
    },
    woodFrames = true, -- Holzrahmen um Fenster
    branch = { -- der Ast (Teldrassil): ein durchgehender Ast, darunter der Stamm
        enabled = true,
        thickness = 28,
        wave = 4,          -- Höhen und Tiefen
        palette = "mahagoni", -- Farbstimmung
        depth = true,      -- Schatten unter dem Ast, Glanzkante oben
        tendrils = true,   -- Ranken mit Schnörkeln
        fillAlpha = 100,   -- Deckkraft des Stamms
        fillBright = 85,   -- Helligkeit der Stammrinde
        tint = { 1, 1, 1 },
        moon = true,       -- Mondsichel auf der Krone
        leaves = true,     -- ein paar Blätter am Ast
        wisps = false,     -- Irrlichter darüber
        xpBranch = true,   -- Erfahrungs-Ast über den Quests, Liane wächst mit den EP
        repBranch = true,  -- Ruf-Ast darüber (blau-türkise Liane), wenn eine Fraktion verfolgt wird
        castBranch = true, -- Zauber-Ast: Zauberbalken zwischen Zweig und Ast (statt Blizzards Zauberleiste)
    },
    root = { -- die Wurzel am unteren Rand (nur ohne Ast)
        enabled = true,
        thickness = 24,    -- Dicke des Strangs
        bed = true,        -- dickes Wurzelbett links hinter Chat und Karte
        bedHeight = 240,   -- Höhe des Wurzelbetts (links, an der dicksten Stelle)
        questWrap = true,  -- Wurzel schlingt sich um den Questtracker
        wrapBoards = true, -- … und um die beiden Tafeln
        wrapThickness = 34,
        arch = false,      -- Wurzelbogen über die oberste Tastenreihe (aus: Mitte ruhiger)
        archHeight = 165,
        bedRight = true,   -- Wurzelbett auch rechts (bis unter den Questtracker)
        bedHeightRight = 180,
        knot = true,       -- Knoten um die Kartenecke
        shoots = false,    -- Triebe hinter Spieler und Ziel
        xp = false,        -- EP-Ranke in der Mulde (ersetzt durch den EP-Balken im Mittelblock)
        hideXPBar = true,  -- Blizzards EP-Balken ausblenden
    },
    auras = { -- eigene Stärkungen/Schwächungen oben rechts
        enabled = true,
        blizzardMode = true,   -- Blizzards Leiste nutzen (funktioniert auch im Kampf)
        healFirst = true,      -- Heilung/HoTs/Kurzes ganz links
        hideBlizzard = false,
        size = 40,
        perRow = 12,
        showTime = true,
        buffs   = { point = { "TOPRIGHT", "UIParent", "TOPRIGHT", -14, -14 } },
        debuffs = { point = { "TOPRIGHT", "UIParent", "TOPRIGHT", -14, -170 } },
    },
    levelUp = { enabled = true, sound = true, hideBlizzard = true },  -- Stufenaufstieg (Blitz, Stufe, Zeichen)
    levelUp = { enabled = true, hideBlizzard = true },   -- Stufenaufstieg (Ben 26.11.)
    combatAlert = {
        enabled = true,
        sound = false,
        textIn = "Kampf",
        textOut = "Kampf verlassen",
        point = { "CENTER", "UIParent", "CENTER", 0, 180 },
    },
    mouseover = {},    -- [Aktionsplatz] = true → Zauber wirkt per Mouseover auf Freunde
    healPrediction = true, -- eingehende Heilung/Schilde in Lebensbalken
    moveWindows = true,    -- Blizzard-Fenster verschiebbar (Plätze in windows)
    editModeFit = true,    -- HUD-Bearbeitungsmodus: Fensterhöhe an den Inhalt anpassen
    loot = {               -- Beute: automatisch plündern, Hinweise, Herkunft im Tooltip
        enabled = true,
        autoLoot = true,
        popups = true,
        tooltip = true,
        minQuality = 2,    -- Hinweis ab Grün (3 = Blau, 4 = Lila)
        history = {},
        origin = {},
    },
    watch = {              -- Wächter: Nachbuffen-Erinnerung, Zeiten am Gegner
        enabled = true,
        warnBefore = 30,   -- Sekunden Vorwarnung (außerhalb des Kampfs), 0 = aus
        rowHeight = 18,
        remind = {},       -- [key] = false → aus
        dots = {},
        learned = {},      -- echte Dauer je Zauber (gemessen, wenn lesbar)
        remindFrame = { point = { "CENTER", "UIParent", "CENTER", 0, 110 } },
        dotFrame = {},     -- ohne Platz: zwischen Spieler- und Zielrahmen
    },
    character = {          -- Charakterfenster: breiter, Mondhain-Look, Verzauberungen
        enabled = true,
        skin = true,
        enchants = true,
    },
    windows = {},
    tooltip = {        -- fester Platz für Tooltips, Mondhain-Look
        enabled = true,
        skin = true,
        ids = true,     -- IDs von Zaubern, Auren, Gegenständen, NPCs … im Tooltip
        point = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -16, 340 },
    },
    groupFrames = {
        enabled = true,
        hideBlizzard = true,
        showSolo = false, -- auch allein anzeigen (zum Einrichten)
        party = { w = 150, h = 34, point = { "BOTTOMRIGHT", "UIParent", "BOTTOM", -240, 124 } },
        raid  = { w = 58,  h = 30, point = { "BOTTOMRIGHT", "UIParent", "BOTTOM", -240, 216 } },
        clicks = {}, -- ["shift-2"] = "Zaubername" · Linksklick ist immer „anvisieren“
    },
    buttonBag = { enabled = true, hideButtons = true }, -- Addon-Beutel in der Karte, Einzelknöpfe weg
    menuButton = {
        enabled = true,
        point = { "BOTTOMRIGHT", "UIParent", "BOTTOMRIGHT", -12, 246 },
    },
    unitFrames = {
        enabled = true,
        hideBlizzard = true,
        mirror = true,     -- Ziel steht spiegelgleich zum Spieler
        look = {
            colorPct = 55,    -- Farbstärke der Balken in Prozent (gedämpft = besser lesbar)
            barBgAlpha = 70,  -- Hintergrund hinter den Balken
            frameAlpha = 85,  -- Hintergrund des ganzen Fensters
            fontSize = 13,    -- Schriftgröße (Name)
            outline = true,   -- dunkle Kontur um die Schrift
        },
        player       = { portrait = true, point = { "BOTTOMRIGHT", "UIParent", "BOTTOM", -240, 46 } },
        target       = { portrait = true, point = { "BOTTOMLEFT", "UIParent", "BOTTOM", 240, 46 } },
        targettarget = { enabled = true,  point = { "BOTTOMLEFT", "UIParent", "BOTTOM", 508, 46 } },
        pet          = { enabled = true,  point = { "BOTTOMLEFT", "UIParent", "BOTTOM", 240, 8 } },
        focus        = { enabled = false, point = { "BOTTOM", "UIParent", "BOTTOM", 0, 320 } },
        targetAuras  = {   -- Auren über dem Ziel
            size = 22,         -- Symbolgröße in Pixeln
            max = 16,          -- höchstens so viele
            debuffs = true,    -- Schwächungen zeigen
            onlyMine = false,  -- nur eigene Schwächungen
            buffs = true,      -- Stärkungen zeigen
            enemyDispel = false, -- bei Gegnern nur bannbare/stehlbare Stärkungen
            blizzard = true,   -- Blizzards Symbole übernehmen (aktualisieren sich auch im Kampf)
        },
    },
    minimapFrame = { -- die Minikarte selbst: eckig, frei platzierbar
        enabled = true,
        size = 200,
        boards = true,     -- Tafeln links und rechts neben der Karte
        boardWidth = 150,
        boardLeft = {},    -- eigene Position, sobald man eine Tafel verschiebt
        boardRight = {},
        point = { "BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 406, 8 },
    },
    centerBlock = { -- ruhiger Grund hinter den drei Leisten
        enabled = true,
        alpha = 88,
        wrap = true,            -- Wurzel um den Block
        stack = true,           -- Schwung/Zauber gestapelt direkt über dem Block
        matchWidth = true,      -- … und so breit wie die Leisten
        swingCombatOnly = true, -- Schwungtimer nur im Kampf
        swingSkin = true,       -- Schwungtimer im Mondhain-Look
        swingUnderPlayer = true, -- Schwungtimer direkt unter dem Spielerrahmen
        xp = true,              -- EP-Balken unten im Grund
    },
    actionBars = {
        enabled = true,
        hideBlizzard = true,
        hotkeys = true,    -- Tastenkürzel auf den Tasten zeigen
        hotkeySize = 9,
        center = { point = { "BOTTOM", "UIParent", "BOTTOM", 0, 8 }, scale = 1.25 },
        park = { enabled = true, point = { "BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 8, 330 } },
        counts = { bar1 = 8, bar2 = 9, bar3 = 9, park = 12 }, -- Tasten je Leiste (1–12)
        wandel = {}, -- ["Leiste:Taste"] = { cat = Platz, prowl = …, bear = …, moonkin = … }
        -- Wie Wandeltasten gekennzeichnet werden (frei einstellbar)
        wandelLook = {
            mark = "frame",   -- frame · corner · line · leaf · none
            thickness = 2,    -- Rahmen-/Liniendicke in Pixeln (1–4)
            flash = true,     -- beim Gestaltwechsel aufleuchten
            flashAlpha = 85,  -- Helligkeit in Prozent
            flashTime = 9,    -- Dauer in Zehntelsekunden
        },
    },
    stanceBar = {
        enabled = true,
        inBoard = true, -- sitzt in der rechten Tafel (bis man sie selbst verschiebt)
        point = { "BOTTOM", "UIParent", "BOTTOM", 0, 160 },
    },
    merchant = { -- Händlerliste mit Suche, Filter, Sortierung
        enabled = true,
        filter = "all",
        sort = "default",
    },
    itemBar = {
        enabled = true,
        point = { "BOTTOMLEFT", "UIParent", "BOTTOM", -420, 8 },
        vertical = true,
        max = 8,
        -- Automatisch auffüllen ist aus: die Leiste zeigt, was du selbst einträgst
        cats = { potion = false, stone = false, food = false, bandage = false, quest = false, elixir = false, other = false },
        showID = true, -- Item-ID im Tooltip
        pinned = {}, -- [itemID] = Reihenfolge  → zeigen, sobald im Inventar
        hidden = {}, -- [itemID] = true  → nie zeigen
    },
    questHelp = {      -- Questhilfe (Stufe, beste Belohnung, Gruppe)
        enabled = true,
        bestReward = true,
        party = true,      -- im Questlog zeigen, wer aus der Gruppe die Quest hat
        announce = true,   -- Fortschritt eigener Quests melden (Hauptschalter)
        announceAccept = true,     -- „Quest angenommen: [Titel]“ (ohne Details)
        announceProgress = false,  -- Zwischenstände (3/8 …)
        announceDone = true,       -- „Quest fertig“, wenn alle Ziele erfüllt
        announceSelf = false,  -- … nur im eigenen Chat (wenn nicht ohnehin in einen Kanal)
        announceParty = true,  -- … an die Gruppe
        announceRaid = false,  -- … an den Schlachtzug
        autoAccept = true, -- Quests automatisch annehmen (Shift = diesmal nicht)
        autoTurnIn = true, -- Quests automatisch abgeben (bei Belohnungswahl wählst du)
    },
}

local function merge(target, source)
    for k, v in pairs(source) do
        if type(v) == "table" then
            if type(target[k]) ~= "table" then target[k] = {} end
            merge(target[k], v)
        elseif target[k] == nil then
            target[k] = v
        end
    end
end

---------------------------------------------------------------------------
-- Ausgabe im Chat
---------------------------------------------------------------------------
function ns.Print(...)
    print("|cffff7c0aMondhain|r:", ...)
end

---------------------------------------------------------------------------
-- Interne Nachrichten (z. B. "FORM_CHANGED"), damit Module sich nicht
-- gegenseitig kennen müssen. Wie ein schwarzes Brett im Hain.
---------------------------------------------------------------------------
local listeners = {}

function ns.On(message, func)
    listeners[message] = listeners[message] or {}
    table.insert(listeners[message], func)
end

function ns.Fire(message, ...)
    local list = listeners[message]
    if not list then return end
    for i = 1, #list do
        list[i](...)
    end
end

---------------------------------------------------------------------------
-- Module
---------------------------------------------------------------------------
ns.modules = {}

function ns.NewModule(name)
    local mod = { name = name }
    ns.modules[#ns.modules + 1] = mod
    return mod
end

---------------------------------------------------------------------------
-- Verschieben
-- Jedes Element bekommt eine blaue Schablone, die nur erscheint, wenn
-- Blizzards Bearbeitungsmodus offen ist oder per /mh unlock entsperrt wurde.
-- Die Schablone liegt über dem Element und dient als Griff zum Ziehen.
---------------------------------------------------------------------------
local movers = {}

-- Rechtsklick auf eine Schablone öffnet die passende Optionsseite
local MOVER_PAGES = {
    ["Aktionsleisten"] = "bars", ["Parkleiste"] = "bars", ["Absteigen"] = "bars", ["Begleiterleiste"] = "bars",
    ["Gestaltleiste"] = "forms", ["Gestalt"] = "forms",
    ["Vorratsleiste"] = "items",
    ["Minikarte"] = "map", ["Linke Tafel"] = "map", ["Rechte Tafel"] = "map",
    ["Chat"] = "chat",
    ["Questtracker"] = "quests",
    ["Spieler"] = "units", ["Ziel"] = "units", ["Ziel des Ziels"] = "units", ["Begleiter"] = "units", ["Fokus"] = "units",
    ["Gruppe"] = "group", ["Schlachtzug"] = "group",
    ["Kampfanzeige"] = "combat",
    ["Erfahrung"] = "root",
    ["Tooltip"] = "layout",
    ["Beute-Hinweise"] = "loot",
    ["Zauber-Medaillon"] = "branch",
    ["Nachbuffen"] = "watch", ["Zeiten am Gegner"] = "watch",
    ["Zauberleiste"] = "center", ["Schwung Waffenhand"] = "center",
    ["Schwung Schildhand"] = "center", ["Schwung Distanz"] = "center",
}
local function moverPage(label)
    if MOVER_PAGES[label] then return MOVER_PAGES[label] end
    if label:find("Stärkung") or label:find("Schwächung") then return "auras" end
    return "layout"
end
ns.MoverPages = MOVER_PAGES

local selectMover   -- (unten definiert)
local function updateMovers()
    local show = ns.db and not ns.db.locked
    for i = 1, #movers do
        movers[i]:SetShown(show)
    end
    if not show and selectMover then selectMover(nil) end
end

---------------------------------------------------------------------------
-- Feinschliff mit den Pfeiltasten: Schablone anklicken (goldener Rand), dann
-- Pfeiltasten = 1 Pixel, Umschalt + Pfeil = 10 Pixel. Esc oder Klick ins
-- Leere hebt die Auswahl auf. Andere Tasten gehen normal ans Spiel weiter.
---------------------------------------------------------------------------
local selected
local nudger = CreateFrame("Frame", "MondhainNudger", UIParent)
nudger:EnableKeyboard(false)
local ARROWS = { UP = { 0, 1 }, DOWN = { 0, -1 }, LEFT = { -1, 0 }, RIGHT = { 1, 0 } }

function selectMover(m)
    if selected and selected ~= m then
        selected.edgeTex:SetColorTexture(0.20, 0.34, 0.50, 0.85)
        selected.isSel = nil
        if selected.refresh then selected.refresh() end
    end
    selected = m
    if m then
        m.edgeTex:SetColorTexture(1, 0.80, 0.25, 1)
        m.isSel = true
        if m.refresh then m.refresh() end
    end
    if not InCombatLockdown() then
        nudger:EnableKeyboard(m ~= nil)
        if nudger.SetPropagateKeyboardInput then nudger:SetPropagateKeyboardInput(true) end
    end
end

nudger:SetScript("OnKeyDown", function(self, key)
    local d = ARROWS[key]
    local m = selected
    local pass = true
    if m and key == "ESCAPE" then
        selectMover(nil)
        pass = false
    elseif m and d and not InCombatLockdown() then
        pass = false
        m.nudge(d[1] * (IsShiftKeyDown() and 10 or 1), d[2] * (IsShiftKeyDown() and 10 or 1))
    end
    if self.SetPropagateKeyboardInput and not InCombatLockdown() then
        self:SetPropagateKeyboardInput(pass)
    end
end)
-- (eigenes Ereignis: ns.RegisterEvent gibt es an dieser Stelle der Datei noch nicht)
nudger:RegisterEvent("PLAYER_REGEN_DISABLED")
nudger:SetScript("OnEvent", function() if selected then selectMover(nil) end end)

-- Schablone: Linke Maustaste ziehen = verschieben, Mausrad = Größe,
-- Rechtsklick = Einstellungen dieses Bereichs, Umschalt + Rechtsklick = Größe 100 %.
-- Die Größe wird als db.scale gespeichert.
-- noScale: nur verschieben (z. B. Chat – dessen Größe kommt aus den Optionen)
-- sizer (optional): { set = function(w, h), minW, minH } → im Bearbeiten-Modus
-- lässt sich das Element an jedem Rand einzeln ziehen (links, rechts, oben, unten)
function ns.MakeMovable(frame, db, label, onMoved, noScale, sizer)
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    if db.scale then frame:SetScale(db.scale) end

    local m = CreateFrame("Frame", nil, frame)
    m:SetAllPoints()
    m:SetFrameLevel(frame:GetFrameLevel() + 20)
    -- unter Optionen und Dialogen; nur wenn das Element selbst höher liegt, mit ihm
    local ORDER = { BACKGROUND = 1, LOW = 2, MEDIUM = 3, HIGH = 4, DIALOG = 5, FULLSCREEN = 6,
        FULLSCREEN_DIALOG = 7, TOOLTIP = 8 }
    local fs = frame:GetFrameStrata()
    m:SetFrameStrata((ORDER[fs] or 0) > 4 and fs or "HIGH")

    local bg = m:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.08, 0.17, 0.28, 0.50)

    local edge = m:CreateTexture(nil, "BORDER")
    edge:SetPoint("TOPLEFT", -1, 1)
    edge:SetPoint("BOTTOMRIGHT", 1, -1)
    edge:SetColorTexture(0.20, 0.34, 0.50, 0.85)
    edge:SetDrawLayer("BACKGROUND", -1)
    m.edgeTex = edge

    local text = m:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    text:SetPoint("CENTER")
    local function updateText()
        local base = noScale and label
            or ("%s  |cff8fa8c4%d%%|r"):format(label, math.floor((db.scale or 1) * 100 + 0.5))
        if m.isSel then
            local l, b = frame:GetLeft(), frame:GetBottom()
            if l and b then
                local k = frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
                base = base .. ("\n|cffffd100%d, %d|r  |cff8fa8c4Pfeiltasten|r"):format(l * k, b * k)
            end
        end
        text:SetText(base)
    end
    m.refresh = updateText
    updateText()

    -- Pfeiltasten: um dx/dy Pixel (UI-Einheiten) schieben und wie nach dem Ziehen merken
    function m.nudge(dx, dy)
        if InCombatLockdown() and frame:IsProtected() then return end
        local l, b = frame:GetLeft(), frame:GetBottom()
        if not (l and b) then return end
        local k = UIParent:GetEffectiveScale() / frame:GetEffectiveScale()
        frame:ClearAllPoints()
        frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", l + dx * k, b + dy * k)
        db.point = { "BOTTOMLEFT", "UIParent", "BOTTOMLEFT", l + dx * k, b + dy * k }
        if onMoved then onMoved() end
        updateText()
    end

    local function blocked()
        if InCombatLockdown() and frame:IsProtected() then
            ns.Print("Im Kampf nicht möglich.")
            return true
        end
    end

    m:EnableMouse(true)
    m:RegisterForDrag("LeftButton")
    m:SetScript("OnDragStart", function()
        if blocked() then return end
        frame.mhMoving = true
        frame:StartMoving()
    end)
    m:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        frame.mhMoving = nil
        local p, _, rp, x, y = frame:GetPoint()
        db.point = { p, "UIParent", rp, x, y }
        if onMoved then onMoved() end
        selectMover(m)
        updateText()
    end)
    m:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" then selectMover(m) end
    end)

    -- Ränder ziehen (Ben 26.11. 05:26: links, rechts, oben, unten einzeln):
    -- die gegenüberliegende Kante bleibt stehen
    if sizer then
        local GRIP = 10
        local function grip(side)
            local g = CreateFrame("Frame", nil, m)
            g:SetFrameLevel(m:GetFrameLevel() + 5)
            if side == "LEFT" or side == "RIGHT" then
                g:SetPoint("TOP" .. side, m, "TOP" .. side, side == "LEFT" and -4 or 4, -GRIP)
                g:SetPoint("BOTTOM" .. side, m, "BOTTOM" .. side, side == "LEFT" and -4 or 4, GRIP)
                g:SetWidth(GRIP)
            else
                g:SetPoint(side .. "LEFT", m, side .. "LEFT", GRIP, side == "TOP" and 4 or -4)
                g:SetPoint(side .. "RIGHT", m, side .. "RIGHT", -GRIP, side == "TOP" and 4 or -4)
                g:SetHeight(GRIP)
            end
            local t = g:CreateTexture(nil, "OVERLAY")
            t:SetAllPoints()
            t:SetColorTexture(1, 0.82, 0.2, 0.18)
            g:EnableMouse(true)
            g:SetScript("OnEnter", function(self)
                t:SetColorTexture(1, 0.82, 0.2, 0.7)
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:AddLine(label, 1, 0.82, 0)
                GameTooltip:AddLine((side == "LEFT" or side == "RIGHT") and "Ziehen: Breite (nur diese Seite)"
                    or "Ziehen: Höhe (nur diese Seite)", 0.8, 0.8, 0.8)
                GameTooltip:Show()
            end)
            g:SetScript("OnLeave", function()
                if not g.start then t:SetColorTexture(1, 0.82, 0.2, 0.18) end
                GameTooltip:Hide()
            end)
            g:SetScript("OnMouseDown", function(_, button)
                if button ~= "LeftButton" or blocked() then return end
                local l, b, w, h = frame:GetLeft(), frame:GetBottom(), frame:GetWidth(), frame:GetHeight()
                if not (l and b and w and h) then return end
                local es = frame:GetEffectiveScale()
                local cx, cy = GetCursorPosition()
                g.start = { cx / es, cy / es, l, b, w, h, es }
                frame.mhMoving = true
                selectMover(m)
                g:SetScript("OnUpdate", function()
                    local st = g.start
                    if not st then return end
                    local x, y = GetCursorPosition()
                    local dx, dy = x / st[7] - st[1], y / st[7] - st[2]
                    local nl, nb, nw, nh = st[3], st[4], st[5], st[6]
                    local minW, minH = sizer.minW or 40, sizer.minH or 30
                    if side == "LEFT" then
                        nw = math.max(minW, st[5] - dx); nl = st[3] + st[5] - nw
                    elseif side == "RIGHT" then
                        nw = math.max(minW, st[5] + dx)
                    elseif side == "TOP" then
                        nh = math.max(minH, st[6] + dy)
                    else
                        nh = math.max(minH, st[6] - dy); nb = st[4] + st[6] - nh
                    end
                    frame:ClearAllPoints()
                    frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", nl, nb)
                    sizer.set(math.floor(nw + 0.5), math.floor(nh + 0.5))
                end)
            end)
            g:SetScript("OnMouseUp", function()
                g:SetScript("OnUpdate", nil)
                if not g.start then return end
                g.start = nil
                t:SetColorTexture(1, 0.82, 0.2, 0.18)
                frame.mhMoving = nil
                local l, b = frame:GetLeft(), frame:GetBottom()
                if l and b then db.point = { "BOTTOMLEFT", "UIParent", "BOTTOMLEFT", l, b } end
                if onMoved then onMoved() end
                updateText()
            end)
        end
        for _, side in ipairs({ "LEFT", "RIGHT", "TOP", "BOTTOM" }) do grip(side) end
    end

    m:EnableMouseWheel(true)
    m:SetScript("OnMouseWheel", function(_, delta)
        if noScale then return end
        if blocked() then return end
        local s = (db.scale or 1) + delta * 0.05
        if s < 0.4 then s = 0.4 elseif s > 2.5 then s = 2.5 end
        db.scale = s
        frame:SetScale(s)
        updateText()
    end)
    m:SetScript("OnMouseUp", function(_, button)
        if button ~= "RightButton" then return end
        if not IsShiftKeyDown() then
            if ns.OpenOptions then ns.OpenOptions(moverPage(label)) end
            return
        end
        if noScale or blocked() then return end
        db.scale = nil
        frame:SetScale(1)
        updateText()
    end)
    m:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(label, 1, 0.82, 0)
        GameTooltip:AddLine("Ziehen: verschieben", 0.8, 0.8, 0.8)
        if sizer then GameTooltip:AddLine("Gelbe Ränder ziehen: Breite/Höhe je Seite", 0.8, 0.8, 0.8) end
        GameTooltip:AddLine("Anklicken, dann Pfeiltasten: 1 Pixel (Umschalt: 10)", 0.8, 0.8, 0.8)
        if noScale then
            GameTooltip:AddLine("Größe: in den Optionen", 0.8, 0.8, 0.8)
        else
            GameTooltip:AddLine("Mausrad: Größe", 0.8, 0.8, 0.8)
            GameTooltip:AddLine("Umschalt + Rechtsklick: Größe 100 %", 0.8, 0.8, 0.8)
        end
        GameTooltip:AddLine("Rechtsklick: Einstellungen", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    m:SetScript("OnLeave", GameTooltip_Hide)

    m:Hide()
    movers[#movers + 1] = m
    updateMovers()
end

---------------------------------------------------------------------------
-- Verschiebe-Modus mit Hinweiskasten (/mh unlock, Optionen)
---------------------------------------------------------------------------
local banner
local function buildBanner()
    banner = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    banner:SetSize(520, 64)
    banner:SetPoint("TOP", 0, -120)
    banner:SetFrameStrata("FULLSCREEN_DIALOG")
    banner:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    banner:SetBackdropColor(0.05, 0.06, 0.08, 0.95)
    banner:SetBackdropBorderColor(0.20, 0.34, 0.50, 0.9)

    local t = banner:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOPLEFT", 14, -10)
    t:SetText("Verschieben & Größe")
    t:SetTextColor(0.62, 0.74, 0.88)

    local d = banner:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -6)
    d:SetText("Ziehen = verschieben  ·  Anklicken + Pfeiltasten = 1 px (Umschalt 10)  ·  Mausrad = Größe  ·  Rechtsklick = Einstellungen")

    local done = CreateFrame("Button", nil, banner, "UIPanelButtonTemplate")
    done:SetSize(80, 22)
    done:SetPoint("RIGHT", -10, 0)
    done:SetText("Fertig")
    done:SetScript("OnClick", function() ns.SetUnlocked(false) end)
    banner:Hide()
end

function ns.SetUnlocked(on)
    if on and InCombatLockdown() then
        ns.Print("Im Kampf nicht möglich.")
        return
    end
    ns.db.locked = not on
    if not banner then buildBanner() end
    banner:SetShown(on)
    ns.Fire("LOCK_CHANGED", not on)
end

ns.On("LOCK_CHANGED", updateMovers)

---------------------------------------------------------------------------
-- Gemeinsames Aussehen für kleine Tasten (Gestaltleiste, Vorratsleiste)
-- Dunkler Holzrahmen, Symbol, Abklingzeit, Zahl unten rechts.
---------------------------------------------------------------------------
-- Geldbetrag mit Münzsymbolen (Forever hat GetCoinTextureString nicht mehr global)
local GOLD = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t"
local SILVER = "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t"
local COPPER = "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t"
function ns.CoinString(c)
    c = math.floor(math.abs(c or 0))
    if C_CurrencyInfo and C_CurrencyInfo.GetCoinTextureString then
        local ok, s = pcall(C_CurrencyInfo.GetCoinTextureString, c)
        if ok and s then return s end
    end
    if GetCoinTextureString then return GetCoinTextureString(c) end
    local g, s, k = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    local out = {}
    if g > 0 then out[#out + 1] = (ns.FormatNumber and ns.FormatNumber(g) or g) .. GOLD end
    if s > 0 or g > 0 then out[#out + 1] = s .. SILVER end
    out[#out + 1] = k .. COPPER
    return table.concat(out, " ")
end

-- Ast an? Dann treten Wurzel, Holzrahmen und Umrankungen am unteren Rand zurück
function ns.UseBranch()
    return ns.db and ns.db.branch and ns.db.branch.enabled and true or false
end

-- Tastenkürzel klein und gedämpft in der Ecke
function ns.StyleHotKey(fs)
    local file = (NumberFontNormalSmall and NumberFontNormalSmall:GetFont()) or STANDARD_TEXT_FONT
    local ab = ns.db and ns.db.actionBars
    fs:SetFont(file, (ab and ab.hotkeySize) or 9, "OUTLINE")
    fs:SetTextColor(0.72, 0.72, 0.66)
    fs:SetAlpha(0.85)
    fs:ClearAllPoints()
    fs:SetPoint("TOPRIGHT", -2, -2)
end

-- Tastenkürzel zeigen? (Optionen → Aktionsleisten)
function ns.ShowHotKeys()
    return not (ns.db and ns.db.actionBars and ns.db.actionBars.hotkeys == false)
end

function ns.SkinButton(b, size)
    local WHITE = "Interface\\Buttons\\WHITE8x8"
    b:SetSize(size, size)

    b.border = b:CreateTexture(nil, "BACKGROUND", nil, -2)
    b.border:SetAllPoints()
    b.border:SetColorTexture(unpack(ns.colors.border))

    local slotBg = b:CreateTexture(nil, "BACKGROUND", nil, -1)
    slotBg:SetPoint("TOPLEFT", 1, -1)
    slotBg:SetPoint("BOTTOMRIGHT", -1, 1)
    slotBg:SetColorTexture(0.05, 0.06, 0.08, 0.85)

    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 1, -1)
    b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b.icon)
    b.cooldown:SetDrawEdge(false)

    local textLayer = CreateFrame("Frame", nil, b)
    textLayer:SetAllPoints()
    textLayer:SetFrameLevel(b.cooldown:GetFrameLevel() + 2)
    b.Count = textLayer:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    b.Count:SetPoint("BOTTOMRIGHT", -2, 2)
    b.HotKey = textLayer:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmallGray")
    b.HotKey:SetPoint("TOPRIGHT", -2, -3)
    b.HotKey:SetWidth(size - 4)
    b.HotKey:SetJustifyH("RIGHT")
    b.HotKey:SetWordWrap(false)
    ns.StyleHotKey(b.HotKey)

    b:SetHighlightTexture(WHITE)
    b:GetHighlightTexture():SetAllPoints(b.icon)
    b:GetHighlightTexture():SetVertexColor(1, 1, 1, 0.15)
    b:SetPushedTexture(WHITE)
    b:GetPushedTexture():SetAllPoints(b.icon)
    b:GetPushedTexture():SetVertexColor(1, 0.85, 0.4, 0.25)
end

-- Rahmen finden, die einen Text zeigen oder deren Name ihn enthält (/mh suche)
function ns.FindFrames(what)
    what = what:lower()
    local hits = 0
    local function chain(f)
        local parts, cur, depth = {}, f, 0
        while cur and cur ~= UIParent and depth < 6 do
            parts[#parts + 1] = cur:GetName() or ("(ohne Namen: " .. (cur:GetObjectType() or "?") .. ")")
            cur = cur:GetParent()
            depth = depth + 1
        end
        return table.concat(parts, "  <  ")
    end
    local f = EnumerateFrames()
    while f and hits < 15 do
        local name = f.GetName and f:GetName()
        local found = name and name:lower():find(what, 1, true)
        if not found and f.GetRegions then
            for _, r in ipairs({ f:GetRegions() }) do
                if r.GetObjectType and r:GetObjectType() == "FontString" then
                    local ok, t = pcall(r.GetText, r)
                    if ok and type(t) == "string" and not ns.isSecret(t) and t:lower():find(what, 1, true) then
                        found = true
                        break
                    end
                end
            end
        end
        if found then
            hits = hits + 1
            ns.Print("|cffffd100" .. chain(f) .. "|r" .. (f:IsShown() and "" or " |cff888888(versteckt)|r"))
        end
        f = EnumerateFrames(f)
    end
    if hits == 0 then ns.Print("Nichts gefunden zu: " .. what) end
end

---------------------------------------------------------------------------
-- Holzrahmen aus Einzelteilen (9-Slice): vier feste Ecken, vier dehnbare
-- Leisten. Wie ein Bilderrahmen aus der Werkstatt – das Fenster darf jede
-- Größe haben, die Ecken bleiben scharf.
---------------------------------------------------------------------------
local WOOD = "Interface\\AddOns\\Mondhain\\media\\holzrahmen"
local WOOD_PARTS = { -- Ausschnitte auf dem Teile-Blatt (256 x 256)
    tl = { 0, 0.25, 0, 0.25 },     tr = { 0.25, 0.5, 0, 0.25 },
    bl = { 0.5, 0.75, 0, 0.25 },   br = { 0.75, 1, 0, 0.25 },
    top = { 0, 0.5, 0.25, 0.5 },   bottom = { 0.5, 1, 0.25, 0.5 },
    left = { 0, 0.25, 0.5, 1 },    right = { 0.25, 0.5, 0.5, 1 },
}
local BAND = 21 / 64 -- Mitte des Holzstrangs im Eckstück

local woodFrames = {}

local function layoutWood(w)
    local f = w.owner
    local minDim = math.min(f:GetWidth(), f:GetHeight())
    local c = math.max(8, math.min(w.size, minDim / 1.34))
    local o = c * BAND
    local p = w.parts
    for _, k in ipairs({ "tl", "tr", "bl", "br" }) do p[k]:SetSize(c, c) end
    p.tl:SetPoint("TOPLEFT", f, "TOPLEFT", -o, o)
    p.tr:SetPoint("TOPRIGHT", f, "TOPRIGHT", o, o)
    p.bl:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", -o, -o)
    p.br:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", o, -o)
end

-- frame: das Fenster · size: Kantenlänge der Eckstücke (Standard 20)
function ns.WoodFrame(frame, size)
    if frame.mondhainWood then return frame.mondhainWood end
    local holder = CreateFrame("Frame", nil, frame)
    holder:SetAllPoints()
    holder:SetFrameLevel(frame:GetFrameLevel() + 4)
    local w = { owner = frame, size = size or 20, parts = {}, holder = holder }
    for key, tc in pairs(WOOD_PARTS) do
        local t = holder:CreateTexture(nil, "OVERLAY", nil, 5)
        t:SetTexture(WOOD)
        t:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
        w.parts[key] = t
    end
    local p = w.parts
    p.top:SetPoint("TOPLEFT", p.tl, "TOPRIGHT");     p.top:SetPoint("BOTTOMRIGHT", p.tr, "BOTTOMLEFT")
    p.bottom:SetPoint("TOPLEFT", p.bl, "TOPRIGHT");  p.bottom:SetPoint("BOTTOMRIGHT", p.br, "BOTTOMLEFT")
    p.left:SetPoint("TOPLEFT", p.tl, "BOTTOMLEFT");  p.left:SetPoint("BOTTOMRIGHT", p.bl, "TOPRIGHT")
    p.right:SetPoint("TOPLEFT", p.tr, "BOTTOMLEFT"); p.right:SetPoint("BOTTOMRIGHT", p.br, "TOPRIGHT")
    layoutWood(w)
    frame:HookScript("OnSizeChanged", function() layoutWood(w) end)
    holder:SetShown(not ns.db or ns.db.woodFrames ~= false)
    frame.mondhainWood = w
    woodFrames[#woodFrames + 1] = w
    return w
end

---------------------------------------------------------------------------
-- Eingehende Heilung, Schilde und Heil-Absorbs an einem Lebensbalken
-- Die Balken hängen jeweils an der Füllkante des vorigen (Leben → eigene
-- Heilung → fremde Heilung → Schild). So rechnet das Spiel die Breiten selbst –
-- das klappt auch im Kampf, wenn Forever die Werte geheim hält.
---------------------------------------------------------------------------
local PRED_WHITE = "Interface\\Buttons\\WHITE8x8"
function ns.AttachHealPrediction(health)
    if health.mhPred then return health.mhPred end
    local clip = CreateFrame("Frame", nil, health)
    clip:SetAllPoints()
    clip:SetClipsChildren(true) -- Überheilung ragt nicht aus dem Balken
    clip:SetFrameLevel(health:GetFrameLevel() + 1)
    -- Schrift über die Vorschau heben
    local top = CreateFrame("Frame", nil, health)
    top:SetAllPoints()
    top:SetFrameLevel(health:GetFrameLevel() + 2)
    for _, r in ipairs({ health:GetRegions() }) do
        if r.GetObjectType and r:GetObjectType() == "FontString" then r:SetParent(top) end
    end
    local function bar(r, g, b, a, reverse)
        local s = CreateFrame("StatusBar", nil, clip)
        s:SetStatusBarTexture(PRED_WHITE)
        s:SetStatusBarColor(r, g, b, a)
        if reverse then s:SetReverseFill(true) end
        s:SetMinMaxValues(0, 1)
        s:SetValue(0)
        return s
    end
    local fill = health:GetStatusBarTexture()
    local P = { clip = clip, text = top }
    P.mine = bar(0.55, 1.00, 0.50, 0.60)          -- eigene Heilung: kräftig
    P.mine:SetPoint("TOPLEFT", fill, "TOPRIGHT")
    P.mine:SetPoint("BOTTOMLEFT", fill, "BOTTOMRIGHT")
    P.other = bar(0.25, 0.75, 0.35, 0.50)         -- fremde Heilung: blasser
    P.other:SetPoint("TOPLEFT", P.mine:GetStatusBarTexture(), "TOPRIGHT")
    P.other:SetPoint("BOTTOMLEFT", P.mine:GetStatusBarTexture(), "BOTTOMRIGHT")
    P.absorb = bar(0.85, 0.95, 1.00, 0.45)        -- Schild: heller Schimmer
    P.absorb:SetPoint("TOPLEFT", P.other:GetStatusBarTexture(), "TOPRIGHT")
    P.absorb:SetPoint("BOTTOMLEFT", P.other:GetStatusBarTexture(), "BOTTOMRIGHT")
    P.healAbs = bar(0.40, 0.02, 0.05, 0.80, true) -- Heil-Absorb: dunkelrot im Leben
    P.healAbs:SetPoint("TOPRIGHT", fill, "TOPRIGHT")
    P.healAbs:SetPoint("BOTTOMRIGHT", fill, "BOTTOMRIGHT")
    -- Überheilung: helle Kante am rechten Rand (nur wenn die Werte lesbar sind)
    P.over = clip:CreateTexture(nil, "OVERLAY")
    P.over:SetTexture(PRED_WHITE)
    P.over:SetVertexColor(0.7, 1, 0.6, 0.9)
    P.over:SetPoint("TOPRIGHT")
    P.over:SetPoint("BOTTOMRIGHT")
    P.over:SetWidth(2)
    P.over:Hide()
    local function size()
        local w = health:GetWidth()
        if ns.isSecret(w) or not w or w <= 0 then return end
        for _, k in ipairs({ "mine", "other", "absorb", "healAbs" }) do P[k]:SetWidth(w) end
    end
    health:HookScript("OnSizeChanged", size)
    size()
    health.mhPred = P
    return P
end

-- nil → 0, ohne den Wert anzufassen (geheime Werte dürfen nicht geprüft werden)
local function nz(v) if type(v) == "nil" then return 0 end return v end

local function predGet(fn, ...)
    if not fn then return nil end
    local ok, v = pcall(fn, ...)
    if ok then return v end
end

function ns.UpdateHealPrediction(health, u)
    local P = health.mhPred
    if not P then return end
    if not u or not UnitExists(u) or (ns.db and ns.db.healPrediction == false) then
        for _, k in ipairs({ "mine", "other", "absorb", "healAbs" }) do P[k]:SetValue(0) end
        P.over:Hide()
        return
    end
    local maxHP = predGet(UnitHealthMax, u)
    if type(maxHP) == "nil" then maxHP = 1 end
    local all = predGet(UnitGetIncomingHeals, u)
    local mine = predGet(UnitGetIncomingHeals, u, "player")
    local absorb = predGet(UnitGetTotalAbsorbs, u)
    local healAbs = predGet(UnitGetTotalHealAbsorbs, u)
    for _, k in ipairs({ "mine", "other", "absorb", "healAbs" }) do pcall(P[k].SetMinMaxValues, P[k], 0, maxHP) end
    local readable = not (ns.isSecret(all) or ns.isSecret(mine))
    if readable then
        all, mine = all or 0, mine or 0
        if mine > all then mine = all end
        pcall(P.mine.SetValue, P.mine, mine)
        pcall(P.other.SetValue, P.other, all - mine)
    else
        -- geheim: alles in einem Abschnitt (Aufteilen bräuchte eine Rechnung)
        if not pcall(P.mine.SetValue, P.mine, nz(all)) then P.mine:SetValue(0) end
        P.other:SetValue(0)
    end
    if not pcall(P.absorb.SetValue, P.absorb, nz(absorb)) then P.absorb:SetValue(0) end
    if not pcall(P.healAbs.SetValue, P.healAbs, nz(healAbs)) then P.healAbs:SetValue(0) end
    local ok, over = pcall(function()
        local cur = UnitHealth(u) or 0
        return cur + (all or 0) + (absorb or 0) > maxHP and ((all or 0) + (absorb or 0)) > 0
    end)
    P.over:SetShown(ok and over and true or false)
end

-- Tooltip seitlich neben einen Knopf setzen, zur Bildschirmmitte hin
-- (nie über den Knopf, auch nicht am Bildschirmrand)
function ns.TooltipBeside(owner)
    GameTooltip:SetOwner(owner, "ANCHOR_NONE")
    GameTooltip:ClearAllPoints()
    local cx, cy = owner:GetCenter()
    local W, H = UIParent:GetWidth(), UIParent:GetHeight()
    local s = owner:GetEffectiveScale() / UIParent:GetEffectiveScale()
    cx, cy = (cx or 0) * s, (cy or 0) * s
    local v = (cy > H / 2) and "TOP" or "BOTTOM"
    if cx < W / 2 then
        GameTooltip:SetPoint(v .. "LEFT", owner, v .. "RIGHT", 8, 0)
    else
        GameTooltip:SetPoint(v .. "RIGHT", owner, v .. "LEFT", -8, 0)
    end
end

-- Holzrahmen an/aus (Optionen)
function ns.SetWoodShown(on)
    for _, w in ipairs(woodFrames) do w.holder:SetShown(on) end
end

-- Tastennamen kurz machen: ALT-Q → a-Q, MOUSEWHEELDOWN → MwD, BUTTON4 → M4
function ns.ShortKey(key)
    if not key then return "" end
    local k = key:upper()
    k = k:gsub("ALT%-", "a-"):gsub("CTRL%-", "c-"):gsub("SHIFT%-", "s-")
    k = k:gsub("MOUSEWHEELUP", "MwU"):gsub("MOUSEWHEELDOWN", "MwD")
    k = k:gsub("MIDDLEMOUSE", "M3"):gsub("BUTTON(%d+)", "M%1")
    k = k:gsub("NUMPADPLUS", "N+"):gsub("NUMPADMINUS", "N-"):gsub("NUMPAD", "N")
    k = k:gsub("SPACE", "Spc"):gsub("ESCAPE", "Esc"):gsub("BACKSPACE", "Bs")
    k = k:gsub("PAGEUP", "PgU"):gsub("PAGEDOWN", "PgD"):gsub("INSERT", "Ins"):gsub("DELETE", "Del")
    return k
end

-- Geheime Werte (Midnight-Regeln) erkennen, ohne sie zu vergleichen
ns.isSecret = issecretvalue or function() return false end

-- Kleiner Hinweiskasten oben mit „Fertig“-Knopf (Wandeltasten, Vorrat …)
function ns.MakeBanner(title, desc, r, g, b, onDone)
    local f = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    f:SetSize(500, 64)
    f:SetPoint("TOP", 0, -120)
    f:SetFrameStrata("DIALOG")
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    f:SetBackdropColor(unpack(ns.colors.background))
    f:SetBackdropBorderColor(r, g, b, 0.8)
    local t = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOPLEFT", 14, -10)
    t:SetText(title)
    t:SetTextColor(r, g, b)
    local d = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -6)
    d:SetPoint("RIGHT", -100, 0)
    d:SetJustifyH("LEFT")
    d:SetText(desc)
    local done = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    done:SetSize(80, 22)
    done:SetPoint("RIGHT", -10, 0)
    done:SetText("Fertig")
    done:SetScript("OnClick", onDone)
    f.done = done
    f:Hide()
    return f
end

---------------------------------------------------------------------------
-- Spiel-Ereignisse
---------------------------------------------------------------------------
local events = CreateFrame("Frame")
local eventHandlers = {}

function ns.RegisterEvent(event, func)
    if not eventHandlers[event] then
        eventHandlers[event] = {}
        events:RegisterEvent(event)
    end
    table.insert(eventHandlers[event], func)
end

events:SetScript("OnEvent", function(_, event, ...)
    local list = eventHandlers[event]
    if not list then return end
    -- ein fehlerhafter Empfänger darf die anderen nicht abschneiden
    -- (sonst fehlen z. B. die Kampf-Schwerter, wenn ein Modul davor stolpert)
    for i = 1, #list do
        local ok, err = pcall(list[i], event, ...)
        if not ok then
            local h = geterrorhandler and geterrorhandler()
            if h then C_Timer.After(0, function() h(err) end) end
        end
    end
end)

ns.RegisterEvent("ADDON_LOADED", function(_, name)
    if name ~= ADDON then return end
    MondhainDB = MondhainDB or {}

    -- Umzug alter Einstellungen
    local v = MondhainDB.version or 0
    if v < 2 and MondhainDB.questTracker then
        MondhainDB.questTracker.width = nil -- v0.2.0 hatte 520 Breite gespeichert
    end
    if MondhainDB.actionBars and MondhainDB.actionBars.park and not MondhainDB.parkScaled then
        if not MondhainDB.actionBars.park.scale then MondhainDB.actionBars.park.scale = 0.8 end
        MondhainDB.parkScaled = true
    end
    if v < 3 then
        -- v0.10.0: Leiste 4/5 entfallen, Leiste 6 wird zur Parkleiste,
        -- der Gestalt-Balken wird durch die Gestaltleiste ersetzt
        if MondhainDB.formIndicator then MondhainDB.formIndicator.enabled = false end
        if MondhainDB.actionBars then
            MondhainDB.actionBars.bar4 = nil
            MondhainDB.actionBars.bar5 = nil
            MondhainDB.actionBars.bar6 = nil
        end
    end
    MondhainDB.version = 3

    -- v0.8.6: eigene Aktionstasten erzeugen unter den Midnight-Regeln Fehler
    -- (Abklingzeiten sind „geheime Werte“). Vorerst abschalten, Blizzard-Leisten zurück.
    if (MondhainDB.abVersion or 0) < 1 then
        MondhainDB.actionBars = MondhainDB.actionBars or {}
        MondhainDB.actionBars.enabled = false
        MondhainDB.actionBars.hideBlizzard = false
        MondhainDB.abVersion = 1
    end
    -- v0.9.0: eigene, Midnight-taugliche Tasten → wieder einschalten
    if MondhainDB.abVersion < 2 then
        MondhainDB.actionBars.enabled = true
        MondhainDB.actionBars.hideBlizzard = true
        MondhainDB.abVersion = 2
    end

    -- v0.13.0: Vorratsleiste wird selbst gebaut – automatisches Auffüllen einmalig aus
    if (MondhainDB.itemVersion or 0) < 1 and MondhainDB.itemBar and MondhainDB.itemBar.cats then
        for k in pairs(MondhainDB.itemBar.cats) do MondhainDB.itemBar.cats[k] = false end
    end
    MondhainDB.itemVersion = 1

    -- v0.19.2: Wurzelbett etwas höher (nur wenn noch der alte Standardwert drinsteht)
    if MondhainDB.root and MondhainDB.root.bedHeight == 210 then MondhainDB.root.bedHeight = 240 end

    -- v0.24.0: Nachtelfen-Grafiken – Ast ungefärbt, Stamm als Rinde
    if (MondhainDB.branchVersion or 0) < 1 then
        if MondhainDB.branch then
            MondhainDB.branch.tint = nil
            MondhainDB.branch.fillColor = nil
            MondhainDB.branch.fillAlpha = nil
        end
        MondhainDB.branchVersion = 1
    end
    -- v0.25.0: Ast schlanker, Schwung/Zauber schweben darüber
    if (MondhainDB.branchVersion or 0) < 2 then
        local b = MondhainDB.branch
        if b and (b.thickness == 22 or b.thickness == 34) then b.thickness = 28 end
        MondhainDB.branchVersion = 2
    end
    -- v0.26.0: Mahagoni statt Violett
    if (MondhainDB.branchVersion or 0) < 3 then
        if MondhainDB.branch then MondhainDB.branch.palette = "mahagoni" end
        MondhainDB.branchVersion = 3
    end
    -- v0.27.0: Irrlichter aus (passten nicht), Efeu statt leuchtender Blätter
    if (MondhainDB.branchVersion or 0) < 4 then
        if MondhainDB.branch then MondhainDB.branch.wisps = false end
        MondhainDB.branchVersion = 4
    end
    -- v0.34.4: Stärkungen über Blizzards eigene Leiste (Forever gibt sie im Kampf
    -- an Addons nicht heraus) – im Mondhain-Look an Mondhains Platz
    if (MondhainDB.auraVersion or 0) < 1 then
        if MondhainDB.auras then
            MondhainDB.auras.blizzardMode = true
            MondhainDB.auras.hideBlizzard = false
        end
        MondhainDB.auraVersion = 1
    end
    merge(MondhainDB, ns.defaults)
    ns.db = MondhainDB

    -- v0.10.1: einmalig die Grundaufstellung setzen (unten links Chat + Karte,
    -- Mitte Leisten, unten rechts Questtracker)
    -- v0.10.2: größere Karte, Parkleiste höher → Grundaufstellung erneut
    if (MondhainDB.layoutVersion or 0) < 2 and ns.ApplyDefaultLayout then
        if (MondhainDB.minimapFrame.size or 0) < 200 then MondhainDB.minimapFrame.size = 200 end
        ns.ApplyDefaultLayout()
        MondhainDB.layoutVersion = 2
    end
    -- v0.15.0: Einheitenfenster – Gestaltleiste unter den Spieler, über den Leisten
    -- zuerst Schwungtimer, darüber Zauberbalken (nur diese Plätze werden neu gesetzt)
    if (MondhainDB.layoutVersion or 0) < 4 and ns.CenterStackPoints then
        ns.CenterStackPoints(MondhainDB)
        MondhainDB.layoutVersion = 4
    end
    -- v0.10.3: Schwungtimer dazu – nur seine Plätze setzen, der Rest bleibt, wie du ihn hast
    if (MondhainDB.layoutVersion or 0) < 3 and ns.DefaultSwingPoints then
        if not (MondhainDB.blizz.swingMain and MondhainDB.blizz.swingMain.point) then
            ns.DefaultSwingPoints(MondhainDB)
        end
        MondhainDB.layoutVersion = 3
    end
    -- v0.16.0: Absteigen-Knopf neben Leiste 1 (nur dieser Platz)
    if (MondhainDB.layoutVersion or 0) < 5 and ns.DefaultLeavePoint then
        ns.DefaultLeavePoint(MondhainDB)
        MondhainDB.layoutVersion = 5
    end
    -- v0.19.0: Wurzel – Leisten ein Stück höher, damit die EP-Ranke darunter in der Mulde liegt
    if (MondhainDB.layoutVersion or 0) < 6 and ns.RootShift then
        ns.RootShift(MondhainDB)
        MondhainDB.layoutVersion = 6
    end
    -- v0.22.0: ruhige Mitte – Ranken in der Mitte aus (Bogen, Triebe, EP-Ranke),
    -- dafür Grund hinter den Leisten und EP-Balken; Schwung/Zauber stapeln sich darüber
    if (MondhainDB.layoutVersion or 0) < 7 then
        local r = MondhainDB.root
        r.arch, r.shoots, r.xp = false, false, false
        for _, k in ipairs({ "swingMain", "cast", "swingOff", "swingRanged" }) do
            if MondhainDB.blizz[k] then MondhainDB.blizz[k].free = nil end
        end
        MondhainDB.layoutVersion = 7
    end

    for _, mod in ipairs(ns.modules) do
        if mod.OnInitialize then xpcall(function() mod:OnInitialize() end, geterrorhandler()) end
    end
end)

ns.RegisterEvent("PLAYER_REGEN_DISABLED", function()
    if ns.db and not ns.db.locked then ns.SetUnlocked(false) end
end)

---------------------------------------------------------------------------
-- Blizzards Bearbeitungsmodus: Blizzard-Fenster, die Mondhain ersetzt, nicht
-- als Vorschau zeigen (sonst stehen Spieler/Ziel/Gruppe doppelt im Bild).
-- Mondhains eigene Teile verschiebt man mit /mh verschieben.
---------------------------------------------------------------------------
local function replacedFrames()
    local list = {}
    local d = ns.db
    if d.unitFrames.enabled and d.unitFrames.hideBlizzard ~= false then
        for _, n in ipairs({ "PlayerFrame", "TargetFrame", "TargetFrameToT", "PetFrame", "FocusFrame" }) do list[#list + 1] = n end
    end
    if d.groupFrames.enabled and d.groupFrames.hideBlizzard ~= false then
        for _, n in ipairs({ "PartyFrame", "CompactPartyFrame", "CompactRaidFrameContainer", "CompactRaidFrameManager" }) do list[#list + 1] = n end
    end
    if d.auras.enabled and d.auras.hideBlizzard ~= false then
        for _, n in ipairs({ "BuffFrame", "DebuffFrame" }) do list[#list + 1] = n end
    end
    return list
end
local function editModePreviews(hide)
    for _, n in ipairs(replacedFrames()) do
        local f = _G[n]
        if f and f.SetAlpha then pcall(f.SetAlpha, f, hide and 0 or 1) end
    end
end

-- Blizzards HUD-Bearbeitungsmodus wird in Forever erst später geladen (beim
-- Login gibt es EditModeManagerFrame noch nicht – darum griff bisher keiner
-- der Haken). Wer sich daran hängen will, meldet sich hier an und wird
-- aufgerufen, sobald das Fenster existiert.
local emWaiting, emWatch = {}, nil
local function emReady()
    local em = _G.EditModeManagerFrame
    if not (type(em) == "table" and em.HookScript) then return false end
    local list = emWaiting
    emWaiting = {}
    for _, fn in ipairs(list) do xpcall(fn, geterrorhandler(), em) end
    return true
end
function ns.OnEditMode(fn)
    local em = _G.EditModeManagerFrame
    if type(em) == "table" and em.HookScript then fn(em) return end
    emWaiting[#emWaiting + 1] = fn
    if emWatch then return end
    emWatch = CreateFrame("Frame")
    emWatch:RegisterEvent("ADDON_LOADED")
    emWatch:SetScript("OnEvent", function(self) if emReady() then self:UnregisterAllEvents() end end)
    -- Sicherheitsnetz, falls das Fenster ohne eigenes Laden entsteht
    local ticker
    ticker = C_Timer.NewTicker(1, function()
        if emReady() then ticker:Cancel(); emWatch:UnregisterAllEvents() end
    end)
end

ns.RegisterEvent("PLAYER_LOGIN", function()
    ns.OnEditMode(function(em)
        if em.mhPreviews then return end
        em.mhPreviews = true
        em:HookScript("OnShow", function() editModePreviews(true) end)
        em:HookScript("OnHide", function() editModePreviews(false) end)
        if em:IsShown() then editModePreviews(true) end
    end)
end)

ns.RegisterEvent("PLAYER_LOGIN", function()
    ns.db.locked = true
    -- Kein Andocken an Blizzards Bearbeitungsmodus mehr: dessen Rückrufe liefen
    -- sonst in Mondhain-Code und könnten Blizzards Kette „verschmutzen“.
    -- Verschieben läuft über Mondhains eigenen Modus (Minikarten-Knopf, /mh verschieben).
    for _, mod in ipairs(ns.modules) do
        -- Fehler in einem Modul melden, aber die anderen trotzdem starten
        if mod.OnEnable then xpcall(function() mod:OnEnable() end, geterrorhandler()) end
    end
    ns.Print("geladen. |cffffd100/mh|r für Optionen, |cffffd100/mh hilfe|r für Befehle.")
end)

---------------------------------------------------------------------------
-- Chatbefehle
---------------------------------------------------------------------------
-- Blizzards eingebauter Schadensmesser (Ben 25.11. 11:01: „zeigt nichts mehr an“).
-- Mondhain fasst ihn nirgends gezielt an; damit er nicht unter Ast/Stamm
-- (Hintergrund-Ebene) oder außerhalb des Bildes landet: prüfen und richten.
local function meterFrames()
    local list = {}
    for _, n in ipairs({ "DamageMeter" }) do
        if _G[n] then list[#list + 1] = { n, _G[n] } end
    end
    for i = 1, 6 do
        local n = "DamageMeterSessionWindow" .. i
        if _G[n] then list[#list + 1] = { n, _G[n] } end
    end
    return list
end
function ns.DamageMeterCheck(verbose)
    local say = verbose and ns.Print or function() end
    if C_DamageMeter and C_DamageMeter.IsDamageMeterAvailable then
        local ok, avail, why = pcall(C_DamageMeter.IsDamageMeterAvailable)
        if ok then
            say(("Schadensmesser: Daten %s%s"):format(avail and "|cff7fff7fverfügbar|r" or "|cffff5555nicht verfügbar|r",
                (why and why ~= "") and (" – " .. tostring(why)) or ""))
        end
    else
        say("Schadensmesser: keine Schnittstelle C_DamageMeter in diesem Client")
    end
    if C_DamageMeter and C_DamageMeter.GetAvailableCombatSessions then
        local ok, list = pcall(C_DamageMeter.GetAvailableCombatSessions)
        if ok then say(("  Kampfabschnitte gespeichert: %s"):format(type(list) == "table" and #list or tostring(list))) end
    end
    if GetCVar then
        for _, cv in ipairs({ "damageMeterEnabled", "showDamageMeter" }) do
            local ok, v = pcall(GetCVar, cv)
            if ok and v ~= nil then say(("  Einstellung %s = %s"):format(cv, tostring(v))) end
        end
    end
    local list = meterFrames()
    if #list == 0 then
        say("  Kein Fenster gefunden – im Spiel unter Optionen den Schadensmesser einschalten.")
        return
    end
    local W, H = UIParent:GetWidth(), UIParent:GetHeight()
    for _, it in ipairs(list) do
        local n, f = it[1], it[2]
        if not (f.IsForbidden and f:IsForbidden()) then
            local p = f:GetParent()
            local pn = p and (p.GetName and p:GetName() or "?") or "–"
            local l, b = f:GetLeft(), f:GetBottom()
            -- Inhalt: sichtbare Kinder (Balkenbereich) zählen
            local kids, shownKids = 0, 0
            for _, c in ipairs({ f:GetChildren() }) do
                kids = kids + 1
                if c:IsShown() then shownKids = shownKids + 1 end
            end
            say(("  %s: %s, Alpha %.2f, Ebene %s/%d, Eltern %s, Lage %s, Größe %dx%d, Teile %d/%d sichtbar"):format(n,
                f:IsShown() and (f:IsVisible() and "sichtbar" or "an, aber Eltern aus") or "aus",
                f:GetAlpha(), f:GetFrameStrata(), f:GetFrameLevel(), pn,
                l and ("%d,%d"):format(l, b) or "?", f:GetWidth() or 0, f:GetHeight() or 0, shownKids, kids))
            if not InCombatLockdown() then
                -- nicht unter Mondhains Hintergrund-Ebene
                if f:GetFrameStrata() == "BACKGROUND" then f:SetFrameStrata("LOW") end
                if f:GetAlpha() < 0.05 then f:SetAlpha(1) end
                if p and p ~= UIParent and not p:IsVisible() and n == "DamageMeter" then f:SetParent(UIParent) end
                -- außerhalb des Bildes: zurück an den rechten Rand
                if l and b and (l > W - 20 or b > H - 20 or l + f:GetWidth() < 20 or b + f:GetHeight() < 20) then
                    f:ClearAllPoints()
                    f:SetPoint("RIGHT", UIParent, "RIGHT", -40, 0)
                    say("    → war außerhalb des Bildes, zurückgeholt")
                end
            end
        end
    end
end
-- leise beim Einloggen und wenn Blizzard den Messer lädt
do
    local mf = CreateFrame("Frame")
    mf:RegisterEvent("PLAYER_ENTERING_WORLD")
    mf:RegisterEvent("ADDON_LOADED")
    mf:SetScript("OnEvent", function(_, e, name)
        if e == "ADDON_LOADED" and name ~= "Blizzard_DamageMeter" then return end
        C_Timer.After(2, function() pcall(ns.DamageMeterCheck, false) end)
    end)
end

SLASH_MONDHAIN1 = "/mh"
SLASH_MONDHAIN2 = "/mondhain"

SlashCmdList.MONDHAIN = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")

    if msg == "unlock" or msg == "verschieben" then
        ns.SetUnlocked(true)
    elseif msg == "lock" then
        ns.SetUnlocked(false)
    elseif msg == "rahmen" then
        if ns.DebugFrames then ns.DebugFrames() end
    elseif msg == "maus" then
        -- Zeigt, welcher Rahmen unter der Maus liegt (mit seinen Eltern)
        local foci = GetMouseFoci and GetMouseFoci() or { GetMouseFocus and GetMouseFocus() }
        if not foci or not foci[1] then
            ns.Print("Unter der Maus liegt kein Rahmen.")
        end
        for _, f in ipairs(foci or {}) do
            local chain, cur, depth = {}, f, 0
            while cur and cur ~= UIParent and depth < 8 do
                chain[#chain + 1] = cur:GetName() or ("(ohne Namen: " .. (cur:GetObjectType() or "?") .. ")")
                cur = cur:GetParent()
                depth = depth + 1
            end
            ns.Print("Unter der Maus: |cffffd100" .. table.concat(chain, "  <  ") .. "|r")
        end
    elseif msg == "reset" then
        MondhainDB = nil
        ReloadUI()
    elseif msg == "levelup" or msg == "stufe" then
        if ns.LevelUp and ns.LevelUp.Play then ns.LevelUp:Play() else ns.Print("Stufenanzeige ist aus.") end
    elseif msg == "questgruppe" then
        if ns.DebugQuestParty then ns.DebugQuestParty() end
    elseif msg == "quests" then
        if ns.DebugQuests then ns.DebugQuests() end
    elseif msg:match("^suche") then
        local what = msg:match("^suche%s+(.+)$")
        if what then ns.FindFrames(what) else ns.Print("Beispiel: /mh suche waffenhand") end
    elseif msg == "knöpfe" or msg == "knoepfe" then
        if ns.ButtonBag then ns.ButtonBag:Debug() end
    elseif msg == "test" or msg == "test gruppe" then
        if ns.GroupFrames then ns.GroupFrames:SetTest("party", not ns.GroupFrames:IsTest("party")) end
    elseif msg == "test auren" or msg == "test buffs" then
        if ns.PlayerAuras then ns.PlayerAuras:SetTest(not ns.PlayerAuras:IsTest()) end
    elseif msg == "test raid" or msg == "test schlachtzug" then
        if ns.GroupFrames then ns.GroupFrames:SetTest("raid", not ns.GroupFrames:IsTest("raid")) end
    elseif msg == "mouseover" then
        if ns.ActionBars then ns.ActionBars:SetMouseoverMode(true) end
    elseif msg == "chatreiter" then
        if ns.Chat then ns.Chat:SetupTabs() end
    elseif msg == "beute" then
        if ns.Loot then ns.Loot:List() end
    elseif msg == "buffs" then
        if ns.PlayerAuras and ns.PlayerAuras.Diagnose then ns.PlayerAuras:Diagnose() end
    elseif msg == "charakter" then
        ns.db.character.enabled = not (ns.db.character.enabled ~= false)
        ns.Print("Charakterfenster im Mondhain-Look " .. (ns.db.character.enabled and "|cff33ff33an|r" or "|cffff5555aus|r") .. " – wirkt nach /reload.")
    elseif msg == "fenster" then
        if ns.Windows then ns.Windows:Reset() end
    elseif msg == "hud" or msg == "hud an" or msg == "hud ein" or msg == "hud aus" then
        if ns.ToggleEditModeFit then
            local want                       -- nil = umschalten
            if msg == "hud aus" then want = false elseif msg ~= "hud" then want = true end
            ns.ToggleEditModeFit(want)
        end
    elseif msg == "medaillon" then
        if ns.Branch and ns.Branch.ResetMedal then ns.Branch:ResetMedal() end
    elseif msg == "levelup" or msg == "stufe" then
        if ns.LevelUp then ns.LevelUp:Play(UnitLevel("player")) end
    elseif msg == "meter" then
        ns.DamageMeterCheck(true)
    elseif msg == "ziel" then
        local st = ns.UnitFrames and ns.UnitFrames.TargetAuraStats and ns.UnitFrames:TargetAuraStats() or {}
        local tf = _G.TargetFrame
        local c = ns.db.unitFrames.targetAuras or {}
        ns.Print(("Ziel-Auren aus Blizzards Zielfenster: %s gefunden, %s sichtbar, %s angeordnet · Pools: %s · klassisch: %s"):format(
            tostring(st.found or "–"), tostring(st.shown or "–"), tostring(st.placed or "–"),
            tostring(tf and tf.auraPools ~= nil), tostring(_G.TargetFrameBuff1 ~= nil or _G.TargetFrameDebuff1 ~= nil)))
        ns.Print(("Eigener Weg: %s (%s gezeigt) · Filter: Schwächungen %s, nur meine %s, Stärkungen %s, bannbar %s%s"):format(
            st.own and "an" or "aus", tostring(st.ownShown or "–"), tostring(c.debuffs ~= false), tostring(c.onlyMine == true),
            tostring(c.buffs ~= false), tostring(c.enemyDispel == true), st.err and (" · Fehler: " .. st.err) or ""))
    elseif msg == "hud info" then
        if ns.EditModeFitInfo then ns.EditModeFitInfo() end
    elseif msg == "ast" then
        if ns.Branch then ns.Branch:Debug() end
    elseif msg == "gestalten" then
        if ns.StanceBar then ns.StanceBar:Debug() end
    elseif msg == "gestalten tafel" then
        if ns.StanceBar then ns.StanceBar:BackToBoard() end
    elseif msg == "grundaufstellung" then
        if InCombatLockdown() then ns.Print("Im Kampf nicht möglich.") return end
        ns.ApplyDefaultLayout()
        ReloadUI()
    elseif msg == "form" then
        local id, key = ns.GetForm()
        local page = ns.ActionBars and select(2, ns.ActionBars:CurrentPage()) or "?"
        ns.Print(("Gestalt-ID: %s  →  %s   |  Leistenseite: %s"):format(tostring(id), key, page))
    elseif msg == "wandel" then
        if ns.ActionBars then ns.ActionBars:SetWandelMode(not ns.ActionBars:IsWandelMode()) end
    elseif msg == "vorrat" then
        if ns.ItemBar then ns.ItemBar:SetEditMode(not ns.ItemBar:IsEditMode()) end
    elseif msg == "tasten" then
        if ns.KeyBind then ns.KeyBind:SetActive(true) end
    elseif msg == "" then
        if ns.ToggleOptions then ns.ToggleOptions() end
    else
        ns.Print("Befehle:")
        print("  |cffffd100/mh|r – Optionen öffnen")
        print("  |cffffd100/mh wandel|r – Wandeltasten festlegen (an/aus)")
        print("  |cffffd100/mh vorrat|r – Vorratsleiste bearbeiten (an/aus)")
        print("  |cffffd100/mh test|r · |cffffd100/mh test raid|r – Gruppe / Schlachtzug zum Einrichten anzeigen")
        print("  |cffffd100/mh mouseover|r – Heilzauber per Mouseover festlegen (je Gestalt)")
        print("  |cffffd100/mh tasten|r – Tasten belegen (auch Strg/Alt/Shift, Maustasten, Mausrad)")
        print("  |cffffd100/mh chatreiter|r – Reiter Allgemein · Kampflog · Handel einrichten")
        print("  |cffffd100/mh verschieben|r – alles verschieben und skalieren")
        print("  |cffffd100/mh lock|r – Elemente festsetzen")
        print("  |cffffd100/mh fenster|r – Blizzard-Fenster wieder an ihren Standardplatz")
        print("  |cffffd100/mh medaillon|r – Zauber-Medaillon zurück an die Gabelung")
        print("  |cffffd100/mh ziel|r – Ziel-Auren: was Mondhain von Blizzards Zielfenster übernimmt")
        print("  |cffffd100/mh meter|r – Blizzards Schadensmesser prüfen und wieder sichtbar machen")
        print("  |cffffd100/mh hud an|r / |cffffd100aus|r – HUD-Bearbeitungsmodus: Fensterhöhe anpassen · |cffffd100/mh hud info|r – Messung anzeigen")
        print("  |cffffd100/mh charakter|r – Charakterfenster im Mondhain-Look an/aus")
        print("  |cffffd100/mh beute|r – letzte gute Beute mit Herkunft")
        print("  |cffffd100/mh quests|r – zeigt, welche Quests der Tracker erkennt (Test)")
        print("  |cffffd100/mh suche <text>|r – Rahmen mit diesem Text oder Namen finden (Test)")
        print("  |cffffd100/mh knöpfe|r – welche Kartenknöpfe gefunden wurden (Test)")
        print("  |cffffd100/mh maus|r – Name des Rahmens unter der Maus (Test)")
        print("  |cffffd100/mh rahmen|r – zeigt, welche Blizzard-Teile gefunden wurden (Test)")
        print("  |cffffd100/mh grundaufstellung|r – alles auf die Grundaufstellung setzen (lädt neu)")
        print("  |cffffd100/mh form|r – aktuelle Gestalt anzeigen (Test)")
        print("  |cffffd100/mh gestalten|r – was die Gestaltleiste findet (Test)")
        print("  |cffffd100/mh gestalten tafel|r – Gestaltleiste zurück in die rechte Tafel")
        print("  |cffffd100/mh reset|r – alle Einstellungen zurücksetzen")
    end
end
