-- Mondhain – Gestalten und Farbpalette
-- Erkennt die Druidengestalt und meldet Wechsel als "FORM_CHANGED".

local _, ns = ...

---------------------------------------------------------------------------
-- Farbpalette je Gestalt (r, g, b von 0 bis 1)
---------------------------------------------------------------------------
ns.palette = {
    caster  = { 1.00, 0.49, 0.04, name = "Normalgestalt" }, -- Druidenorange
    bear    = { 0.62, 0.27, 0.16, name = "Bärengestalt" },  -- erdiges Rotbraun
    cat     = { 0.95, 0.78, 0.25, name = "Katzengestalt" }, -- Gold
    travel  = { 0.35, 0.72, 0.38, name = "Reisegestalt" },  -- Waldgrün
    aquatic = { 0.25, 0.62, 0.80, name = "Wassergestalt" }, -- Seeblau
    moonkin = { 0.58, 0.45, 0.92, name = "Mondkingestalt" },-- Mondviolett
    tree    = { 0.45, 0.80, 0.30, name = "Baumgestalt" },   -- Lebensgrün
    flight  = { 0.75, 0.85, 0.95, name = "Fluggestalt" },   -- Himmelsgrau
}

-- Hintergrund- und Rahmenfarben für alle Elemente
ns.colors = {
    background = { 0.05, 0.06, 0.08, 0.85 }, -- Nachtschwarz
    border     = { 0.20, 0.17, 0.13, 1.00 }, -- dunkles Holz
    text       = { 0.92, 0.90, 0.84 },       -- Pergament
}

---------------------------------------------------------------------------
-- Gestalt-IDs → Schlüssel der Palette
-- Unbekannte IDs landen bei "caster". Mit /mh form kannst du im Spiel
-- nachsehen, welche ID Forever für eine Gestalt meldet.
---------------------------------------------------------------------------
local FORM_KEYS = {
    [1]  = "cat",
    [2]  = "tree",
    [3]  = "travel",
    [4]  = "aquatic",
    [5]  = "bear",
    [8]  = "bear",    -- Terrorbär (alte ID)
    [27] = "flight",
    [29] = "flight",
    [31] = "moonkin",
    [35] = "moonkin",
    [36] = "tree",
}

function ns.GetForm()
    local id = GetShapeshiftFormID()
    local key = (id and FORM_KEYS[id]) or "caster"
    return id, key
end

function ns.GetFormColor(key)
    local c = ns.palette[key or select(2, ns.GetForm())] or ns.palette.caster
    return c[1], c[2], c[3]
end

local currentKey

local function update()
    local _, key = ns.GetForm()
    if key ~= currentKey then
        currentKey = key
        ns.Fire("FORM_CHANGED", key)
    end
end

ns.RegisterEvent("PLAYER_ENTERING_WORLD", update)
ns.RegisterEvent("UPDATE_SHAPESHIFT_FORM", update)
